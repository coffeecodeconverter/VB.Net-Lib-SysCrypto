﻿Imports System.Text

Public Class FormCommonRows
    Private Sub FormCommonRows_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Set the tab header size to 1x1 to make the tabs invisible
        TabControl_CommonRows.ItemSize = New Size(1, 1)

        ' Set each tab's text to an empty string to remove the labels
        For Each tab As TabPage In TabControl_CommonRows.TabPages
            tab.Text = ""
        Next



        ' Temporarily remove the event handlers
        RemoveHandler CheckBox_CommonRows_Data_LicenseKey.CheckedChanged, AddressOf CheckBox_CommonRows_Data_LicenseKey_CheckedChanged
        RemoveHandler CheckBox_CommonRows_Data_Product.CheckedChanged, AddressOf CheckBox_CommonRows_Data_Product_CheckedChanged
        RemoveHandler CheckBox_CommonRows_Data_LicenseCount.CheckedChanged, AddressOf CheckBox_CommonRows_Data_LicenseCount_CheckedChanged
        RemoveHandler CheckBox_CommonRows_Data_LicensesUsed.CheckedChanged, AddressOf CheckBox_CommonRows_Data_LicensesUsed_CheckedChanged
        RemoveHandler CheckBox_CommonRows_Data_LicensesRemaining.CheckedChanged, AddressOf CheckBox_CommonRows_Data_LicensesRemaining_CheckedChanged
        RemoveHandler CheckBox_CommonRows_Data_Licensee.CheckedChanged, AddressOf CheckBox_CommonRows_Data_Licensee_CheckedChanged
        RemoveHandler CheckBox_CommonRows_Data_Email.CheckedChanged, AddressOf CheckBox_CommonRows_Data_Email_CheckedChanged
        RemoveHandler CheckBox_CommonRows_Data_Address.CheckedChanged, AddressOf CheckBox_CommonRows_Data_Address_CheckedChanged
        RemoveHandler CheckBox_CommonRows_Data_Modules.CheckedChanged, AddressOf CheckBox_CommonRows_Data_Modules_CheckedChanged
        RemoveHandler CheckBox_CommonRows_Data_Features.CheckedChanged, AddressOf CheckBox_CommonRows_Data_Features_CheckedChanged
        RemoveHandler CheckBox_CommonRows_Data_Type.CheckedChanged, AddressOf CheckBox_CommonRows_Data_Type_CheckedChanged
        RemoveHandler CheckBox_CommonRows_Data_Terminal.CheckedChanged, AddressOf CheckBox_CommonRows_Data_Terminal_CheckedChanged
        RemoveHandler CheckBox_CommonRows_Data_Branch.CheckedChanged, AddressOf CheckBox_CommonRows_Data_Branch_CheckedChanged
        RemoveHandler CheckBox_CommonRows_Data_IssuedDate.CheckedChanged, AddressOf CheckBox_CommonRows_Data_IssuedDate_CheckedChanged
        RemoveHandler CheckBox_CommonRows_Data_ExpiryDate.CheckedChanged, AddressOf CheckBox_CommonRows_Data_ExpiryDate_CheckedChanged
        RemoveHandler CheckBox_CommonRows_Data_HardDriveFingerprints.CheckedChanged, AddressOf CheckBox_CommonRows_Data_HardDriveFingerprints_CheckedChanged
        RemoveHandler CheckBox_CommonRows_Data_ComputerFingerprints.CheckedChanged, AddressOf CheckBox_CommonRows_Data_ComputerFingerprints_CheckedChanged



        ' Make your changes (set all checkboxes to unchecked)
        CheckBox_CommonRows_Data_LicenseKey.Checked = False
        CheckBox_CommonRows_Data_Product.Checked = False
        CheckBox_CommonRows_Data_LicenseCount.Checked = False
        CheckBox_CommonRows_Data_LicensesUsed.Checked = False
        CheckBox_CommonRows_Data_LicensesRemaining.Checked = False
        CheckBox_CommonRows_Data_Licensee.Checked = False
        CheckBox_CommonRows_Data_Email.Checked = False
        CheckBox_CommonRows_Data_Address.Checked = False
        CheckBox_CommonRows_Data_Modules.Checked = False
        CheckBox_CommonRows_Data_Features.Checked = False
        CheckBox_CommonRows_Data_Type.Checked = False
        CheckBox_CommonRows_Data_Terminal.Checked = False
        CheckBox_CommonRows_Data_Branch.Checked = False
        CheckBox_CommonRows_Data_IssuedDate.Checked = False
        CheckBox_CommonRows_Data_ExpiryDate.Checked = False
        CheckBox_CommonRows_Data_HardDriveFingerprints.Checked = False
        CheckBox_CommonRows_Data_ComputerFingerprints.Checked = False

        ' Re-add the event handlers
        AddHandler CheckBox_CommonRows_Data_LicenseKey.CheckedChanged, AddressOf CheckBox_CommonRows_Data_LicenseKey_CheckedChanged
        AddHandler CheckBox_CommonRows_Data_Product.CheckedChanged, AddressOf CheckBox_CommonRows_Data_Product_CheckedChanged
        AddHandler CheckBox_CommonRows_Data_LicenseCount.CheckedChanged, AddressOf CheckBox_CommonRows_Data_LicenseCount_CheckedChanged
        AddHandler CheckBox_CommonRows_Data_LicensesUsed.CheckedChanged, AddressOf CheckBox_CommonRows_Data_LicensesUsed_CheckedChanged
        AddHandler CheckBox_CommonRows_Data_LicensesRemaining.CheckedChanged, AddressOf CheckBox_CommonRows_Data_LicensesRemaining_CheckedChanged
        AddHandler CheckBox_CommonRows_Data_Licensee.CheckedChanged, AddressOf CheckBox_CommonRows_Data_Licensee_CheckedChanged
        AddHandler CheckBox_CommonRows_Data_Email.CheckedChanged, AddressOf CheckBox_CommonRows_Data_Email_CheckedChanged
        AddHandler CheckBox_CommonRows_Data_Address.CheckedChanged, AddressOf CheckBox_CommonRows_Data_Address_CheckedChanged
        AddHandler CheckBox_CommonRows_Data_Modules.CheckedChanged, AddressOf CheckBox_CommonRows_Data_Modules_CheckedChanged
        AddHandler CheckBox_CommonRows_Data_Features.CheckedChanged, AddressOf CheckBox_CommonRows_Data_Features_CheckedChanged
        AddHandler CheckBox_CommonRows_Data_Type.CheckedChanged, AddressOf CheckBox_CommonRows_Data_Type_CheckedChanged
        AddHandler CheckBox_CommonRows_Data_Terminal.CheckedChanged, AddressOf CheckBox_CommonRows_Data_Terminal_CheckedChanged
        AddHandler CheckBox_CommonRows_Data_Branch.CheckedChanged, AddressOf CheckBox_CommonRows_Data_Branch_CheckedChanged
        AddHandler CheckBox_CommonRows_Data_IssuedDate.CheckedChanged, AddressOf CheckBox_CommonRows_Data_IssuedDate_CheckedChanged
        AddHandler CheckBox_CommonRows_Data_ExpiryDate.CheckedChanged, AddressOf CheckBox_CommonRows_Data_ExpiryDate_CheckedChanged
        AddHandler CheckBox_CommonRows_Data_HardDriveFingerprints.CheckedChanged, AddressOf CheckBox_CommonRows_Data_HardDriveFingerprints_CheckedChanged
        AddHandler CheckBox_CommonRows_Data_ComputerFingerprints.CheckedChanged, AddressOf CheckBox_CommonRows_Data_ComputerFingerprints_CheckedChanged





        ' Temporarily remove the event handlers
        RemoveHandler CheckBox_CommonRows_Signature_KeySize.CheckedChanged, AddressOf CheckBox_CommonRows_Signature_KeySize_CheckedChanged
        RemoveHandler CheckBox_CommonRows_Signature_Algorithm.CheckedChanged, AddressOf CheckBox_CommonRows_Signature_Algorithm_CheckedChanged
        RemoveHandler CheckBox_CommonRows_Signature_PublicKeyFingerprint.CheckedChanged, AddressOf CheckBox_CommonRows_Signature_PublicKeyFingerprint_CheckedChanged
        RemoveHandler CheckBox_CommonRows_Signature_AddSignatureRow.CheckedChanged, AddressOf CheckBox_CommonRows_Signature_AddSignatureRow_CheckedChanged
        RemoveHandler CheckBox_CommonRows_Signature_Salt.CheckedChanged, AddressOf CheckBox_CommonRows_Signature_Salt_CheckedChanged

        ' Make your changes
        CheckBox_CommonRows_Signature_KeySize.Checked = False
        CheckBox_CommonRows_Signature_Algorithm.Checked = False
        CheckBox_CommonRows_Signature_PublicKeyFingerprint.Checked = False
        CheckBox_CommonRows_Signature_AddSignatureRow.Checked = False
        CheckBox_CommonRows_Signature_Salt.Checked = False

        ' Re-add the event handlers
        AddHandler CheckBox_CommonRows_Signature_KeySize.CheckedChanged, AddressOf CheckBox_CommonRows_Signature_KeySize_CheckedChanged
        AddHandler CheckBox_CommonRows_Signature_Algorithm.CheckedChanged, AddressOf CheckBox_CommonRows_Signature_Algorithm_CheckedChanged
        AddHandler CheckBox_CommonRows_Signature_PublicKeyFingerprint.CheckedChanged, AddressOf CheckBox_CommonRows_Signature_PublicKeyFingerprint_CheckedChanged
        AddHandler CheckBox_CommonRows_Signature_AddSignatureRow.CheckedChanged, AddressOf CheckBox_CommonRows_Signature_AddSignatureRow_CheckedChanged
        AddHandler CheckBox_CommonRows_Signature_Salt.CheckedChanged, AddressOf CheckBox_CommonRows_Signature_Salt_CheckedChanged


    End Sub



    Private Sub CheckBox_CommonRows_Signature_KeySize_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_CommonRows_Signature_KeySize.CheckedChanged
        If CheckBox_CommonRows_Signature_KeySize.Checked = True Then
            Form1.removeRowByKey("key_size", Form1.DataGridView_License_Lic_Signature)
            Dim rowsValue As String = ""
            If String.IsNullOrEmpty(Form1.TextBox_License_Lic_KeySize.Text) = True Then
                rowsValue = "INSERT_HERE"
            Else
                rowsValue = Form1.TextBox_License_Lic_KeySize.Text
            End If

            Form1.addDistinctRow("key_size", rowsValue, Form1.DataGridView_License_Lic_Signature)
        Else
            Form1.removeRowByKey("key_size", Form1.DataGridView_License_Lic_Signature)
        End If
    End Sub


    Private Sub CheckBox_CommonRows_Signature_Algorithm_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_CommonRows_Signature_Algorithm.CheckedChanged
        If CheckBox_CommonRows_Signature_Algorithm.Checked = True Then
            Form1.addDistinctRow("algorithm", "SHA256RSA", Form1.DataGridView_License_Lic_Signature)
        Else
            Form1.removeRowByKey("algorithm", Form1.DataGridView_License_Lic_Signature)
        End If
    End Sub


    Private Sub CheckBox_CommonRows_Signature_PublicKeyFingerprint_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_CommonRows_Signature_PublicKeyFingerprint.CheckedChanged
        'If CheckBox_CommonRows_Signature_PublicKeyFingerprint.Checked = True Then
        '    Form1.addDistinctRow("publickey_fingerprint", "INSERT_HERE", Form1.DataGridView_License_Lic_Signature)
        'Else
        '    Form1.removeRowByKey("publickey_fingerprint", Form1.DataGridView_License_Lic_Signature)
        'End If


        Form1.removeRowByKey("publickey_fingerprint", Form1.DataGridView_License_Lic_Signature)
        Dim rowsValue As String = ""
        If String.IsNullOrEmpty(Form1.TextBox_License_Lic_HashPublicKey.Text) = True Then
            rowsValue = "INSERT_HERE"
        Else
            rowsValue = Form1.TextBox_License_Lic_HashPublicKey.Text
        End If
        Form1.addDistinctRow("publickey_fingerprint", rowsValue, Form1.DataGridView_License_Lic_Signature)


        If CheckBox_CommonRows_Signature_PublicKeyFingerprint.Checked = False Then
            '    Form1.addDistinctRow(Form1.TextBox_License_Lic_Verify_SignatureNodeName.Text, "INSERT_HERE", Form1.DataGridView_License_Lic_Signature)
            'Else
            Form1.removeRowByKey("publickey_fingerprint", Form1.DataGridView_License_Lic_Signature)
        End If


    End Sub



    Private Sub CheckBox_CommonRows_Data_LicenseKey_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_CommonRows_Data_LicenseKey.CheckedChanged
        If CheckBox_CommonRows_Data_LicenseKey.Checked = True Then
            Form1.addDistinctRow("license_key", "INSERT_HERE", Form1.DataGridView_License_Lic_Data)
        Else
            Form1.removeRowByKey("license_key", Form1.DataGridView_License_Lic_Data)
        End If
    End Sub

    Private Sub CheckBox_CommonRows_Data_Product_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_CommonRows_Data_Product.CheckedChanged
        If CheckBox_CommonRows_Data_Product.Checked = True Then
            Form1.addDistinctRow("product", "INSERT_HERE", Form1.DataGridView_License_Lic_Data)
        Else
            Form1.removeRowByKey("product", Form1.DataGridView_License_Lic_Data)
        End If
    End Sub

    Private Sub CheckBox_CommonRows_Data_LicenseCount_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_CommonRows_Data_LicenseCount.CheckedChanged
        If CheckBox_CommonRows_Data_LicenseCount.Checked = True Then
            Form1.addDistinctRow("license_count", "INSERT_HERE", Form1.DataGridView_License_Lic_Data)
        Else
            Form1.removeRowByKey("license_count", Form1.DataGridView_License_Lic_Data)
        End If
    End Sub

    Private Sub CheckBox_CommonRows_Data_LicensesUsed_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_CommonRows_Data_LicensesUsed.CheckedChanged
        If CheckBox_CommonRows_Data_LicensesUsed.Checked = True Then
            Form1.addDistinctRow("licenses_used", "INSERT_HERE", Form1.DataGridView_License_Lic_Data)
        Else
            Form1.removeRowByKey("licenses_used", Form1.DataGridView_License_Lic_Data)
        End If
    End Sub

    Private Sub CheckBox_CommonRows_Data_LicensesRemaining_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_CommonRows_Data_LicensesRemaining.CheckedChanged
        If CheckBox_CommonRows_Data_LicensesRemaining.Checked = True Then
            Form1.addDistinctRow("licenses_remaining", "INSERT_HERE", Form1.DataGridView_License_Lic_Data)
        Else
            Form1.removeRowByKey("licenses_remaining", Form1.DataGridView_License_Lic_Data)
        End If
    End Sub

    Private Sub CheckBox_CommonRows_Data_Licensee_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_CommonRows_Data_Licensee.CheckedChanged
        If CheckBox_CommonRows_Data_Licensee.Checked = True Then
            Form1.addDistinctRow("licensed_to", "INSERT_HERE", Form1.DataGridView_License_Lic_Data)
        Else
            Form1.removeRowByKey("licensed_to", Form1.DataGridView_License_Lic_Data)
        End If
    End Sub

    Private Sub CheckBox_CommonRows_Data_Email_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_CommonRows_Data_Email.CheckedChanged
        If CheckBox_CommonRows_Data_Email.Checked = True Then
            Form1.addDistinctRow("email", "INSERT_HERE", Form1.DataGridView_License_Lic_Data)
        Else
            Form1.removeRowByKey("email", Form1.DataGridView_License_Lic_Data)
        End If
    End Sub

    Private Sub CheckBox_CommonRows_Data_Address_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_CommonRows_Data_Address.CheckedChanged
        If CheckBox_CommonRows_Data_Address.Checked = True Then
            Form1.addDistinctRow("address", "INSERT_HERE", Form1.DataGridView_License_Lic_Data)
        Else
            Form1.removeRowByKey("address", Form1.DataGridView_License_Lic_Data)
        End If
    End Sub

    Private Sub CheckBox_CommonRows_Data_Modules_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_CommonRows_Data_Modules.CheckedChanged
        If CheckBox_CommonRows_Data_Modules.Checked = True Then
            Form1.addDistinctRow("modules", "INSERT_HERE", Form1.DataGridView_License_Lic_Data)
        Else
            Form1.removeRowByKey("modules", Form1.DataGridView_License_Lic_Data)
        End If
    End Sub

    Private Sub CheckBox_CommonRows_Data_Features_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_CommonRows_Data_Features.CheckedChanged
        If CheckBox_CommonRows_Data_Features.Checked = True Then
            Form1.addDistinctRow("features", "INSERT_HERE", Form1.DataGridView_License_Lic_Data)
        Else
            Form1.removeRowByKey("features", Form1.DataGridView_License_Lic_Data)
        End If
    End Sub

    Private Sub CheckBox_CommonRows_Data_Type_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_CommonRows_Data_Type.CheckedChanged
        If CheckBox_CommonRows_Data_Type.Checked = True Then
            Form1.addDistinctRow("license_type", "INSERT_HERE", Form1.DataGridView_License_Lic_Data)
        Else
            Form1.removeRowByKey("license_type", Form1.DataGridView_License_Lic_Data)
        End If
    End Sub

    Private Sub CheckBox_CommonRows_Data_Terminal_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_CommonRows_Data_Terminal.CheckedChanged
        If CheckBox_CommonRows_Data_Terminal.Checked = True Then
            Form1.addDistinctRow("terminal", "INSERT_HERE", Form1.DataGridView_License_Lic_Data)
        Else
            Form1.removeRowByKey("terminal", Form1.DataGridView_License_Lic_Data)
        End If
    End Sub

    Private Sub CheckBox_CommonRows_Data_Branch_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_CommonRows_Data_Branch.CheckedChanged
        If CheckBox_CommonRows_Data_Branch.Checked = True Then
            Form1.addDistinctRow("branch", "INSERT_HERE", Form1.DataGridView_License_Lic_Data)
        Else
            Form1.removeRowByKey("branch", Form1.DataGridView_License_Lic_Data)
        End If
    End Sub

    Private Sub CheckBox_CommonRows_Data_IssuedDate_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_CommonRows_Data_IssuedDate.CheckedChanged
        If CheckBox_CommonRows_Data_IssuedDate.Checked = True Then
            Form1.addDistinctRow("date_issued", "INSERT_HERE", Form1.DataGridView_License_Lic_Data)
        Else
            Form1.removeRowByKey("date_issued", Form1.DataGridView_License_Lic_Data)
        End If
    End Sub

    Private Sub CheckBox_CommonRows_Data_ExpiryDate_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_CommonRows_Data_ExpiryDate.CheckedChanged
        If CheckBox_CommonRows_Data_ExpiryDate.Checked = True Then
            Form1.addDistinctRow("date_expiry", "INSERT_HERE", Form1.DataGridView_License_Lic_Data)
        Else
            Form1.removeRowByKey("date_expiry", Form1.DataGridView_License_Lic_Data)
        End If
    End Sub

    Private Sub CheckBox_CommonRows_Data_All_CheckedChanged(sender As Object, e As EventArgs)

    End Sub


    Private Sub CheckBox_CommonRows_Data_Noner_CheckedChanged(sender As Object, e As EventArgs)

    End Sub


    Sub CheckAllCheckboxes(flowLayoutPanel As FlowLayoutPanel)
        For Each control As Control In flowLayoutPanel.Controls
            If TypeOf control Is CheckBox Then
                Dim chkBox As CheckBox = CType(control, CheckBox)
                chkBox.Checked = True
            End If
        Next
    End Sub

    Sub UncheckAllCheckboxes(flowLayoutPanel As FlowLayoutPanel)
        For Each control As Control In flowLayoutPanel.Controls
            If TypeOf control Is CheckBox Then
                Dim chkBox As CheckBox = CType(control, CheckBox)
                chkBox.Checked = False
            End If
        Next
    End Sub


    Private Sub Button_CommonRows_Signature_All_Click(sender As Object, e As EventArgs) Handles Button_CommonRows_Signature_All.Click
        CheckAllCheckboxes(FlowLayoutPanel_Signature_CommonRows)
    End Sub

    Private Sub Button_CommonRows_Signature_None_Click(sender As Object, e As EventArgs) Handles Button_CommonRows_Signature_None.Click
        UncheckAllCheckboxes(FlowLayoutPanel_Signature_CommonRows)
    End Sub

    Private Sub Button_CommonRows_Data_All_Click(sender As Object, e As EventArgs) Handles Button_CommonRows_Data_All.Click
        CheckAllCheckboxes(FlowLayoutPanel_Data_CommonRows)
    End Sub

    Private Sub Button_CommonRows_Data_Noner_Click(sender As Object, e As EventArgs) Handles Button_CommonRows_Data_Noner.Click
        UncheckAllCheckboxes(FlowLayoutPanel_Data_CommonRows)
    End Sub

    Private Sub CheckBox_CommonRows_Data_Serial_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_CommonRows_Data_Serial.CheckedChanged
        If CheckBox_CommonRows_Data_Serial.Checked = True Then
            Form1.addDistinctRow("serial", "INSERT_HERE", Form1.DataGridView_License_Lic_Data)
        Else
            Form1.removeRowByKey("serial", Form1.DataGridView_License_Lic_Data)
        End If
    End Sub

    Private Sub CheckBox_CommonRows_Data_UUID_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_CommonRows_Data_UUID.CheckedChanged
        If CheckBox_CommonRows_Data_UUID.Checked = True Then
            Form1.addDistinctRow("uuid", "INSERT_HERE", Form1.DataGridView_License_Lic_Data)
        Else
            Form1.removeRowByKey("uuid", Form1.DataGridView_License_Lic_Data)
        End If
    End Sub

    Private Sub CheckBox_CommonRows_Data_ContractNumber_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_CommonRows_Data_ContractNumber.CheckedChanged
        If CheckBox_CommonRows_Data_ContractNumber.Checked = True Then
            Form1.addDistinctRow("contract_num", "INSERT_HERE", Form1.DataGridView_License_Lic_Data)
        Else
            Form1.removeRowByKey("contract_num", Form1.DataGridView_License_Lic_Data)
        End If
    End Sub

    Private Sub CheckBox_CommonRows_Signature_AddSignatureRow_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_CommonRows_Signature_AddSignatureRow.CheckedChanged
        Form1.removeRowByKey(Form1.TextBox_License_Lic_Verify_SignatureNodeName.Text, Form1.DataGridView_License_Lic_Signature)
        Dim rowsValue As String = ""
        If String.IsNullOrEmpty(Form1.TextBox_License_Lic_Signature.Text) = True Then
            rowsValue = "INSERT_HERE"
        Else
            rowsValue = Form1.TextBox_License_Lic_Signature.Text
        End If
        Form1.addDistinctRow(Form1.TextBox_License_Lic_Verify_SignatureNodeName.Text, rowsValue, Form1.DataGridView_License_Lic_Signature)


        If CheckBox_CommonRows_Signature_AddSignatureRow.Checked = False Then
            '    Form1.addDistinctRow(Form1.TextBox_License_Lic_Verify_SignatureNodeName.Text, "INSERT_HERE", Form1.DataGridView_License_Lic_Signature)
            'Else
            Form1.removeRowByKey(Form1.TextBox_License_Lic_Verify_SignatureNodeName.Text, Form1.DataGridView_License_Lic_Signature)
        End If
    End Sub

    Private Sub CheckBox_CommonRows_Signature_Salt_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_CommonRows_Signature_Salt.CheckedChanged
        Form1.removeRowByKey("salt", Form1.DataGridView_License_Lic_Signature)
        Dim rowsValue As String = ""
        If String.IsNullOrEmpty(Form1.TextBox_License_Lic_Salt.Text) = True Then
            rowsValue = "INSERT_HERE"
        Else
            rowsValue = Form1.TextBox_License_Lic_Salt.Text
        End If
        Form1.addDistinctRow("salt", rowsValue, Form1.DataGridView_License_Lic_Signature)


        If CheckBox_CommonRows_Signature_Salt.Checked = False Then
            '    Form1.addDistinctRow(Form1.TextBox_License_Lic_Verify_SignatureNodeName.Text, "INSERT_HERE", Form1.DataGridView_License_Lic_Signature)
            'Else
            Form1.removeRowByKey("salt", Form1.DataGridView_License_Lic_Signature)
        End If
    End Sub



    Private Async Sub CheckBox_CommonRows_Data_HardDriveFingerprints_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_CommonRows_Data_HardDriveFingerprints.CheckedChanged
        If CheckBox_CommonRows_Data_HardDriveFingerprints.Checked = True Then
            Dim driveHashes As List(Of String) = Await GetFingerprint_HardDrives()
            Dim concatenatedHashes As New StringBuilder()
            For Each drivehash In driveHashes
                concatenatedHashes.Append(drivehash & ";")
            Next
            Form1.addDistinctRow("fingerprint_drives", concatenatedHashes.ToString(), Form1.DataGridView_License_Lic_Data)
        Else
            Form1.removeRowByKey("fingerprint_drives", Form1.DataGridView_License_Lic_Data)
        End If
    End Sub



    Private Async Sub CheckBox_CommonRows_Data_ComputerFingerprints_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_CommonRows_Data_ComputerFingerprints.CheckedChanged
        If CheckBox_CommonRows_Data_ComputerFingerprints.Checked = True Then
            Dim machineHash As String = Await GetFingerprint_Computer()
            Form1.addDistinctRow("fingerprint_computer", machineHash, Form1.DataGridView_License_Lic_Data)
        Else
            Form1.removeRowByKey("fingerprint_computer", Form1.DataGridView_License_Lic_Data)
        End If
    End Sub




End Class