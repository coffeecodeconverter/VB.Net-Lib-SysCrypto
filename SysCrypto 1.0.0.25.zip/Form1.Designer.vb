﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Button_Test = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.TextBox_InputData = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.FlowLayoutPanel1 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Button_Encrypt = New System.Windows.Forms.Button()
        Me.Button_Decrypt = New System.Windows.Forms.Button()
        Me.Button_AES_SwapInputOutput = New System.Windows.Forms.Button()
        Me.Button_AES_CelarInputOutput = New System.Windows.Forms.Button()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.Button_AES_ClearOutput = New System.Windows.Forms.Button()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.TextBox_OutputData = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.Panel36 = New System.Windows.Forms.Panel()
        Me.CheckBox_AES_Salt = New System.Windows.Forms.CheckBox()
        Me.Button_AES_SaltGenerate = New System.Windows.Forms.Button()
        Me.TextBox_AES_Salt = New System.Windows.Forms.TextBox()
        Me.Panel33 = New System.Windows.Forms.Panel()
        Me.CheckBox_AES_Seed = New System.Windows.Forms.CheckBox()
        Me.Button_AES_SeedGenerate = New System.Windows.Forms.Button()
        Me.TextBox_AES_Seed = New System.Windows.Forms.TextBox()
        Me.Button_AES_KeyGenHash = New System.Windows.Forms.Button()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.TextBox_IV = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.TextBox_EncryptionKey = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage_SysInfo = New System.Windows.Forms.TabPage()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label80 = New System.Windows.Forms.Label()
        Me.TabControl4 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.Panel78 = New System.Windows.Forms.Panel()
        Me.FlowLayoutPanel6 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.Button16 = New System.Windows.Forms.Button()
        Me.Button17 = New System.Windows.Forms.Button()
        Me.Button18 = New System.Windows.Forms.Button()
        Me.Button19 = New System.Windows.Forms.Button()
        Me.Button20 = New System.Windows.Forms.Button()
        Me.Button21 = New System.Windows.Forms.Button()
        Me.Button22 = New System.Windows.Forms.Button()
        Me.Button23 = New System.Windows.Forms.Button()
        Me.Button24 = New System.Windows.Forms.Button()
        Me.Button25 = New System.Windows.Forms.Button()
        Me.Button26 = New System.Windows.Forms.Button()
        Me.Button27 = New System.Windows.Forms.Button()
        Me.Button28 = New System.Windows.Forms.Button()
        Me.Button29 = New System.Windows.Forms.Button()
        Me.Button30 = New System.Windows.Forms.Button()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.Panel86 = New System.Windows.Forms.Panel()
        Me.FlowLayoutPanel7 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Button33 = New System.Windows.Forms.Button()
        Me.Button31 = New System.Windows.Forms.Button()
        Me.Button32 = New System.Windows.Forms.Button()
        Me.Button34 = New System.Windows.Forms.Button()
        Me.Button35 = New System.Windows.Forms.Button()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.Panel87 = New System.Windows.Forms.Panel()
        Me.FlowLayoutPanel8 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Button36 = New System.Windows.Forms.Button()
        Me.Button37 = New System.Windows.Forms.Button()
        Me.Button38 = New System.Windows.Forms.Button()
        Me.Button39 = New System.Windows.Forms.Button()
        Me.Button40 = New System.Windows.Forms.Button()
        Me.Button41 = New System.Windows.Forms.Button()
        Me.Button42 = New System.Windows.Forms.Button()
        Me.Button43 = New System.Windows.Forms.Button()
        Me.Button44 = New System.Windows.Forms.Button()
        Me.Button45 = New System.Windows.Forms.Button()
        Me.Button46 = New System.Windows.Forms.Button()
        Me.Button47 = New System.Windows.Forms.Button()
        Me.Button48 = New System.Windows.Forms.Button()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.Panel88 = New System.Windows.Forms.Panel()
        Me.FlowLayoutPanel9 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Button49 = New System.Windows.Forms.Button()
        Me.Button50 = New System.Windows.Forms.Button()
        Me.Button51 = New System.Windows.Forms.Button()
        Me.Button52 = New System.Windows.Forms.Button()
        Me.Button53 = New System.Windows.Forms.Button()
        Me.Button54 = New System.Windows.Forms.Button()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.Panel89 = New System.Windows.Forms.Panel()
        Me.FlowLayoutPanel10 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Button55 = New System.Windows.Forms.Button()
        Me.Button56 = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.CheckBox_System_Include_UUID = New System.Windows.Forms.CheckBox()
        Me.CheckBox_System_Include_MotherboardBaseBoardProduct = New System.Windows.Forms.CheckBox()
        Me.CheckBox_System_Include_MotherboardSerial = New System.Windows.Forms.CheckBox()
        Me.CheckBox_System_Include_BIOSSerial = New System.Windows.Forms.CheckBox()
        Me.CheckBox_System_Include_SystemModelFull = New System.Windows.Forms.CheckBox()
        Me.CheckBox_System_Include_SystemModel = New System.Windows.Forms.CheckBox()
        Me.CheckBox_System_Include_Model = New System.Windows.Forms.CheckBox()
        Me.CheckBox_System_Include_Make = New System.Windows.Forms.CheckBox()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.ListBox3 = New System.Windows.Forms.ListBox()
        Me.ListBox2 = New System.Windows.Forms.ListBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.TabPage_Encoding = New System.Windows.Forms.TabPage()
        Me.Panel44 = New System.Windows.Forms.Panel()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Panel29 = New System.Windows.Forms.Panel()
        Me.Button57 = New System.Windows.Forms.Button()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.ComboBox_Encoding_EncodeOrDecodeIn = New System.Windows.Forms.ComboBox()
        Me.Button_Encoding_DecodeData = New System.Windows.Forms.Button()
        Me.Button_Encoding_EncodeData = New System.Windows.Forms.Button()
        Me.Button_Encoding_Base64StringEncodedCopy = New System.Windows.Forms.Button()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.TabControl_Encoding_StringOrFile = New System.Windows.Forms.TabControl()
        Me.TabPage_String = New System.Windows.Forms.TabPage()
        Me.Panel27 = New System.Windows.Forms.Panel()
        Me.TextBox_Encoding_StringToHash = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.TabPage_File = New System.Windows.Forms.TabPage()
        Me.Panel43 = New System.Windows.Forms.Panel()
        Me.TextBox_Encoding_FilePathToHash = New System.Windows.Forms.TextBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Button_Encoding_BrowseForFileToHash = New System.Windows.Forms.Button()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Panel35 = New System.Windows.Forms.Panel()
        Me.TextBox_Encoding_DecodedData = New System.Windows.Forms.TextBox()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Panel28 = New System.Windows.Forms.Panel()
        Me.Button_Encoding_HashedStringCopy = New System.Windows.Forms.Button()
        Me.Button_Encoding_StringToHash = New System.Windows.Forms.Button()
        Me.TextBox_Encoding_HashedString = New System.Windows.Forms.TextBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Panel30 = New System.Windows.Forms.Panel()
        Me.TextBox_Encoding_EncodedData = New System.Windows.Forms.TextBox()
        Me.Panel32 = New System.Windows.Forms.Panel()
        Me.TextBox_Encoding_InputData = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Panel26 = New System.Windows.Forms.Panel()
        Me.Panel71 = New System.Windows.Forms.Panel()
        Me.ComboBox_Encoding_TimestampGenerate = New System.Windows.Forms.ComboBox()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button_Encoding_TimestampGenerate = New System.Windows.Forms.Button()
        Me.TextBox_Encoding_TimestampGenerate = New System.Windows.Forms.TextBox()
        Me.Label66 = New System.Windows.Forms.Label()
        Me.Panel70 = New System.Windows.Forms.Panel()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Button_Encoding_GenerateGUID = New System.Windows.Forms.Button()
        Me.TextBox_Encoding_GenerateGUID = New System.Windows.Forms.TextBox()
        Me.Label64 = New System.Windows.Forms.Label()
        Me.Panel31 = New System.Windows.Forms.Panel()
        Me.Button_Encoding_RandomStringCopy = New System.Windows.Forms.Button()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.TextBox_Encoding_RandomStringLength = New System.Windows.Forms.TextBox()
        Me.Button_Encoding_RandomString = New System.Windows.Forms.Button()
        Me.TextBox_Encoding_RandomString = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.TabPage_RSA = New System.Windows.Forms.TabPage()
        Me.Button_RSA_GenerateKeys = New System.Windows.Forms.Button()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Panel22 = New System.Windows.Forms.Panel()
        Me.Button_RSA_HashInputClear = New System.Windows.Forms.Button()
        Me.Panel20 = New System.Windows.Forms.Panel()
        Me.FlowLayoutPanel4 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Button_RSA_Sign_WithPrivate = New System.Windows.Forms.Button()
        Me.Button_RSA_Verify_WithPublic = New System.Windows.Forms.Button()
        Me.Button_RSA_VerifyClear = New System.Windows.Forms.Button()
        Me.Panel21 = New System.Windows.Forms.Panel()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.Button_RSA_SignatureCopy = New System.Windows.Forms.Button()
        Me.TextBox_RSA_Signature = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Panel24 = New System.Windows.Forms.Panel()
        Me.TextBox_RSA_MatchingSignatures = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Panel18 = New System.Windows.Forms.Panel()
        Me.Button_RSA_HashInputAndSalt = New System.Windows.Forms.Button()
        Me.Button_RSA_HashInput = New System.Windows.Forms.Button()
        Me.Panel19 = New System.Windows.Forms.Panel()
        Me.TextBox_RSA_HashInput = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.FlowLayoutPanel3 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Button_RSA_GenerateKeysClear = New System.Windows.Forms.Button()
        Me.Button_RSA_ExportGeneratedKeyPairs = New System.Windows.Forms.Button()
        Me.Button_RSA_ImportGeneratedKeyPairs = New System.Windows.Forms.Button()
        Me.Panel10 = New System.Windows.Forms.Panel()
        Me.Panel40 = New System.Windows.Forms.Panel()
        Me.CheckBox_RSA_Salt = New System.Windows.Forms.CheckBox()
        Me.TextBox_RSA_Salt = New System.Windows.Forms.TextBox()
        Me.Panel34 = New System.Windows.Forms.Panel()
        Me.CheckBox_RSA_EnableSeed = New System.Windows.Forms.CheckBox()
        Me.TextBox_RSA_Seed = New System.Windows.Forms.TextBox()
        Me.Panel42 = New System.Windows.Forms.Panel()
        Me.TextBox_RSA_KeyPairDescription = New System.Windows.Forms.TextBox()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Panel25 = New System.Windows.Forms.Panel()
        Me.Button_RSA_PreviousPairsEmpty = New System.Windows.Forms.Button()
        Me.ComboBox_RSA_PreviousPairs = New System.Windows.Forms.ComboBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Panel23 = New System.Windows.Forms.Panel()
        Me.ComboBox_RSA_KeySize = New System.Windows.Forms.ComboBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Panel11 = New System.Windows.Forms.Panel()
        Me.Button_RSA_PublicKey_Copy = New System.Windows.Forms.Button()
        Me.TextBox_RSA_PublicKey = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Panel12 = New System.Windows.Forms.Panel()
        Me.Button_RSA_PrivateKey_Copy = New System.Windows.Forms.Button()
        Me.TextBox_RSA_PrivateKey = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Panel13 = New System.Windows.Forms.Panel()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Button_RSA_InputDataClear = New System.Windows.Forms.Button()
        Me.Panel14 = New System.Windows.Forms.Panel()
        Me.TextBox_RSA_InputData = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Panel15 = New System.Windows.Forms.Panel()
        Me.FlowLayoutPanel2 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Button_RSA_Encrypt_WithPublic = New System.Windows.Forms.Button()
        Me.Button_RSA_Encrypt_WithPrivate = New System.Windows.Forms.Button()
        Me.Button_RSA_Decrypt_WithPrivate = New System.Windows.Forms.Button()
        Me.Button_RSA_SwapInputOutpu = New System.Windows.Forms.Button()
        Me.Button_RSA_SwapInputOutput = New System.Windows.Forms.Button()
        Me.Panel16 = New System.Windows.Forms.Panel()
        Me.Button_RSA_OutputDataClear = New System.Windows.Forms.Button()
        Me.Panel17 = New System.Windows.Forms.Panel()
        Me.TextBox_RSA_OutputData = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.TabPage_AES = New System.Windows.Forms.TabPage()
        Me.Panel37 = New System.Windows.Forms.Panel()
        Me.TabControl3 = New System.Windows.Forms.TabControl()
        Me.TabPage9 = New System.Windows.Forms.TabPage()
        Me.Button_AES_ClearInput = New System.Windows.Forms.Button()
        Me.TabPage10 = New System.Windows.Forms.TabPage()
        Me.Panel41 = New System.Windows.Forms.Panel()
        Me.Button_AES_FolderToOutput = New System.Windows.Forms.Button()
        Me.TextBox_AES_OutputFile = New System.Windows.Forms.TextBox()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Panel39 = New System.Windows.Forms.Panel()
        Me.FlowLayoutPanel5 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Button_AES_Files_Encrypt = New System.Windows.Forms.Button()
        Me.Button_AES_Files_Decrypt = New System.Windows.Forms.Button()
        Me.Button_AES_Files_SwapInputOutput = New System.Windows.Forms.Button()
        Me.Button_AES_Files_ClearInputOutput = New System.Windows.Forms.Button()
        Me.Panel38 = New System.Windows.Forms.Panel()
        Me.TextBox_AES_BrowsedFilePath = New System.Windows.Forms.TextBox()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Button_AES_BrowseForFile = New System.Windows.Forms.Button()
        Me.Button_AES_ConvertIVToHash = New System.Windows.Forms.Button()
        Me.Button_AES_ConvertKeyToHash = New System.Windows.Forms.Button()
        Me.Button_AES_Clear = New System.Windows.Forms.Button()
        Me.Button_AES_Export = New System.Windows.Forms.Button()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.TabPage_LicenseGeneration = New System.Windows.Forms.TabPage()
        Me.TabControl2 = New System.Windows.Forms.TabControl()
        Me.TabPage_LICFile = New System.Windows.Forms.TabPage()
        Me.Panel69 = New System.Windows.Forms.Panel()
        Me.TextBox_License_Lic_Imported_DataHashed = New System.Windows.Forms.TextBox()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.TabControl_License_Lic_ImportedData = New System.Windows.Forms.TabControl()
        Me.TabPage_DataFields = New System.Windows.Forms.TabPage()
        Me.Panel68 = New System.Windows.Forms.Panel()
        Me.TextBox_License_Lic_Imported_DataFields = New System.Windows.Forms.TextBox()
        Me.Panel67 = New System.Windows.Forms.Panel()
        Me.TextBox_License_Lic_ImportedPublicKeyFingerprint = New System.Windows.Forms.TextBox()
        Me.Label61 = New System.Windows.Forms.Label()
        Me.Panel66 = New System.Windows.Forms.Panel()
        Me.TextBox_License_Lic_ImportedAlgorithm = New System.Windows.Forms.TextBox()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.Button_License_Lic_CloseJSONLicFile = New System.Windows.Forms.Button()
        Me.Panel65 = New System.Windows.Forms.Panel()
        Me.TextBox_License_Lic_LICFilePath = New System.Windows.Forms.TextBox()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.Panel64 = New System.Windows.Forms.Panel()
        Me.TextBox_License_Lic_ImportedSignature = New System.Windows.Forms.TextBox()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.Panel63 = New System.Windows.Forms.Panel()
        Me.Button_License_Lic_VerifyImportedLicFile = New System.Windows.Forms.Button()
        Me.TextBox_License_Lic_VerifyImportedLICFile = New System.Windows.Forms.TextBox()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.Panel62 = New System.Windows.Forms.Panel()
        Me.TextBox_License_Lic_ImportedSalt = New System.Windows.Forms.TextBox()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.Panel60 = New System.Windows.Forms.Panel()
        Me.TextBox_License_Lic_ImportedKeySize = New System.Windows.Forms.TextBox()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.Panel61 = New System.Windows.Forms.Panel()
        Me.TextBox_License_Lic_PastedPublicKey = New System.Windows.Forms.TextBox()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.Button_License_Lic_ImportJSONLicFile = New System.Windows.Forms.Button()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.Button_License_Lic_SaveFile = New System.Windows.Forms.Button()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Panel46 = New System.Windows.Forms.Panel()
        Me.Panel_License_Lic_Verification = New System.Windows.Forms.Panel()
        Me.Panel54 = New System.Windows.Forms.Panel()
        Me.Button_License_Lic_HashPublicKeyClear = New System.Windows.Forms.Button()
        Me.Button_License_Lic_HashPublicKey = New System.Windows.Forms.Button()
        Me.TextBox_License_Lic_HashPublicKey = New System.Windows.Forms.TextBox()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Panel50 = New System.Windows.Forms.Panel()
        Me.TextBox_License_Lic_KeySize = New System.Windows.Forms.TextBox()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Panel51 = New System.Windows.Forms.Panel()
        Me.Button_License_Lic_CopyAllPublicKey = New System.Windows.Forms.Button()
        Me.Button_License_Lic_CopyPublicKey = New System.Windows.Forms.Button()
        Me.TextBox_License_Lic_PublicKey = New System.Windows.Forms.TextBox()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Panel52 = New System.Windows.Forms.Panel()
        Me.Button_License_Lic_CopyAllPrivateKey = New System.Windows.Forms.Button()
        Me.Button_License_Lic_CopyPrivateKey = New System.Windows.Forms.Button()
        Me.TextBox_License_Lic_PrivateKey = New System.Windows.Forms.TextBox()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Panel53 = New System.Windows.Forms.Panel()
        Me.TextBox_License_Lic_Salt = New System.Windows.Forms.TextBox()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.Panel59 = New System.Windows.Forms.Panel()
        Me.ComboBox_License_Lic_PreviousPairs = New System.Windows.Forms.ComboBox()
        Me.Button_License_Lic_GenerateKeys = New System.Windows.Forms.Button()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.Panel58 = New System.Windows.Forms.Panel()
        Me.TextBox_License_Lic_DataOnlyFields = New System.Windows.Forms.TextBox()
        Me.Panel57 = New System.Windows.Forms.Panel()
        Me.Button_License_Lic_Verify_Clear = New System.Windows.Forms.Button()
        Me.Button_License_Lic_Verify = New System.Windows.Forms.Button()
        Me.TextBox_License_Lic_Verified = New System.Windows.Forms.TextBox()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Panel56 = New System.Windows.Forms.Panel()
        Me.Button_License_Lic_SignIt_Clear = New System.Windows.Forms.Button()
        Me.Button_License_Lic_SignIt = New System.Windows.Forms.Button()
        Me.TextBox_License_Lic_Signature = New System.Windows.Forms.TextBox()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Panel55 = New System.Windows.Forms.Panel()
        Me.Button_License_Lic_HashDataFields_Clear = New System.Windows.Forms.Button()
        Me.Button_License_Lic_HashDataFields = New System.Windows.Forms.Button()
        Me.TextBox_License_Lic_HashDataFields = New System.Windows.Forms.TextBox()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Panel49 = New System.Windows.Forms.Panel()
        Me.Button_License_Lic_Verify_DefaultSignatureNodeName = New System.Windows.Forms.Button()
        Me.TextBox_License_Lic_Verify_SignatureNodeName = New System.Windows.Forms.TextBox()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Panel47 = New System.Windows.Forms.Panel()
        Me.Button_License_Lic_Verify_DefaultJSONNodeName = New System.Windows.Forms.Button()
        Me.TextBox_License_Lic_Verify_JSONNodeName = New System.Windows.Forms.TextBox()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.FlowLayoutPanel_License_Lic_Verification = New System.Windows.Forms.FlowLayoutPanel()
        Me.Button_License_Lic_Verify_AddRow = New System.Windows.Forms.Button()
        Me.Button_License_Lic_Verify_AddCommonRows = New System.Windows.Forms.Button()
        Me.Button_License_Lic_Verify_DeleteSelected = New System.Windows.Forms.Button()
        Me.Button_License_Lic_Verify_Up = New System.Windows.Forms.Button()
        Me.Button_License_Lic_Verify_Down = New System.Windows.Forms.Button()
        Me.Button_License_Lic_Verify_AutoSort = New System.Windows.Forms.Button()
        Me.Button_License_Lic_Verify_AddSignatureRow = New System.Windows.Forms.Button()
        Me.DataGridView_License_Lic_Signature = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.CheckBox_License_Lic_AddSignature = New System.Windows.Forms.CheckBox()
        Me.Button_License_Lic_Preview = New System.Windows.Forms.Button()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Panel45 = New System.Windows.Forms.Panel()
        Me.Panel48 = New System.Windows.Forms.Panel()
        Me.Button_License_Lic_Data_JSONNodeNameDefault = New System.Windows.Forms.Button()
        Me.TextBox_License_Lic_Data_JSONNodeName = New System.Windows.Forms.TextBox()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.FlowLayoutPanel_License_Lic_AddDataFields = New System.Windows.Forms.FlowLayoutPanel()
        Me.Button_License_Lic_AddRow = New System.Windows.Forms.Button()
        Me.Button_License_Lic_Data_AddCommonRows = New System.Windows.Forms.Button()
        Me.Button_License_Lic_DeleteSelected = New System.Windows.Forms.Button()
        Me.Button_License_Lic_Data_Up = New System.Windows.Forms.Button()
        Me.Button_License_Lic_Data_Down = New System.Windows.Forms.Button()
        Me.Button_License_Lic_Data_AutoSort = New System.Windows.Forms.Button()
        Me.DataGridView_License_Lic_Data = New System.Windows.Forms.DataGridView()
        Me.DataName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataValue = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TabPage_ProductSerial = New System.Windows.Forms.TabPage()
        Me.TabPage11 = New System.Windows.Forms.TabPage()
        Me.Panel149 = New System.Windows.Forms.Panel()
        Me.GroupBox9 = New System.Windows.Forms.GroupBox()
        Me.Panel134 = New System.Windows.Forms.Panel()
        Me.Panel151 = New System.Windows.Forms.Panel()
        Me.TextBox_LicenseOTP_TOTP_ServerCodeAdmin = New System.Windows.Forms.TextBox()
        Me.Label169 = New System.Windows.Forms.Label()
        Me.Panel139 = New System.Windows.Forms.Panel()
        Me.TextBox_LicenseOTP_TOTP_Verified = New System.Windows.Forms.TextBox()
        Me.Label158 = New System.Windows.Forms.Label()
        Me.Panel135 = New System.Windows.Forms.Panel()
        Me.TextBox_LicenseOTP_TOTP_UserCodeAdmin = New System.Windows.Forms.TextBox()
        Me.Label152 = New System.Windows.Forms.Label()
        Me.Button_LicenseOTP_TOTP_VerifyCode = New System.Windows.Forms.Button()
        Me.Panel137 = New System.Windows.Forms.Panel()
        Me.Button_LicenseOTP_TOTP_IntervalCopyUser = New System.Windows.Forms.Button()
        Me.ComboBox_LicenseOTP_TOTP_IntervalAdmin = New System.Windows.Forms.ComboBox()
        Me.Label153 = New System.Windows.Forms.Label()
        Me.Panel138 = New System.Windows.Forms.Panel()
        Me.Button_LicenseOTP_TOTP_SecretCopyUser = New System.Windows.Forms.Button()
        Me.TextBox_LicenseOTP_TOTP_SecretAdmin = New System.Windows.Forms.TextBox()
        Me.Label154 = New System.Windows.Forms.Label()
        Me.Label155 = New System.Windows.Forms.Label()
        Me.Panel130 = New System.Windows.Forms.Panel()
        Me.Panel150 = New System.Windows.Forms.Panel()
        Me.TextBox_LicenseOTP_TOTP_AsBase32User = New System.Windows.Forms.TextBox()
        Me.Label168 = New System.Windows.Forms.Label()
        Me.Panel133 = New System.Windows.Forms.Panel()
        Me.TextBox_LicenseOTP_TOTP_CodeUser = New System.Windows.Forms.TextBox()
        Me.Label151 = New System.Windows.Forms.Label()
        Me.Button_LicenseOTP_TOTP_GetCodeUser = New System.Windows.Forms.Button()
        Me.Panel132 = New System.Windows.Forms.Panel()
        Me.ComboBox_LicenseOTP_TOTP_IntervalUser = New System.Windows.Forms.ComboBox()
        Me.Label150 = New System.Windows.Forms.Label()
        Me.Panel131 = New System.Windows.Forms.Panel()
        Me.Button_LicenseOTP_TOTP_SecretUser = New System.Windows.Forms.Button()
        Me.TextBox_LicenseOTP_TOTP_SecretUser = New System.Windows.Forms.TextBox()
        Me.Label149 = New System.Windows.Forms.Label()
        Me.Label148 = New System.Windows.Forms.Label()
        Me.TabPage_Verify = New System.Windows.Forms.TabPage()
        Me.Label72 = New System.Windows.Forms.Label()
        Me.Panel85 = New System.Windows.Forms.Panel()
        Me.TextBox_Verify_SaltForSignature = New System.Windows.Forms.TextBox()
        Me.Label79 = New System.Windows.Forms.Label()
        Me.Panel82 = New System.Windows.Forms.Panel()
        Me.TextBox_Verify_DataHashForSignature = New System.Windows.Forms.TextBox()
        Me.Label76 = New System.Windows.Forms.Label()
        Me.Panel83 = New System.Windows.Forms.Panel()
        Me.TextBox_Verify_PrivateKeyForSignature = New System.Windows.Forms.TextBox()
        Me.Label77 = New System.Windows.Forms.Label()
        Me.Panel84 = New System.Windows.Forms.Panel()
        Me.Button_LicenseGen_Verify_GetSignature = New System.Windows.Forms.Button()
        Me.TextBox_Verify_Signature = New System.Windows.Forms.TextBox()
        Me.Label78 = New System.Windows.Forms.Label()
        Me.Panel81 = New System.Windows.Forms.Panel()
        Me.Button_LicenseGen_Verify_Verify = New System.Windows.Forms.Button()
        Me.TextBox_LicenseGen_Verify_Verified = New System.Windows.Forms.TextBox()
        Me.Label75 = New System.Windows.Forms.Label()
        Me.Panel79 = New System.Windows.Forms.Panel()
        Me.TextBox_LicenseGen_Verify_DataHashForVerification = New System.Windows.Forms.TextBox()
        Me.Label73 = New System.Windows.Forms.Label()
        Me.Panel80 = New System.Windows.Forms.Panel()
        Me.TextBox_LicenseGen_Verify_SignatureForVerification = New System.Windows.Forms.TextBox()
        Me.Label74 = New System.Windows.Forms.Label()
        Me.Panel76 = New System.Windows.Forms.Panel()
        Me.TextBox_LicenseGen_Verify_SaltForVerification = New System.Windows.Forms.TextBox()
        Me.Label70 = New System.Windows.Forms.Label()
        Me.Panel77 = New System.Windows.Forms.Panel()
        Me.TextBox_LicenseGen_Verify_PublicKeyForVerification = New System.Windows.Forms.TextBox()
        Me.Label71 = New System.Windows.Forms.Label()
        Me.Panel74 = New System.Windows.Forms.Panel()
        Me.Button_LicenseGen_Verify_GetTestDataHash = New System.Windows.Forms.Button()
        Me.Button_LicenseGen_Verify_CopyTestDataHash = New System.Windows.Forms.Button()
        Me.TextBox_LicenseGen_Verify_TestDataHashed = New System.Windows.Forms.TextBox()
        Me.Label68 = New System.Windows.Forms.Label()
        Me.Panel75 = New System.Windows.Forms.Panel()
        Me.TextBox_LicenseGen_Verify_TestData = New System.Windows.Forms.TextBox()
        Me.Label69 = New System.Windows.Forms.Label()
        Me.Panel72 = New System.Windows.Forms.Panel()
        Me.Button_LicenseGen_Verify_GetMachineHash = New System.Windows.Forms.Button()
        Me.Button_LicenseGen_Verify_CopyMachineHash = New System.Windows.Forms.Button()
        Me.TextBox_LicenseGen_Verify_FingerPrintHash = New System.Windows.Forms.TextBox()
        Me.Label67 = New System.Windows.Forms.Label()
        Me.Panel73 = New System.Windows.Forms.Panel()
        Me.Button_LicenseGen_Verify_GetMachineFingerprint = New System.Windows.Forms.Button()
        Me.Button_LicenseGen_Verify_CopyMAchineFingerprint = New System.Windows.Forms.Button()
        Me.TextBox_LicenseGen_Verify_MachineFingerprint = New System.Windows.Forms.TextBox()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.TabControl5 = New System.Windows.Forms.TabControl()
        Me.TabPage7 = New System.Windows.Forms.TabPage()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.Panel113 = New System.Windows.Forms.Panel()
        Me.TextBox_Demo1_Verify_CurrentLocalTime = New System.Windows.Forms.TextBox()
        Me.Label119 = New System.Windows.Forms.Label()
        Me.Panel112 = New System.Windows.Forms.Panel()
        Me.TextBox_Demo1_Verify_Expired = New System.Windows.Forms.TextBox()
        Me.Label117 = New System.Windows.Forms.Label()
        Me.Panel111 = New System.Windows.Forms.Panel()
        Me.TextBox_Demo1_Verify_CurrentUTCTime = New System.Windows.Forms.TextBox()
        Me.Label112 = New System.Windows.Forms.Label()
        Me.Panel110 = New System.Windows.Forms.Panel()
        Me.TextBox_Demo1_Verify_IsVerified = New System.Windows.Forms.TextBox()
        Me.Label110 = New System.Windows.Forms.Label()
        Me.Button68 = New System.Windows.Forms.Button()
        Me.Panel109 = New System.Windows.Forms.Panel()
        Me.TextBox_Demo1_Verify_ExtractedFingerprint = New System.Windows.Forms.TextBox()
        Me.Label118 = New System.Windows.Forms.Label()
        Me.Panel107 = New System.Windows.Forms.Panel()
        Me.TextBox_Demo1_VerifyFingerprintPlusExpiryHash = New System.Windows.Forms.TextBox()
        Me.Label114 = New System.Windows.Forms.Label()
        Me.Panel108 = New System.Windows.Forms.Panel()
        Me.TextBox_Demo1_VerifyFingerprintPlusExpiry = New System.Windows.Forms.TextBox()
        Me.Label116 = New System.Windows.Forms.Label()
        Me.Panel106 = New System.Windows.Forms.Panel()
        Me.TextBox_Demo1_VerifyFingerprint = New System.Windows.Forms.TextBox()
        Me.Label115 = New System.Windows.Forms.Label()
        Me.Panel105 = New System.Windows.Forms.Panel()
        Me.Label_Demo1_Verify_ExtractedExpiryInLocalTime = New System.Windows.Forms.Label()
        Me.Label113 = New System.Windows.Forms.Label()
        Me.Panel104 = New System.Windows.Forms.Panel()
        Me.Label_Demo1_Verify_ExtractedExpiry = New System.Windows.Forms.Label()
        Me.Label111 = New System.Windows.Forms.Label()
        Me.Label109 = New System.Windows.Forms.Label()
        Me.Label108 = New System.Windows.Forms.Label()
        Me.Label107 = New System.Windows.Forms.Label()
        Me.Label106 = New System.Windows.Forms.Label()
        Me.Panel103 = New System.Windows.Forms.Panel()
        Me.Button_Demo1_LoadedLICFileReload = New System.Windows.Forms.Button()
        Me.Button_Demo1_LoadedLICFileClose = New System.Windows.Forms.Button()
        Me.Button_Demo1_LoadedLICFileBrowse = New System.Windows.Forms.Button()
        Me.TextBox_Demo1_LoadedLICFile = New System.Windows.Forms.TextBox()
        Me.Label98 = New System.Windows.Forms.Label()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.Panel94 = New System.Windows.Forms.Panel()
        Me.Label_Demo1_SetExpiryValueInUTC = New System.Windows.Forms.Label()
        Me.Label105 = New System.Windows.Forms.Label()
        Me.Button59 = New System.Windows.Forms.Button()
        Me.Panel102 = New System.Windows.Forms.Panel()
        Me.Button58 = New System.Windows.Forms.Button()
        Me.TextBox_Demo1_Signature = New System.Windows.Forms.TextBox()
        Me.Label104 = New System.Windows.Forms.Label()
        Me.Panel101 = New System.Windows.Forms.Panel()
        Me.Button61 = New System.Windows.Forms.Button()
        Me.TextBox_Demo1_FingerprintPlusExpiryHash = New System.Windows.Forms.TextBox()
        Me.Label103 = New System.Windows.Forms.Label()
        Me.Panel100 = New System.Windows.Forms.Panel()
        Me.Button60 = New System.Windows.Forms.Button()
        Me.TextBox_Demo1_FingerprintPlusExpiry = New System.Windows.Forms.TextBox()
        Me.Label102 = New System.Windows.Forms.Label()
        Me.Panel99 = New System.Windows.Forms.Panel()
        Me.CheckBox12 = New System.Windows.Forms.CheckBox()
        Me.Label97 = New System.Windows.Forms.Label()
        Me.Label_Demo1_SetExpiryValue = New System.Windows.Forms.Label()
        Me.CheckBox15 = New System.Windows.Forms.CheckBox()
        Me.CheckBox14 = New System.Windows.Forms.CheckBox()
        Me.CheckBox13 = New System.Windows.Forms.CheckBox()
        Me.CheckBox11 = New System.Windows.Forms.CheckBox()
        Me.CheckBox10 = New System.Windows.Forms.CheckBox()
        Me.CheckBox9 = New System.Windows.Forms.CheckBox()
        Me.CheckBox8 = New System.Windows.Forms.CheckBox()
        Me.CheckBox7 = New System.Windows.Forms.CheckBox()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.Label101 = New System.Windows.Forms.Label()
        Me.Label100 = New System.Windows.Forms.Label()
        Me.Label99 = New System.Windows.Forms.Label()
        Me.Label96 = New System.Windows.Forms.Label()
        Me.Label88 = New System.Windows.Forms.Label()
        Me.Panel90 = New System.Windows.Forms.Panel()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Label93 = New System.Windows.Forms.Label()
        Me.Button_Demo1_GenerateKeys = New System.Windows.Forms.Button()
        Me.Panel91 = New System.Windows.Forms.Panel()
        Me.Panel92 = New System.Windows.Forms.Panel()
        Me.Label95 = New System.Windows.Forms.Label()
        Me.TextBox_Demo1_Salt = New System.Windows.Forms.TextBox()
        Me.Panel93 = New System.Windows.Forms.Panel()
        Me.Label94 = New System.Windows.Forms.Label()
        Me.TextBox_Demo1_Seed = New System.Windows.Forms.TextBox()
        Me.Panel95 = New System.Windows.Forms.Panel()
        Me.Button_Demo1_DeletePairs = New System.Windows.Forms.Button()
        Me.ComboBox_Demo1_PreviousPairs = New System.Windows.Forms.ComboBox()
        Me.Label89 = New System.Windows.Forms.Label()
        Me.Panel96 = New System.Windows.Forms.Panel()
        Me.TextBox_Demo1_KeySize = New System.Windows.Forms.TextBox()
        Me.Label90 = New System.Windows.Forms.Label()
        Me.Panel97 = New System.Windows.Forms.Panel()
        Me.Button_Demo1_PublicKeyCopy = New System.Windows.Forms.Button()
        Me.TextBox_Demo1_PublicKey = New System.Windows.Forms.TextBox()
        Me.Label91 = New System.Windows.Forms.Label()
        Me.Panel98 = New System.Windows.Forms.Panel()
        Me.Button_Demo1_PrivateKeyCopy = New System.Windows.Forms.Button()
        Me.TextBox_Demo1_PrivateKey = New System.Windows.Forms.TextBox()
        Me.Label92 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.CheckBox_Demo1_ShowConcatenatedData = New System.Windows.Forms.CheckBox()
        Me.Label87 = New System.Windows.Forms.Label()
        Me.Button_Demo1_GenerateFingerprint = New System.Windows.Forms.Button()
        Me.TextBox_Demo1_Fingerprint = New System.Windows.Forms.TextBox()
        Me.Label86 = New System.Windows.Forms.Label()
        Me.Label85 = New System.Windows.Forms.Label()
        Me.ListBox_Demo1_Characteristics = New System.Windows.Forms.ListBox()
        Me.FlowLayoutPanel11 = New System.Windows.Forms.FlowLayoutPanel()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.CheckBox2 = New System.Windows.Forms.CheckBox()
        Me.CheckBox3 = New System.Windows.Forms.CheckBox()
        Me.CheckBox4 = New System.Windows.Forms.CheckBox()
        Me.CheckBox5 = New System.Windows.Forms.CheckBox()
        Me.CheckBox6 = New System.Windows.Forms.CheckBox()
        Me.Label84 = New System.Windows.Forms.Label()
        Me.Label83 = New System.Windows.Forms.Label()
        Me.Label82 = New System.Windows.Forms.Label()
        Me.Label81 = New System.Windows.Forms.Label()
        Me.TabPage8 = New System.Windows.Forms.TabPage()
        Me.Panel126 = New System.Windows.Forms.Panel()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.Button65 = New System.Windows.Forms.Button()
        Me.Panel129 = New System.Windows.Forms.Panel()
        Me.TextBox9 = New System.Windows.Forms.TextBox()
        Me.Label147 = New System.Windows.Forms.Label()
        Me.Panel128 = New System.Windows.Forms.Panel()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.Label146 = New System.Windows.Forms.Label()
        Me.Panel127 = New System.Windows.Forms.Panel()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.Label145 = New System.Windows.Forms.Label()
        Me.Panel125 = New System.Windows.Forms.Panel()
        Me.Label133 = New System.Windows.Forms.Label()
        Me.TextBox_Demo2_VerifyKeyPart5 = New System.Windows.Forms.TextBox()
        Me.Label141 = New System.Windows.Forms.Label()
        Me.TextBox_Demo2_VerifyKeyPart4 = New System.Windows.Forms.TextBox()
        Me.Label142 = New System.Windows.Forms.Label()
        Me.TextBox_Demo2_VerifyKeyPart3 = New System.Windows.Forms.TextBox()
        Me.Label143 = New System.Windows.Forms.Label()
        Me.TextBox_Demo2_VerifyKeyPart2 = New System.Windows.Forms.TextBox()
        Me.TextBox_Demo2_VerifyKeyPart1 = New System.Windows.Forms.TextBox()
        Me.Label144 = New System.Windows.Forms.Label()
        Me.Button66 = New System.Windows.Forms.Button()
        Me.Label156 = New System.Windows.Forms.Label()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.Panel121 = New System.Windows.Forms.Panel()
        Me.Label132 = New System.Windows.Forms.Label()
        Me.DateTimePicker2 = New System.Windows.Forms.DateTimePicker()
        Me.Label125 = New System.Windows.Forms.Label()
        Me.Panel120 = New System.Windows.Forms.Panel()
        Me.Button63 = New System.Windows.Forms.Button()
        Me.TextBox_Demo2_RandomString = New System.Windows.Forms.TextBox()
        Me.Label131 = New System.Windows.Forms.Label()
        Me.Panel136 = New System.Windows.Forms.Panel()
        Me.Button69 = New System.Windows.Forms.Button()
        Me.TextBox_Demo2_HashCombined = New System.Windows.Forms.TextBox()
        Me.Label157 = New System.Windows.Forms.Label()
        Me.RadioButton2 = New System.Windows.Forms.RadioButton()
        Me.RadioButton1 = New System.Windows.Forms.RadioButton()
        Me.Panel119 = New System.Windows.Forms.Panel()
        Me.Panel114 = New System.Windows.Forms.Panel()
        Me.TextBox_Demo2_LicensedTo = New System.Windows.Forms.TextBox()
        Me.Label120 = New System.Windows.Forms.Label()
        Me.Panel115 = New System.Windows.Forms.Panel()
        Me.TextBox_Demo2_Email = New System.Windows.Forms.TextBox()
        Me.Label124 = New System.Windows.Forms.Label()
        Me.Panel116 = New System.Windows.Forms.Panel()
        Me.TextBox_Demo2_Branch = New System.Windows.Forms.TextBox()
        Me.Label126 = New System.Windows.Forms.Label()
        Me.Panel122 = New System.Windows.Forms.Panel()
        Me.Button64 = New System.Windows.Forms.Button()
        Me.TextBox_Demo2_Base64Encoded = New System.Windows.Forms.TextBox()
        Me.Label134 = New System.Windows.Forms.Label()
        Me.Panel117 = New System.Windows.Forms.Panel()
        Me.TextBox_Demo2_Terminal = New System.Windows.Forms.TextBox()
        Me.Label129 = New System.Windows.Forms.Label()
        Me.Panel123 = New System.Windows.Forms.Panel()
        Me.Button62 = New System.Windows.Forms.Button()
        Me.TextBox_Demo2_Concatenated = New System.Windows.Forms.TextBox()
        Me.Label135 = New System.Windows.Forms.Label()
        Me.Panel118 = New System.Windows.Forms.Panel()
        Me.TextBox_Demo2_Seed = New System.Windows.Forms.TextBox()
        Me.Label130 = New System.Windows.Forms.Label()
        Me.Panel124 = New System.Windows.Forms.Panel()
        Me.Label140 = New System.Windows.Forms.Label()
        Me.TextBox_Demo2_LicenseKeyPart5 = New System.Windows.Forms.TextBox()
        Me.Label139 = New System.Windows.Forms.Label()
        Me.TextBox_Demo2_LicenseKeyPart4 = New System.Windows.Forms.TextBox()
        Me.Label138 = New System.Windows.Forms.Label()
        Me.TextBox_Demo2_LicenseKeyPart3 = New System.Windows.Forms.TextBox()
        Me.Label137 = New System.Windows.Forms.Label()
        Me.TextBox_Demo2_LicenseKeyPart2 = New System.Windows.Forms.TextBox()
        Me.TextBox_Demo2_LicenseKeyPart1 = New System.Windows.Forms.TextBox()
        Me.Label136 = New System.Windows.Forms.Label()
        Me.Button_Demo2_GeneralteLicenseKey = New System.Windows.Forms.Button()
        Me.Label127 = New System.Windows.Forms.Label()
        Me.Label128 = New System.Windows.Forms.Label()
        Me.Label121 = New System.Windows.Forms.Label()
        Me.Label122 = New System.Windows.Forms.Label()
        Me.Label123 = New System.Windows.Forms.Label()
        Me.Button_LicenseOTP_TOTP_UserCodeCopyFromUser = New System.Windows.Forms.Button()
        Me.Label170 = New System.Windows.Forms.Label()
        Me.Label172 = New System.Windows.Forms.Label()
        Me.Label173 = New System.Windows.Forms.Label()
        Me.GroupBox10 = New System.Windows.Forms.GroupBox()
        Me.Label159 = New System.Windows.Forms.Label()
        Me.Label160 = New System.Windows.Forms.Label()
        Me.Panel140 = New System.Windows.Forms.Panel()
        Me.Label161 = New System.Windows.Forms.Label()
        Me.Panel141 = New System.Windows.Forms.Panel()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Label162 = New System.Windows.Forms.Label()
        Me.Button67 = New System.Windows.Forms.Button()
        Me.Panel142 = New System.Windows.Forms.Panel()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.Label163 = New System.Windows.Forms.Label()
        Me.Panel143 = New System.Windows.Forms.Panel()
        Me.Button70 = New System.Windows.Forms.Button()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.Label164 = New System.Windows.Forms.Label()
        Me.Panel144 = New System.Windows.Forms.Panel()
        Me.Button71 = New System.Windows.Forms.Button()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.Label165 = New System.Windows.Forms.Label()
        Me.Panel145 = New System.Windows.Forms.Panel()
        Me.Button72 = New System.Windows.Forms.Button()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.Label166 = New System.Windows.Forms.Label()
        Me.Label167 = New System.Windows.Forms.Label()
        Me.Panel146 = New System.Windows.Forms.Panel()
        Me.Panel147 = New System.Windows.Forms.Panel()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.Label174 = New System.Windows.Forms.Label()
        Me.Panel148 = New System.Windows.Forms.Panel()
        Me.TextBox10 = New System.Windows.Forms.TextBox()
        Me.Label175 = New System.Windows.Forms.Label()
        Me.Button73 = New System.Windows.Forms.Button()
        Me.Panel152 = New System.Windows.Forms.Panel()
        Me.Label176 = New System.Windows.Forms.Label()
        Me.Panel153 = New System.Windows.Forms.Panel()
        Me.Button74 = New System.Windows.Forms.Button()
        Me.TextBox11 = New System.Windows.Forms.TextBox()
        Me.Label177 = New System.Windows.Forms.Label()
        Me.Label178 = New System.Windows.Forms.Label()
        Me.TextBox12 = New System.Windows.Forms.TextBox()
        Me.Panel1.SuspendLayout
        Me.Panel2.SuspendLayout
        Me.FlowLayoutPanel1.SuspendLayout
        Me.Panel3.SuspendLayout
        Me.Panel4.SuspendLayout
        Me.MenuStrip1.SuspendLayout
        Me.Panel5.SuspendLayout
        Me.Panel6.SuspendLayout
        Me.Panel7.SuspendLayout
        Me.Panel36.SuspendLayout
        Me.Panel33.SuspendLayout
        Me.Panel9.SuspendLayout
        Me.Panel8.SuspendLayout
        Me.TabControl1.SuspendLayout
        Me.TabPage_SysInfo.SuspendLayout
        Me.GroupBox2.SuspendLayout
        Me.TabControl4.SuspendLayout
        Me.TabPage1.SuspendLayout
        Me.Panel78.SuspendLayout
        Me.FlowLayoutPanel6.SuspendLayout
        Me.TabPage2.SuspendLayout
        Me.Panel86.SuspendLayout
        Me.FlowLayoutPanel7.SuspendLayout
        Me.TabPage3.SuspendLayout
        Me.Panel87.SuspendLayout
        Me.FlowLayoutPanel8.SuspendLayout
        Me.TabPage4.SuspendLayout
        Me.Panel88.SuspendLayout
        Me.FlowLayoutPanel9.SuspendLayout
        Me.TabPage5.SuspendLayout
        Me.Panel89.SuspendLayout
        Me.FlowLayoutPanel10.SuspendLayout
        Me.GroupBox1.SuspendLayout
        Me.TabPage_Encoding.SuspendLayout
        Me.Panel29.SuspendLayout
        Me.TabControl_Encoding_StringOrFile.SuspendLayout
        Me.TabPage_String.SuspendLayout
        Me.Panel27.SuspendLayout
        Me.TabPage_File.SuspendLayout
        Me.Panel43.SuspendLayout
        Me.Panel35.SuspendLayout
        Me.Panel28.SuspendLayout
        Me.Panel30.SuspendLayout
        Me.Panel32.SuspendLayout
        Me.Panel26.SuspendLayout
        Me.Panel71.SuspendLayout
        Me.Panel70.SuspendLayout
        Me.Panel31.SuspendLayout
        Me.TabPage_RSA.SuspendLayout
        Me.Panel20.SuspendLayout
        Me.FlowLayoutPanel4.SuspendLayout
        Me.Panel21.SuspendLayout
        Me.Panel24.SuspendLayout
        Me.Panel18.SuspendLayout
        Me.Panel19.SuspendLayout
        Me.FlowLayoutPanel3.SuspendLayout
        Me.Panel10.SuspendLayout
        Me.Panel40.SuspendLayout
        Me.Panel34.SuspendLayout
        Me.Panel42.SuspendLayout
        Me.Panel25.SuspendLayout
        Me.Panel23.SuspendLayout
        Me.Panel11.SuspendLayout
        Me.Panel12.SuspendLayout
        Me.Panel13.SuspendLayout
        Me.Panel14.SuspendLayout
        Me.Panel15.SuspendLayout
        Me.FlowLayoutPanel2.SuspendLayout
        Me.Panel16.SuspendLayout
        Me.Panel17.SuspendLayout
        Me.TabPage_AES.SuspendLayout
        Me.TabControl3.SuspendLayout
        Me.TabPage9.SuspendLayout
        Me.TabPage10.SuspendLayout
        Me.Panel41.SuspendLayout
        Me.Panel39.SuspendLayout
        Me.FlowLayoutPanel5.SuspendLayout
        Me.Panel38.SuspendLayout
        Me.TabPage_LicenseGeneration.SuspendLayout
        Me.TabControl2.SuspendLayout
        Me.TabPage_LICFile.SuspendLayout
        Me.Panel69.SuspendLayout
        Me.TabControl_License_Lic_ImportedData.SuspendLayout
        Me.TabPage_DataFields.SuspendLayout
        Me.Panel68.SuspendLayout
        Me.Panel67.SuspendLayout
        Me.Panel66.SuspendLayout
        Me.Panel65.SuspendLayout
        Me.Panel64.SuspendLayout
        Me.Panel63.SuspendLayout
        Me.Panel62.SuspendLayout
        Me.Panel60.SuspendLayout
        Me.Panel61.SuspendLayout
        Me.Panel_License_Lic_Verification.SuspendLayout
        Me.Panel54.SuspendLayout
        Me.Panel50.SuspendLayout
        Me.Panel51.SuspendLayout
        Me.Panel52.SuspendLayout
        Me.Panel53.SuspendLayout
        Me.Panel59.SuspendLayout
        Me.Panel58.SuspendLayout
        Me.Panel57.SuspendLayout
        Me.Panel56.SuspendLayout
        Me.Panel55.SuspendLayout
        Me.Panel49.SuspendLayout
        Me.Panel47.SuspendLayout
        Me.FlowLayoutPanel_License_Lic_Verification.SuspendLayout
        CType(Me.DataGridView_License_Lic_Signature, System.ComponentModel.ISupportInitialize).BeginInit
        Me.Panel45.SuspendLayout
        Me.Panel48.SuspendLayout
        Me.FlowLayoutPanel_License_Lic_AddDataFields.SuspendLayout
        CType(Me.DataGridView_License_Lic_Data, System.ComponentModel.ISupportInitialize).BeginInit
        Me.TabPage11.SuspendLayout
        Me.GroupBox9.SuspendLayout
        Me.Panel134.SuspendLayout
        Me.Panel151.SuspendLayout
        Me.Panel139.SuspendLayout
        Me.Panel135.SuspendLayout
        Me.Panel137.SuspendLayout
        Me.Panel138.SuspendLayout
        Me.Panel130.SuspendLayout
        Me.Panel150.SuspendLayout
        Me.Panel133.SuspendLayout
        Me.Panel132.SuspendLayout
        Me.Panel131.SuspendLayout
        Me.TabPage_Verify.SuspendLayout
        Me.Panel85.SuspendLayout
        Me.Panel82.SuspendLayout
        Me.Panel83.SuspendLayout
        Me.Panel84.SuspendLayout
        Me.Panel81.SuspendLayout
        Me.Panel79.SuspendLayout
        Me.Panel80.SuspendLayout
        Me.Panel76.SuspendLayout
        Me.Panel77.SuspendLayout
        Me.Panel74.SuspendLayout
        Me.Panel75.SuspendLayout
        Me.Panel72.SuspendLayout
        Me.Panel73.SuspendLayout
        Me.TabPage6.SuspendLayout
        Me.TabControl5.SuspendLayout
        Me.TabPage7.SuspendLayout
        Me.GroupBox6.SuspendLayout
        Me.Panel113.SuspendLayout
        Me.Panel112.SuspendLayout
        Me.Panel111.SuspendLayout
        Me.Panel110.SuspendLayout
        Me.Panel109.SuspendLayout
        Me.Panel107.SuspendLayout
        Me.Panel108.SuspendLayout
        Me.Panel106.SuspendLayout
        Me.Panel105.SuspendLayout
        Me.Panel104.SuspendLayout
        Me.Panel103.SuspendLayout
        Me.GroupBox5.SuspendLayout
        Me.Panel94.SuspendLayout
        Me.Panel102.SuspendLayout
        Me.Panel101.SuspendLayout
        Me.Panel100.SuspendLayout
        Me.Panel99.SuspendLayout
        Me.GroupBox4.SuspendLayout
        Me.Panel91.SuspendLayout
        Me.Panel92.SuspendLayout
        Me.Panel93.SuspendLayout
        Me.Panel95.SuspendLayout
        Me.Panel96.SuspendLayout
        Me.Panel97.SuspendLayout
        Me.Panel98.SuspendLayout
        Me.GroupBox3.SuspendLayout
        Me.FlowLayoutPanel11.SuspendLayout
        Me.TabPage8.SuspendLayout
        Me.GroupBox8.SuspendLayout
        Me.Panel129.SuspendLayout
        Me.Panel128.SuspendLayout
        Me.Panel127.SuspendLayout
        Me.Panel125.SuspendLayout
        Me.GroupBox7.SuspendLayout
        Me.Panel121.SuspendLayout
        Me.Panel120.SuspendLayout
        Me.Panel136.SuspendLayout
        Me.Panel119.SuspendLayout
        Me.Panel114.SuspendLayout
        Me.Panel115.SuspendLayout
        Me.Panel116.SuspendLayout
        Me.Panel122.SuspendLayout
        Me.Panel117.SuspendLayout
        Me.Panel123.SuspendLayout
        Me.Panel118.SuspendLayout
        Me.Panel124.SuspendLayout
        Me.GroupBox10.SuspendLayout
        Me.Panel140.SuspendLayout
        Me.Panel141.SuspendLayout
        Me.Panel142.SuspendLayout
        Me.Panel143.SuspendLayout
        Me.Panel144.SuspendLayout
        Me.Panel145.SuspendLayout
        Me.Panel146.SuspendLayout
        Me.Panel147.SuspendLayout
        Me.Panel148.SuspendLayout
        Me.Panel152.SuspendLayout
        Me.Panel153.SuspendLayout
        Me.SuspendLayout
        '
        'Button_Test
        '
        Me.Button_Test.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_Test.Location = New System.Drawing.Point(649, 19)
        Me.Button_Test.Name = "Button_Test"
        Me.Button_Test.Size = New System.Drawing.Size(75, 23)
        Me.Button_Test.TabIndex = 0
        Me.Button_Test.Text = "Show All"
        Me.Button_Test.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Location = New System.Drawing.Point(16, 34)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(619, 92)
        Me.Panel1.TabIndex = 1
        '
        'Panel2
        '
        Me.Panel2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.TextBox_InputData)
        Me.Panel2.Location = New System.Drawing.Point(9, 3)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(602, 89)
        Me.Panel2.TabIndex = 2
        '
        'TextBox_InputData
        '
        Me.TextBox_InputData.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox_InputData.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TextBox_InputData.Location = New System.Drawing.Point(0, 0)
        Me.TextBox_InputData.Multiline = True
        Me.TextBox_InputData.Name = "TextBox_InputData"
        Me.TextBox_InputData.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TextBox_InputData.Size = New System.Drawing.Size(600, 87)
        Me.TextBox_InputData.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(18, 14)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(57, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Input Data"
        '
        'FlowLayoutPanel1
        '
        Me.FlowLayoutPanel1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.FlowLayoutPanel1.Controls.Add(Me.Button_Encrypt)
        Me.FlowLayoutPanel1.Controls.Add(Me.Button_Decrypt)
        Me.FlowLayoutPanel1.Controls.Add(Me.Button_AES_SwapInputOutput)
        Me.FlowLayoutPanel1.Controls.Add(Me.Button_AES_CelarInputOutput)
        Me.FlowLayoutPanel1.Location = New System.Drawing.Point(5, 1)
        Me.FlowLayoutPanel1.Name = "FlowLayoutPanel1"
        Me.FlowLayoutPanel1.Size = New System.Drawing.Size(610, 32)
        Me.FlowLayoutPanel1.TabIndex = 2
        '
        'Button_Encrypt
        '
        Me.Button_Encrypt.Location = New System.Drawing.Point(3, 3)
        Me.Button_Encrypt.Name = "Button_Encrypt"
        Me.Button_Encrypt.Size = New System.Drawing.Size(75, 23)
        Me.Button_Encrypt.TabIndex = 0
        Me.Button_Encrypt.Text = "Encrypt"
        Me.Button_Encrypt.UseVisualStyleBackColor = True
        '
        'Button_Decrypt
        '
        Me.Button_Decrypt.Location = New System.Drawing.Point(84, 3)
        Me.Button_Decrypt.Name = "Button_Decrypt"
        Me.Button_Decrypt.Size = New System.Drawing.Size(75, 23)
        Me.Button_Decrypt.TabIndex = 1
        Me.Button_Decrypt.Text = "Decrypt"
        Me.Button_Decrypt.UseVisualStyleBackColor = True
        '
        'Button_AES_SwapInputOutput
        '
        Me.Button_AES_SwapInputOutput.Location = New System.Drawing.Point(165, 3)
        Me.Button_AES_SwapInputOutput.Name = "Button_AES_SwapInputOutput"
        Me.Button_AES_SwapInputOutput.Size = New System.Drawing.Size(134, 23)
        Me.Button_AES_SwapInputOutput.TabIndex = 24
        Me.Button_AES_SwapInputOutput.Text = "Swap Input and Output"
        Me.Button_AES_SwapInputOutput.UseVisualStyleBackColor = True
        '
        'Button_AES_CelarInputOutput
        '
        Me.Button_AES_CelarInputOutput.Location = New System.Drawing.Point(305, 3)
        Me.Button_AES_CelarInputOutput.Name = "Button_AES_CelarInputOutput"
        Me.Button_AES_CelarInputOutput.Size = New System.Drawing.Size(133, 23)
        Me.Button_AES_CelarInputOutput.TabIndex = 25
        Me.Button_AES_CelarInputOutput.Text = "Clear Input and Output"
        Me.Button_AES_CelarInputOutput.UseVisualStyleBackColor = True
        '
        'Panel3
        '
        Me.Panel3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel3.Controls.Add(Me.FlowLayoutPanel1)
        Me.Panel3.Location = New System.Drawing.Point(16, 131)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(620, 34)
        Me.Panel3.TabIndex = 3
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.MenuStrip1)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel4.Location = New System.Drawing.Point(0, 0)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(803, 38)
        Me.Panel4.TabIndex = 4
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.LightSteelBlue
        Me.MenuStrip1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.HelpToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(803, 38)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 34)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(93, 22)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AboutToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(44, 34)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(107, 22)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'Panel5
        '
        Me.Panel5.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel5.Controls.Add(Me.Button_AES_ClearOutput)
        Me.Panel5.Controls.Add(Me.Panel6)
        Me.Panel5.Controls.Add(Me.Label2)
        Me.Panel5.Location = New System.Drawing.Point(15, 171)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(619, 148)
        Me.Panel5.TabIndex = 5
        '
        'Button_AES_ClearOutput
        '
        Me.Button_AES_ClearOutput.Location = New System.Drawing.Point(77, 5)
        Me.Button_AES_ClearOutput.Name = "Button_AES_ClearOutput"
        Me.Button_AES_ClearOutput.Size = New System.Drawing.Size(52, 23)
        Me.Button_AES_ClearOutput.TabIndex = 23
        Me.Button_AES_ClearOutput.Text = "Clear"
        Me.Button_AES_ClearOutput.UseVisualStyleBackColor = True
        '
        'Panel6
        '
        Me.Panel6.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel6.Controls.Add(Me.TextBox_OutputData)
        Me.Panel6.Location = New System.Drawing.Point(9, 34)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(602, 114)
        Me.Panel6.TabIndex = 2
        '
        'TextBox_OutputData
        '
        Me.TextBox_OutputData.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox_OutputData.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TextBox_OutputData.Location = New System.Drawing.Point(0, 0)
        Me.TextBox_OutputData.Multiline = True
        Me.TextBox_OutputData.Name = "TextBox_OutputData"
        Me.TextBox_OutputData.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TextBox_OutputData.Size = New System.Drawing.Size(600, 112)
        Me.TextBox_OutputData.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(6, 9)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(65, 13)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Output Data"
        '
        'Panel7
        '
        Me.Panel7.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel7.Controls.Add(Me.Panel36)
        Me.Panel7.Controls.Add(Me.Panel33)
        Me.Panel7.Controls.Add(Me.Button_AES_KeyGenHash)
        Me.Panel7.Controls.Add(Me.Panel9)
        Me.Panel7.Controls.Add(Me.Panel8)
        Me.Panel7.Location = New System.Drawing.Point(18, 85)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(660, 107)
        Me.Panel7.TabIndex = 6
        '
        'Panel36
        '
        Me.Panel36.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel36.Controls.Add(Me.CheckBox_AES_Salt)
        Me.Panel36.Controls.Add(Me.Button_AES_SaltGenerate)
        Me.Panel36.Controls.Add(Me.TextBox_AES_Salt)
        Me.Panel36.Location = New System.Drawing.Point(3, 30)
        Me.Panel36.Name = "Panel36"
        Me.Panel36.Size = New System.Drawing.Size(649, 23)
        Me.Panel36.TabIndex = 23
        '
        'CheckBox_AES_Salt
        '
        Me.CheckBox_AES_Salt.AutoSize = True
        Me.CheckBox_AES_Salt.Location = New System.Drawing.Point(3, 3)
        Me.CheckBox_AES_Salt.Name = "CheckBox_AES_Salt"
        Me.CheckBox_AES_Salt.Size = New System.Drawing.Size(92, 17)
        Me.CheckBox_AES_Salt.TabIndex = 23
        Me.CheckBox_AES_Salt.Text = "Salt (Optional)"
        Me.CheckBox_AES_Salt.UseVisualStyleBackColor = True
        '
        'Button_AES_SaltGenerate
        '
        Me.Button_AES_SaltGenerate.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_AES_SaltGenerate.Enabled = False
        Me.Button_AES_SaltGenerate.Location = New System.Drawing.Point(586, -1)
        Me.Button_AES_SaltGenerate.Name = "Button_AES_SaltGenerate"
        Me.Button_AES_SaltGenerate.Size = New System.Drawing.Size(63, 23)
        Me.Button_AES_SaltGenerate.TabIndex = 22
        Me.Button_AES_SaltGenerate.Text = "Auto-Gen"
        Me.Button_AES_SaltGenerate.UseVisualStyleBackColor = True
        '
        'TextBox_AES_Salt
        '
        Me.TextBox_AES_Salt.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_AES_Salt.Enabled = False
        Me.TextBox_AES_Salt.Location = New System.Drawing.Point(105, 0)
        Me.TextBox_AES_Salt.Name = "TextBox_AES_Salt"
        Me.TextBox_AES_Salt.Size = New System.Drawing.Size(480, 20)
        Me.TextBox_AES_Salt.TabIndex = 1
        '
        'Panel33
        '
        Me.Panel33.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel33.Controls.Add(Me.CheckBox_AES_Seed)
        Me.Panel33.Controls.Add(Me.Button_AES_SeedGenerate)
        Me.Panel33.Controls.Add(Me.TextBox_AES_Seed)
        Me.Panel33.Location = New System.Drawing.Point(4, 4)
        Me.Panel33.Name = "Panel33"
        Me.Panel33.Size = New System.Drawing.Size(649, 23)
        Me.Panel33.TabIndex = 2
        '
        'CheckBox_AES_Seed
        '
        Me.CheckBox_AES_Seed.AutoSize = True
        Me.CheckBox_AES_Seed.Location = New System.Drawing.Point(3, 3)
        Me.CheckBox_AES_Seed.Name = "CheckBox_AES_Seed"
        Me.CheckBox_AES_Seed.Size = New System.Drawing.Size(99, 17)
        Me.CheckBox_AES_Seed.TabIndex = 23
        Me.CheckBox_AES_Seed.Text = "Seed (Optional)"
        Me.CheckBox_AES_Seed.UseVisualStyleBackColor = True
        '
        'Button_AES_SeedGenerate
        '
        Me.Button_AES_SeedGenerate.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_AES_SeedGenerate.Enabled = False
        Me.Button_AES_SeedGenerate.Location = New System.Drawing.Point(586, -1)
        Me.Button_AES_SeedGenerate.Name = "Button_AES_SeedGenerate"
        Me.Button_AES_SeedGenerate.Size = New System.Drawing.Size(63, 23)
        Me.Button_AES_SeedGenerate.TabIndex = 22
        Me.Button_AES_SeedGenerate.Text = "Auto-Gen"
        Me.Button_AES_SeedGenerate.UseVisualStyleBackColor = True
        '
        'TextBox_AES_Seed
        '
        Me.TextBox_AES_Seed.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_AES_Seed.Enabled = False
        Me.TextBox_AES_Seed.Location = New System.Drawing.Point(105, 0)
        Me.TextBox_AES_Seed.Name = "TextBox_AES_Seed"
        Me.TextBox_AES_Seed.Size = New System.Drawing.Size(480, 20)
        Me.TextBox_AES_Seed.TabIndex = 1
        '
        'Button_AES_KeyGenHash
        '
        Me.Button_AES_KeyGenHash.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_AES_KeyGenHash.BackColor = System.Drawing.Color.PaleGreen
        Me.Button_AES_KeyGenHash.Location = New System.Drawing.Point(590, 55)
        Me.Button_AES_KeyGenHash.Name = "Button_AES_KeyGenHash"
        Me.Button_AES_KeyGenHash.Size = New System.Drawing.Size(63, 50)
        Me.Button_AES_KeyGenHash.TabIndex = 22
        Me.Button_AES_KeyGenHash.Text = "Generate Keys"
        Me.Button_AES_KeyGenHash.UseVisualStyleBackColor = False
        '
        'Panel9
        '
        Me.Panel9.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel9.Controls.Add(Me.TextBox_IV)
        Me.Panel9.Controls.Add(Me.Label4)
        Me.Panel9.Location = New System.Drawing.Point(3, 82)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(585, 22)
        Me.Panel9.TabIndex = 1
        '
        'TextBox_IV
        '
        Me.TextBox_IV.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_IV.Location = New System.Drawing.Point(106, 0)
        Me.TextBox_IV.Name = "TextBox_IV"
        Me.TextBox_IV.Size = New System.Drawing.Size(479, 20)
        Me.TextBox_IV.TabIndex = 1
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(3, 3)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(17, 13)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "IV"
        '
        'Panel8
        '
        Me.Panel8.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel8.Controls.Add(Me.TextBox_EncryptionKey)
        Me.Panel8.Controls.Add(Me.Label3)
        Me.Panel8.Location = New System.Drawing.Point(3, 56)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(585, 23)
        Me.Panel8.TabIndex = 0
        '
        'TextBox_EncryptionKey
        '
        Me.TextBox_EncryptionKey.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_EncryptionKey.Location = New System.Drawing.Point(106, 0)
        Me.TextBox_EncryptionKey.Name = "TextBox_EncryptionKey"
        Me.TextBox_EncryptionKey.Size = New System.Drawing.Size(479, 20)
        Me.TextBox_EncryptionKey.TabIndex = 1
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(3, 3)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(25, 13)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "Key"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(217, 3)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(81, 23)
        Me.Button1.TabIndex = 7
        Me.Button1.Text = "Admin Rights"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'TabControl1
        '
        Me.TabControl1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TabControl1.Controls.Add(Me.TabPage_SysInfo)
        Me.TabControl1.Controls.Add(Me.TabPage_Encoding)
        Me.TabControl1.Controls.Add(Me.TabPage_RSA)
        Me.TabControl1.Controls.Add(Me.TabPage_AES)
        Me.TabControl1.Controls.Add(Me.TabPage_LicenseGeneration)
        Me.TabControl1.Location = New System.Drawing.Point(12, 44)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(779, 655)
        Me.TabControl1.TabIndex = 8
        '
        'TabPage_SysInfo
        '
        Me.TabPage_SysInfo.AutoScroll = True
        Me.TabPage_SysInfo.Controls.Add(Me.GroupBox2)
        Me.TabPage_SysInfo.Controls.Add(Me.GroupBox1)
        Me.TabPage_SysInfo.Location = New System.Drawing.Point(4, 22)
        Me.TabPage_SysInfo.Name = "TabPage_SysInfo"
        Me.TabPage_SysInfo.Size = New System.Drawing.Size(771, 629)
        Me.TabPage_SysInfo.TabIndex = 4
        Me.TabPage_SysInfo.Text = "System Info"
        Me.TabPage_SysInfo.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox2.Controls.Add(Me.Label80)
        Me.GroupBox2.Controls.Add(Me.TabControl4)
        Me.GroupBox2.Controls.Add(Me.Button_Test)
        Me.GroupBox2.Location = New System.Drawing.Point(15, 22)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(738, 253)
        Me.GroupBox2.TabIndex = 20
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "System Info"
        '
        'Label80
        '
        Me.Label80.AutoSize = True
        Me.Label80.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label80.Location = New System.Drawing.Point(10, 24)
        Me.Label80.Name = "Label80"
        Me.Label80.Size = New System.Drawing.Size(123, 13)
        Me.Label80.TabIndex = 22
        Me.Label80.Text = "Show system information"
        '
        'TabControl4
        '
        Me.TabControl4.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TabControl4.Controls.Add(Me.TabPage1)
        Me.TabControl4.Controls.Add(Me.TabPage2)
        Me.TabControl4.Controls.Add(Me.TabPage3)
        Me.TabControl4.Controls.Add(Me.TabPage4)
        Me.TabControl4.Controls.Add(Me.TabPage5)
        Me.TabControl4.Location = New System.Drawing.Point(6, 48)
        Me.TabControl4.Name = "TabControl4"
        Me.TabControl4.SelectedIndex = 0
        Me.TabControl4.Size = New System.Drawing.Size(726, 199)
        Me.TabControl4.TabIndex = 21
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.Panel78)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(718, 173)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Computer"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'Panel78
        '
        Me.Panel78.AutoScroll = True
        Me.Panel78.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel78.Controls.Add(Me.FlowLayoutPanel6)
        Me.Panel78.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel78.Location = New System.Drawing.Point(3, 3)
        Me.Panel78.Name = "Panel78"
        Me.Panel78.Size = New System.Drawing.Size(712, 167)
        Me.Panel78.TabIndex = 20
        '
        'FlowLayoutPanel6
        '
        Me.FlowLayoutPanel6.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.FlowLayoutPanel6.Controls.Add(Me.Button10)
        Me.FlowLayoutPanel6.Controls.Add(Me.Button14)
        Me.FlowLayoutPanel6.Controls.Add(Me.Button15)
        Me.FlowLayoutPanel6.Controls.Add(Me.Button16)
        Me.FlowLayoutPanel6.Controls.Add(Me.Button17)
        Me.FlowLayoutPanel6.Controls.Add(Me.Button18)
        Me.FlowLayoutPanel6.Controls.Add(Me.Button19)
        Me.FlowLayoutPanel6.Controls.Add(Me.Button20)
        Me.FlowLayoutPanel6.Controls.Add(Me.Button21)
        Me.FlowLayoutPanel6.Controls.Add(Me.Button22)
        Me.FlowLayoutPanel6.Controls.Add(Me.Button23)
        Me.FlowLayoutPanel6.Controls.Add(Me.Button24)
        Me.FlowLayoutPanel6.Controls.Add(Me.Button25)
        Me.FlowLayoutPanel6.Controls.Add(Me.Button26)
        Me.FlowLayoutPanel6.Controls.Add(Me.Button27)
        Me.FlowLayoutPanel6.Controls.Add(Me.Button28)
        Me.FlowLayoutPanel6.Controls.Add(Me.Button29)
        Me.FlowLayoutPanel6.Controls.Add(Me.Button30)
        Me.FlowLayoutPanel6.Location = New System.Drawing.Point(3, 3)
        Me.FlowLayoutPanel6.Name = "FlowLayoutPanel6"
        Me.FlowLayoutPanel6.Size = New System.Drawing.Size(704, 160)
        Me.FlowLayoutPanel6.TabIndex = 19
        '
        'Button10
        '
        Me.Button10.Location = New System.Drawing.Point(3, 3)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(75, 23)
        Me.Button10.TabIndex = 0
        Me.Button10.Text = "Hostname"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Button14
        '
        Me.Button14.Location = New System.Drawing.Point(84, 3)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(75, 23)
        Me.Button14.TabIndex = 1
        Me.Button14.Text = "Domain"
        Me.Button14.UseVisualStyleBackColor = True
        '
        'Button15
        '
        Me.Button15.Location = New System.Drawing.Point(165, 3)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(75, 23)
        Me.Button15.TabIndex = 2
        Me.Button15.Text = "Make"
        Me.Button15.UseVisualStyleBackColor = True
        '
        'Button16
        '
        Me.Button16.Location = New System.Drawing.Point(246, 3)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(75, 23)
        Me.Button16.TabIndex = 3
        Me.Button16.Text = "Model"
        Me.Button16.UseVisualStyleBackColor = True
        '
        'Button17
        '
        Me.Button17.Location = New System.Drawing.Point(327, 3)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(101, 23)
        Me.Button17.TabIndex = 4
        Me.Button17.Text = "System Model"
        Me.Button17.UseVisualStyleBackColor = True
        '
        'Button18
        '
        Me.Button18.Location = New System.Drawing.Point(434, 3)
        Me.Button18.Name = "Button18"
        Me.Button18.Size = New System.Drawing.Size(119, 23)
        Me.Button18.TabIndex = 5
        Me.Button18.Text = "System Model Full"
        Me.Button18.UseVisualStyleBackColor = True
        '
        'Button19
        '
        Me.Button19.Location = New System.Drawing.Point(559, 3)
        Me.Button19.Name = "Button19"
        Me.Button19.Size = New System.Drawing.Size(75, 23)
        Me.Button19.TabIndex = 6
        Me.Button19.Text = "BIOS Serial"
        Me.Button19.UseVisualStyleBackColor = True
        '
        'Button20
        '
        Me.Button20.Location = New System.Drawing.Point(3, 32)
        Me.Button20.Name = "Button20"
        Me.Button20.Size = New System.Drawing.Size(108, 23)
        Me.Button20.TabIndex = 7
        Me.Button20.Text = "Motherboard Serial"
        Me.Button20.UseVisualStyleBackColor = True
        '
        'Button21
        '
        Me.Button21.Location = New System.Drawing.Point(117, 32)
        Me.Button21.Name = "Button21"
        Me.Button21.Size = New System.Drawing.Size(144, 23)
        Me.Button21.TabIndex = 8
        Me.Button21.Text = "Motherboard Base Product"
        Me.Button21.UseVisualStyleBackColor = True
        '
        'Button22
        '
        Me.Button22.Location = New System.Drawing.Point(267, 32)
        Me.Button22.Name = "Button22"
        Me.Button22.Size = New System.Drawing.Size(75, 23)
        Me.Button22.TabIndex = 9
        Me.Button22.Text = "UUID"
        Me.Button22.UseVisualStyleBackColor = True
        '
        'Button23
        '
        Me.Button23.Location = New System.Drawing.Point(348, 32)
        Me.Button23.Name = "Button23"
        Me.Button23.Size = New System.Drawing.Size(75, 23)
        Me.Button23.TabIndex = 10
        Me.Button23.Text = "CPU Name"
        Me.Button23.UseVisualStyleBackColor = True
        '
        'Button24
        '
        Me.Button24.Location = New System.Drawing.Point(429, 32)
        Me.Button24.Name = "Button24"
        Me.Button24.Size = New System.Drawing.Size(75, 23)
        Me.Button24.TabIndex = 11
        Me.Button24.Text = "CPU Count"
        Me.Button24.UseVisualStyleBackColor = True
        '
        'Button25
        '
        Me.Button25.Location = New System.Drawing.Point(510, 32)
        Me.Button25.Name = "Button25"
        Me.Button25.Size = New System.Drawing.Size(75, 23)
        Me.Button25.TabIndex = 12
        Me.Button25.Text = "CPU Cores"
        Me.Button25.UseVisualStyleBackColor = True
        '
        'Button26
        '
        Me.Button26.Location = New System.Drawing.Point(591, 32)
        Me.Button26.Name = "Button26"
        Me.Button26.Size = New System.Drawing.Size(83, 23)
        Me.Button26.TabIndex = 13
        Me.Button26.Text = "CPU Threads"
        Me.Button26.UseVisualStyleBackColor = True
        '
        'Button27
        '
        Me.Button27.Location = New System.Drawing.Point(3, 61)
        Me.Button27.Name = "Button27"
        Me.Button27.Size = New System.Drawing.Size(75, 23)
        Me.Button27.TabIndex = 14
        Me.Button27.Text = "CPU Speed"
        Me.Button27.UseVisualStyleBackColor = True
        '
        'Button28
        '
        Me.Button28.Location = New System.Drawing.Point(84, 61)
        Me.Button28.Name = "Button28"
        Me.Button28.Size = New System.Drawing.Size(107, 23)
        Me.Button28.TabIndex = 15
        Me.Button28.Text = "CPU Architecture"
        Me.Button28.UseVisualStyleBackColor = True
        '
        'Button29
        '
        Me.Button29.Location = New System.Drawing.Point(197, 61)
        Me.Button29.Name = "Button29"
        Me.Button29.Size = New System.Drawing.Size(75, 23)
        Me.Button29.TabIndex = 16
        Me.Button29.Text = "RAM Size"
        Me.Button29.UseVisualStyleBackColor = True
        '
        'Button30
        '
        Me.Button30.Location = New System.Drawing.Point(278, 61)
        Me.Button30.Name = "Button30"
        Me.Button30.Size = New System.Drawing.Size(75, 23)
        Me.Button30.TabIndex = 17
        Me.Button30.Text = "RAM Speed"
        Me.Button30.UseVisualStyleBackColor = True
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.Panel86)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(718, 173)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "OS"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'Panel86
        '
        Me.Panel86.AutoScroll = True
        Me.Panel86.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel86.Controls.Add(Me.FlowLayoutPanel7)
        Me.Panel86.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel86.Location = New System.Drawing.Point(3, 3)
        Me.Panel86.Name = "Panel86"
        Me.Panel86.Size = New System.Drawing.Size(712, 167)
        Me.Panel86.TabIndex = 21
        '
        'FlowLayoutPanel7
        '
        Me.FlowLayoutPanel7.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.FlowLayoutPanel7.Controls.Add(Me.Button33)
        Me.FlowLayoutPanel7.Controls.Add(Me.Button31)
        Me.FlowLayoutPanel7.Controls.Add(Me.Button32)
        Me.FlowLayoutPanel7.Controls.Add(Me.Button34)
        Me.FlowLayoutPanel7.Controls.Add(Me.Button35)
        Me.FlowLayoutPanel7.Location = New System.Drawing.Point(3, 3)
        Me.FlowLayoutPanel7.Name = "FlowLayoutPanel7"
        Me.FlowLayoutPanel7.Size = New System.Drawing.Size(704, 159)
        Me.FlowLayoutPanel7.TabIndex = 19
        '
        'Button33
        '
        Me.Button33.Location = New System.Drawing.Point(3, 3)
        Me.Button33.Name = "Button33"
        Me.Button33.Size = New System.Drawing.Size(75, 23)
        Me.Button33.TabIndex = 20
        Me.Button33.Text = "OS Version"
        Me.Button33.UseVisualStyleBackColor = True
        '
        'Button31
        '
        Me.Button31.Location = New System.Drawing.Point(84, 3)
        Me.Button31.Name = "Button31"
        Me.Button31.Size = New System.Drawing.Size(75, 23)
        Me.Button31.TabIndex = 18
        Me.Button31.Text = "OS Name"
        Me.Button31.UseVisualStyleBackColor = True
        '
        'Button32
        '
        Me.Button32.Location = New System.Drawing.Point(165, 3)
        Me.Button32.Name = "Button32"
        Me.Button32.Size = New System.Drawing.Size(75, 23)
        Me.Button32.TabIndex = 19
        Me.Button32.Text = "OS Build"
        Me.Button32.UseVisualStyleBackColor = True
        '
        'Button34
        '
        Me.Button34.Location = New System.Drawing.Point(246, 3)
        Me.Button34.Name = "Button34"
        Me.Button34.Size = New System.Drawing.Size(94, 23)
        Me.Button34.TabIndex = 21
        Me.Button34.Text = "OS Arcitecture"
        Me.Button34.UseVisualStyleBackColor = True
        '
        'Button35
        '
        Me.Button35.Location = New System.Drawing.Point(346, 3)
        Me.Button35.Name = "Button35"
        Me.Button35.Size = New System.Drawing.Size(126, 23)
        Me.Button35.TabIndex = 22
        Me.Button35.Text = "OS Service Channel"
        Me.Button35.UseVisualStyleBackColor = True
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.Panel87)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(718, 173)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Hard Drive"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'Panel87
        '
        Me.Panel87.AutoScroll = True
        Me.Panel87.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel87.Controls.Add(Me.FlowLayoutPanel8)
        Me.Panel87.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel87.Location = New System.Drawing.Point(3, 3)
        Me.Panel87.Name = "Panel87"
        Me.Panel87.Size = New System.Drawing.Size(712, 167)
        Me.Panel87.TabIndex = 22
        '
        'FlowLayoutPanel8
        '
        Me.FlowLayoutPanel8.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.FlowLayoutPanel8.Controls.Add(Me.Button36)
        Me.FlowLayoutPanel8.Controls.Add(Me.Button37)
        Me.FlowLayoutPanel8.Controls.Add(Me.Button38)
        Me.FlowLayoutPanel8.Controls.Add(Me.Button39)
        Me.FlowLayoutPanel8.Controls.Add(Me.Button40)
        Me.FlowLayoutPanel8.Controls.Add(Me.Button41)
        Me.FlowLayoutPanel8.Controls.Add(Me.Button42)
        Me.FlowLayoutPanel8.Controls.Add(Me.Button43)
        Me.FlowLayoutPanel8.Controls.Add(Me.Button44)
        Me.FlowLayoutPanel8.Controls.Add(Me.Button45)
        Me.FlowLayoutPanel8.Controls.Add(Me.Button46)
        Me.FlowLayoutPanel8.Controls.Add(Me.Button47)
        Me.FlowLayoutPanel8.Controls.Add(Me.Button48)
        Me.FlowLayoutPanel8.Location = New System.Drawing.Point(3, 3)
        Me.FlowLayoutPanel8.Name = "FlowLayoutPanel8"
        Me.FlowLayoutPanel8.Size = New System.Drawing.Size(704, 159)
        Me.FlowLayoutPanel8.TabIndex = 19
        '
        'Button36
        '
        Me.Button36.Location = New System.Drawing.Point(3, 3)
        Me.Button36.Name = "Button36"
        Me.Button36.Size = New System.Drawing.Size(75, 23)
        Me.Button36.TabIndex = 23
        Me.Button36.Text = "Drive Count"
        Me.Button36.UseVisualStyleBackColor = True
        '
        'Button37
        '
        Me.Button37.Location = New System.Drawing.Point(84, 3)
        Me.Button37.Name = "Button37"
        Me.Button37.Size = New System.Drawing.Size(93, 23)
        Me.Button37.TabIndex = 24
        Me.Button37.Text = "PNP Device ID"
        Me.Button37.UseVisualStyleBackColor = True
        '
        'Button38
        '
        Me.Button38.Location = New System.Drawing.Point(183, 3)
        Me.Button38.Name = "Button38"
        Me.Button38.Size = New System.Drawing.Size(120, 23)
        Me.Button38.TabIndex = 25
        Me.Button38.Text = "Drive Serial Number"
        Me.Button38.UseVisualStyleBackColor = True
        '
        'Button39
        '
        Me.Button39.Location = New System.Drawing.Point(309, 3)
        Me.Button39.Name = "Button39"
        Me.Button39.Size = New System.Drawing.Size(127, 23)
        Me.Button39.TabIndex = 26
        Me.Button39.Text = "Volume Serial Number"
        Me.Button39.UseVisualStyleBackColor = True
        '
        'Button40
        '
        Me.Button40.Location = New System.Drawing.Point(442, 3)
        Me.Button40.Name = "Button40"
        Me.Button40.Size = New System.Drawing.Size(75, 23)
        Me.Button40.TabIndex = 27
        Me.Button40.Text = "Model"
        Me.Button40.UseVisualStyleBackColor = True
        '
        'Button41
        '
        Me.Button41.Location = New System.Drawing.Point(523, 3)
        Me.Button41.Name = "Button41"
        Me.Button41.Size = New System.Drawing.Size(97, 23)
        Me.Button41.TabIndex = 28
        Me.Button41.Text = "Disk Device ID"
        Me.Button41.UseVisualStyleBackColor = True
        '
        'Button42
        '
        Me.Button42.Location = New System.Drawing.Point(626, 3)
        Me.Button42.Name = "Button42"
        Me.Button42.Size = New System.Drawing.Size(75, 23)
        Me.Button42.TabIndex = 29
        Me.Button42.Text = "Size Bytes"
        Me.Button42.UseVisualStyleBackColor = True
        '
        'Button43
        '
        Me.Button43.Location = New System.Drawing.Point(3, 32)
        Me.Button43.Name = "Button43"
        Me.Button43.Size = New System.Drawing.Size(75, 23)
        Me.Button43.TabIndex = 30
        Me.Button43.Text = "Size GB"
        Me.Button43.UseVisualStyleBackColor = True
        '
        'Button44
        '
        Me.Button44.Location = New System.Drawing.Point(84, 32)
        Me.Button44.Name = "Button44"
        Me.Button44.Size = New System.Drawing.Size(101, 23)
        Me.Button44.TabIndex = 31
        Me.Button44.Text = "Free Space Bytes"
        Me.Button44.UseVisualStyleBackColor = True
        '
        'Button45
        '
        Me.Button45.Location = New System.Drawing.Point(191, 32)
        Me.Button45.Name = "Button45"
        Me.Button45.Size = New System.Drawing.Size(93, 23)
        Me.Button45.TabIndex = 32
        Me.Button45.Text = "Free Space GB"
        Me.Button45.UseVisualStyleBackColor = True
        '
        'Button46
        '
        Me.Button46.Location = New System.Drawing.Point(290, 32)
        Me.Button46.Name = "Button46"
        Me.Button46.Size = New System.Drawing.Size(103, 23)
        Me.Button46.TabIndex = 33
        Me.Button46.Text = "Drive Letter(s)"
        Me.Button46.UseVisualStyleBackColor = True
        '
        'Button47
        '
        Me.Button47.Location = New System.Drawing.Point(399, 32)
        Me.Button47.Name = "Button47"
        Me.Button47.Size = New System.Drawing.Size(103, 23)
        Me.Button47.TabIndex = 34
        Me.Button47.Text = "Volume Name"
        Me.Button47.UseVisualStyleBackColor = True
        '
        'Button48
        '
        Me.Button48.Location = New System.Drawing.Point(508, 32)
        Me.Button48.Name = "Button48"
        Me.Button48.Size = New System.Drawing.Size(75, 23)
        Me.Button48.TabIndex = 35
        Me.Button48.Text = "File System"
        Me.Button48.UseVisualStyleBackColor = True
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.Panel88)
        Me.TabPage4.Location = New System.Drawing.Point(4, 22)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(718, 173)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Network"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'Panel88
        '
        Me.Panel88.AutoScroll = True
        Me.Panel88.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel88.Controls.Add(Me.FlowLayoutPanel9)
        Me.Panel88.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel88.Location = New System.Drawing.Point(3, 3)
        Me.Panel88.Name = "Panel88"
        Me.Panel88.Size = New System.Drawing.Size(712, 167)
        Me.Panel88.TabIndex = 23
        '
        'FlowLayoutPanel9
        '
        Me.FlowLayoutPanel9.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.FlowLayoutPanel9.Controls.Add(Me.Button49)
        Me.FlowLayoutPanel9.Controls.Add(Me.Button50)
        Me.FlowLayoutPanel9.Controls.Add(Me.Button51)
        Me.FlowLayoutPanel9.Controls.Add(Me.Button52)
        Me.FlowLayoutPanel9.Controls.Add(Me.Button53)
        Me.FlowLayoutPanel9.Controls.Add(Me.Button54)
        Me.FlowLayoutPanel9.Location = New System.Drawing.Point(3, 3)
        Me.FlowLayoutPanel9.Name = "FlowLayoutPanel9"
        Me.FlowLayoutPanel9.Size = New System.Drawing.Size(704, 159)
        Me.FlowLayoutPanel9.TabIndex = 19
        '
        'Button49
        '
        Me.Button49.Location = New System.Drawing.Point(3, 3)
        Me.Button49.Name = "Button49"
        Me.Button49.Size = New System.Drawing.Size(105, 23)
        Me.Button49.TabIndex = 0
        Me.Button49.Text = "NIC Description"
        Me.Button49.UseVisualStyleBackColor = True
        '
        'Button50
        '
        Me.Button50.Location = New System.Drawing.Point(114, 3)
        Me.Button50.Name = "Button50"
        Me.Button50.Size = New System.Drawing.Size(95, 23)
        Me.Button50.TabIndex = 1
        Me.Button50.Text = "IPv4 Address"
        Me.Button50.UseVisualStyleBackColor = True
        '
        'Button51
        '
        Me.Button51.Location = New System.Drawing.Point(215, 3)
        Me.Button51.Name = "Button51"
        Me.Button51.Size = New System.Drawing.Size(93, 23)
        Me.Button51.TabIndex = 2
        Me.Button51.Text = "MAC Address"
        Me.Button51.UseVisualStyleBackColor = True
        '
        'Button52
        '
        Me.Button52.Location = New System.Drawing.Point(314, 3)
        Me.Button52.Name = "Button52"
        Me.Button52.Size = New System.Drawing.Size(94, 23)
        Me.Button52.TabIndex = 3
        Me.Button52.Text = "Subnet Mask"
        Me.Button52.UseVisualStyleBackColor = True
        '
        'Button53
        '
        Me.Button53.Location = New System.Drawing.Point(414, 3)
        Me.Button53.Name = "Button53"
        Me.Button53.Size = New System.Drawing.Size(107, 23)
        Me.Button53.TabIndex = 4
        Me.Button53.Text = "Default Gateway"
        Me.Button53.UseVisualStyleBackColor = True
        '
        'Button54
        '
        Me.Button54.Location = New System.Drawing.Point(527, 3)
        Me.Button54.Name = "Button54"
        Me.Button54.Size = New System.Drawing.Size(115, 23)
        Me.Button54.TabIndex = 5
        Me.Button54.Text = "DNS Domain Suffix"
        Me.Button54.UseVisualStyleBackColor = True
        '
        'TabPage5
        '
        Me.TabPage5.Controls.Add(Me.Panel89)
        Me.TabPage5.Location = New System.Drawing.Point(4, 22)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage5.Size = New System.Drawing.Size(718, 173)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "User"
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'Panel89
        '
        Me.Panel89.AutoScroll = True
        Me.Panel89.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel89.Controls.Add(Me.FlowLayoutPanel10)
        Me.Panel89.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel89.Location = New System.Drawing.Point(3, 3)
        Me.Panel89.Name = "Panel89"
        Me.Panel89.Size = New System.Drawing.Size(712, 167)
        Me.Panel89.TabIndex = 23
        '
        'FlowLayoutPanel10
        '
        Me.FlowLayoutPanel10.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.FlowLayoutPanel10.Controls.Add(Me.Button55)
        Me.FlowLayoutPanel10.Controls.Add(Me.Button56)
        Me.FlowLayoutPanel10.Controls.Add(Me.Button1)
        Me.FlowLayoutPanel10.Location = New System.Drawing.Point(3, 3)
        Me.FlowLayoutPanel10.Name = "FlowLayoutPanel10"
        Me.FlowLayoutPanel10.Size = New System.Drawing.Size(687, 159)
        Me.FlowLayoutPanel10.TabIndex = 19
        '
        'Button55
        '
        Me.Button55.Location = New System.Drawing.Point(3, 3)
        Me.Button55.Name = "Button55"
        Me.Button55.Size = New System.Drawing.Size(75, 23)
        Me.Button55.TabIndex = 8
        Me.Button55.Text = "Username"
        Me.Button55.UseVisualStyleBackColor = True
        '
        'Button56
        '
        Me.Button56.Location = New System.Drawing.Point(84, 3)
        Me.Button56.Name = "Button56"
        Me.Button56.Size = New System.Drawing.Size(127, 23)
        Me.Button56.TabIndex = 9
        Me.Button56.Text = "Domain and Username"
        Me.Button56.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox1.Controls.Add(Me.CheckBox_System_Include_UUID)
        Me.GroupBox1.Controls.Add(Me.CheckBox_System_Include_MotherboardBaseBoardProduct)
        Me.GroupBox1.Controls.Add(Me.CheckBox_System_Include_MotherboardSerial)
        Me.GroupBox1.Controls.Add(Me.CheckBox_System_Include_BIOSSerial)
        Me.GroupBox1.Controls.Add(Me.CheckBox_System_Include_SystemModelFull)
        Me.GroupBox1.Controls.Add(Me.CheckBox_System_Include_SystemModel)
        Me.GroupBox1.Controls.Add(Me.CheckBox_System_Include_Model)
        Me.GroupBox1.Controls.Add(Me.CheckBox_System_Include_Make)
        Me.GroupBox1.Controls.Add(Me.Button5)
        Me.GroupBox1.Controls.Add(Me.Button3)
        Me.GroupBox1.Controls.Add(Me.Button7)
        Me.GroupBox1.Controls.Add(Me.ListBox1)
        Me.GroupBox1.Controls.Add(Me.Button13)
        Me.GroupBox1.Controls.Add(Me.ListBox3)
        Me.GroupBox1.Controls.Add(Me.ListBox2)
        Me.GroupBox1.Controls.Add(Me.Button2)
        Me.GroupBox1.Controls.Add(Me.Button4)
        Me.GroupBox1.Location = New System.Drawing.Point(15, 313)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(738, 302)
        Me.GroupBox1.TabIndex = 18
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Fingerprints"
        '
        'CheckBox_System_Include_UUID
        '
        Me.CheckBox_System_Include_UUID.Appearance = System.Windows.Forms.Appearance.Button
        Me.CheckBox_System_Include_UUID.AutoSize = True
        Me.CheckBox_System_Include_UUID.Checked = True
        Me.CheckBox_System_Include_UUID.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox_System_Include_UUID.Location = New System.Drawing.Point(360, 51)
        Me.CheckBox_System_Include_UUID.Name = "CheckBox_System_Include_UUID"
        Me.CheckBox_System_Include_UUID.Size = New System.Drawing.Size(44, 23)
        Me.CheckBox_System_Include_UUID.TabIndex = 25
        Me.CheckBox_System_Include_UUID.Text = "UUID"
        Me.CheckBox_System_Include_UUID.UseVisualStyleBackColor = True
        '
        'CheckBox_System_Include_MotherboardBaseBoardProduct
        '
        Me.CheckBox_System_Include_MotherboardBaseBoardProduct.Appearance = System.Windows.Forms.Appearance.Button
        Me.CheckBox_System_Include_MotherboardBaseBoardProduct.AutoSize = True
        Me.CheckBox_System_Include_MotherboardBaseBoardProduct.Checked = True
        Me.CheckBox_System_Include_MotherboardBaseBoardProduct.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox_System_Include_MotherboardBaseBoardProduct.Location = New System.Drawing.Point(179, 51)
        Me.CheckBox_System_Include_MotherboardBaseBoardProduct.Name = "CheckBox_System_Include_MotherboardBaseBoardProduct"
        Me.CheckBox_System_Include_MotherboardBaseBoardProduct.Size = New System.Drawing.Size(175, 23)
        Me.CheckBox_System_Include_MotherboardBaseBoardProduct.TabIndex = 24
        Me.CheckBox_System_Include_MotherboardBaseBoardProduct.Text = "Motherboard Base Board Product"
        Me.CheckBox_System_Include_MotherboardBaseBoardProduct.UseVisualStyleBackColor = True
        '
        'CheckBox_System_Include_MotherboardSerial
        '
        Me.CheckBox_System_Include_MotherboardSerial.Appearance = System.Windows.Forms.Appearance.Button
        Me.CheckBox_System_Include_MotherboardSerial.AutoSize = True
        Me.CheckBox_System_Include_MotherboardSerial.Checked = True
        Me.CheckBox_System_Include_MotherboardSerial.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox_System_Include_MotherboardSerial.Location = New System.Drawing.Point(555, 23)
        Me.CheckBox_System_Include_MotherboardSerial.Name = "CheckBox_System_Include_MotherboardSerial"
        Me.CheckBox_System_Include_MotherboardSerial.Size = New System.Drawing.Size(106, 23)
        Me.CheckBox_System_Include_MotherboardSerial.TabIndex = 23
        Me.CheckBox_System_Include_MotherboardSerial.Text = "Motherboard Serial"
        Me.CheckBox_System_Include_MotherboardSerial.UseVisualStyleBackColor = True
        '
        'CheckBox_System_Include_BIOSSerial
        '
        Me.CheckBox_System_Include_BIOSSerial.Appearance = System.Windows.Forms.Appearance.Button
        Me.CheckBox_System_Include_BIOSSerial.AutoSize = True
        Me.CheckBox_System_Include_BIOSSerial.Checked = True
        Me.CheckBox_System_Include_BIOSSerial.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox_System_Include_BIOSSerial.Location = New System.Drawing.Point(478, 23)
        Me.CheckBox_System_Include_BIOSSerial.Name = "CheckBox_System_Include_BIOSSerial"
        Me.CheckBox_System_Include_BIOSSerial.Size = New System.Drawing.Size(71, 23)
        Me.CheckBox_System_Include_BIOSSerial.TabIndex = 22
        Me.CheckBox_System_Include_BIOSSerial.Text = "BIOS Serial"
        Me.CheckBox_System_Include_BIOSSerial.UseVisualStyleBackColor = True
        '
        'CheckBox_System_Include_SystemModelFull
        '
        Me.CheckBox_System_Include_SystemModelFull.Appearance = System.Windows.Forms.Appearance.Button
        Me.CheckBox_System_Include_SystemModelFull.AutoSize = True
        Me.CheckBox_System_Include_SystemModelFull.Checked = True
        Me.CheckBox_System_Include_SystemModelFull.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox_System_Include_SystemModelFull.Location = New System.Drawing.Point(370, 23)
        Me.CheckBox_System_Include_SystemModelFull.Name = "CheckBox_System_Include_SystemModelFull"
        Me.CheckBox_System_Include_SystemModelFull.Size = New System.Drawing.Size(102, 23)
        Me.CheckBox_System_Include_SystemModelFull.TabIndex = 21
        Me.CheckBox_System_Include_SystemModelFull.Text = "System Model Full"
        Me.CheckBox_System_Include_SystemModelFull.UseVisualStyleBackColor = True
        '
        'CheckBox_System_Include_SystemModel
        '
        Me.CheckBox_System_Include_SystemModel.Appearance = System.Windows.Forms.Appearance.Button
        Me.CheckBox_System_Include_SystemModel.AutoSize = True
        Me.CheckBox_System_Include_SystemModel.Checked = True
        Me.CheckBox_System_Include_SystemModel.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox_System_Include_SystemModel.Location = New System.Drawing.Point(281, 23)
        Me.CheckBox_System_Include_SystemModel.Name = "CheckBox_System_Include_SystemModel"
        Me.CheckBox_System_Include_SystemModel.Size = New System.Drawing.Size(83, 23)
        Me.CheckBox_System_Include_SystemModel.TabIndex = 20
        Me.CheckBox_System_Include_SystemModel.Text = "System Model"
        Me.CheckBox_System_Include_SystemModel.UseVisualStyleBackColor = True
        '
        'CheckBox_System_Include_Model
        '
        Me.CheckBox_System_Include_Model.Appearance = System.Windows.Forms.Appearance.Button
        Me.CheckBox_System_Include_Model.AutoSize = True
        Me.CheckBox_System_Include_Model.Checked = True
        Me.CheckBox_System_Include_Model.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox_System_Include_Model.Location = New System.Drawing.Point(229, 23)
        Me.CheckBox_System_Include_Model.Name = "CheckBox_System_Include_Model"
        Me.CheckBox_System_Include_Model.Size = New System.Drawing.Size(46, 23)
        Me.CheckBox_System_Include_Model.TabIndex = 19
        Me.CheckBox_System_Include_Model.Text = "Model"
        Me.CheckBox_System_Include_Model.UseVisualStyleBackColor = True
        '
        'CheckBox_System_Include_Make
        '
        Me.CheckBox_System_Include_Make.Appearance = System.Windows.Forms.Appearance.Button
        Me.CheckBox_System_Include_Make.AutoSize = True
        Me.CheckBox_System_Include_Make.Checked = True
        Me.CheckBox_System_Include_Make.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox_System_Include_Make.Location = New System.Drawing.Point(179, 23)
        Me.CheckBox_System_Include_Make.Name = "CheckBox_System_Include_Make"
        Me.CheckBox_System_Include_Make.Size = New System.Drawing.Size(44, 23)
        Me.CheckBox_System_Include_Make.TabIndex = 18
        Me.CheckBox_System_Include_Make.Text = "Make"
        Me.CheckBox_System_Include_Make.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(21, 23)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(112, 23)
        Me.Button5.TabIndex = 11
        Me.Button5.Text = "Computer Fingerprint"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button3.Location = New System.Drawing.Point(668, 135)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(49, 23)
        Me.Button3.TabIndex = 10
        Me.Button3.Text = "Clear"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button7.Location = New System.Drawing.Point(668, 241)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(49, 23)
        Me.Button7.TabIndex = 17
        Me.Button7.Text = "Clear"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'ListBox1
        '
        Me.ListBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Location = New System.Drawing.Point(19, 164)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.ListBox1.Size = New System.Drawing.Size(698, 69)
        Me.ListBox1.TabIndex = 9
        '
        'Button13
        '
        Me.Button13.Location = New System.Drawing.Point(19, 241)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(205, 23)
        Me.Button13.TabIndex = 15
        Me.Button13.Text = "HardDrive Fingerprint app runs from" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Button13.UseVisualStyleBackColor = True
        '
        'ListBox3
        '
        Me.ListBox3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ListBox3.FormattingEnabled = True
        Me.ListBox3.Location = New System.Drawing.Point(19, 270)
        Me.ListBox3.Name = "ListBox3"
        Me.ListBox3.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.ListBox3.Size = New System.Drawing.Size(698, 17)
        Me.ListBox3.TabIndex = 16
        '
        'ListBox2
        '
        Me.ListBox2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ListBox2.FormattingEnabled = True
        Me.ListBox2.Location = New System.Drawing.Point(21, 83)
        Me.ListBox2.Name = "ListBox2"
        Me.ListBox2.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.ListBox2.Size = New System.Drawing.Size(640, 17)
        Me.ListBox2.TabIndex = 12
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(19, 135)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(156, 23)
        Me.Button2.TabIndex = 8
        Me.Button2.Text = "HardDrive Fingerprint(s)"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button4.Location = New System.Drawing.Point(667, 81)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(49, 23)
        Me.Button4.TabIndex = 13
        Me.Button4.Text = "Clear"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'TabPage_Encoding
        '
        Me.TabPage_Encoding.AutoScroll = True
        Me.TabPage_Encoding.Controls.Add(Me.Panel44)
        Me.TabPage_Encoding.Controls.Add(Me.Label23)
        Me.TabPage_Encoding.Controls.Add(Me.Panel29)
        Me.TabPage_Encoding.Controls.Add(Me.Label20)
        Me.TabPage_Encoding.Controls.Add(Me.Panel26)
        Me.TabPage_Encoding.Location = New System.Drawing.Point(4, 22)
        Me.TabPage_Encoding.Name = "TabPage_Encoding"
        Me.TabPage_Encoding.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage_Encoding.Size = New System.Drawing.Size(771, 629)
        Me.TabPage_Encoding.TabIndex = 2
        Me.TabPage_Encoding.Text = "Hashing / Encoding"
        Me.TabPage_Encoding.UseVisualStyleBackColor = True
        '
        'Panel44
        '
        Me.Panel44.Location = New System.Drawing.Point(6, 916)
        Me.Panel44.Name = "Panel44"
        Me.Panel44.Size = New System.Drawing.Size(200, 100)
        Me.Panel44.TabIndex = 24
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(20, 254)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(60, 13)
        Me.Label23.TabIndex = 23
        Me.Label23.Text = "Encoding"
        '
        'Panel29
        '
        Me.Panel29.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel29.Controls.Add(Me.Button57)
        Me.Panel29.Controls.Add(Me.Button12)
        Me.Panel29.Controls.Add(Me.Button11)
        Me.Panel29.Controls.Add(Me.Button9)
        Me.Panel29.Controls.Add(Me.ComboBox_Encoding_EncodeOrDecodeIn)
        Me.Panel29.Controls.Add(Me.Button_Encoding_DecodeData)
        Me.Panel29.Controls.Add(Me.Button_Encoding_EncodeData)
        Me.Panel29.Controls.Add(Me.Button_Encoding_Base64StringEncodedCopy)
        Me.Panel29.Controls.Add(Me.Label34)
        Me.Panel29.Controls.Add(Me.Label21)
        Me.Panel29.Controls.Add(Me.Label28)
        Me.Panel29.Controls.Add(Me.TabControl_Encoding_StringOrFile)
        Me.Panel29.Controls.Add(Me.Label27)
        Me.Panel29.Controls.Add(Me.Panel35)
        Me.Panel29.Controls.Add(Me.Label31)
        Me.Panel29.Controls.Add(Me.Panel28)
        Me.Panel29.Controls.Add(Me.Panel30)
        Me.Panel29.Controls.Add(Me.Panel32)
        Me.Panel29.Location = New System.Drawing.Point(20, 284)
        Me.Panel29.Name = "Panel29"
        Me.Panel29.Size = New System.Drawing.Size(646, 626)
        Me.Panel29.TabIndex = 22
        '
        'Button57
        '
        Me.Button57.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button57.Location = New System.Drawing.Point(226, 117)
        Me.Button57.Name = "Button57"
        Me.Button57.Size = New System.Drawing.Size(143, 23)
        Me.Button57.TabIndex = 30
        Me.Button57.Text = "Split and Reverse Input"
        Me.Button57.UseVisualStyleBackColor = True
        '
        'Button12
        '
        Me.Button12.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button12.Location = New System.Drawing.Point(375, 117)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(69, 23)
        Me.Button12.TabIndex = 29
        Me.Button12.Text = "Swap"
        Me.Button12.UseVisualStyleBackColor = True
        '
        'Button11
        '
        Me.Button11.Location = New System.Drawing.Point(94, 241)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(69, 23)
        Me.Button11.TabIndex = 28
        Me.Button11.Text = "Clear"
        Me.Button11.UseVisualStyleBackColor = True
        Me.Button11.Visible = False
        '
        'Button9
        '
        Me.Button9.Location = New System.Drawing.Point(82, 126)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(69, 23)
        Me.Button9.TabIndex = 27
        Me.Button9.Text = "Clear"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'ComboBox_Encoding_EncodeOrDecodeIn
        '
        Me.ComboBox_Encoding_EncodeOrDecodeIn.FormattingEnabled = True
        Me.ComboBox_Encoding_EncodeOrDecodeIn.Items.AddRange(New Object() {"Base64", "Base32", "Hex"})
        Me.ComboBox_Encoding_EncodeOrDecodeIn.Location = New System.Drawing.Point(119, 4)
        Me.ComboBox_Encoding_EncodeOrDecodeIn.Name = "ComboBox_Encoding_EncodeOrDecodeIn"
        Me.ComboBox_Encoding_EncodeOrDecodeIn.Size = New System.Drawing.Size(154, 21)
        Me.ComboBox_Encoding_EncodeOrDecodeIn.TabIndex = 26
        Me.ComboBox_Encoding_EncodeOrDecodeIn.Text = "Base64"
        '
        'Button_Encoding_DecodeData
        '
        Me.Button_Encoding_DecodeData.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_Encoding_DecodeData.Location = New System.Drawing.Point(546, 117)
        Me.Button_Encoding_DecodeData.Name = "Button_Encoding_DecodeData"
        Me.Button_Encoding_DecodeData.Size = New System.Drawing.Size(94, 23)
        Me.Button_Encoding_DecodeData.TabIndex = 22
        Me.Button_Encoding_DecodeData.Text = "Decode"
        Me.Button_Encoding_DecodeData.UseVisualStyleBackColor = True
        '
        'Button_Encoding_EncodeData
        '
        Me.Button_Encoding_EncodeData.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_Encoding_EncodeData.Location = New System.Drawing.Point(446, 117)
        Me.Button_Encoding_EncodeData.Name = "Button_Encoding_EncodeData"
        Me.Button_Encoding_EncodeData.Size = New System.Drawing.Size(94, 23)
        Me.Button_Encoding_EncodeData.TabIndex = 22
        Me.Button_Encoding_EncodeData.Text = "Encode"
        Me.Button_Encoding_EncodeData.UseVisualStyleBackColor = True
        '
        'Button_Encoding_Base64StringEncodedCopy
        '
        Me.Button_Encoding_Base64StringEncodedCopy.Location = New System.Drawing.Point(14, 220)
        Me.Button_Encoding_Base64StringEncodedCopy.Name = "Button_Encoding_Base64StringEncodedCopy"
        Me.Button_Encoding_Base64StringEncodedCopy.Size = New System.Drawing.Size(69, 23)
        Me.Button_Encoding_Base64StringEncodedCopy.TabIndex = 25
        Me.Button_Encoding_Base64StringEncodedCopy.Text = "Copy"
        Me.Button_Encoding_Base64StringEncodedCopy.UseVisualStyleBackColor = True
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(11, 246)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(77, 13)
        Me.Label34.TabIndex = 0
        Me.Label34.Text = "Decoded Data"
        Me.Label34.Visible = False
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label21.Location = New System.Drawing.Point(7, 7)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(110, 13)
        Me.Label21.TabIndex = 24
        Me.Label21.Text = "Encode / Decode in: "
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(11, 31)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(57, 13)
        Me.Label28.TabIndex = 0
        Me.Label28.Text = "Input Data"
        '
        'TabControl_Encoding_StringOrFile
        '
        Me.TabControl_Encoding_StringOrFile.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TabControl_Encoding_StringOrFile.Controls.Add(Me.TabPage_String)
        Me.TabControl_Encoding_StringOrFile.Controls.Add(Me.TabPage_File)
        Me.TabControl_Encoding_StringOrFile.Location = New System.Drawing.Point(3, 450)
        Me.TabControl_Encoding_StringOrFile.Name = "TabControl_Encoding_StringOrFile"
        Me.TabControl_Encoding_StringOrFile.SelectedIndex = 0
        Me.TabControl_Encoding_StringOrFile.Size = New System.Drawing.Size(636, 136)
        Me.TabControl_Encoding_StringOrFile.TabIndex = 24
        '
        'TabPage_String
        '
        Me.TabPage_String.Controls.Add(Me.Panel27)
        Me.TabPage_String.Controls.Add(Me.Label22)
        Me.TabPage_String.Location = New System.Drawing.Point(4, 22)
        Me.TabPage_String.Name = "TabPage_String"
        Me.TabPage_String.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage_String.Size = New System.Drawing.Size(628, 110)
        Me.TabPage_String.TabIndex = 0
        Me.TabPage_String.Text = "Hash String"
        Me.TabPage_String.UseVisualStyleBackColor = True
        '
        'Panel27
        '
        Me.Panel27.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel27.Controls.Add(Me.TextBox_Encoding_StringToHash)
        Me.Panel27.Location = New System.Drawing.Point(6, 23)
        Me.Panel27.Name = "Panel27"
        Me.Panel27.Size = New System.Drawing.Size(616, 81)
        Me.Panel27.TabIndex = 2
        '
        'TextBox_Encoding_StringToHash
        '
        Me.TextBox_Encoding_StringToHash.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TextBox_Encoding_StringToHash.Location = New System.Drawing.Point(0, 0)
        Me.TextBox_Encoding_StringToHash.Multiline = True
        Me.TextBox_Encoding_StringToHash.Name = "TextBox_Encoding_StringToHash"
        Me.TextBox_Encoding_StringToHash.Size = New System.Drawing.Size(616, 81)
        Me.TextBox_Encoding_StringToHash.TabIndex = 1
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(8, 6)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(74, 13)
        Me.Label22.TabIndex = 0
        Me.Label22.Text = "String to Hash"
        '
        'TabPage_File
        '
        Me.TabPage_File.Controls.Add(Me.Panel43)
        Me.TabPage_File.Location = New System.Drawing.Point(4, 22)
        Me.TabPage_File.Name = "TabPage_File"
        Me.TabPage_File.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage_File.Size = New System.Drawing.Size(628, 110)
        Me.TabPage_File.TabIndex = 1
        Me.TabPage_File.Text = "Hash File"
        Me.TabPage_File.UseVisualStyleBackColor = True
        '
        'Panel43
        '
        Me.Panel43.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel43.Controls.Add(Me.TextBox_Encoding_FilePathToHash)
        Me.Panel43.Controls.Add(Me.Label30)
        Me.Panel43.Controls.Add(Me.Button_Encoding_BrowseForFileToHash)
        Me.Panel43.Location = New System.Drawing.Point(6, 4)
        Me.Panel43.Name = "Panel43"
        Me.Panel43.Size = New System.Drawing.Size(616, 23)
        Me.Panel43.TabIndex = 11
        '
        'TextBox_Encoding_FilePathToHash
        '
        Me.TextBox_Encoding_FilePathToHash.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_Encoding_FilePathToHash.Location = New System.Drawing.Point(106, 0)
        Me.TextBox_Encoding_FilePathToHash.Name = "TextBox_Encoding_FilePathToHash"
        Me.TextBox_Encoding_FilePathToHash.ReadOnly = True
        Me.TextBox_Encoding_FilePathToHash.Size = New System.Drawing.Size(345, 20)
        Me.TextBox_Encoding_FilePathToHash.TabIndex = 1
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(3, 3)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(63, 13)
        Me.Label30.TabIndex = 0
        Me.Label30.Text = "File to Hash"
        '
        'Button_Encoding_BrowseForFileToHash
        '
        Me.Button_Encoding_BrowseForFileToHash.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_Encoding_BrowseForFileToHash.Location = New System.Drawing.Point(532, 0)
        Me.Button_Encoding_BrowseForFileToHash.Name = "Button_Encoding_BrowseForFileToHash"
        Me.Button_Encoding_BrowseForFileToHash.Size = New System.Drawing.Size(84, 23)
        Me.Button_Encoding_BrowseForFileToHash.TabIndex = 9
        Me.Button_Encoding_BrowseForFileToHash.Text = "Browse"
        Me.Button_Encoding_BrowseForFileToHash.UseVisualStyleBackColor = True
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(11, 131)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(65, 13)
        Me.Label27.TabIndex = 0
        Me.Label27.Text = "Output Data"
        '
        'Panel35
        '
        Me.Panel35.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel35.Controls.Add(Me.TextBox_Encoding_DecodedData)
        Me.Panel35.Location = New System.Drawing.Point(14, 265)
        Me.Panel35.Name = "Panel35"
        Me.Panel35.Size = New System.Drawing.Size(625, 19)
        Me.Panel35.TabIndex = 4
        Me.Panel35.Visible = False
        '
        'TextBox_Encoding_DecodedData
        '
        Me.TextBox_Encoding_DecodedData.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TextBox_Encoding_DecodedData.Location = New System.Drawing.Point(0, 0)
        Me.TextBox_Encoding_DecodedData.Multiline = True
        Me.TextBox_Encoding_DecodedData.Name = "TextBox_Encoding_DecodedData"
        Me.TextBox_Encoding_DecodedData.ReadOnly = True
        Me.TextBox_Encoding_DecodedData.Size = New System.Drawing.Size(625, 19)
        Me.TextBox_Encoding_DecodedData.TabIndex = 1
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label31.Location = New System.Drawing.Point(7, 429)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(89, 13)
        Me.Label31.TabIndex = 22
        Me.Label31.Text = "Hash Data or File"
        '
        'Panel28
        '
        Me.Panel28.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel28.Controls.Add(Me.Button_Encoding_HashedStringCopy)
        Me.Panel28.Controls.Add(Me.Button_Encoding_StringToHash)
        Me.Panel28.Controls.Add(Me.TextBox_Encoding_HashedString)
        Me.Panel28.Controls.Add(Me.Label25)
        Me.Panel28.Location = New System.Drawing.Point(13, 593)
        Me.Panel28.Name = "Panel28"
        Me.Panel28.Size = New System.Drawing.Size(616, 21)
        Me.Panel28.TabIndex = 3
        '
        'Button_Encoding_HashedStringCopy
        '
        Me.Button_Encoding_HashedStringCopy.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_Encoding_HashedStringCopy.Location = New System.Drawing.Point(533, -1)
        Me.Button_Encoding_HashedStringCopy.Name = "Button_Encoding_HashedStringCopy"
        Me.Button_Encoding_HashedStringCopy.Size = New System.Drawing.Size(83, 23)
        Me.Button_Encoding_HashedStringCopy.TabIndex = 24
        Me.Button_Encoding_HashedStringCopy.Text = "Copy"
        Me.Button_Encoding_HashedStringCopy.UseVisualStyleBackColor = True
        '
        'Button_Encoding_StringToHash
        '
        Me.Button_Encoding_StringToHash.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_Encoding_StringToHash.Location = New System.Drawing.Point(457, -1)
        Me.Button_Encoding_StringToHash.Name = "Button_Encoding_StringToHash"
        Me.Button_Encoding_StringToHash.Size = New System.Drawing.Size(70, 23)
        Me.Button_Encoding_StringToHash.TabIndex = 22
        Me.Button_Encoding_StringToHash.Text = "Hash It"
        Me.Button_Encoding_StringToHash.UseVisualStyleBackColor = True
        '
        'TextBox_Encoding_HashedString
        '
        Me.TextBox_Encoding_HashedString.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_Encoding_HashedString.Location = New System.Drawing.Point(106, 0)
        Me.TextBox_Encoding_HashedString.Name = "TextBox_Encoding_HashedString"
        Me.TextBox_Encoding_HashedString.Size = New System.Drawing.Size(345, 20)
        Me.TextBox_Encoding_HashedString.TabIndex = 1
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(3, 3)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(79, 13)
        Me.Label25.TabIndex = 0
        Me.Label25.Text = "Resulting Hash"
        '
        'Panel30
        '
        Me.Panel30.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel30.Controls.Add(Me.TextBox_Encoding_EncodedData)
        Me.Panel30.Location = New System.Drawing.Point(14, 155)
        Me.Panel30.Name = "Panel30"
        Me.Panel30.Size = New System.Drawing.Size(625, 59)
        Me.Panel30.TabIndex = 3
        '
        'TextBox_Encoding_EncodedData
        '
        Me.TextBox_Encoding_EncodedData.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TextBox_Encoding_EncodedData.Location = New System.Drawing.Point(0, 0)
        Me.TextBox_Encoding_EncodedData.Multiline = True
        Me.TextBox_Encoding_EncodedData.Name = "TextBox_Encoding_EncodedData"
        Me.TextBox_Encoding_EncodedData.ReadOnly = True
        Me.TextBox_Encoding_EncodedData.Size = New System.Drawing.Size(625, 59)
        Me.TextBox_Encoding_EncodedData.TabIndex = 1
        '
        'Panel32
        '
        Me.Panel32.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel32.Controls.Add(Me.TextBox_Encoding_InputData)
        Me.Panel32.Location = New System.Drawing.Point(14, 50)
        Me.Panel32.Name = "Panel32"
        Me.Panel32.Size = New System.Drawing.Size(625, 61)
        Me.Panel32.TabIndex = 2
        '
        'TextBox_Encoding_InputData
        '
        Me.TextBox_Encoding_InputData.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TextBox_Encoding_InputData.Location = New System.Drawing.Point(0, 0)
        Me.TextBox_Encoding_InputData.Multiline = True
        Me.TextBox_Encoding_InputData.Name = "TextBox_Encoding_InputData"
        Me.TextBox_Encoding_InputData.Size = New System.Drawing.Size(625, 61)
        Me.TextBox_Encoding_InputData.TabIndex = 1
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(20, 26)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(69, 13)
        Me.Label20.TabIndex = 20
        Me.Label20.Text = "Generation"
        '
        'Panel26
        '
        Me.Panel26.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel26.Controls.Add(Me.Panel71)
        Me.Panel26.Controls.Add(Me.Panel70)
        Me.Panel26.Controls.Add(Me.Panel31)
        Me.Panel26.Controls.Add(Me.Label19)
        Me.Panel26.Location = New System.Drawing.Point(20, 56)
        Me.Panel26.Name = "Panel26"
        Me.Panel26.Size = New System.Drawing.Size(653, 143)
        Me.Panel26.TabIndex = 18
        '
        'Panel71
        '
        Me.Panel71.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel71.Controls.Add(Me.ComboBox_Encoding_TimestampGenerate)
        Me.Panel71.Controls.Add(Me.Button8)
        Me.Panel71.Controls.Add(Me.Button_Encoding_TimestampGenerate)
        Me.Panel71.Controls.Add(Me.TextBox_Encoding_TimestampGenerate)
        Me.Panel71.Controls.Add(Me.Label66)
        Me.Panel71.Location = New System.Drawing.Point(4, 75)
        Me.Panel71.Name = "Panel71"
        Me.Panel71.Size = New System.Drawing.Size(642, 21)
        Me.Panel71.TabIndex = 23
        '
        'ComboBox_Encoding_TimestampGenerate
        '
        Me.ComboBox_Encoding_TimestampGenerate.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ComboBox_Encoding_TimestampGenerate.FormattingEnabled = True
        Me.ComboBox_Encoding_TimestampGenerate.Items.AddRange(New Object() {"UTC Seconds", "YYYY-MM-DD HH:MM:SS", "DD-MM-YYYY HH:MM:SS", "HH:MM:SS DD-MM-YYYY", "HH:MM:SS YYYY-MM-DD", "YYYY-MM-DD", "DD-MM-YYYY", "HH:MM:SS"})
        Me.ComboBox_Encoding_TimestampGenerate.Location = New System.Drawing.Point(378, 0)
        Me.ComboBox_Encoding_TimestampGenerate.Name = "ComboBox_Encoding_TimestampGenerate"
        Me.ComboBox_Encoding_TimestampGenerate.Size = New System.Drawing.Size(157, 21)
        Me.ComboBox_Encoding_TimestampGenerate.TabIndex = 24
        Me.ComboBox_Encoding_TimestampGenerate.Text = "UTC Seconds"
        '
        'Button8
        '
        Me.Button8.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button8.Location = New System.Drawing.Point(601, -1)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(42, 23)
        Me.Button8.TabIndex = 23
        Me.Button8.Text = "Copy"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button_Encoding_TimestampGenerate
        '
        Me.Button_Encoding_TimestampGenerate.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_Encoding_TimestampGenerate.Location = New System.Drawing.Point(541, -1)
        Me.Button_Encoding_TimestampGenerate.Name = "Button_Encoding_TimestampGenerate"
        Me.Button_Encoding_TimestampGenerate.Size = New System.Drawing.Size(60, 23)
        Me.Button_Encoding_TimestampGenerate.TabIndex = 22
        Me.Button_Encoding_TimestampGenerate.Text = "Generate"
        Me.Button_Encoding_TimestampGenerate.UseVisualStyleBackColor = True
        '
        'TextBox_Encoding_TimestampGenerate
        '
        Me.TextBox_Encoding_TimestampGenerate.Location = New System.Drawing.Point(115, 0)
        Me.TextBox_Encoding_TimestampGenerate.Name = "TextBox_Encoding_TimestampGenerate"
        Me.TextBox_Encoding_TimestampGenerate.Size = New System.Drawing.Size(257, 20)
        Me.TextBox_Encoding_TimestampGenerate.TabIndex = 1
        '
        'Label66
        '
        Me.Label66.AutoSize = True
        Me.Label66.Location = New System.Drawing.Point(3, 3)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(58, 13)
        Me.Label66.TabIndex = 0
        Me.Label66.Text = "Timestamp"
        '
        'Panel70
        '
        Me.Panel70.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel70.Controls.Add(Me.Button6)
        Me.Panel70.Controls.Add(Me.Label63)
        Me.Panel70.Controls.Add(Me.TextBox1)
        Me.Panel70.Controls.Add(Me.Button_Encoding_GenerateGUID)
        Me.Panel70.Controls.Add(Me.TextBox_Encoding_GenerateGUID)
        Me.Panel70.Controls.Add(Me.Label64)
        Me.Panel70.Location = New System.Drawing.Point(4, 49)
        Me.Panel70.Name = "Panel70"
        Me.Panel70.Size = New System.Drawing.Size(642, 21)
        Me.Panel70.TabIndex = 22
        '
        'Button6
        '
        Me.Button6.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button6.Location = New System.Drawing.Point(601, -1)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(42, 23)
        Me.Button6.TabIndex = 23
        Me.Button6.Text = "Copy"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Label63
        '
        Me.Label63.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label63.AutoSize = True
        Me.Label63.Location = New System.Drawing.Point(464, 4)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(40, 13)
        Me.Label63.TabIndex = 24
        Me.Label63.Text = "Length"
        Me.Label63.Visible = False
        '
        'TextBox1
        '
        Me.TextBox1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox1.Location = New System.Drawing.Point(506, 1)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(29, 20)
        Me.TextBox1.TabIndex = 23
        Me.TextBox1.Text = "50"
        Me.TextBox1.Visible = False
        '
        'Button_Encoding_GenerateGUID
        '
        Me.Button_Encoding_GenerateGUID.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_Encoding_GenerateGUID.Location = New System.Drawing.Point(541, -1)
        Me.Button_Encoding_GenerateGUID.Name = "Button_Encoding_GenerateGUID"
        Me.Button_Encoding_GenerateGUID.Size = New System.Drawing.Size(60, 23)
        Me.Button_Encoding_GenerateGUID.TabIndex = 22
        Me.Button_Encoding_GenerateGUID.Text = "Generate"
        Me.Button_Encoding_GenerateGUID.UseVisualStyleBackColor = True
        '
        'TextBox_Encoding_GenerateGUID
        '
        Me.TextBox_Encoding_GenerateGUID.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_Encoding_GenerateGUID.Location = New System.Drawing.Point(115, 0)
        Me.TextBox_Encoding_GenerateGUID.Name = "TextBox_Encoding_GenerateGUID"
        Me.TextBox_Encoding_GenerateGUID.Size = New System.Drawing.Size(343, 20)
        Me.TextBox_Encoding_GenerateGUID.TabIndex = 1
        '
        'Label64
        '
        Me.Label64.AutoSize = True
        Me.Label64.Location = New System.Drawing.Point(3, 3)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(34, 13)
        Me.Label64.TabIndex = 0
        Me.Label64.Text = "GUID"
        '
        'Panel31
        '
        Me.Panel31.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel31.Controls.Add(Me.Button_Encoding_RandomStringCopy)
        Me.Panel31.Controls.Add(Me.Label26)
        Me.Panel31.Controls.Add(Me.TextBox_Encoding_RandomStringLength)
        Me.Panel31.Controls.Add(Me.Button_Encoding_RandomString)
        Me.Panel31.Controls.Add(Me.TextBox_Encoding_RandomString)
        Me.Panel31.Controls.Add(Me.Label24)
        Me.Panel31.Location = New System.Drawing.Point(4, 23)
        Me.Panel31.Name = "Panel31"
        Me.Panel31.Size = New System.Drawing.Size(642, 21)
        Me.Panel31.TabIndex = 1
        '
        'Button_Encoding_RandomStringCopy
        '
        Me.Button_Encoding_RandomStringCopy.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_Encoding_RandomStringCopy.Location = New System.Drawing.Point(601, -1)
        Me.Button_Encoding_RandomStringCopy.Name = "Button_Encoding_RandomStringCopy"
        Me.Button_Encoding_RandomStringCopy.Size = New System.Drawing.Size(42, 23)
        Me.Button_Encoding_RandomStringCopy.TabIndex = 23
        Me.Button_Encoding_RandomStringCopy.Text = "Copy"
        Me.Button_Encoding_RandomStringCopy.UseVisualStyleBackColor = True
        '
        'Label26
        '
        Me.Label26.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(464, 3)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(40, 13)
        Me.Label26.TabIndex = 24
        Me.Label26.Text = "Length"
        '
        'TextBox_Encoding_RandomStringLength
        '
        Me.TextBox_Encoding_RandomStringLength.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_Encoding_RandomStringLength.Location = New System.Drawing.Point(506, 0)
        Me.TextBox_Encoding_RandomStringLength.Name = "TextBox_Encoding_RandomStringLength"
        Me.TextBox_Encoding_RandomStringLength.Size = New System.Drawing.Size(29, 20)
        Me.TextBox_Encoding_RandomStringLength.TabIndex = 23
        Me.TextBox_Encoding_RandomStringLength.Text = "50"
        '
        'Button_Encoding_RandomString
        '
        Me.Button_Encoding_RandomString.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_Encoding_RandomString.Location = New System.Drawing.Point(541, -1)
        Me.Button_Encoding_RandomString.Name = "Button_Encoding_RandomString"
        Me.Button_Encoding_RandomString.Size = New System.Drawing.Size(60, 23)
        Me.Button_Encoding_RandomString.TabIndex = 22
        Me.Button_Encoding_RandomString.Text = "Generate"
        Me.Button_Encoding_RandomString.UseVisualStyleBackColor = True
        '
        'TextBox_Encoding_RandomString
        '
        Me.TextBox_Encoding_RandomString.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_Encoding_RandomString.Location = New System.Drawing.Point(115, 0)
        Me.TextBox_Encoding_RandomString.Name = "TextBox_Encoding_RandomString"
        Me.TextBox_Encoding_RandomString.Size = New System.Drawing.Size(343, 20)
        Me.TextBox_Encoding_RandomString.TabIndex = 1
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(3, 3)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(77, 13)
        Me.Label24.TabIndex = 0
        Me.Label24.Text = "Random String"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label19.Location = New System.Drawing.Point(7, 5)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(75, 13)
        Me.Label19.TabIndex = 21
        Me.Label19.Text = "Generate data"
        '
        'TabPage_RSA
        '
        Me.TabPage_RSA.AutoScroll = True
        Me.TabPage_RSA.Controls.Add(Me.Button_RSA_GenerateKeys)
        Me.TabPage_RSA.Controls.Add(Me.Label17)
        Me.TabPage_RSA.Controls.Add(Me.Label16)
        Me.TabPage_RSA.Controls.Add(Me.Label14)
        Me.TabPage_RSA.Controls.Add(Me.Label13)
        Me.TabPage_RSA.Controls.Add(Me.Panel22)
        Me.TabPage_RSA.Controls.Add(Me.Button_RSA_HashInputClear)
        Me.TabPage_RSA.Controls.Add(Me.Panel20)
        Me.TabPage_RSA.Controls.Add(Me.Panel18)
        Me.TabPage_RSA.Controls.Add(Me.FlowLayoutPanel3)
        Me.TabPage_RSA.Controls.Add(Me.Panel10)
        Me.TabPage_RSA.Controls.Add(Me.Panel13)
        Me.TabPage_RSA.Controls.Add(Me.Panel15)
        Me.TabPage_RSA.Controls.Add(Me.Panel16)
        Me.TabPage_RSA.Location = New System.Drawing.Point(4, 22)
        Me.TabPage_RSA.Name = "TabPage_RSA"
        Me.TabPage_RSA.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage_RSA.Size = New System.Drawing.Size(771, 629)
        Me.TabPage_RSA.TabIndex = 1
        Me.TabPage_RSA.Text = "RSA Encrypt"
        Me.TabPage_RSA.UseVisualStyleBackColor = True
        '
        'Button_RSA_GenerateKeys
        '
        Me.Button_RSA_GenerateKeys.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_RSA_GenerateKeys.BackColor = System.Drawing.Color.PaleGreen
        Me.Button_RSA_GenerateKeys.Location = New System.Drawing.Point(574, 299)
        Me.Button_RSA_GenerateKeys.Name = "Button_RSA_GenerateKeys"
        Me.Button_RSA_GenerateKeys.Size = New System.Drawing.Size(105, 33)
        Me.Button_RSA_GenerateKeys.TabIndex = 0
        Me.Button_RSA_GenerateKeys.Text = "Generate Keys"
        Me.Button_RSA_GenerateKeys.UseVisualStyleBackColor = False
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label17.Location = New System.Drawing.Point(22, 735)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(415, 13)
        Me.Label17.TabIndex = 18
        Me.Label17.Text = "hash data and sign it with private key, then verify with public key, and compare " &
    "hashes"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label16.Location = New System.Drawing.Point(20, 51)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(496, 13)
        Me.Label16.TabIndex = 17
        Me.Label16.Text = "Generate public and private key pair - public to encrypt, private to decrypt - us" &
    "ed on short pieces of data"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(20, 26)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(146, 13)
        Me.Label14.TabIndex = 16
        Me.Label14.Text = "Encryption  / Decryption"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(17, 714)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(127, 13)
        Me.Label13.TabIndex = 15
        Me.Label13.Text = "Signing / Verification"
        '
        'Panel22
        '
        Me.Panel22.Location = New System.Drawing.Point(6, 1008)
        Me.Panel22.Name = "Panel22"
        Me.Panel22.Size = New System.Drawing.Size(200, 58)
        Me.Panel22.TabIndex = 14
        '
        'Button_RSA_HashInputClear
        '
        Me.Button_RSA_HashInputClear.Location = New System.Drawing.Point(443, 730)
        Me.Button_RSA_HashInputClear.Name = "Button_RSA_HashInputClear"
        Me.Button_RSA_HashInputClear.Size = New System.Drawing.Size(52, 23)
        Me.Button_RSA_HashInputClear.TabIndex = 20
        Me.Button_RSA_HashInputClear.Text = "Clear"
        Me.Button_RSA_HashInputClear.UseVisualStyleBackColor = True
        '
        'Panel20
        '
        Me.Panel20.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel20.Controls.Add(Me.FlowLayoutPanel4)
        Me.Panel20.Location = New System.Drawing.Point(20, 850)
        Me.Panel20.Name = "Panel20"
        Me.Panel20.Size = New System.Drawing.Size(604, 126)
        Me.Panel20.TabIndex = 13
        '
        'FlowLayoutPanel4
        '
        Me.FlowLayoutPanel4.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.FlowLayoutPanel4.Controls.Add(Me.Button_RSA_Sign_WithPrivate)
        Me.FlowLayoutPanel4.Controls.Add(Me.Button_RSA_Verify_WithPublic)
        Me.FlowLayoutPanel4.Controls.Add(Me.Button_RSA_VerifyClear)
        Me.FlowLayoutPanel4.Controls.Add(Me.Panel21)
        Me.FlowLayoutPanel4.Controls.Add(Me.Panel24)
        Me.FlowLayoutPanel4.Location = New System.Drawing.Point(5, 4)
        Me.FlowLayoutPanel4.Name = "FlowLayoutPanel4"
        Me.FlowLayoutPanel4.Size = New System.Drawing.Size(596, 119)
        Me.FlowLayoutPanel4.TabIndex = 2
        '
        'Button_RSA_Sign_WithPrivate
        '
        Me.Button_RSA_Sign_WithPrivate.Location = New System.Drawing.Point(3, 3)
        Me.Button_RSA_Sign_WithPrivate.Name = "Button_RSA_Sign_WithPrivate"
        Me.Button_RSA_Sign_WithPrivate.Size = New System.Drawing.Size(100, 23)
        Me.Button_RSA_Sign_WithPrivate.TabIndex = 2
        Me.Button_RSA_Sign_WithPrivate.Text = "Sign With Private"
        Me.Button_RSA_Sign_WithPrivate.UseVisualStyleBackColor = True
        '
        'Button_RSA_Verify_WithPublic
        '
        Me.Button_RSA_Verify_WithPublic.Location = New System.Drawing.Point(109, 3)
        Me.Button_RSA_Verify_WithPublic.Name = "Button_RSA_Verify_WithPublic"
        Me.Button_RSA_Verify_WithPublic.Size = New System.Drawing.Size(108, 23)
        Me.Button_RSA_Verify_WithPublic.TabIndex = 4
        Me.Button_RSA_Verify_WithPublic.Text = "Verify With Public"
        Me.Button_RSA_Verify_WithPublic.UseVisualStyleBackColor = True
        '
        'Button_RSA_VerifyClear
        '
        Me.Button_RSA_VerifyClear.Location = New System.Drawing.Point(223, 3)
        Me.Button_RSA_VerifyClear.Name = "Button_RSA_VerifyClear"
        Me.Button_RSA_VerifyClear.Size = New System.Drawing.Size(52, 23)
        Me.Button_RSA_VerifyClear.TabIndex = 19
        Me.Button_RSA_VerifyClear.Text = "Clear"
        Me.Button_RSA_VerifyClear.UseVisualStyleBackColor = True
        '
        'Panel21
        '
        Me.Panel21.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel21.Controls.Add(Me.LinkLabel1)
        Me.Panel21.Controls.Add(Me.Button_RSA_SignatureCopy)
        Me.Panel21.Controls.Add(Me.TextBox_RSA_Signature)
        Me.Panel21.Controls.Add(Me.Label10)
        Me.Panel21.Location = New System.Drawing.Point(3, 32)
        Me.Panel21.Name = "Panel21"
        Me.Panel21.Size = New System.Drawing.Size(540, 48)
        Me.Panel21.TabIndex = 3
        '
        'LinkLabel1
        '
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.Location = New System.Drawing.Point(117, 5)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(236, 13)
        Me.LinkLabel1.TabIndex = 21
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "https://emn178.github.io/online-tools/rsa/verify/"
        '
        'Button_RSA_SignatureCopy
        '
        Me.Button_RSA_SignatureCopy.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_RSA_SignatureCopy.Location = New System.Drawing.Point(475, 20)
        Me.Button_RSA_SignatureCopy.Name = "Button_RSA_SignatureCopy"
        Me.Button_RSA_SignatureCopy.Size = New System.Drawing.Size(52, 23)
        Me.Button_RSA_SignatureCopy.TabIndex = 21
        Me.Button_RSA_SignatureCopy.Text = "Copy"
        Me.Button_RSA_SignatureCopy.UseVisualStyleBackColor = True
        '
        'TextBox_RSA_Signature
        '
        Me.TextBox_RSA_Signature.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_RSA_Signature.Location = New System.Drawing.Point(6, 22)
        Me.TextBox_RSA_Signature.Name = "TextBox_RSA_Signature"
        Me.TextBox_RSA_Signature.Size = New System.Drawing.Size(465, 20)
        Me.TextBox_RSA_Signature.TabIndex = 1
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(3, 5)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(108, 13)
        Me.Label10.TabIndex = 0
        Me.Label10.Text = "Signature (in Base64)"
        '
        'Panel24
        '
        Me.Panel24.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel24.Controls.Add(Me.TextBox_RSA_MatchingSignatures)
        Me.Panel24.Controls.Add(Me.Label12)
        Me.Panel24.Location = New System.Drawing.Point(3, 86)
        Me.Panel24.Name = "Panel24"
        Me.Panel24.Size = New System.Drawing.Size(540, 20)
        Me.Panel24.TabIndex = 6
        '
        'TextBox_RSA_MatchingSignatures
        '
        Me.TextBox_RSA_MatchingSignatures.Location = New System.Drawing.Point(87, 0)
        Me.TextBox_RSA_MatchingSignatures.Name = "TextBox_RSA_MatchingSignatures"
        Me.TextBox_RSA_MatchingSignatures.Size = New System.Drawing.Size(91, 20)
        Me.TextBox_RSA_MatchingSignatures.TabIndex = 1
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(3, 3)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(36, 13)
        Me.Label12.TabIndex = 0
        Me.Label12.Text = "Valid?"
        '
        'Panel18
        '
        Me.Panel18.Controls.Add(Me.Button_RSA_HashInputAndSalt)
        Me.Panel18.Controls.Add(Me.Button_RSA_HashInput)
        Me.Panel18.Controls.Add(Me.Panel19)
        Me.Panel18.Location = New System.Drawing.Point(20, 757)
        Me.Panel18.Name = "Panel18"
        Me.Panel18.Size = New System.Drawing.Size(701, 68)
        Me.Panel18.TabIndex = 12
        '
        'Button_RSA_HashInputAndSalt
        '
        Me.Button_RSA_HashInputAndSalt.Location = New System.Drawing.Point(114, 3)
        Me.Button_RSA_HashInputAndSalt.Name = "Button_RSA_HashInputAndSalt"
        Me.Button_RSA_HashInputAndSalt.Size = New System.Drawing.Size(103, 23)
        Me.Button_RSA_HashInputAndSalt.TabIndex = 3
        Me.Button_RSA_HashInputAndSalt.Text = "Hash Input + Salt"
        Me.Button_RSA_HashInputAndSalt.UseVisualStyleBackColor = True
        '
        'Button_RSA_HashInput
        '
        Me.Button_RSA_HashInput.Location = New System.Drawing.Point(5, 3)
        Me.Button_RSA_HashInput.Name = "Button_RSA_HashInput"
        Me.Button_RSA_HashInput.Size = New System.Drawing.Size(103, 23)
        Me.Button_RSA_HashInput.TabIndex = 2
        Me.Button_RSA_HashInput.Text = "Hash Input"
        Me.Button_RSA_HashInput.UseVisualStyleBackColor = True
        '
        'Panel19
        '
        Me.Panel19.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel19.Controls.Add(Me.TextBox_RSA_HashInput)
        Me.Panel19.Controls.Add(Me.Label9)
        Me.Panel19.Location = New System.Drawing.Point(5, 32)
        Me.Panel19.Name = "Panel19"
        Me.Panel19.Size = New System.Drawing.Size(686, 20)
        Me.Panel19.TabIndex = 1
        '
        'TextBox_RSA_HashInput
        '
        Me.TextBox_RSA_HashInput.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_RSA_HashInput.Location = New System.Drawing.Point(109, 0)
        Me.TextBox_RSA_HashInput.Name = "TextBox_RSA_HashInput"
        Me.TextBox_RSA_HashInput.Size = New System.Drawing.Size(574, 20)
        Me.TextBox_RSA_HashInput.TabIndex = 1
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(3, 3)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(70, 13)
        Me.Label9.TabIndex = 0
        Me.Label9.Text = "Hashed Data"
        '
        'FlowLayoutPanel3
        '
        Me.FlowLayoutPanel3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.FlowLayoutPanel3.Controls.Add(Me.Button_RSA_GenerateKeysClear)
        Me.FlowLayoutPanel3.Controls.Add(Me.Button_RSA_ExportGeneratedKeyPairs)
        Me.FlowLayoutPanel3.Controls.Add(Me.Button_RSA_ImportGeneratedKeyPairs)
        Me.FlowLayoutPanel3.Location = New System.Drawing.Point(20, 72)
        Me.FlowLayoutPanel3.Name = "FlowLayoutPanel3"
        Me.FlowLayoutPanel3.Size = New System.Drawing.Size(656, 33)
        Me.FlowLayoutPanel3.TabIndex = 11
        '
        'Button_RSA_GenerateKeysClear
        '
        Me.Button_RSA_GenerateKeysClear.Location = New System.Drawing.Point(3, 3)
        Me.Button_RSA_GenerateKeysClear.Name = "Button_RSA_GenerateKeysClear"
        Me.Button_RSA_GenerateKeysClear.Size = New System.Drawing.Size(52, 23)
        Me.Button_RSA_GenerateKeysClear.TabIndex = 21
        Me.Button_RSA_GenerateKeysClear.Text = "Clear"
        Me.Button_RSA_GenerateKeysClear.UseVisualStyleBackColor = True
        '
        'Button_RSA_ExportGeneratedKeyPairs
        '
        Me.Button_RSA_ExportGeneratedKeyPairs.Location = New System.Drawing.Point(61, 3)
        Me.Button_RSA_ExportGeneratedKeyPairs.Name = "Button_RSA_ExportGeneratedKeyPairs"
        Me.Button_RSA_ExportGeneratedKeyPairs.Size = New System.Drawing.Size(162, 23)
        Me.Button_RSA_ExportGeneratedKeyPairs.TabIndex = 22
        Me.Button_RSA_ExportGeneratedKeyPairs.Text = "Export Generated Key Pairs"
        Me.Button_RSA_ExportGeneratedKeyPairs.UseVisualStyleBackColor = True
        '
        'Button_RSA_ImportGeneratedKeyPairs
        '
        Me.Button_RSA_ImportGeneratedKeyPairs.Location = New System.Drawing.Point(229, 3)
        Me.Button_RSA_ImportGeneratedKeyPairs.Name = "Button_RSA_ImportGeneratedKeyPairs"
        Me.Button_RSA_ImportGeneratedKeyPairs.Size = New System.Drawing.Size(162, 23)
        Me.Button_RSA_ImportGeneratedKeyPairs.TabIndex = 23
        Me.Button_RSA_ImportGeneratedKeyPairs.Text = "Import Generated Key Pairs"
        Me.Button_RSA_ImportGeneratedKeyPairs.UseVisualStyleBackColor = True
        '
        'Panel10
        '
        Me.Panel10.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel10.Controls.Add(Me.Panel40)
        Me.Panel10.Controls.Add(Me.Panel34)
        Me.Panel10.Controls.Add(Me.Panel42)
        Me.Panel10.Controls.Add(Me.Panel25)
        Me.Panel10.Controls.Add(Me.Panel23)
        Me.Panel10.Controls.Add(Me.Panel11)
        Me.Panel10.Controls.Add(Me.Panel12)
        Me.Panel10.Location = New System.Drawing.Point(20, 111)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Size = New System.Drawing.Size(659, 182)
        Me.Panel10.TabIndex = 10
        '
        'Panel40
        '
        Me.Panel40.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel40.Controls.Add(Me.CheckBox_RSA_Salt)
        Me.Panel40.Controls.Add(Me.TextBox_RSA_Salt)
        Me.Panel40.Location = New System.Drawing.Point(3, 58)
        Me.Panel40.Name = "Panel40"
        Me.Panel40.Size = New System.Drawing.Size(648, 20)
        Me.Panel40.TabIndex = 6
        '
        'CheckBox_RSA_Salt
        '
        Me.CheckBox_RSA_Salt.AutoSize = True
        Me.CheckBox_RSA_Salt.Location = New System.Drawing.Point(5, 2)
        Me.CheckBox_RSA_Salt.Name = "CheckBox_RSA_Salt"
        Me.CheckBox_RSA_Salt.Size = New System.Drawing.Size(92, 17)
        Me.CheckBox_RSA_Salt.TabIndex = 2
        Me.CheckBox_RSA_Salt.Text = "Salt (Optional)"
        Me.CheckBox_RSA_Salt.UseVisualStyleBackColor = True
        '
        'TextBox_RSA_Salt
        '
        Me.TextBox_RSA_Salt.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_RSA_Salt.Enabled = False
        Me.TextBox_RSA_Salt.Location = New System.Drawing.Point(117, 0)
        Me.TextBox_RSA_Salt.Name = "TextBox_RSA_Salt"
        Me.TextBox_RSA_Salt.Size = New System.Drawing.Size(445, 20)
        Me.TextBox_RSA_Salt.TabIndex = 1
        '
        'Panel34
        '
        Me.Panel34.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel34.Controls.Add(Me.CheckBox_RSA_EnableSeed)
        Me.Panel34.Controls.Add(Me.TextBox_RSA_Seed)
        Me.Panel34.Location = New System.Drawing.Point(3, 36)
        Me.Panel34.Name = "Panel34"
        Me.Panel34.Size = New System.Drawing.Size(648, 20)
        Me.Panel34.TabIndex = 5
        '
        'CheckBox_RSA_EnableSeed
        '
        Me.CheckBox_RSA_EnableSeed.AutoSize = True
        Me.CheckBox_RSA_EnableSeed.Location = New System.Drawing.Point(5, 2)
        Me.CheckBox_RSA_EnableSeed.Name = "CheckBox_RSA_EnableSeed"
        Me.CheckBox_RSA_EnableSeed.Size = New System.Drawing.Size(99, 17)
        Me.CheckBox_RSA_EnableSeed.TabIndex = 2
        Me.CheckBox_RSA_EnableSeed.Text = "Seed (Optional)"
        Me.CheckBox_RSA_EnableSeed.UseVisualStyleBackColor = True
        '
        'TextBox_RSA_Seed
        '
        Me.TextBox_RSA_Seed.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_RSA_Seed.Enabled = False
        Me.TextBox_RSA_Seed.Location = New System.Drawing.Point(117, 0)
        Me.TextBox_RSA_Seed.Name = "TextBox_RSA_Seed"
        Me.TextBox_RSA_Seed.Size = New System.Drawing.Size(445, 20)
        Me.TextBox_RSA_Seed.TabIndex = 1
        '
        'Panel42
        '
        Me.Panel42.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel42.Controls.Add(Me.TextBox_RSA_KeyPairDescription)
        Me.Panel42.Controls.Add(Me.Label32)
        Me.Panel42.Location = New System.Drawing.Point(3, 153)
        Me.Panel42.Name = "Panel42"
        Me.Panel42.Size = New System.Drawing.Size(648, 25)
        Me.Panel42.TabIndex = 4
        '
        'TextBox_RSA_KeyPairDescription
        '
        Me.TextBox_RSA_KeyPairDescription.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_RSA_KeyPairDescription.Location = New System.Drawing.Point(117, 3)
        Me.TextBox_RSA_KeyPairDescription.Name = "TextBox_RSA_KeyPairDescription"
        Me.TextBox_RSA_KeyPairDescription.Size = New System.Drawing.Size(531, 20)
        Me.TextBox_RSA_KeyPairDescription.TabIndex = 1
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(3, 6)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(106, 13)
        Me.Label32.TabIndex = 0
        Me.Label32.Text = "Description (optional)"
        '
        'Panel25
        '
        Me.Panel25.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel25.Controls.Add(Me.Button_RSA_PreviousPairsEmpty)
        Me.Panel25.Controls.Add(Me.ComboBox_RSA_PreviousPairs)
        Me.Panel25.Controls.Add(Me.Label18)
        Me.Panel25.Location = New System.Drawing.Point(3, 3)
        Me.Panel25.Name = "Panel25"
        Me.Panel25.Size = New System.Drawing.Size(648, 26)
        Me.Panel25.TabIndex = 3
        '
        'Button_RSA_PreviousPairsEmpty
        '
        Me.Button_RSA_PreviousPairsEmpty.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_RSA_PreviousPairsEmpty.Location = New System.Drawing.Point(568, 0)
        Me.Button_RSA_PreviousPairsEmpty.Name = "Button_RSA_PreviousPairsEmpty"
        Me.Button_RSA_PreviousPairsEmpty.Size = New System.Drawing.Size(80, 23)
        Me.Button_RSA_PreviousPairsEmpty.TabIndex = 23
        Me.Button_RSA_PreviousPairsEmpty.Text = "Delete Pairs"
        Me.Button_RSA_PreviousPairsEmpty.UseVisualStyleBackColor = True
        '
        'ComboBox_RSA_PreviousPairs
        '
        Me.ComboBox_RSA_PreviousPairs.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ComboBox_RSA_PreviousPairs.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_RSA_PreviousPairs.FormattingEnabled = True
        Me.ComboBox_RSA_PreviousPairs.Location = New System.Drawing.Point(117, 0)
        Me.ComboBox_RSA_PreviousPairs.Name = "ComboBox_RSA_PreviousPairs"
        Me.ComboBox_RSA_PreviousPairs.Size = New System.Drawing.Size(445, 21)
        Me.ComboBox_RSA_PreviousPairs.TabIndex = 1
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(3, 3)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(74, 13)
        Me.Label18.TabIndex = 0
        Me.Label18.Text = "Previous Pairs"
        '
        'Panel23
        '
        Me.Panel23.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel23.Controls.Add(Me.ComboBox_RSA_KeySize)
        Me.Panel23.Controls.Add(Me.Label11)
        Me.Panel23.Location = New System.Drawing.Point(3, 128)
        Me.Panel23.Name = "Panel23"
        Me.Panel23.Size = New System.Drawing.Size(648, 24)
        Me.Panel23.TabIndex = 2
        '
        'ComboBox_RSA_KeySize
        '
        Me.ComboBox_RSA_KeySize.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_RSA_KeySize.FormattingEnabled = True
        Me.ComboBox_RSA_KeySize.Items.AddRange(New Object() {"24", "32", "64", "128", "256", "512", "1024", "2048", "4096"})
        Me.ComboBox_RSA_KeySize.Location = New System.Drawing.Point(117, 1)
        Me.ComboBox_RSA_KeySize.Name = "ComboBox_RSA_KeySize"
        Me.ComboBox_RSA_KeySize.Size = New System.Drawing.Size(83, 21)
        Me.ComboBox_RSA_KeySize.TabIndex = 1
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(3, 3)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(48, 13)
        Me.Label11.TabIndex = 0
        Me.Label11.Text = "Key Size"
        '
        'Panel11
        '
        Me.Panel11.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel11.Controls.Add(Me.Button_RSA_PublicKey_Copy)
        Me.Panel11.Controls.Add(Me.TextBox_RSA_PublicKey)
        Me.Panel11.Controls.Add(Me.Label5)
        Me.Panel11.Location = New System.Drawing.Point(3, 80)
        Me.Panel11.Name = "Panel11"
        Me.Panel11.Size = New System.Drawing.Size(648, 22)
        Me.Panel11.TabIndex = 1
        '
        'Button_RSA_PublicKey_Copy
        '
        Me.Button_RSA_PublicKey_Copy.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_RSA_PublicKey_Copy.Location = New System.Drawing.Point(568, -1)
        Me.Button_RSA_PublicKey_Copy.Name = "Button_RSA_PublicKey_Copy"
        Me.Button_RSA_PublicKey_Copy.Size = New System.Drawing.Size(80, 23)
        Me.Button_RSA_PublicKey_Copy.TabIndex = 22
        Me.Button_RSA_PublicKey_Copy.Text = "Copy Key"
        Me.Button_RSA_PublicKey_Copy.UseVisualStyleBackColor = True
        '
        'TextBox_RSA_PublicKey
        '
        Me.TextBox_RSA_PublicKey.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_RSA_PublicKey.Location = New System.Drawing.Point(117, 0)
        Me.TextBox_RSA_PublicKey.Name = "TextBox_RSA_PublicKey"
        Me.TextBox_RSA_PublicKey.ReadOnly = True
        Me.TextBox_RSA_PublicKey.Size = New System.Drawing.Size(445, 20)
        Me.TextBox_RSA_PublicKey.TabIndex = 1
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(3, 3)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(57, 13)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "Public Key"
        '
        'Panel12
        '
        Me.Panel12.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel12.Controls.Add(Me.Button_RSA_PrivateKey_Copy)
        Me.Panel12.Controls.Add(Me.TextBox_RSA_PrivateKey)
        Me.Panel12.Controls.Add(Me.Label6)
        Me.Panel12.Location = New System.Drawing.Point(3, 103)
        Me.Panel12.Name = "Panel12"
        Me.Panel12.Size = New System.Drawing.Size(648, 24)
        Me.Panel12.TabIndex = 0
        '
        'Button_RSA_PrivateKey_Copy
        '
        Me.Button_RSA_PrivateKey_Copy.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_RSA_PrivateKey_Copy.Location = New System.Drawing.Point(568, 0)
        Me.Button_RSA_PrivateKey_Copy.Name = "Button_RSA_PrivateKey_Copy"
        Me.Button_RSA_PrivateKey_Copy.Size = New System.Drawing.Size(80, 23)
        Me.Button_RSA_PrivateKey_Copy.TabIndex = 23
        Me.Button_RSA_PrivateKey_Copy.Text = "Copy Key"
        Me.Button_RSA_PrivateKey_Copy.UseVisualStyleBackColor = True
        '
        'TextBox_RSA_PrivateKey
        '
        Me.TextBox_RSA_PrivateKey.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_RSA_PrivateKey.Location = New System.Drawing.Point(117, 1)
        Me.TextBox_RSA_PrivateKey.Name = "TextBox_RSA_PrivateKey"
        Me.TextBox_RSA_PrivateKey.ReadOnly = True
        Me.TextBox_RSA_PrivateKey.Size = New System.Drawing.Size(445, 20)
        Me.TextBox_RSA_PrivateKey.TabIndex = 1
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(3, 3)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(61, 13)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "Private Key"
        '
        'Panel13
        '
        Me.Panel13.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel13.Controls.Add(Me.Label33)
        Me.Panel13.Controls.Add(Me.Button_RSA_InputDataClear)
        Me.Panel13.Controls.Add(Me.Panel14)
        Me.Panel13.Controls.Add(Me.Label7)
        Me.Panel13.Location = New System.Drawing.Point(20, 349)
        Me.Panel13.Name = "Panel13"
        Me.Panel13.Size = New System.Drawing.Size(659, 114)
        Me.Panel13.TabIndex = 7
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label33.Location = New System.Drawing.Point(69, 10)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(459, 13)
        Me.Label33.TabIndex = 21
        Me.Label33.Text = "NOTE: the input should be fairly short, as its RSA - no more than the key size in" &
    " character length"
        '
        'Button_RSA_InputDataClear
        '
        Me.Button_RSA_InputDataClear.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_RSA_InputDataClear.Location = New System.Drawing.Point(601, 5)
        Me.Button_RSA_InputDataClear.Name = "Button_RSA_InputDataClear"
        Me.Button_RSA_InputDataClear.Size = New System.Drawing.Size(52, 23)
        Me.Button_RSA_InputDataClear.TabIndex = 22
        Me.Button_RSA_InputDataClear.Text = "Clear"
        Me.Button_RSA_InputDataClear.UseVisualStyleBackColor = True
        '
        'Panel14
        '
        Me.Panel14.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel14.Controls.Add(Me.TextBox_RSA_InputData)
        Me.Panel14.Location = New System.Drawing.Point(9, 31)
        Me.Panel14.Name = "Panel14"
        Me.Panel14.Size = New System.Drawing.Size(642, 83)
        Me.Panel14.TabIndex = 2
        '
        'TextBox_RSA_InputData
        '
        Me.TextBox_RSA_InputData.AcceptsReturn = True
        Me.TextBox_RSA_InputData.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox_RSA_InputData.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TextBox_RSA_InputData.Location = New System.Drawing.Point(0, 0)
        Me.TextBox_RSA_InputData.Multiline = True
        Me.TextBox_RSA_InputData.Name = "TextBox_RSA_InputData"
        Me.TextBox_RSA_InputData.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TextBox_RSA_InputData.Size = New System.Drawing.Size(640, 81)
        Me.TextBox_RSA_InputData.TabIndex = 1
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(6, 9)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(57, 13)
        Me.Label7.TabIndex = 0
        Me.Label7.Text = "Input Data"
        '
        'Panel15
        '
        Me.Panel15.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel15.Controls.Add(Me.FlowLayoutPanel2)
        Me.Panel15.Location = New System.Drawing.Point(20, 469)
        Me.Panel15.Name = "Panel15"
        Me.Panel15.Size = New System.Drawing.Size(659, 35)
        Me.Panel15.TabIndex = 8
        '
        'FlowLayoutPanel2
        '
        Me.FlowLayoutPanel2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.FlowLayoutPanel2.Controls.Add(Me.Button_RSA_Encrypt_WithPublic)
        Me.FlowLayoutPanel2.Controls.Add(Me.Button_RSA_Encrypt_WithPrivate)
        Me.FlowLayoutPanel2.Controls.Add(Me.Button_RSA_Decrypt_WithPrivate)
        Me.FlowLayoutPanel2.Controls.Add(Me.Button_RSA_SwapInputOutpu)
        Me.FlowLayoutPanel2.Controls.Add(Me.Button_RSA_SwapInputOutput)
        Me.FlowLayoutPanel2.Location = New System.Drawing.Point(5, 0)
        Me.FlowLayoutPanel2.Name = "FlowLayoutPanel2"
        Me.FlowLayoutPanel2.Size = New System.Drawing.Size(649, 35)
        Me.FlowLayoutPanel2.TabIndex = 2
        '
        'Button_RSA_Encrypt_WithPublic
        '
        Me.Button_RSA_Encrypt_WithPublic.Location = New System.Drawing.Point(3, 3)
        Me.Button_RSA_Encrypt_WithPublic.Name = "Button_RSA_Encrypt_WithPublic"
        Me.Button_RSA_Encrypt_WithPublic.Size = New System.Drawing.Size(123, 23)
        Me.Button_RSA_Encrypt_WithPublic.TabIndex = 1
        Me.Button_RSA_Encrypt_WithPublic.Text = "Encrypt With Public"
        Me.Button_RSA_Encrypt_WithPublic.UseVisualStyleBackColor = True
        '
        'Button_RSA_Encrypt_WithPrivate
        '
        Me.Button_RSA_Encrypt_WithPrivate.Location = New System.Drawing.Point(132, 3)
        Me.Button_RSA_Encrypt_WithPrivate.Name = "Button_RSA_Encrypt_WithPrivate"
        Me.Button_RSA_Encrypt_WithPrivate.Size = New System.Drawing.Size(123, 23)
        Me.Button_RSA_Encrypt_WithPrivate.TabIndex = 24
        Me.Button_RSA_Encrypt_WithPrivate.Text = "Encrypt With Private"
        Me.Button_RSA_Encrypt_WithPrivate.UseVisualStyleBackColor = True
        '
        'Button_RSA_Decrypt_WithPrivate
        '
        Me.Button_RSA_Decrypt_WithPrivate.Location = New System.Drawing.Point(261, 3)
        Me.Button_RSA_Decrypt_WithPrivate.Name = "Button_RSA_Decrypt_WithPrivate"
        Me.Button_RSA_Decrypt_WithPrivate.Size = New System.Drawing.Size(68, 23)
        Me.Button_RSA_Decrypt_WithPrivate.TabIndex = 3
        Me.Button_RSA_Decrypt_WithPrivate.Text = "Decrypt"
        Me.Button_RSA_Decrypt_WithPrivate.UseVisualStyleBackColor = True
        '
        'Button_RSA_SwapInputOutpu
        '
        Me.Button_RSA_SwapInputOutpu.Location = New System.Drawing.Point(335, 3)
        Me.Button_RSA_SwapInputOutpu.Name = "Button_RSA_SwapInputOutpu"
        Me.Button_RSA_SwapInputOutpu.Size = New System.Drawing.Size(134, 23)
        Me.Button_RSA_SwapInputOutpu.TabIndex = 4
        Me.Button_RSA_SwapInputOutpu.Text = "Swap Input and Output"
        Me.Button_RSA_SwapInputOutpu.UseVisualStyleBackColor = True
        '
        'Button_RSA_SwapInputOutput
        '
        Me.Button_RSA_SwapInputOutput.Location = New System.Drawing.Point(475, 3)
        Me.Button_RSA_SwapInputOutput.Name = "Button_RSA_SwapInputOutput"
        Me.Button_RSA_SwapInputOutput.Size = New System.Drawing.Size(133, 23)
        Me.Button_RSA_SwapInputOutput.TabIndex = 23
        Me.Button_RSA_SwapInputOutput.Text = "Clear Input and Output"
        Me.Button_RSA_SwapInputOutput.UseVisualStyleBackColor = True
        '
        'Panel16
        '
        Me.Panel16.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel16.Controls.Add(Me.Button_RSA_OutputDataClear)
        Me.Panel16.Controls.Add(Me.Panel17)
        Me.Panel16.Controls.Add(Me.Label8)
        Me.Panel16.Location = New System.Drawing.Point(20, 507)
        Me.Panel16.Name = "Panel16"
        Me.Panel16.Size = New System.Drawing.Size(659, 125)
        Me.Panel16.TabIndex = 9
        '
        'Button_RSA_OutputDataClear
        '
        Me.Button_RSA_OutputDataClear.Location = New System.Drawing.Point(72, 7)
        Me.Button_RSA_OutputDataClear.Name = "Button_RSA_OutputDataClear"
        Me.Button_RSA_OutputDataClear.Size = New System.Drawing.Size(52, 23)
        Me.Button_RSA_OutputDataClear.TabIndex = 23
        Me.Button_RSA_OutputDataClear.Text = "Clear"
        Me.Button_RSA_OutputDataClear.UseVisualStyleBackColor = True
        '
        'Panel17
        '
        Me.Panel17.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel17.Controls.Add(Me.TextBox_RSA_OutputData)
        Me.Panel17.Location = New System.Drawing.Point(9, 35)
        Me.Panel17.Name = "Panel17"
        Me.Panel17.Size = New System.Drawing.Size(642, 90)
        Me.Panel17.TabIndex = 2
        '
        'TextBox_RSA_OutputData
        '
        Me.TextBox_RSA_OutputData.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox_RSA_OutputData.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TextBox_RSA_OutputData.Location = New System.Drawing.Point(0, 0)
        Me.TextBox_RSA_OutputData.Multiline = True
        Me.TextBox_RSA_OutputData.Name = "TextBox_RSA_OutputData"
        Me.TextBox_RSA_OutputData.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TextBox_RSA_OutputData.Size = New System.Drawing.Size(640, 88)
        Me.TextBox_RSA_OutputData.TabIndex = 1
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(6, 11)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(65, 13)
        Me.Label8.TabIndex = 0
        Me.Label8.Text = "Output Data"
        '
        'TabPage_AES
        '
        Me.TabPage_AES.AutoScroll = True
        Me.TabPage_AES.Controls.Add(Me.Panel37)
        Me.TabPage_AES.Controls.Add(Me.TabControl3)
        Me.TabPage_AES.Controls.Add(Me.Button_AES_ConvertIVToHash)
        Me.TabPage_AES.Controls.Add(Me.Button_AES_ConvertKeyToHash)
        Me.TabPage_AES.Controls.Add(Me.Button_AES_Clear)
        Me.TabPage_AES.Controls.Add(Me.Button_AES_Export)
        Me.TabPage_AES.Controls.Add(Me.Label15)
        Me.TabPage_AES.Controls.Add(Me.Panel7)
        Me.TabPage_AES.Location = New System.Drawing.Point(4, 22)
        Me.TabPage_AES.Name = "TabPage_AES"
        Me.TabPage_AES.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage_AES.Size = New System.Drawing.Size(771, 629)
        Me.TabPage_AES.TabIndex = 0
        Me.TabPage_AES.Text = "AES Encrypt"
        Me.TabPage_AES.UseVisualStyleBackColor = True
        '
        'Panel37
        '
        Me.Panel37.Location = New System.Drawing.Point(22, 616)
        Me.Panel37.Name = "Panel37"
        Me.Panel37.Size = New System.Drawing.Size(200, 53)
        Me.Panel37.TabIndex = 13
        '
        'TabControl3
        '
        Me.TabControl3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TabControl3.Controls.Add(Me.TabPage9)
        Me.TabControl3.Controls.Add(Me.TabPage10)
        Me.TabControl3.Location = New System.Drawing.Point(18, 213)
        Me.TabControl3.Name = "TabControl3"
        Me.TabControl3.SelectedIndex = 0
        Me.TabControl3.Size = New System.Drawing.Size(660, 354)
        Me.TabControl3.TabIndex = 12
        '
        'TabPage9
        '
        Me.TabPage9.Controls.Add(Me.Button_AES_ClearInput)
        Me.TabPage9.Controls.Add(Me.Panel1)
        Me.TabPage9.Controls.Add(Me.Label1)
        Me.TabPage9.Controls.Add(Me.Panel3)
        Me.TabPage9.Controls.Add(Me.Panel5)
        Me.TabPage9.Location = New System.Drawing.Point(4, 22)
        Me.TabPage9.Name = "TabPage9"
        Me.TabPage9.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage9.Size = New System.Drawing.Size(652, 328)
        Me.TabPage9.TabIndex = 0
        Me.TabPage9.Text = "Text"
        Me.TabPage9.UseVisualStyleBackColor = True
        '
        'Button_AES_ClearInput
        '
        Me.Button_AES_ClearInput.Location = New System.Drawing.Point(92, 9)
        Me.Button_AES_ClearInput.Name = "Button_AES_ClearInput"
        Me.Button_AES_ClearInput.Size = New System.Drawing.Size(52, 23)
        Me.Button_AES_ClearInput.TabIndex = 22
        Me.Button_AES_ClearInput.Text = "Clear"
        Me.Button_AES_ClearInput.UseVisualStyleBackColor = True
        '
        'TabPage10
        '
        Me.TabPage10.Controls.Add(Me.Panel41)
        Me.TabPage10.Controls.Add(Me.Panel39)
        Me.TabPage10.Controls.Add(Me.Panel38)
        Me.TabPage10.Location = New System.Drawing.Point(4, 22)
        Me.TabPage10.Name = "TabPage10"
        Me.TabPage10.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage10.Size = New System.Drawing.Size(652, 328)
        Me.TabPage10.TabIndex = 1
        Me.TabPage10.Text = "File"
        Me.TabPage10.UseVisualStyleBackColor = True
        '
        'Panel41
        '
        Me.Panel41.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel41.Controls.Add(Me.Button_AES_FolderToOutput)
        Me.Panel41.Controls.Add(Me.TextBox_AES_OutputFile)
        Me.Panel41.Controls.Add(Me.Label35)
        Me.Panel41.Location = New System.Drawing.Point(9, 78)
        Me.Panel41.Name = "Panel41"
        Me.Panel41.Size = New System.Drawing.Size(627, 23)
        Me.Panel41.TabIndex = 24
        '
        'Button_AES_FolderToOutput
        '
        Me.Button_AES_FolderToOutput.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_AES_FolderToOutput.Location = New System.Drawing.Point(577, -1)
        Me.Button_AES_FolderToOutput.Name = "Button_AES_FolderToOutput"
        Me.Button_AES_FolderToOutput.Size = New System.Drawing.Size(50, 23)
        Me.Button_AES_FolderToOutput.TabIndex = 10
        Me.Button_AES_FolderToOutput.Text = "Folder"
        Me.Button_AES_FolderToOutput.UseVisualStyleBackColor = True
        '
        'TextBox_AES_OutputFile
        '
        Me.TextBox_AES_OutputFile.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_AES_OutputFile.Location = New System.Drawing.Point(95, 1)
        Me.TextBox_AES_OutputFile.Name = "TextBox_AES_OutputFile"
        Me.TextBox_AES_OutputFile.ReadOnly = True
        Me.TextBox_AES_OutputFile.Size = New System.Drawing.Size(480, 20)
        Me.TextBox_AES_OutputFile.TabIndex = 1
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(3, 3)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(58, 13)
        Me.Label35.TabIndex = 0
        Me.Label35.Text = "Output File"
        '
        'Panel39
        '
        Me.Panel39.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel39.Controls.Add(Me.FlowLayoutPanel5)
        Me.Panel39.Location = New System.Drawing.Point(9, 38)
        Me.Panel39.Name = "Panel39"
        Me.Panel39.Size = New System.Drawing.Size(620, 34)
        Me.Panel39.TabIndex = 11
        '
        'FlowLayoutPanel5
        '
        Me.FlowLayoutPanel5.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.FlowLayoutPanel5.Controls.Add(Me.Button_AES_Files_Encrypt)
        Me.FlowLayoutPanel5.Controls.Add(Me.Button_AES_Files_Decrypt)
        Me.FlowLayoutPanel5.Controls.Add(Me.Button_AES_Files_SwapInputOutput)
        Me.FlowLayoutPanel5.Controls.Add(Me.Button_AES_Files_ClearInputOutput)
        Me.FlowLayoutPanel5.Location = New System.Drawing.Point(5, 1)
        Me.FlowLayoutPanel5.Name = "FlowLayoutPanel5"
        Me.FlowLayoutPanel5.Size = New System.Drawing.Size(610, 32)
        Me.FlowLayoutPanel5.TabIndex = 2
        '
        'Button_AES_Files_Encrypt
        '
        Me.Button_AES_Files_Encrypt.Location = New System.Drawing.Point(3, 3)
        Me.Button_AES_Files_Encrypt.Name = "Button_AES_Files_Encrypt"
        Me.Button_AES_Files_Encrypt.Size = New System.Drawing.Size(75, 23)
        Me.Button_AES_Files_Encrypt.TabIndex = 0
        Me.Button_AES_Files_Encrypt.Text = "Encrypt"
        Me.Button_AES_Files_Encrypt.UseVisualStyleBackColor = True
        '
        'Button_AES_Files_Decrypt
        '
        Me.Button_AES_Files_Decrypt.Location = New System.Drawing.Point(84, 3)
        Me.Button_AES_Files_Decrypt.Name = "Button_AES_Files_Decrypt"
        Me.Button_AES_Files_Decrypt.Size = New System.Drawing.Size(75, 23)
        Me.Button_AES_Files_Decrypt.TabIndex = 1
        Me.Button_AES_Files_Decrypt.Text = "Decrypt"
        Me.Button_AES_Files_Decrypt.UseVisualStyleBackColor = True
        '
        'Button_AES_Files_SwapInputOutput
        '
        Me.Button_AES_Files_SwapInputOutput.Location = New System.Drawing.Point(165, 3)
        Me.Button_AES_Files_SwapInputOutput.Name = "Button_AES_Files_SwapInputOutput"
        Me.Button_AES_Files_SwapInputOutput.Size = New System.Drawing.Size(134, 23)
        Me.Button_AES_Files_SwapInputOutput.TabIndex = 24
        Me.Button_AES_Files_SwapInputOutput.Text = "Swap Input and Output"
        Me.Button_AES_Files_SwapInputOutput.UseVisualStyleBackColor = True
        '
        'Button_AES_Files_ClearInputOutput
        '
        Me.Button_AES_Files_ClearInputOutput.Location = New System.Drawing.Point(305, 3)
        Me.Button_AES_Files_ClearInputOutput.Name = "Button_AES_Files_ClearInputOutput"
        Me.Button_AES_Files_ClearInputOutput.Size = New System.Drawing.Size(133, 23)
        Me.Button_AES_Files_ClearInputOutput.TabIndex = 25
        Me.Button_AES_Files_ClearInputOutput.Text = "Clear Input and Output"
        Me.Button_AES_Files_ClearInputOutput.UseVisualStyleBackColor = True
        '
        'Panel38
        '
        Me.Panel38.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel38.Controls.Add(Me.TextBox_AES_BrowsedFilePath)
        Me.Panel38.Controls.Add(Me.Label29)
        Me.Panel38.Controls.Add(Me.Button_AES_BrowseForFile)
        Me.Panel38.Location = New System.Drawing.Point(9, 9)
        Me.Panel38.Name = "Panel38"
        Me.Panel38.Size = New System.Drawing.Size(627, 23)
        Me.Panel38.TabIndex = 10
        '
        'TextBox_AES_BrowsedFilePath
        '
        Me.TextBox_AES_BrowsedFilePath.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_AES_BrowsedFilePath.Location = New System.Drawing.Point(95, 0)
        Me.TextBox_AES_BrowsedFilePath.Name = "TextBox_AES_BrowsedFilePath"
        Me.TextBox_AES_BrowsedFilePath.ReadOnly = True
        Me.TextBox_AES_BrowsedFilePath.Size = New System.Drawing.Size(480, 20)
        Me.TextBox_AES_BrowsedFilePath.TabIndex = 1
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(3, 3)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(50, 13)
        Me.Label29.TabIndex = 0
        Me.Label29.Text = "Input File"
        '
        'Button_AES_BrowseForFile
        '
        Me.Button_AES_BrowseForFile.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_AES_BrowseForFile.Location = New System.Drawing.Point(577, 0)
        Me.Button_AES_BrowseForFile.Name = "Button_AES_BrowseForFile"
        Me.Button_AES_BrowseForFile.Size = New System.Drawing.Size(50, 23)
        Me.Button_AES_BrowseForFile.TabIndex = 9
        Me.Button_AES_BrowseForFile.Text = "Browse"
        Me.Button_AES_BrowseForFile.UseVisualStyleBackColor = True
        '
        'Button_AES_ConvertIVToHash
        '
        Me.Button_AES_ConvertIVToHash.Enabled = False
        Me.Button_AES_ConvertIVToHash.Location = New System.Drawing.Point(238, 48)
        Me.Button_AES_ConvertIVToHash.Name = "Button_AES_ConvertIVToHash"
        Me.Button_AES_ConvertIVToHash.Size = New System.Drawing.Size(141, 23)
        Me.Button_AES_ConvertIVToHash.TabIndex = 11
        Me.Button_AES_ConvertIVToHash.Text = "Convert Salt to Hash"
        Me.Button_AES_ConvertIVToHash.UseVisualStyleBackColor = True
        '
        'Button_AES_ConvertKeyToHash
        '
        Me.Button_AES_ConvertKeyToHash.Enabled = False
        Me.Button_AES_ConvertKeyToHash.Location = New System.Drawing.Point(104, 48)
        Me.Button_AES_ConvertKeyToHash.Name = "Button_AES_ConvertKeyToHash"
        Me.Button_AES_ConvertKeyToHash.Size = New System.Drawing.Size(128, 23)
        Me.Button_AES_ConvertKeyToHash.TabIndex = 10
        Me.Button_AES_ConvertKeyToHash.Text = "Convert Seed to Hash"
        Me.Button_AES_ConvertKeyToHash.UseVisualStyleBackColor = True
        '
        'Button_AES_Clear
        '
        Me.Button_AES_Clear.Location = New System.Drawing.Point(385, 48)
        Me.Button_AES_Clear.Name = "Button_AES_Clear"
        Me.Button_AES_Clear.Size = New System.Drawing.Size(75, 23)
        Me.Button_AES_Clear.TabIndex = 9
        Me.Button_AES_Clear.Text = "Clear"
        Me.Button_AES_Clear.UseVisualStyleBackColor = True
        '
        'Button_AES_Export
        '
        Me.Button_AES_Export.Location = New System.Drawing.Point(23, 48)
        Me.Button_AES_Export.Name = "Button_AES_Export"
        Me.Button_AES_Export.Size = New System.Drawing.Size(75, 23)
        Me.Button_AES_Export.TabIndex = 8
        Me.Button_AES_Export.Text = "Export Key"
        Me.Button_AES_Export.UseVisualStyleBackColor = True
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label15.Location = New System.Drawing.Point(20, 23)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(720, 13)
        Me.Label15.TabIndex = 7
        Me.Label15.Text = "Provide anything as the encryption key and Password - both are needed for encrypt" &
    "ion and decryption though - or auto-generate them using the buttons"
        '
        'TabPage_LicenseGeneration
        '
        Me.TabPage_LicenseGeneration.Controls.Add(Me.TabControl2)
        Me.TabPage_LicenseGeneration.Location = New System.Drawing.Point(4, 22)
        Me.TabPage_LicenseGeneration.Name = "TabPage_LicenseGeneration"
        Me.TabPage_LicenseGeneration.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage_LicenseGeneration.Size = New System.Drawing.Size(771, 629)
        Me.TabPage_LicenseGeneration.TabIndex = 5
        Me.TabPage_LicenseGeneration.Text = "License Generation"
        Me.TabPage_LicenseGeneration.UseVisualStyleBackColor = True
        '
        'TabControl2
        '
        Me.TabControl2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TabControl2.Controls.Add(Me.TabPage_LICFile)
        Me.TabControl2.Controls.Add(Me.TabPage_ProductSerial)
        Me.TabControl2.Controls.Add(Me.TabPage11)
        Me.TabControl2.Controls.Add(Me.TabPage_Verify)
        Me.TabControl2.Controls.Add(Me.TabPage6)
        Me.TabControl2.Location = New System.Drawing.Point(6, 16)
        Me.TabControl2.Name = "TabControl2"
        Me.TabControl2.SelectedIndex = 0
        Me.TabControl2.Size = New System.Drawing.Size(759, 607)
        Me.TabControl2.TabIndex = 0
        '
        'TabPage_LICFile
        '
        Me.TabPage_LICFile.AutoScroll = True
        Me.TabPage_LICFile.Controls.Add(Me.Panel69)
        Me.TabPage_LICFile.Controls.Add(Me.TabControl_License_Lic_ImportedData)
        Me.TabPage_LICFile.Controls.Add(Me.Panel67)
        Me.TabPage_LICFile.Controls.Add(Me.Panel66)
        Me.TabPage_LICFile.Controls.Add(Me.Button_License_Lic_CloseJSONLicFile)
        Me.TabPage_LICFile.Controls.Add(Me.Panel65)
        Me.TabPage_LICFile.Controls.Add(Me.Panel64)
        Me.TabPage_LICFile.Controls.Add(Me.Panel63)
        Me.TabPage_LICFile.Controls.Add(Me.Panel62)
        Me.TabPage_LICFile.Controls.Add(Me.Panel60)
        Me.TabPage_LICFile.Controls.Add(Me.Panel61)
        Me.TabPage_LICFile.Controls.Add(Me.Button_License_Lic_ImportJSONLicFile)
        Me.TabPage_LICFile.Controls.Add(Me.Label53)
        Me.TabPage_LICFile.Controls.Add(Me.Button_License_Lic_SaveFile)
        Me.TabPage_LICFile.Controls.Add(Me.Label39)
        Me.TabPage_LICFile.Controls.Add(Me.Label38)
        Me.TabPage_LICFile.Controls.Add(Me.Panel46)
        Me.TabPage_LICFile.Controls.Add(Me.Panel_License_Lic_Verification)
        Me.TabPage_LICFile.Controls.Add(Me.Label37)
        Me.TabPage_LICFile.Controls.Add(Me.CheckBox_License_Lic_AddSignature)
        Me.TabPage_LICFile.Controls.Add(Me.Button_License_Lic_Preview)
        Me.TabPage_LICFile.Controls.Add(Me.Label36)
        Me.TabPage_LICFile.Controls.Add(Me.Panel45)
        Me.TabPage_LICFile.Location = New System.Drawing.Point(4, 22)
        Me.TabPage_LICFile.Name = "TabPage_LICFile"
        Me.TabPage_LICFile.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage_LICFile.Size = New System.Drawing.Size(751, 581)
        Me.TabPage_LICFile.TabIndex = 0
        Me.TabPage_LICFile.Text = "LIC File"
        Me.TabPage_LICFile.UseVisualStyleBackColor = True
        '
        'Panel69
        '
        Me.Panel69.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel69.Controls.Add(Me.TextBox_License_Lic_Imported_DataHashed)
        Me.Panel69.Controls.Add(Me.Label62)
        Me.Panel69.Location = New System.Drawing.Point(9, 1885)
        Me.Panel69.Name = "Panel69"
        Me.Panel69.Size = New System.Drawing.Size(596, 24)
        Me.Panel69.TabIndex = 47
        '
        'TextBox_License_Lic_Imported_DataHashed
        '
        Me.TextBox_License_Lic_Imported_DataHashed.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_License_Lic_Imported_DataHashed.Location = New System.Drawing.Point(117, 1)
        Me.TextBox_License_Lic_Imported_DataHashed.Name = "TextBox_License_Lic_Imported_DataHashed"
        Me.TextBox_License_Lic_Imported_DataHashed.Size = New System.Drawing.Size(469, 20)
        Me.TextBox_License_Lic_Imported_DataHashed.TabIndex = 1
        '
        'Label62
        '
        Me.Label62.AutoSize = True
        Me.Label62.Location = New System.Drawing.Point(2, 4)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(61, 13)
        Me.Label62.TabIndex = 0
        Me.Label62.Text = "Data Hash:"
        '
        'TabControl_License_Lic_ImportedData
        '
        Me.TabControl_License_Lic_ImportedData.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TabControl_License_Lic_ImportedData.Controls.Add(Me.TabPage_DataFields)
        Me.TabControl_License_Lic_ImportedData.Location = New System.Drawing.Point(9, 1701)
        Me.TabControl_License_Lic_ImportedData.Name = "TabControl_License_Lic_ImportedData"
        Me.TabControl_License_Lic_ImportedData.SelectedIndex = 0
        Me.TabControl_License_Lic_ImportedData.Size = New System.Drawing.Size(598, 170)
        Me.TabControl_License_Lic_ImportedData.TabIndex = 46
        '
        'TabPage_DataFields
        '
        Me.TabPage_DataFields.Controls.Add(Me.Panel68)
        Me.TabPage_DataFields.Location = New System.Drawing.Point(4, 22)
        Me.TabPage_DataFields.Name = "TabPage_DataFields"
        Me.TabPage_DataFields.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage_DataFields.Size = New System.Drawing.Size(590, 144)
        Me.TabPage_DataFields.TabIndex = 0
        Me.TabPage_DataFields.Text = "Data Fields"
        Me.TabPage_DataFields.UseVisualStyleBackColor = True
        '
        'Panel68
        '
        Me.Panel68.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel68.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel68.Controls.Add(Me.TextBox_License_Lic_Imported_DataFields)
        Me.Panel68.Location = New System.Drawing.Point(6, 6)
        Me.Panel68.Name = "Panel68"
        Me.Panel68.Size = New System.Drawing.Size(578, 132)
        Me.Panel68.TabIndex = 0
        '
        'TextBox_License_Lic_Imported_DataFields
        '
        Me.TextBox_License_Lic_Imported_DataFields.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox_License_Lic_Imported_DataFields.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TextBox_License_Lic_Imported_DataFields.Location = New System.Drawing.Point(0, 0)
        Me.TextBox_License_Lic_Imported_DataFields.Multiline = True
        Me.TextBox_License_Lic_Imported_DataFields.Name = "TextBox_License_Lic_Imported_DataFields"
        Me.TextBox_License_Lic_Imported_DataFields.Size = New System.Drawing.Size(576, 130)
        Me.TextBox_License_Lic_Imported_DataFields.TabIndex = 0
        '
        'Panel67
        '
        Me.Panel67.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel67.Controls.Add(Me.TextBox_License_Lic_ImportedPublicKeyFingerprint)
        Me.Panel67.Controls.Add(Me.Label61)
        Me.Panel67.Location = New System.Drawing.Point(10, 2015)
        Me.Panel67.Name = "Panel67"
        Me.Panel67.Size = New System.Drawing.Size(596, 24)
        Me.Panel67.TabIndex = 45
        '
        'TextBox_License_Lic_ImportedPublicKeyFingerprint
        '
        Me.TextBox_License_Lic_ImportedPublicKeyFingerprint.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_License_Lic_ImportedPublicKeyFingerprint.Location = New System.Drawing.Point(117, 2)
        Me.TextBox_License_Lic_ImportedPublicKeyFingerprint.Name = "TextBox_License_Lic_ImportedPublicKeyFingerprint"
        Me.TextBox_License_Lic_ImportedPublicKeyFingerprint.ReadOnly = True
        Me.TextBox_License_Lic_ImportedPublicKeyFingerprint.Size = New System.Drawing.Size(469, 20)
        Me.TextBox_License_Lic_ImportedPublicKeyFingerprint.TabIndex = 24
        '
        'Label61
        '
        Me.Label61.AutoSize = True
        Me.Label61.Location = New System.Drawing.Point(1, 2)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(109, 13)
        Me.Label61.TabIndex = 0
        Me.Label61.Text = "Public Key Fingerprint"
        '
        'Panel66
        '
        Me.Panel66.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel66.Controls.Add(Me.TextBox_License_Lic_ImportedAlgorithm)
        Me.Panel66.Controls.Add(Me.Label60)
        Me.Panel66.Location = New System.Drawing.Point(9, 1989)
        Me.Panel66.Name = "Panel66"
        Me.Panel66.Size = New System.Drawing.Size(596, 24)
        Me.Panel66.TabIndex = 44
        '
        'TextBox_License_Lic_ImportedAlgorithm
        '
        Me.TextBox_License_Lic_ImportedAlgorithm.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_License_Lic_ImportedAlgorithm.Location = New System.Drawing.Point(117, 2)
        Me.TextBox_License_Lic_ImportedAlgorithm.Name = "TextBox_License_Lic_ImportedAlgorithm"
        Me.TextBox_License_Lic_ImportedAlgorithm.ReadOnly = True
        Me.TextBox_License_Lic_ImportedAlgorithm.Size = New System.Drawing.Size(469, 20)
        Me.TextBox_License_Lic_ImportedAlgorithm.TabIndex = 24
        '
        'Label60
        '
        Me.Label60.AutoSize = True
        Me.Label60.Location = New System.Drawing.Point(1, 2)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(50, 13)
        Me.Label60.TabIndex = 0
        Me.Label60.Text = "Algorithm"
        '
        'Button_License_Lic_CloseJSONLicFile
        '
        Me.Button_License_Lic_CloseJSONLicFile.Location = New System.Drawing.Point(133, 1630)
        Me.Button_License_Lic_CloseJSONLicFile.Name = "Button_License_Lic_CloseJSONLicFile"
        Me.Button_License_Lic_CloseJSONLicFile.Size = New System.Drawing.Size(70, 23)
        Me.Button_License_Lic_CloseJSONLicFile.TabIndex = 43
        Me.Button_License_Lic_CloseJSONLicFile.Text = "Close File"
        Me.Button_License_Lic_CloseJSONLicFile.UseVisualStyleBackColor = True
        '
        'Panel65
        '
        Me.Panel65.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel65.Controls.Add(Me.TextBox_License_Lic_LICFilePath)
        Me.Panel65.Controls.Add(Me.Label59)
        Me.Panel65.Location = New System.Drawing.Point(9, 1669)
        Me.Panel65.Name = "Panel65"
        Me.Panel65.Size = New System.Drawing.Size(598, 24)
        Me.Panel65.TabIndex = 42
        '
        'TextBox_License_Lic_LICFilePath
        '
        Me.TextBox_License_Lic_LICFilePath.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_License_Lic_LICFilePath.Location = New System.Drawing.Point(117, 1)
        Me.TextBox_License_Lic_LICFilePath.Name = "TextBox_License_Lic_LICFilePath"
        Me.TextBox_License_Lic_LICFilePath.ReadOnly = True
        Me.TextBox_License_Lic_LICFilePath.Size = New System.Drawing.Size(470, 20)
        Me.TextBox_License_Lic_LICFilePath.TabIndex = 1
        '
        'Label59
        '
        Me.Label59.AutoSize = True
        Me.Label59.Location = New System.Drawing.Point(3, 4)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(67, 13)
        Me.Label59.TabIndex = 0
        Me.Label59.Text = "LIC File Path"
        '
        'Panel64
        '
        Me.Panel64.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel64.Controls.Add(Me.TextBox_License_Lic_ImportedSignature)
        Me.Panel64.Controls.Add(Me.Label58)
        Me.Panel64.Location = New System.Drawing.Point(9, 1911)
        Me.Panel64.Name = "Panel64"
        Me.Panel64.Size = New System.Drawing.Size(596, 24)
        Me.Panel64.TabIndex = 41
        '
        'TextBox_License_Lic_ImportedSignature
        '
        Me.TextBox_License_Lic_ImportedSignature.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_License_Lic_ImportedSignature.Location = New System.Drawing.Point(117, 1)
        Me.TextBox_License_Lic_ImportedSignature.Name = "TextBox_License_Lic_ImportedSignature"
        Me.TextBox_License_Lic_ImportedSignature.Size = New System.Drawing.Size(469, 20)
        Me.TextBox_License_Lic_ImportedSignature.TabIndex = 1
        '
        'Label58
        '
        Me.Label58.AutoSize = True
        Me.Label58.Location = New System.Drawing.Point(2, 4)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(52, 13)
        Me.Label58.TabIndex = 0
        Me.Label58.Text = "Signature"
        '
        'Panel63
        '
        Me.Panel63.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel63.Controls.Add(Me.Button_License_Lic_VerifyImportedLicFile)
        Me.Panel63.Controls.Add(Me.TextBox_License_Lic_VerifyImportedLICFile)
        Me.Panel63.Controls.Add(Me.Label57)
        Me.Panel63.Location = New System.Drawing.Point(9, 2101)
        Me.Panel63.Name = "Panel63"
        Me.Panel63.Size = New System.Drawing.Size(598, 24)
        Me.Panel63.TabIndex = 40
        '
        'Button_License_Lic_VerifyImportedLicFile
        '
        Me.Button_License_Lic_VerifyImportedLicFile.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_License_Lic_VerifyImportedLicFile.Location = New System.Drawing.Point(525, 0)
        Me.Button_License_Lic_VerifyImportedLicFile.Name = "Button_License_Lic_VerifyImportedLicFile"
        Me.Button_License_Lic_VerifyImportedLicFile.Size = New System.Drawing.Size(62, 23)
        Me.Button_License_Lic_VerifyImportedLicFile.TabIndex = 26
        Me.Button_License_Lic_VerifyImportedLicFile.Text = "Verify"
        Me.Button_License_Lic_VerifyImportedLicFile.UseVisualStyleBackColor = True
        '
        'TextBox_License_Lic_VerifyImportedLICFile
        '
        Me.TextBox_License_Lic_VerifyImportedLICFile.Location = New System.Drawing.Point(117, 2)
        Me.TextBox_License_Lic_VerifyImportedLICFile.Name = "TextBox_License_Lic_VerifyImportedLICFile"
        Me.TextBox_License_Lic_VerifyImportedLICFile.Size = New System.Drawing.Size(77, 20)
        Me.TextBox_License_Lic_VerifyImportedLICFile.TabIndex = 24
        '
        'Label57
        '
        Me.Label57.AutoSize = True
        Me.Label57.Location = New System.Drawing.Point(3, 3)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(48, 13)
        Me.Label57.TabIndex = 0
        Me.Label57.Text = "Verified?"
        '
        'Panel62
        '
        Me.Panel62.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel62.Controls.Add(Me.TextBox_License_Lic_ImportedSalt)
        Me.Panel62.Controls.Add(Me.Label56)
        Me.Panel62.Location = New System.Drawing.Point(9, 1937)
        Me.Panel62.Name = "Panel62"
        Me.Panel62.Size = New System.Drawing.Size(596, 24)
        Me.Panel62.TabIndex = 40
        '
        'TextBox_License_Lic_ImportedSalt
        '
        Me.TextBox_License_Lic_ImportedSalt.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_License_Lic_ImportedSalt.Location = New System.Drawing.Point(117, 1)
        Me.TextBox_License_Lic_ImportedSalt.Name = "TextBox_License_Lic_ImportedSalt"
        Me.TextBox_License_Lic_ImportedSalt.Size = New System.Drawing.Size(469, 20)
        Me.TextBox_License_Lic_ImportedSalt.TabIndex = 1
        '
        'Label56
        '
        Me.Label56.AutoSize = True
        Me.Label56.Location = New System.Drawing.Point(0, 4)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(90, 13)
        Me.Label56.TabIndex = 0
        Me.Label56.Text = "Salt (if applicable)"
        '
        'Panel60
        '
        Me.Panel60.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel60.Controls.Add(Me.TextBox_License_Lic_ImportedKeySize)
        Me.Panel60.Controls.Add(Me.Label54)
        Me.Panel60.Location = New System.Drawing.Point(9, 1963)
        Me.Panel60.Name = "Panel60"
        Me.Panel60.Size = New System.Drawing.Size(596, 24)
        Me.Panel60.TabIndex = 39
        '
        'TextBox_License_Lic_ImportedKeySize
        '
        Me.TextBox_License_Lic_ImportedKeySize.Location = New System.Drawing.Point(117, 2)
        Me.TextBox_License_Lic_ImportedKeySize.Name = "TextBox_License_Lic_ImportedKeySize"
        Me.TextBox_License_Lic_ImportedKeySize.Size = New System.Drawing.Size(77, 20)
        Me.TextBox_License_Lic_ImportedKeySize.TabIndex = 24
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.Location = New System.Drawing.Point(1, 2)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(48, 13)
        Me.Label54.TabIndex = 0
        Me.Label54.Text = "Key Size"
        '
        'Panel61
        '
        Me.Panel61.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel61.Controls.Add(Me.TextBox_License_Lic_PastedPublicKey)
        Me.Panel61.Controls.Add(Me.Label55)
        Me.Panel61.Location = New System.Drawing.Point(9, 2075)
        Me.Panel61.Name = "Panel61"
        Me.Panel61.Size = New System.Drawing.Size(598, 24)
        Me.Panel61.TabIndex = 38
        '
        'TextBox_License_Lic_PastedPublicKey
        '
        Me.TextBox_License_Lic_PastedPublicKey.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_License_Lic_PastedPublicKey.Location = New System.Drawing.Point(117, 1)
        Me.TextBox_License_Lic_PastedPublicKey.Name = "TextBox_License_Lic_PastedPublicKey"
        Me.TextBox_License_Lic_PastedPublicKey.Size = New System.Drawing.Size(470, 20)
        Me.TextBox_License_Lic_PastedPublicKey.TabIndex = 1
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.Location = New System.Drawing.Point(3, 3)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(87, 13)
        Me.Label55.TabIndex = 0
        Me.Label55.Text = "Paste Public Key"
        '
        'Button_License_Lic_ImportJSONLicFile
        '
        Me.Button_License_Lic_ImportJSONLicFile.Location = New System.Drawing.Point(9, 1630)
        Me.Button_License_Lic_ImportJSONLicFile.Name = "Button_License_Lic_ImportJSONLicFile"
        Me.Button_License_Lic_ImportJSONLicFile.Size = New System.Drawing.Size(118, 23)
        Me.Button_License_Lic_ImportJSONLicFile.TabIndex = 37
        Me.Button_License_Lic_ImportJSONLicFile.Text = "Import License .JSON"
        Me.Button_License_Lic_ImportJSONLicFile.UseVisualStyleBackColor = True
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label53.Location = New System.Drawing.Point(6, 1599)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(98, 13)
        Me.Label53.TabIndex = 36
        Me.Label53.Text = "Import / Testing"
        '
        'Button_License_Lic_SaveFile
        '
        Me.Button_License_Lic_SaveFile.Location = New System.Drawing.Point(95, 1478)
        Me.Button_License_Lic_SaveFile.Name = "Button_License_Lic_SaveFile"
        Me.Button_License_Lic_SaveFile.Size = New System.Drawing.Size(80, 23)
        Me.Button_License_Lic_SaveFile.TabIndex = 34
        Me.Button_License_Lic_SaveFile.Text = "Save File"
        Me.Button_License_Lic_SaveFile.UseVisualStyleBackColor = True
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label39.Location = New System.Drawing.Point(9, 32)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(622, 13)
        Me.Label39.TabIndex = 33
        Me.Label39.Text = "Create a License file (.LIC) by building a serialzed JSON-object. Its strongly ad" &
    "vised to add a signature to the license for verification."
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.Location = New System.Drawing.Point(9, 1453)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(52, 13)
        Me.Label38.TabIndex = 32
        Me.Label38.Text = "Preview"
        '
        'Panel46
        '
        Me.Panel46.Location = New System.Drawing.Point(3, 2153)
        Me.Panel46.Name = "Panel46"
        Me.Panel46.Size = New System.Drawing.Size(200, 39)
        Me.Panel46.TabIndex = 31
        '
        'Panel_License_Lic_Verification
        '
        Me.Panel_License_Lic_Verification.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel_License_Lic_Verification.Controls.Add(Me.Panel54)
        Me.Panel_License_Lic_Verification.Controls.Add(Me.Label49)
        Me.Panel_License_Lic_Verification.Controls.Add(Me.Panel50)
        Me.Panel_License_Lic_Verification.Controls.Add(Me.Panel51)
        Me.Panel_License_Lic_Verification.Controls.Add(Me.Panel52)
        Me.Panel_License_Lic_Verification.Controls.Add(Me.Panel53)
        Me.Panel_License_Lic_Verification.Controls.Add(Me.Panel59)
        Me.Panel_License_Lic_Verification.Controls.Add(Me.Panel58)
        Me.Panel_License_Lic_Verification.Controls.Add(Me.Panel57)
        Me.Panel_License_Lic_Verification.Controls.Add(Me.Panel56)
        Me.Panel_License_Lic_Verification.Controls.Add(Me.Panel55)
        Me.Panel_License_Lic_Verification.Controls.Add(Me.Panel49)
        Me.Panel_License_Lic_Verification.Controls.Add(Me.Panel47)
        Me.Panel_License_Lic_Verification.Controls.Add(Me.FlowLayoutPanel_License_Lic_Verification)
        Me.Panel_License_Lic_Verification.Controls.Add(Me.DataGridView_License_Lic_Signature)
        Me.Panel_License_Lic_Verification.Enabled = False
        Me.Panel_License_Lic_Verification.Location = New System.Drawing.Point(6, 513)
        Me.Panel_License_Lic_Verification.Name = "Panel_License_Lic_Verification"
        Me.Panel_License_Lic_Verification.Size = New System.Drawing.Size(604, 763)
        Me.Panel_License_Lic_Verification.TabIndex = 30
        '
        'Panel54
        '
        Me.Panel54.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel54.Controls.Add(Me.Button_License_Lic_HashPublicKeyClear)
        Me.Panel54.Controls.Add(Me.Button_License_Lic_HashPublicKey)
        Me.Panel54.Controls.Add(Me.TextBox_License_Lic_HashPublicKey)
        Me.Panel54.Controls.Add(Me.Label52)
        Me.Panel54.Location = New System.Drawing.Point(7, 410)
        Me.Panel54.Name = "Panel54"
        Me.Panel54.Size = New System.Drawing.Size(593, 23)
        Me.Panel54.TabIndex = 16
        '
        'Button_License_Lic_HashPublicKeyClear
        '
        Me.Button_License_Lic_HashPublicKeyClear.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_License_Lic_HashPublicKeyClear.Location = New System.Drawing.Point(540, 0)
        Me.Button_License_Lic_HashPublicKeyClear.Name = "Button_License_Lic_HashPublicKeyClear"
        Me.Button_License_Lic_HashPublicKeyClear.Size = New System.Drawing.Size(51, 23)
        Me.Button_License_Lic_HashPublicKeyClear.TabIndex = 4
        Me.Button_License_Lic_HashPublicKeyClear.Text = "Clear"
        Me.Button_License_Lic_HashPublicKeyClear.UseVisualStyleBackColor = True
        '
        'Button_License_Lic_HashPublicKey
        '
        Me.Button_License_Lic_HashPublicKey.Location = New System.Drawing.Point(2, -1)
        Me.Button_License_Lic_HashPublicKey.Name = "Button_License_Lic_HashPublicKey"
        Me.Button_License_Lic_HashPublicKey.Size = New System.Drawing.Size(101, 23)
        Me.Button_License_Lic_HashPublicKey.TabIndex = 3
        Me.Button_License_Lic_HashPublicKey.Text = "Hash Public Key"
        Me.Button_License_Lic_HashPublicKey.UseVisualStyleBackColor = True
        '
        'TextBox_License_Lic_HashPublicKey
        '
        Me.TextBox_License_Lic_HashPublicKey.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_License_Lic_HashPublicKey.Location = New System.Drawing.Point(182, 0)
        Me.TextBox_License_Lic_HashPublicKey.Name = "TextBox_License_Lic_HashPublicKey"
        Me.TextBox_License_Lic_HashPublicKey.ReadOnly = True
        Me.TextBox_License_Lic_HashPublicKey.Size = New System.Drawing.Size(353, 20)
        Me.TextBox_License_Lic_HashPublicKey.TabIndex = 1
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Location = New System.Drawing.Point(121, 4)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(56, 13)
        Me.Label52.TabIndex = 0
        Me.Label52.Text = "Fingerprint"
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Location = New System.Drawing.Point(10, 161)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(108, 13)
        Me.Label49.TabIndex = 0
        Me.Label49.Text = "Serialized Data Fields"
        '
        'Panel50
        '
        Me.Panel50.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel50.Controls.Add(Me.TextBox_License_Lic_KeySize)
        Me.Panel50.Controls.Add(Me.Label43)
        Me.Panel50.Location = New System.Drawing.Point(6, 111)
        Me.Panel50.Name = "Panel50"
        Me.Panel50.Size = New System.Drawing.Size(594, 24)
        Me.Panel50.TabIndex = 7
        '
        'TextBox_License_Lic_KeySize
        '
        Me.TextBox_License_Lic_KeySize.Location = New System.Drawing.Point(117, 2)
        Me.TextBox_License_Lic_KeySize.Name = "TextBox_License_Lic_KeySize"
        Me.TextBox_License_Lic_KeySize.ReadOnly = True
        Me.TextBox_License_Lic_KeySize.Size = New System.Drawing.Size(74, 20)
        Me.TextBox_License_Lic_KeySize.TabIndex = 24
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Location = New System.Drawing.Point(3, 3)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(48, 13)
        Me.Label43.TabIndex = 0
        Me.Label43.Text = "Key Size"
        '
        'Panel51
        '
        Me.Panel51.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel51.Controls.Add(Me.Button_License_Lic_CopyAllPublicKey)
        Me.Panel51.Controls.Add(Me.Button_License_Lic_CopyPublicKey)
        Me.Panel51.Controls.Add(Me.TextBox_License_Lic_PublicKey)
        Me.Panel51.Controls.Add(Me.Label44)
        Me.Panel51.Location = New System.Drawing.Point(6, 61)
        Me.Panel51.Name = "Panel51"
        Me.Panel51.Size = New System.Drawing.Size(594, 24)
        Me.Panel51.TabIndex = 6
        '
        'Button_License_Lic_CopyAllPublicKey
        '
        Me.Button_License_Lic_CopyAllPublicKey.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_License_Lic_CopyAllPublicKey.Location = New System.Drawing.Point(541, -1)
        Me.Button_License_Lic_CopyAllPublicKey.Name = "Button_License_Lic_CopyAllPublicKey"
        Me.Button_License_Lic_CopyAllPublicKey.Size = New System.Drawing.Size(53, 23)
        Me.Button_License_Lic_CopyAllPublicKey.TabIndex = 25
        Me.Button_License_Lic_CopyAllPublicKey.Text = "Copy All"
        Me.Button_License_Lic_CopyAllPublicKey.UseVisualStyleBackColor = True
        '
        'Button_License_Lic_CopyPublicKey
        '
        Me.Button_License_Lic_CopyPublicKey.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_License_Lic_CopyPublicKey.Location = New System.Drawing.Point(478, -1)
        Me.Button_License_Lic_CopyPublicKey.Name = "Button_License_Lic_CopyPublicKey"
        Me.Button_License_Lic_CopyPublicKey.Size = New System.Drawing.Size(62, 23)
        Me.Button_License_Lic_CopyPublicKey.TabIndex = 22
        Me.Button_License_Lic_CopyPublicKey.Text = "Copy Key"
        Me.Button_License_Lic_CopyPublicKey.UseVisualStyleBackColor = True
        '
        'TextBox_License_Lic_PublicKey
        '
        Me.TextBox_License_Lic_PublicKey.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_License_Lic_PublicKey.Location = New System.Drawing.Point(117, 1)
        Me.TextBox_License_Lic_PublicKey.Name = "TextBox_License_Lic_PublicKey"
        Me.TextBox_License_Lic_PublicKey.ReadOnly = True
        Me.TextBox_License_Lic_PublicKey.Size = New System.Drawing.Size(355, 20)
        Me.TextBox_License_Lic_PublicKey.TabIndex = 1
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Location = New System.Drawing.Point(3, 3)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(57, 13)
        Me.Label44.TabIndex = 0
        Me.Label44.Text = "Public Key"
        '
        'Panel52
        '
        Me.Panel52.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel52.Controls.Add(Me.Button_License_Lic_CopyAllPrivateKey)
        Me.Panel52.Controls.Add(Me.Button_License_Lic_CopyPrivateKey)
        Me.Panel52.Controls.Add(Me.TextBox_License_Lic_PrivateKey)
        Me.Panel52.Controls.Add(Me.Label45)
        Me.Panel52.Location = New System.Drawing.Point(6, 86)
        Me.Panel52.Name = "Panel52"
        Me.Panel52.Size = New System.Drawing.Size(594, 24)
        Me.Panel52.TabIndex = 5
        '
        'Button_License_Lic_CopyAllPrivateKey
        '
        Me.Button_License_Lic_CopyAllPrivateKey.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_License_Lic_CopyAllPrivateKey.Location = New System.Drawing.Point(541, 0)
        Me.Button_License_Lic_CopyAllPrivateKey.Name = "Button_License_Lic_CopyAllPrivateKey"
        Me.Button_License_Lic_CopyAllPrivateKey.Size = New System.Drawing.Size(53, 23)
        Me.Button_License_Lic_CopyAllPrivateKey.TabIndex = 24
        Me.Button_License_Lic_CopyAllPrivateKey.Text = "Copy All"
        Me.Button_License_Lic_CopyAllPrivateKey.UseVisualStyleBackColor = True
        '
        'Button_License_Lic_CopyPrivateKey
        '
        Me.Button_License_Lic_CopyPrivateKey.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_License_Lic_CopyPrivateKey.Location = New System.Drawing.Point(478, 0)
        Me.Button_License_Lic_CopyPrivateKey.Name = "Button_License_Lic_CopyPrivateKey"
        Me.Button_License_Lic_CopyPrivateKey.Size = New System.Drawing.Size(62, 23)
        Me.Button_License_Lic_CopyPrivateKey.TabIndex = 23
        Me.Button_License_Lic_CopyPrivateKey.Text = "Copy Key"
        Me.Button_License_Lic_CopyPrivateKey.UseVisualStyleBackColor = True
        '
        'TextBox_License_Lic_PrivateKey
        '
        Me.TextBox_License_Lic_PrivateKey.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_License_Lic_PrivateKey.Location = New System.Drawing.Point(117, 1)
        Me.TextBox_License_Lic_PrivateKey.Name = "TextBox_License_Lic_PrivateKey"
        Me.TextBox_License_Lic_PrivateKey.ReadOnly = True
        Me.TextBox_License_Lic_PrivateKey.Size = New System.Drawing.Size(355, 20)
        Me.TextBox_License_Lic_PrivateKey.TabIndex = 1
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Location = New System.Drawing.Point(3, 3)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(61, 13)
        Me.Label45.TabIndex = 0
        Me.Label45.Text = "Private Key"
        '
        'Panel53
        '
        Me.Panel53.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel53.Controls.Add(Me.TextBox_License_Lic_Salt)
        Me.Panel53.Controls.Add(Me.Label51)
        Me.Panel53.Location = New System.Drawing.Point(6, 36)
        Me.Panel53.Name = "Panel53"
        Me.Panel53.Size = New System.Drawing.Size(594, 24)
        Me.Panel53.TabIndex = 15
        '
        'TextBox_License_Lic_Salt
        '
        Me.TextBox_License_Lic_Salt.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_License_Lic_Salt.Location = New System.Drawing.Point(117, 2)
        Me.TextBox_License_Lic_Salt.Name = "TextBox_License_Lic_Salt"
        Me.TextBox_License_Lic_Salt.ReadOnly = True
        Me.TextBox_License_Lic_Salt.Size = New System.Drawing.Size(355, 20)
        Me.TextBox_License_Lic_Salt.TabIndex = 1
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Location = New System.Drawing.Point(3, 3)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(25, 13)
        Me.Label51.TabIndex = 0
        Me.Label51.Text = "Salt"
        '
        'Panel59
        '
        Me.Panel59.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel59.Controls.Add(Me.ComboBox_License_Lic_PreviousPairs)
        Me.Panel59.Controls.Add(Me.Button_License_Lic_GenerateKeys)
        Me.Panel59.Controls.Add(Me.Label50)
        Me.Panel59.Location = New System.Drawing.Point(6, 4)
        Me.Panel59.Name = "Panel59"
        Me.Panel59.Size = New System.Drawing.Size(594, 23)
        Me.Panel59.TabIndex = 14
        '
        'ComboBox_License_Lic_PreviousPairs
        '
        Me.ComboBox_License_Lic_PreviousPairs.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ComboBox_License_Lic_PreviousPairs.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_License_Lic_PreviousPairs.FormattingEnabled = True
        Me.ComboBox_License_Lic_PreviousPairs.Location = New System.Drawing.Point(117, 1)
        Me.ComboBox_License_Lic_PreviousPairs.Name = "ComboBox_License_Lic_PreviousPairs"
        Me.ComboBox_License_Lic_PreviousPairs.Size = New System.Drawing.Size(355, 21)
        Me.ComboBox_License_Lic_PreviousPairs.TabIndex = 1
        '
        'Button_License_Lic_GenerateKeys
        '
        Me.Button_License_Lic_GenerateKeys.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_License_Lic_GenerateKeys.BackColor = System.Drawing.Color.LightGreen
        Me.Button_License_Lic_GenerateKeys.Location = New System.Drawing.Point(478, 0)
        Me.Button_License_Lic_GenerateKeys.Name = "Button_License_Lic_GenerateKeys"
        Me.Button_License_Lic_GenerateKeys.Size = New System.Drawing.Size(115, 23)
        Me.Button_License_Lic_GenerateKeys.TabIndex = 23
        Me.Button_License_Lic_GenerateKeys.Text = "Generate"
        Me.Button_License_Lic_GenerateKeys.UseVisualStyleBackColor = False
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Location = New System.Drawing.Point(3, 3)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(104, 13)
        Me.Label50.TabIndex = 0
        Me.Label50.Text = "Select RSA Key Pair"
        '
        'Panel58
        '
        Me.Panel58.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel58.Controls.Add(Me.TextBox_License_Lic_DataOnlyFields)
        Me.Panel58.Location = New System.Drawing.Point(13, 183)
        Me.Panel58.Name = "Panel58"
        Me.Panel58.Size = New System.Drawing.Size(586, 94)
        Me.Panel58.TabIndex = 13
        '
        'TextBox_License_Lic_DataOnlyFields
        '
        Me.TextBox_License_Lic_DataOnlyFields.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TextBox_License_Lic_DataOnlyFields.Location = New System.Drawing.Point(0, 0)
        Me.TextBox_License_Lic_DataOnlyFields.Multiline = True
        Me.TextBox_License_Lic_DataOnlyFields.Name = "TextBox_License_Lic_DataOnlyFields"
        Me.TextBox_License_Lic_DataOnlyFields.ReadOnly = True
        Me.TextBox_License_Lic_DataOnlyFields.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TextBox_License_Lic_DataOnlyFields.Size = New System.Drawing.Size(586, 94)
        Me.TextBox_License_Lic_DataOnlyFields.TabIndex = 1
        '
        'Panel57
        '
        Me.Panel57.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel57.Controls.Add(Me.Button_License_Lic_Verify_Clear)
        Me.Panel57.Controls.Add(Me.Button_License_Lic_Verify)
        Me.Panel57.Controls.Add(Me.TextBox_License_Lic_Verified)
        Me.Panel57.Controls.Add(Me.Label48)
        Me.Panel57.Location = New System.Drawing.Point(6, 352)
        Me.Panel57.Name = "Panel57"
        Me.Panel57.Size = New System.Drawing.Size(593, 23)
        Me.Panel57.TabIndex = 12
        '
        'Button_License_Lic_Verify_Clear
        '
        Me.Button_License_Lic_Verify_Clear.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_License_Lic_Verify_Clear.Location = New System.Drawing.Point(541, -1)
        Me.Button_License_Lic_Verify_Clear.Name = "Button_License_Lic_Verify_Clear"
        Me.Button_License_Lic_Verify_Clear.Size = New System.Drawing.Size(51, 23)
        Me.Button_License_Lic_Verify_Clear.TabIndex = 6
        Me.Button_License_Lic_Verify_Clear.Text = "Clear"
        Me.Button_License_Lic_Verify_Clear.UseVisualStyleBackColor = True
        '
        'Button_License_Lic_Verify
        '
        Me.Button_License_Lic_Verify.Location = New System.Drawing.Point(2, -1)
        Me.Button_License_Lic_Verify.Name = "Button_License_Lic_Verify"
        Me.Button_License_Lic_Verify.Size = New System.Drawing.Size(101, 23)
        Me.Button_License_Lic_Verify.TabIndex = 3
        Me.Button_License_Lic_Verify.Text = "Verify"
        Me.Button_License_Lic_Verify.UseVisualStyleBackColor = True
        '
        'TextBox_License_Lic_Verified
        '
        Me.TextBox_License_Lic_Verified.Location = New System.Drawing.Point(183, 0)
        Me.TextBox_License_Lic_Verified.Name = "TextBox_License_Lic_Verified"
        Me.TextBox_License_Lic_Verified.ReadOnly = True
        Me.TextBox_License_Lic_Verified.Size = New System.Drawing.Size(93, 20)
        Me.TextBox_License_Lic_Verified.TabIndex = 1
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Location = New System.Drawing.Point(130, 3)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(48, 13)
        Me.Label48.TabIndex = 0
        Me.Label48.Text = "Verified?"
        '
        'Panel56
        '
        Me.Panel56.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel56.Controls.Add(Me.Button_License_Lic_SignIt_Clear)
        Me.Panel56.Controls.Add(Me.Button_License_Lic_SignIt)
        Me.Panel56.Controls.Add(Me.TextBox_License_Lic_Signature)
        Me.Panel56.Controls.Add(Me.Label47)
        Me.Panel56.Location = New System.Drawing.Point(7, 327)
        Me.Panel56.Name = "Panel56"
        Me.Panel56.Size = New System.Drawing.Size(593, 23)
        Me.Panel56.TabIndex = 11
        '
        'Button_License_Lic_SignIt_Clear
        '
        Me.Button_License_Lic_SignIt_Clear.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_License_Lic_SignIt_Clear.Location = New System.Drawing.Point(540, 0)
        Me.Button_License_Lic_SignIt_Clear.Name = "Button_License_Lic_SignIt_Clear"
        Me.Button_License_Lic_SignIt_Clear.Size = New System.Drawing.Size(51, 23)
        Me.Button_License_Lic_SignIt_Clear.TabIndex = 5
        Me.Button_License_Lic_SignIt_Clear.Text = "Clear"
        Me.Button_License_Lic_SignIt_Clear.UseVisualStyleBackColor = True
        '
        'Button_License_Lic_SignIt
        '
        Me.Button_License_Lic_SignIt.Location = New System.Drawing.Point(2, -1)
        Me.Button_License_Lic_SignIt.Name = "Button_License_Lic_SignIt"
        Me.Button_License_Lic_SignIt.Size = New System.Drawing.Size(101, 23)
        Me.Button_License_Lic_SignIt.TabIndex = 3
        Me.Button_License_Lic_SignIt.Text = "Sign It"
        Me.Button_License_Lic_SignIt.UseVisualStyleBackColor = True
        '
        'TextBox_License_Lic_Signature
        '
        Me.TextBox_License_Lic_Signature.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_License_Lic_Signature.Location = New System.Drawing.Point(183, 0)
        Me.TextBox_License_Lic_Signature.Name = "TextBox_License_Lic_Signature"
        Me.TextBox_License_Lic_Signature.ReadOnly = True
        Me.TextBox_License_Lic_Signature.Size = New System.Drawing.Size(352, 20)
        Me.TextBox_License_Lic_Signature.TabIndex = 1
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Location = New System.Drawing.Point(125, 3)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(52, 13)
        Me.Label47.TabIndex = 0
        Me.Label47.Text = "Signature"
        '
        'Panel55
        '
        Me.Panel55.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel55.Controls.Add(Me.Button_License_Lic_HashDataFields_Clear)
        Me.Panel55.Controls.Add(Me.Button_License_Lic_HashDataFields)
        Me.Panel55.Controls.Add(Me.TextBox_License_Lic_HashDataFields)
        Me.Panel55.Controls.Add(Me.Label46)
        Me.Panel55.Location = New System.Drawing.Point(7, 302)
        Me.Panel55.Name = "Panel55"
        Me.Panel55.Size = New System.Drawing.Size(593, 23)
        Me.Panel55.TabIndex = 10
        '
        'Button_License_Lic_HashDataFields_Clear
        '
        Me.Button_License_Lic_HashDataFields_Clear.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_License_Lic_HashDataFields_Clear.Location = New System.Drawing.Point(540, 0)
        Me.Button_License_Lic_HashDataFields_Clear.Name = "Button_License_Lic_HashDataFields_Clear"
        Me.Button_License_Lic_HashDataFields_Clear.Size = New System.Drawing.Size(51, 23)
        Me.Button_License_Lic_HashDataFields_Clear.TabIndex = 4
        Me.Button_License_Lic_HashDataFields_Clear.Text = "Clear"
        Me.Button_License_Lic_HashDataFields_Clear.UseVisualStyleBackColor = True
        '
        'Button_License_Lic_HashDataFields
        '
        Me.Button_License_Lic_HashDataFields.Location = New System.Drawing.Point(2, -1)
        Me.Button_License_Lic_HashDataFields.Name = "Button_License_Lic_HashDataFields"
        Me.Button_License_Lic_HashDataFields.Size = New System.Drawing.Size(101, 23)
        Me.Button_License_Lic_HashDataFields.TabIndex = 3
        Me.Button_License_Lic_HashDataFields.Text = "Hash Data Fields"
        Me.Button_License_Lic_HashDataFields.UseVisualStyleBackColor = True
        '
        'TextBox_License_Lic_HashDataFields
        '
        Me.TextBox_License_Lic_HashDataFields.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_License_Lic_HashDataFields.Location = New System.Drawing.Point(182, 0)
        Me.TextBox_License_Lic_HashDataFields.Name = "TextBox_License_Lic_HashDataFields"
        Me.TextBox_License_Lic_HashDataFields.ReadOnly = True
        Me.TextBox_License_Lic_HashDataFields.Size = New System.Drawing.Size(353, 20)
        Me.TextBox_License_Lic_HashDataFields.TabIndex = 1
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Location = New System.Drawing.Point(142, 4)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(35, 13)
        Me.Label46.TabIndex = 0
        Me.Label46.Text = "Hash:"
        '
        'Panel49
        '
        Me.Panel49.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel49.Controls.Add(Me.Button_License_Lic_Verify_DefaultSignatureNodeName)
        Me.Panel49.Controls.Add(Me.TextBox_License_Lic_Verify_SignatureNodeName)
        Me.Panel49.Controls.Add(Me.Label42)
        Me.Panel49.Location = New System.Drawing.Point(6, 498)
        Me.Panel49.Name = "Panel49"
        Me.Panel49.Size = New System.Drawing.Size(594, 23)
        Me.Panel49.TabIndex = 4
        '
        'Button_License_Lic_Verify_DefaultSignatureNodeName
        '
        Me.Button_License_Lic_Verify_DefaultSignatureNodeName.Location = New System.Drawing.Point(234, -1)
        Me.Button_License_Lic_Verify_DefaultSignatureNodeName.Name = "Button_License_Lic_Verify_DefaultSignatureNodeName"
        Me.Button_License_Lic_Verify_DefaultSignatureNodeName.Size = New System.Drawing.Size(61, 23)
        Me.Button_License_Lic_Verify_DefaultSignatureNodeName.TabIndex = 25
        Me.Button_License_Lic_Verify_DefaultSignatureNodeName.Text = "Default"
        Me.Button_License_Lic_Verify_DefaultSignatureNodeName.UseVisualStyleBackColor = True
        '
        'TextBox_License_Lic_Verify_SignatureNodeName
        '
        Me.TextBox_License_Lic_Verify_SignatureNodeName.Location = New System.Drawing.Point(121, 1)
        Me.TextBox_License_Lic_Verify_SignatureNodeName.Name = "TextBox_License_Lic_Verify_SignatureNodeName"
        Me.TextBox_License_Lic_Verify_SignatureNodeName.Size = New System.Drawing.Size(107, 20)
        Me.TextBox_License_Lic_Verify_SignatureNodeName.TabIndex = 1
        Me.TextBox_License_Lic_Verify_SignatureNodeName.Text = "DigitalSignature"
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Location = New System.Drawing.Point(3, 4)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(112, 13)
        Me.Label42.TabIndex = 0
        Me.Label42.Text = "Signature Node Name"
        '
        'Panel47
        '
        Me.Panel47.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel47.Controls.Add(Me.Button_License_Lic_Verify_DefaultJSONNodeName)
        Me.Panel47.Controls.Add(Me.TextBox_License_Lic_Verify_JSONNodeName)
        Me.Panel47.Controls.Add(Me.Label41)
        Me.Panel47.Location = New System.Drawing.Point(6, 473)
        Me.Panel47.Name = "Panel47"
        Me.Panel47.Size = New System.Drawing.Size(594, 23)
        Me.Panel47.TabIndex = 3
        Me.Panel47.Visible = False
        '
        'Button_License_Lic_Verify_DefaultJSONNodeName
        '
        Me.Button_License_Lic_Verify_DefaultJSONNodeName.Location = New System.Drawing.Point(234, -1)
        Me.Button_License_Lic_Verify_DefaultJSONNodeName.Name = "Button_License_Lic_Verify_DefaultJSONNodeName"
        Me.Button_License_Lic_Verify_DefaultJSONNodeName.Size = New System.Drawing.Size(61, 23)
        Me.Button_License_Lic_Verify_DefaultJSONNodeName.TabIndex = 26
        Me.Button_License_Lic_Verify_DefaultJSONNodeName.Text = "Default"
        Me.Button_License_Lic_Verify_DefaultJSONNodeName.UseVisualStyleBackColor = True
        '
        'TextBox_License_Lic_Verify_JSONNodeName
        '
        Me.TextBox_License_Lic_Verify_JSONNodeName.Location = New System.Drawing.Point(121, 1)
        Me.TextBox_License_Lic_Verify_JSONNodeName.Name = "TextBox_License_Lic_Verify_JSONNodeName"
        Me.TextBox_License_Lic_Verify_JSONNodeName.Size = New System.Drawing.Size(107, 20)
        Me.TextBox_License_Lic_Verify_JSONNodeName.TabIndex = 1
        Me.TextBox_License_Lic_Verify_JSONNodeName.Text = "signature"
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Location = New System.Drawing.Point(3, 4)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(98, 13)
        Me.Label41.TabIndex = 0
        Me.Label41.Text = "JSON Node Name:"
        '
        'FlowLayoutPanel_License_Lic_Verification
        '
        Me.FlowLayoutPanel_License_Lic_Verification.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.FlowLayoutPanel_License_Lic_Verification.Controls.Add(Me.Button_License_Lic_Verify_AddRow)
        Me.FlowLayoutPanel_License_Lic_Verification.Controls.Add(Me.Button_License_Lic_Verify_AddCommonRows)
        Me.FlowLayoutPanel_License_Lic_Verification.Controls.Add(Me.Button_License_Lic_Verify_DeleteSelected)
        Me.FlowLayoutPanel_License_Lic_Verification.Controls.Add(Me.Button_License_Lic_Verify_Up)
        Me.FlowLayoutPanel_License_Lic_Verification.Controls.Add(Me.Button_License_Lic_Verify_Down)
        Me.FlowLayoutPanel_License_Lic_Verification.Controls.Add(Me.Button_License_Lic_Verify_AutoSort)
        Me.FlowLayoutPanel_License_Lic_Verification.Controls.Add(Me.Button_License_Lic_Verify_AddSignatureRow)
        Me.FlowLayoutPanel_License_Lic_Verification.Location = New System.Drawing.Point(3, 550)
        Me.FlowLayoutPanel_License_Lic_Verification.Name = "FlowLayoutPanel_License_Lic_Verification"
        Me.FlowLayoutPanel_License_Lic_Verification.Size = New System.Drawing.Size(597, 30)
        Me.FlowLayoutPanel_License_Lic_Verification.TabIndex = 2
        '
        'Button_License_Lic_Verify_AddRow
        '
        Me.Button_License_Lic_Verify_AddRow.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_License_Lic_Verify_AddRow.Location = New System.Drawing.Point(3, 3)
        Me.Button_License_Lic_Verify_AddRow.Name = "Button_License_Lic_Verify_AddRow"
        Me.Button_License_Lic_Verify_AddRow.Size = New System.Drawing.Size(61, 23)
        Me.Button_License_Lic_Verify_AddRow.TabIndex = 24
        Me.Button_License_Lic_Verify_AddRow.Text = "Add Row"
        Me.Button_License_Lic_Verify_AddRow.UseVisualStyleBackColor = True
        '
        'Button_License_Lic_Verify_AddCommonRows
        '
        Me.Button_License_Lic_Verify_AddCommonRows.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_License_Lic_Verify_AddCommonRows.Location = New System.Drawing.Point(70, 3)
        Me.Button_License_Lic_Verify_AddCommonRows.Name = "Button_License_Lic_Verify_AddCommonRows"
        Me.Button_License_Lic_Verify_AddCommonRows.Size = New System.Drawing.Size(111, 23)
        Me.Button_License_Lic_Verify_AddCommonRows.TabIndex = 27
        Me.Button_License_Lic_Verify_AddCommonRows.Text = "Add Common Rows"
        Me.Button_License_Lic_Verify_AddCommonRows.UseVisualStyleBackColor = True
        '
        'Button_License_Lic_Verify_DeleteSelected
        '
        Me.Button_License_Lic_Verify_DeleteSelected.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_License_Lic_Verify_DeleteSelected.Location = New System.Drawing.Point(187, 3)
        Me.Button_License_Lic_Verify_DeleteSelected.Name = "Button_License_Lic_Verify_DeleteSelected"
        Me.Button_License_Lic_Verify_DeleteSelected.Size = New System.Drawing.Size(96, 23)
        Me.Button_License_Lic_Verify_DeleteSelected.TabIndex = 25
        Me.Button_License_Lic_Verify_DeleteSelected.Text = "Delete Selected"
        Me.Button_License_Lic_Verify_DeleteSelected.UseVisualStyleBackColor = True
        '
        'Button_License_Lic_Verify_Up
        '
        Me.Button_License_Lic_Verify_Up.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_License_Lic_Verify_Up.Location = New System.Drawing.Point(289, 3)
        Me.Button_License_Lic_Verify_Up.Name = "Button_License_Lic_Verify_Up"
        Me.Button_License_Lic_Verify_Up.Size = New System.Drawing.Size(61, 23)
        Me.Button_License_Lic_Verify_Up.TabIndex = 28
        Me.Button_License_Lic_Verify_Up.Text = "Up"
        Me.Button_License_Lic_Verify_Up.UseVisualStyleBackColor = True
        Me.Button_License_Lic_Verify_Up.Visible = False
        '
        'Button_License_Lic_Verify_Down
        '
        Me.Button_License_Lic_Verify_Down.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_License_Lic_Verify_Down.Location = New System.Drawing.Point(356, 3)
        Me.Button_License_Lic_Verify_Down.Name = "Button_License_Lic_Verify_Down"
        Me.Button_License_Lic_Verify_Down.Size = New System.Drawing.Size(61, 23)
        Me.Button_License_Lic_Verify_Down.TabIndex = 29
        Me.Button_License_Lic_Verify_Down.Text = "Down"
        Me.Button_License_Lic_Verify_Down.UseVisualStyleBackColor = True
        Me.Button_License_Lic_Verify_Down.Visible = False
        '
        'Button_License_Lic_Verify_AutoSort
        '
        Me.Button_License_Lic_Verify_AutoSort.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_License_Lic_Verify_AutoSort.Location = New System.Drawing.Point(423, 3)
        Me.Button_License_Lic_Verify_AutoSort.Name = "Button_License_Lic_Verify_AutoSort"
        Me.Button_License_Lic_Verify_AutoSort.Size = New System.Drawing.Size(61, 23)
        Me.Button_License_Lic_Verify_AutoSort.TabIndex = 30
        Me.Button_License_Lic_Verify_AutoSort.Text = "Auto Sort"
        Me.Button_License_Lic_Verify_AutoSort.UseVisualStyleBackColor = True
        Me.Button_License_Lic_Verify_AutoSort.Visible = False
        '
        'Button_License_Lic_Verify_AddSignatureRow
        '
        Me.Button_License_Lic_Verify_AddSignatureRow.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_License_Lic_Verify_AddSignatureRow.Location = New System.Drawing.Point(3, 32)
        Me.Button_License_Lic_Verify_AddSignatureRow.Name = "Button_License_Lic_Verify_AddSignatureRow"
        Me.Button_License_Lic_Verify_AddSignatureRow.Size = New System.Drawing.Size(110, 23)
        Me.Button_License_Lic_Verify_AddSignatureRow.TabIndex = 26
        Me.Button_License_Lic_Verify_AddSignatureRow.Text = "Add Signature Row"
        Me.Button_License_Lic_Verify_AddSignatureRow.UseVisualStyleBackColor = True
        Me.Button_License_Lic_Verify_AddSignatureRow.Visible = False
        '
        'DataGridView_License_Lic_Signature
        '
        Me.DataGridView_License_Lic_Signature.AllowUserToAddRows = False
        Me.DataGridView_License_Lic_Signature.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataGridView_License_Lic_Signature.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView_License_Lic_Signature.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2})
        Me.DataGridView_License_Lic_Signature.Location = New System.Drawing.Point(7, 582)
        Me.DataGridView_License_Lic_Signature.Name = "DataGridView_License_Lic_Signature"
        Me.DataGridView_License_Lic_Signature.Size = New System.Drawing.Size(594, 178)
        Me.DataGridView_License_Lic_Signature.TabIndex = 1
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "DataName"
        Me.DataGridViewTextBoxColumn1.HeaderText = "DataName"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.Width = 83
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "DataValue"
        Me.DataGridViewTextBoxColumn2.HeaderText = "DataValue"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.Width = 82
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.Location = New System.Drawing.Point(11, 459)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(61, 13)
        Me.Label37.TabIndex = 29
        Me.Label37.Text = "Signature"
        '
        'CheckBox_License_Lic_AddSignature
        '
        Me.CheckBox_License_Lic_AddSignature.AutoSize = True
        Me.CheckBox_License_Lic_AddSignature.Location = New System.Drawing.Point(14, 490)
        Me.CheckBox_License_Lic_AddSignature.Name = "CheckBox_License_Lic_AddSignature"
        Me.CheckBox_License_Lic_AddSignature.Size = New System.Drawing.Size(141, 17)
        Me.CheckBox_License_Lic_AddSignature.TabIndex = 0
        Me.CheckBox_License_Lic_AddSignature.Text = "Include Digital Signature"
        Me.CheckBox_License_Lic_AddSignature.UseVisualStyleBackColor = True
        '
        'Button_License_Lic_Preview
        '
        Me.Button_License_Lic_Preview.Location = New System.Drawing.Point(9, 1478)
        Me.Button_License_Lic_Preview.Name = "Button_License_Lic_Preview"
        Me.Button_License_Lic_Preview.Size = New System.Drawing.Size(80, 23)
        Me.Button_License_Lic_Preview.TabIndex = 28
        Me.Button_License_Lic_Preview.Text = "Preview"
        Me.Button_License_Lic_Preview.UseVisualStyleBackColor = True
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.Location = New System.Drawing.Point(9, 76)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(96, 13)
        Me.Label36.TabIndex = 27
        Me.Label36.Text = "Key Value Pairs"
        '
        'Panel45
        '
        Me.Panel45.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel45.Controls.Add(Me.Panel48)
        Me.Panel45.Controls.Add(Me.FlowLayoutPanel_License_Lic_AddDataFields)
        Me.Panel45.Controls.Add(Me.DataGridView_License_Lic_Data)
        Me.Panel45.Location = New System.Drawing.Point(6, 103)
        Me.Panel45.Name = "Panel45"
        Me.Panel45.Size = New System.Drawing.Size(598, 302)
        Me.Panel45.TabIndex = 26
        '
        'Panel48
        '
        Me.Panel48.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel48.Controls.Add(Me.Button_License_Lic_Data_JSONNodeNameDefault)
        Me.Panel48.Controls.Add(Me.TextBox_License_Lic_Data_JSONNodeName)
        Me.Panel48.Controls.Add(Me.Label40)
        Me.Panel48.Location = New System.Drawing.Point(6, 3)
        Me.Panel48.Name = "Panel48"
        Me.Panel48.Size = New System.Drawing.Size(588, 23)
        Me.Panel48.TabIndex = 1
        '
        'Button_License_Lic_Data_JSONNodeNameDefault
        '
        Me.Button_License_Lic_Data_JSONNodeNameDefault.Location = New System.Drawing.Point(238, -1)
        Me.Button_License_Lic_Data_JSONNodeNameDefault.Name = "Button_License_Lic_Data_JSONNodeNameDefault"
        Me.Button_License_Lic_Data_JSONNodeNameDefault.Size = New System.Drawing.Size(61, 23)
        Me.Button_License_Lic_Data_JSONNodeNameDefault.TabIndex = 27
        Me.Button_License_Lic_Data_JSONNodeNameDefault.Text = "Default"
        Me.Button_License_Lic_Data_JSONNodeNameDefault.UseVisualStyleBackColor = True
        '
        'TextBox_License_Lic_Data_JSONNodeName
        '
        Me.TextBox_License_Lic_Data_JSONNodeName.Location = New System.Drawing.Point(121, 1)
        Me.TextBox_License_Lic_Data_JSONNodeName.Name = "TextBox_License_Lic_Data_JSONNodeName"
        Me.TextBox_License_Lic_Data_JSONNodeName.Size = New System.Drawing.Size(111, 20)
        Me.TextBox_License_Lic_Data_JSONNodeName.TabIndex = 1
        Me.TextBox_License_Lic_Data_JSONNodeName.Text = "data"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Location = New System.Drawing.Point(3, 4)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(98, 13)
        Me.Label40.TabIndex = 0
        Me.Label40.Text = "JSON Node Name:"
        '
        'FlowLayoutPanel_License_Lic_AddDataFields
        '
        Me.FlowLayoutPanel_License_Lic_AddDataFields.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.FlowLayoutPanel_License_Lic_AddDataFields.Controls.Add(Me.Button_License_Lic_AddRow)
        Me.FlowLayoutPanel_License_Lic_AddDataFields.Controls.Add(Me.Button_License_Lic_Data_AddCommonRows)
        Me.FlowLayoutPanel_License_Lic_AddDataFields.Controls.Add(Me.Button_License_Lic_DeleteSelected)
        Me.FlowLayoutPanel_License_Lic_AddDataFields.Controls.Add(Me.Button_License_Lic_Data_Up)
        Me.FlowLayoutPanel_License_Lic_AddDataFields.Controls.Add(Me.Button_License_Lic_Data_Down)
        Me.FlowLayoutPanel_License_Lic_AddDataFields.Controls.Add(Me.Button_License_Lic_Data_AutoSort)
        Me.FlowLayoutPanel_License_Lic_AddDataFields.Location = New System.Drawing.Point(3, 44)
        Me.FlowLayoutPanel_License_Lic_AddDataFields.Name = "FlowLayoutPanel_License_Lic_AddDataFields"
        Me.FlowLayoutPanel_License_Lic_AddDataFields.Size = New System.Drawing.Size(591, 30)
        Me.FlowLayoutPanel_License_Lic_AddDataFields.TabIndex = 1
        '
        'Button_License_Lic_AddRow
        '
        Me.Button_License_Lic_AddRow.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_License_Lic_AddRow.Location = New System.Drawing.Point(3, 3)
        Me.Button_License_Lic_AddRow.Name = "Button_License_Lic_AddRow"
        Me.Button_License_Lic_AddRow.Size = New System.Drawing.Size(61, 23)
        Me.Button_License_Lic_AddRow.TabIndex = 24
        Me.Button_License_Lic_AddRow.Text = "Add Row"
        Me.Button_License_Lic_AddRow.UseVisualStyleBackColor = True
        '
        'Button_License_Lic_Data_AddCommonRows
        '
        Me.Button_License_Lic_Data_AddCommonRows.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_License_Lic_Data_AddCommonRows.Location = New System.Drawing.Point(70, 3)
        Me.Button_License_Lic_Data_AddCommonRows.Name = "Button_License_Lic_Data_AddCommonRows"
        Me.Button_License_Lic_Data_AddCommonRows.Size = New System.Drawing.Size(111, 23)
        Me.Button_License_Lic_Data_AddCommonRows.TabIndex = 32
        Me.Button_License_Lic_Data_AddCommonRows.Text = "Add Common Rows"
        Me.Button_License_Lic_Data_AddCommonRows.UseVisualStyleBackColor = True
        '
        'Button_License_Lic_DeleteSelected
        '
        Me.Button_License_Lic_DeleteSelected.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_License_Lic_DeleteSelected.Location = New System.Drawing.Point(187, 3)
        Me.Button_License_Lic_DeleteSelected.Name = "Button_License_Lic_DeleteSelected"
        Me.Button_License_Lic_DeleteSelected.Size = New System.Drawing.Size(96, 23)
        Me.Button_License_Lic_DeleteSelected.TabIndex = 25
        Me.Button_License_Lic_DeleteSelected.Text = "Delete Selected"
        Me.Button_License_Lic_DeleteSelected.UseVisualStyleBackColor = True
        '
        'Button_License_Lic_Data_Up
        '
        Me.Button_License_Lic_Data_Up.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_License_Lic_Data_Up.Location = New System.Drawing.Point(289, 3)
        Me.Button_License_Lic_Data_Up.Name = "Button_License_Lic_Data_Up"
        Me.Button_License_Lic_Data_Up.Size = New System.Drawing.Size(61, 23)
        Me.Button_License_Lic_Data_Up.TabIndex = 30
        Me.Button_License_Lic_Data_Up.Text = "Up"
        Me.Button_License_Lic_Data_Up.UseVisualStyleBackColor = True
        Me.Button_License_Lic_Data_Up.Visible = False
        '
        'Button_License_Lic_Data_Down
        '
        Me.Button_License_Lic_Data_Down.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_License_Lic_Data_Down.Location = New System.Drawing.Point(356, 3)
        Me.Button_License_Lic_Data_Down.Name = "Button_License_Lic_Data_Down"
        Me.Button_License_Lic_Data_Down.Size = New System.Drawing.Size(61, 23)
        Me.Button_License_Lic_Data_Down.TabIndex = 31
        Me.Button_License_Lic_Data_Down.Text = "Down"
        Me.Button_License_Lic_Data_Down.UseVisualStyleBackColor = True
        Me.Button_License_Lic_Data_Down.Visible = False
        '
        'Button_License_Lic_Data_AutoSort
        '
        Me.Button_License_Lic_Data_AutoSort.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_License_Lic_Data_AutoSort.Location = New System.Drawing.Point(423, 3)
        Me.Button_License_Lic_Data_AutoSort.Name = "Button_License_Lic_Data_AutoSort"
        Me.Button_License_Lic_Data_AutoSort.Size = New System.Drawing.Size(61, 23)
        Me.Button_License_Lic_Data_AutoSort.TabIndex = 33
        Me.Button_License_Lic_Data_AutoSort.Text = "Auto Sort"
        Me.Button_License_Lic_Data_AutoSort.UseVisualStyleBackColor = True
        Me.Button_License_Lic_Data_AutoSort.Visible = False
        '
        'DataGridView_License_Lic_Data
        '
        Me.DataGridView_License_Lic_Data.AllowUserToAddRows = False
        Me.DataGridView_License_Lic_Data.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataGridView_License_Lic_Data.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView_License_Lic_Data.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataName, Me.DataValue})
        Me.DataGridView_License_Lic_Data.Location = New System.Drawing.Point(7, 76)
        Me.DataGridView_License_Lic_Data.Name = "DataGridView_License_Lic_Data"
        Me.DataGridView_License_Lic_Data.Size = New System.Drawing.Size(587, 223)
        Me.DataGridView_License_Lic_Data.TabIndex = 0
        '
        'DataName
        '
        Me.DataName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataName.HeaderText = "DataName"
        Me.DataName.Name = "DataName"
        Me.DataName.Width = 83
        '
        'DataValue
        '
        Me.DataValue.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataValue.HeaderText = "DataValue"
        Me.DataValue.Name = "DataValue"
        Me.DataValue.Width = 82
        '
        'TabPage_ProductSerial
        '
        Me.TabPage_ProductSerial.Location = New System.Drawing.Point(4, 22)
        Me.TabPage_ProductSerial.Name = "TabPage_ProductSerial"
        Me.TabPage_ProductSerial.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage_ProductSerial.Size = New System.Drawing.Size(751, 581)
        Me.TabPage_ProductSerial.TabIndex = 1
        Me.TabPage_ProductSerial.Text = "Product Serial"
        Me.TabPage_ProductSerial.UseVisualStyleBackColor = True
        '
        'TabPage11
        '
        Me.TabPage11.AutoScroll = True
        Me.TabPage11.Controls.Add(Me.GroupBox10)
        Me.TabPage11.Controls.Add(Me.Panel149)
        Me.TabPage11.Controls.Add(Me.GroupBox9)
        Me.TabPage11.Location = New System.Drawing.Point(4, 22)
        Me.TabPage11.Name = "TabPage11"
        Me.TabPage11.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage11.Size = New System.Drawing.Size(751, 581)
        Me.TabPage11.TabIndex = 4
        Me.TabPage11.Text = "One-Time Passcode"
        Me.TabPage11.UseVisualStyleBackColor = True
        '
        'Panel149
        '
        Me.Panel149.Location = New System.Drawing.Point(33, 1002)
        Me.Panel149.Name = "Panel149"
        Me.Panel149.Size = New System.Drawing.Size(154, 35)
        Me.Panel149.TabIndex = 1
        '
        'GroupBox9
        '
        Me.GroupBox9.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox9.Controls.Add(Me.Label172)
        Me.GroupBox9.Controls.Add(Me.Label170)
        Me.GroupBox9.Controls.Add(Me.Panel134)
        Me.GroupBox9.Controls.Add(Me.Panel130)
        Me.GroupBox9.Location = New System.Drawing.Point(15, 19)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(683, 437)
        Me.GroupBox9.TabIndex = 0
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "TOTP"
        '
        'Panel134
        '
        Me.Panel134.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel134.Controls.Add(Me.Label173)
        Me.Panel134.Controls.Add(Me.Panel151)
        Me.Panel134.Controls.Add(Me.Panel139)
        Me.Panel134.Controls.Add(Me.Panel135)
        Me.Panel134.Controls.Add(Me.Panel137)
        Me.Panel134.Controls.Add(Me.Panel138)
        Me.Panel134.Controls.Add(Me.Label155)
        Me.Panel134.Location = New System.Drawing.Point(18, 225)
        Me.Panel134.Name = "Panel134"
        Me.Panel134.Size = New System.Drawing.Size(645, 189)
        Me.Panel134.TabIndex = 3
        '
        'Panel151
        '
        Me.Panel151.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel151.Controls.Add(Me.TextBox_LicenseOTP_TOTP_ServerCodeAdmin)
        Me.Panel151.Controls.Add(Me.Label169)
        Me.Panel151.Controls.Add(Me.Button_LicenseOTP_TOTP_VerifyCode)
        Me.Panel151.Location = New System.Drawing.Point(6, 123)
        Me.Panel151.Name = "Panel151"
        Me.Panel151.Size = New System.Drawing.Size(636, 25)
        Me.Panel151.TabIndex = 9
        '
        'TextBox_LicenseOTP_TOTP_ServerCodeAdmin
        '
        Me.TextBox_LicenseOTP_TOTP_ServerCodeAdmin.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_LicenseOTP_TOTP_ServerCodeAdmin.Location = New System.Drawing.Point(81, 3)
        Me.TextBox_LicenseOTP_TOTP_ServerCodeAdmin.Name = "TextBox_LicenseOTP_TOTP_ServerCodeAdmin"
        Me.TextBox_LicenseOTP_TOTP_ServerCodeAdmin.ReadOnly = True
        Me.TextBox_LicenseOTP_TOTP_ServerCodeAdmin.Size = New System.Drawing.Size(472, 20)
        Me.TextBox_LicenseOTP_TOTP_ServerCodeAdmin.TabIndex = 1
        '
        'Label169
        '
        Me.Label169.AutoSize = True
        Me.Label169.Location = New System.Drawing.Point(3, 6)
        Me.Label169.Name = "Label169"
        Me.Label169.Size = New System.Drawing.Size(69, 13)
        Me.Label169.TabIndex = 0
        Me.Label169.Text = "Server Code:"
        '
        'Panel139
        '
        Me.Panel139.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel139.Controls.Add(Me.TextBox_LicenseOTP_TOTP_Verified)
        Me.Panel139.Controls.Add(Me.Label158)
        Me.Panel139.Location = New System.Drawing.Point(6, 150)
        Me.Panel139.Name = "Panel139"
        Me.Panel139.Size = New System.Drawing.Size(636, 25)
        Me.Panel139.TabIndex = 8
        '
        'TextBox_LicenseOTP_TOTP_Verified
        '
        Me.TextBox_LicenseOTP_TOTP_Verified.Location = New System.Drawing.Point(81, 3)
        Me.TextBox_LicenseOTP_TOTP_Verified.Name = "TextBox_LicenseOTP_TOTP_Verified"
        Me.TextBox_LicenseOTP_TOTP_Verified.Size = New System.Drawing.Size(87, 20)
        Me.TextBox_LicenseOTP_TOTP_Verified.TabIndex = 1
        '
        'Label158
        '
        Me.Label158.AutoSize = True
        Me.Label158.Location = New System.Drawing.Point(3, 6)
        Me.Label158.Name = "Label158"
        Me.Label158.Size = New System.Drawing.Size(45, 13)
        Me.Label158.TabIndex = 0
        Me.Label158.Text = "Verified:"
        '
        'Panel135
        '
        Me.Panel135.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel135.Controls.Add(Me.Button_LicenseOTP_TOTP_UserCodeCopyFromUser)
        Me.Panel135.Controls.Add(Me.TextBox_LicenseOTP_TOTP_UserCodeAdmin)
        Me.Panel135.Controls.Add(Me.Label152)
        Me.Panel135.Location = New System.Drawing.Point(6, 97)
        Me.Panel135.Name = "Panel135"
        Me.Panel135.Size = New System.Drawing.Size(636, 25)
        Me.Panel135.TabIndex = 7
        '
        'TextBox_LicenseOTP_TOTP_UserCodeAdmin
        '
        Me.TextBox_LicenseOTP_TOTP_UserCodeAdmin.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_LicenseOTP_TOTP_UserCodeAdmin.Location = New System.Drawing.Point(81, 3)
        Me.TextBox_LicenseOTP_TOTP_UserCodeAdmin.Name = "TextBox_LicenseOTP_TOTP_UserCodeAdmin"
        Me.TextBox_LicenseOTP_TOTP_UserCodeAdmin.Size = New System.Drawing.Size(472, 20)
        Me.TextBox_LicenseOTP_TOTP_UserCodeAdmin.TabIndex = 1
        '
        'Label152
        '
        Me.Label152.AutoSize = True
        Me.Label152.Location = New System.Drawing.Point(3, 6)
        Me.Label152.Name = "Label152"
        Me.Label152.Size = New System.Drawing.Size(65, 13)
        Me.Label152.TabIndex = 0
        Me.Label152.Text = "Users Code:"
        '
        'Button_LicenseOTP_TOTP_VerifyCode
        '
        Me.Button_LicenseOTP_TOTP_VerifyCode.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_LicenseOTP_TOTP_VerifyCode.BackColor = System.Drawing.Color.LightGreen
        Me.Button_LicenseOTP_TOTP_VerifyCode.Location = New System.Drawing.Point(558, 0)
        Me.Button_LicenseOTP_TOTP_VerifyCode.Name = "Button_LicenseOTP_TOTP_VerifyCode"
        Me.Button_LicenseOTP_TOTP_VerifyCode.Size = New System.Drawing.Size(75, 23)
        Me.Button_LicenseOTP_TOTP_VerifyCode.TabIndex = 0
        Me.Button_LicenseOTP_TOTP_VerifyCode.Text = "Verify Code"
        Me.Button_LicenseOTP_TOTP_VerifyCode.UseVisualStyleBackColor = False
        '
        'Panel137
        '
        Me.Panel137.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel137.Controls.Add(Me.Button_LicenseOTP_TOTP_IntervalCopyUser)
        Me.Panel137.Controls.Add(Me.ComboBox_LicenseOTP_TOTP_IntervalAdmin)
        Me.Panel137.Controls.Add(Me.Label153)
        Me.Panel137.Location = New System.Drawing.Point(6, 70)
        Me.Panel137.Name = "Panel137"
        Me.Panel137.Size = New System.Drawing.Size(636, 25)
        Me.Panel137.TabIndex = 6
        '
        'Button_LicenseOTP_TOTP_IntervalCopyUser
        '
        Me.Button_LicenseOTP_TOTP_IntervalCopyUser.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_LicenseOTP_TOTP_IntervalCopyUser.Location = New System.Drawing.Point(558, 1)
        Me.Button_LicenseOTP_TOTP_IntervalCopyUser.Name = "Button_LicenseOTP_TOTP_IntervalCopyUser"
        Me.Button_LicenseOTP_TOTP_IntervalCopyUser.Size = New System.Drawing.Size(75, 23)
        Me.Button_LicenseOTP_TOTP_IntervalCopyUser.TabIndex = 3
        Me.Button_LicenseOTP_TOTP_IntervalCopyUser.Text = "Copy User"
        Me.Button_LicenseOTP_TOTP_IntervalCopyUser.UseVisualStyleBackColor = True
        Me.Button_LicenseOTP_TOTP_IntervalCopyUser.Visible = False
        '
        'ComboBox_LicenseOTP_TOTP_IntervalAdmin
        '
        Me.ComboBox_LicenseOTP_TOTP_IntervalAdmin.FormattingEnabled = True
        Me.ComboBox_LicenseOTP_TOTP_IntervalAdmin.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "60", "120", "180", "240", "300", "600", "900", "1200", "1800", "3600"})
        Me.ComboBox_LicenseOTP_TOTP_IntervalAdmin.Location = New System.Drawing.Point(81, 3)
        Me.ComboBox_LicenseOTP_TOTP_IntervalAdmin.Name = "ComboBox_LicenseOTP_TOTP_IntervalAdmin"
        Me.ComboBox_LicenseOTP_TOTP_IntervalAdmin.Size = New System.Drawing.Size(87, 21)
        Me.ComboBox_LicenseOTP_TOTP_IntervalAdmin.TabIndex = 1
        Me.ComboBox_LicenseOTP_TOTP_IntervalAdmin.Text = "30"
        '
        'Label153
        '
        Me.Label153.AutoSize = True
        Me.Label153.Location = New System.Drawing.Point(3, 6)
        Me.Label153.Name = "Label153"
        Me.Label153.Size = New System.Drawing.Size(73, 13)
        Me.Label153.TabIndex = 0
        Me.Label153.Text = "Interval (secs)"
        '
        'Panel138
        '
        Me.Panel138.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel138.Controls.Add(Me.Button_LicenseOTP_TOTP_SecretCopyUser)
        Me.Panel138.Controls.Add(Me.TextBox_LicenseOTP_TOTP_SecretAdmin)
        Me.Panel138.Controls.Add(Me.Label154)
        Me.Panel138.Location = New System.Drawing.Point(6, 43)
        Me.Panel138.Name = "Panel138"
        Me.Panel138.Size = New System.Drawing.Size(636, 25)
        Me.Panel138.TabIndex = 5
        '
        'Button_LicenseOTP_TOTP_SecretCopyUser
        '
        Me.Button_LicenseOTP_TOTP_SecretCopyUser.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_LicenseOTP_TOTP_SecretCopyUser.Location = New System.Drawing.Point(558, 1)
        Me.Button_LicenseOTP_TOTP_SecretCopyUser.Name = "Button_LicenseOTP_TOTP_SecretCopyUser"
        Me.Button_LicenseOTP_TOTP_SecretCopyUser.Size = New System.Drawing.Size(75, 23)
        Me.Button_LicenseOTP_TOTP_SecretCopyUser.TabIndex = 2
        Me.Button_LicenseOTP_TOTP_SecretCopyUser.Text = "Copy User"
        Me.Button_LicenseOTP_TOTP_SecretCopyUser.UseVisualStyleBackColor = True
        Me.Button_LicenseOTP_TOTP_SecretCopyUser.Visible = False
        '
        'TextBox_LicenseOTP_TOTP_SecretAdmin
        '
        Me.TextBox_LicenseOTP_TOTP_SecretAdmin.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_LicenseOTP_TOTP_SecretAdmin.Location = New System.Drawing.Point(81, 3)
        Me.TextBox_LicenseOTP_TOTP_SecretAdmin.Name = "TextBox_LicenseOTP_TOTP_SecretAdmin"
        Me.TextBox_LicenseOTP_TOTP_SecretAdmin.Size = New System.Drawing.Size(472, 20)
        Me.TextBox_LicenseOTP_TOTP_SecretAdmin.TabIndex = 1
        '
        'Label154
        '
        Me.Label154.AutoSize = True
        Me.Label154.Location = New System.Drawing.Point(3, 6)
        Me.Label154.Name = "Label154"
        Me.Label154.Size = New System.Drawing.Size(38, 13)
        Me.Label154.TabIndex = 0
        Me.Label154.Text = "Secret"
        '
        'Label155
        '
        Me.Label155.AutoSize = True
        Me.Label155.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label155.Location = New System.Drawing.Point(3, 3)
        Me.Label155.Name = "Label155"
        Me.Label155.Size = New System.Drawing.Size(44, 13)
        Me.Label155.TabIndex = 0
        Me.Label155.Text = "Server"
        '
        'Panel130
        '
        Me.Panel130.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel130.Controls.Add(Me.Panel150)
        Me.Panel130.Controls.Add(Me.Panel133)
        Me.Panel130.Controls.Add(Me.Panel132)
        Me.Panel130.Controls.Add(Me.Panel131)
        Me.Panel130.Controls.Add(Me.Label148)
        Me.Panel130.Location = New System.Drawing.Point(18, 73)
        Me.Panel130.Name = "Panel130"
        Me.Panel130.Size = New System.Drawing.Size(645, 144)
        Me.Panel130.TabIndex = 2
        '
        'Panel150
        '
        Me.Panel150.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel150.Controls.Add(Me.TextBox_LicenseOTP_TOTP_AsBase32User)
        Me.Panel150.Controls.Add(Me.Label168)
        Me.Panel150.Location = New System.Drawing.Point(6, 48)
        Me.Panel150.Name = "Panel150"
        Me.Panel150.Size = New System.Drawing.Size(636, 25)
        Me.Panel150.TabIndex = 8
        '
        'TextBox_LicenseOTP_TOTP_AsBase32User
        '
        Me.TextBox_LicenseOTP_TOTP_AsBase32User.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_LicenseOTP_TOTP_AsBase32User.Location = New System.Drawing.Point(81, 3)
        Me.TextBox_LicenseOTP_TOTP_AsBase32User.Name = "TextBox_LicenseOTP_TOTP_AsBase32User"
        Me.TextBox_LicenseOTP_TOTP_AsBase32User.ReadOnly = True
        Me.TextBox_LicenseOTP_TOTP_AsBase32User.Size = New System.Drawing.Size(472, 20)
        Me.TextBox_LicenseOTP_TOTP_AsBase32User.TabIndex = 1
        '
        'Label168
        '
        Me.Label168.AutoSize = True
        Me.Label168.Location = New System.Drawing.Point(3, 6)
        Me.Label168.Name = "Label168"
        Me.Label168.Size = New System.Drawing.Size(74, 13)
        Me.Label168.TabIndex = 0
        Me.Label168.Text = "Base32Secret"
        '
        'Panel133
        '
        Me.Panel133.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel133.Controls.Add(Me.TextBox_LicenseOTP_TOTP_CodeUser)
        Me.Panel133.Controls.Add(Me.Label151)
        Me.Panel133.Controls.Add(Me.Button_LicenseOTP_TOTP_GetCodeUser)
        Me.Panel133.Location = New System.Drawing.Point(6, 102)
        Me.Panel133.Name = "Panel133"
        Me.Panel133.Size = New System.Drawing.Size(636, 25)
        Me.Panel133.TabIndex = 7
        '
        'TextBox_LicenseOTP_TOTP_CodeUser
        '
        Me.TextBox_LicenseOTP_TOTP_CodeUser.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_LicenseOTP_TOTP_CodeUser.Location = New System.Drawing.Point(81, 3)
        Me.TextBox_LicenseOTP_TOTP_CodeUser.Name = "TextBox_LicenseOTP_TOTP_CodeUser"
        Me.TextBox_LicenseOTP_TOTP_CodeUser.ReadOnly = True
        Me.TextBox_LicenseOTP_TOTP_CodeUser.Size = New System.Drawing.Size(472, 20)
        Me.TextBox_LicenseOTP_TOTP_CodeUser.TabIndex = 1
        '
        'Label151
        '
        Me.Label151.AutoSize = True
        Me.Label151.Location = New System.Drawing.Point(3, 6)
        Me.Label151.Name = "Label151"
        Me.Label151.Size = New System.Drawing.Size(35, 13)
        Me.Label151.TabIndex = 0
        Me.Label151.Text = "Code:"
        '
        'Button_LicenseOTP_TOTP_GetCodeUser
        '
        Me.Button_LicenseOTP_TOTP_GetCodeUser.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_LicenseOTP_TOTP_GetCodeUser.BackColor = System.Drawing.Color.LightGreen
        Me.Button_LicenseOTP_TOTP_GetCodeUser.Location = New System.Drawing.Point(558, 1)
        Me.Button_LicenseOTP_TOTP_GetCodeUser.Name = "Button_LicenseOTP_TOTP_GetCodeUser"
        Me.Button_LicenseOTP_TOTP_GetCodeUser.Size = New System.Drawing.Size(75, 23)
        Me.Button_LicenseOTP_TOTP_GetCodeUser.TabIndex = 0
        Me.Button_LicenseOTP_TOTP_GetCodeUser.Text = "Get Code"
        Me.Button_LicenseOTP_TOTP_GetCodeUser.UseVisualStyleBackColor = False
        '
        'Panel132
        '
        Me.Panel132.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel132.Controls.Add(Me.ComboBox_LicenseOTP_TOTP_IntervalUser)
        Me.Panel132.Controls.Add(Me.Label150)
        Me.Panel132.Location = New System.Drawing.Point(6, 75)
        Me.Panel132.Name = "Panel132"
        Me.Panel132.Size = New System.Drawing.Size(636, 25)
        Me.Panel132.TabIndex = 6
        '
        'ComboBox_LicenseOTP_TOTP_IntervalUser
        '
        Me.ComboBox_LicenseOTP_TOTP_IntervalUser.FormattingEnabled = True
        Me.ComboBox_LicenseOTP_TOTP_IntervalUser.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "60", "120", "180", "240", "300", "600", "900", "1200", "1800", "3600"})
        Me.ComboBox_LicenseOTP_TOTP_IntervalUser.Location = New System.Drawing.Point(81, 3)
        Me.ComboBox_LicenseOTP_TOTP_IntervalUser.Name = "ComboBox_LicenseOTP_TOTP_IntervalUser"
        Me.ComboBox_LicenseOTP_TOTP_IntervalUser.Size = New System.Drawing.Size(87, 21)
        Me.ComboBox_LicenseOTP_TOTP_IntervalUser.TabIndex = 1
        Me.ComboBox_LicenseOTP_TOTP_IntervalUser.Text = "30"
        '
        'Label150
        '
        Me.Label150.AutoSize = True
        Me.Label150.Location = New System.Drawing.Point(3, 6)
        Me.Label150.Name = "Label150"
        Me.Label150.Size = New System.Drawing.Size(73, 13)
        Me.Label150.TabIndex = 0
        Me.Label150.Text = "Interval (secs)"
        '
        'Panel131
        '
        Me.Panel131.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel131.Controls.Add(Me.Button_LicenseOTP_TOTP_SecretUser)
        Me.Panel131.Controls.Add(Me.TextBox_LicenseOTP_TOTP_SecretUser)
        Me.Panel131.Controls.Add(Me.Label149)
        Me.Panel131.Location = New System.Drawing.Point(6, 22)
        Me.Panel131.Name = "Panel131"
        Me.Panel131.Size = New System.Drawing.Size(636, 25)
        Me.Panel131.TabIndex = 5
        '
        'Button_LicenseOTP_TOTP_SecretUser
        '
        Me.Button_LicenseOTP_TOTP_SecretUser.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_LicenseOTP_TOTP_SecretUser.Location = New System.Drawing.Point(558, 1)
        Me.Button_LicenseOTP_TOTP_SecretUser.Name = "Button_LicenseOTP_TOTP_SecretUser"
        Me.Button_LicenseOTP_TOTP_SecretUser.Size = New System.Drawing.Size(75, 23)
        Me.Button_LicenseOTP_TOTP_SecretUser.TabIndex = 2
        Me.Button_LicenseOTP_TOTP_SecretUser.Text = "Generate"
        Me.Button_LicenseOTP_TOTP_SecretUser.UseVisualStyleBackColor = True
        '
        'TextBox_LicenseOTP_TOTP_SecretUser
        '
        Me.TextBox_LicenseOTP_TOTP_SecretUser.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_LicenseOTP_TOTP_SecretUser.Location = New System.Drawing.Point(81, 3)
        Me.TextBox_LicenseOTP_TOTP_SecretUser.Name = "TextBox_LicenseOTP_TOTP_SecretUser"
        Me.TextBox_LicenseOTP_TOTP_SecretUser.Size = New System.Drawing.Size(472, 20)
        Me.TextBox_LicenseOTP_TOTP_SecretUser.TabIndex = 1
        '
        'Label149
        '
        Me.Label149.AutoSize = True
        Me.Label149.Location = New System.Drawing.Point(3, 6)
        Me.Label149.Name = "Label149"
        Me.Label149.Size = New System.Drawing.Size(38, 13)
        Me.Label149.TabIndex = 0
        Me.Label149.Text = "Secret"
        '
        'Label148
        '
        Me.Label148.AutoSize = True
        Me.Label148.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label148.Location = New System.Drawing.Point(3, 3)
        Me.Label148.Name = "Label148"
        Me.Label148.Size = New System.Drawing.Size(39, 13)
        Me.Label148.TabIndex = 0
        Me.Label148.Text = "Client"
        '
        'TabPage_Verify
        '
        Me.TabPage_Verify.AutoScroll = True
        Me.TabPage_Verify.Controls.Add(Me.Label72)
        Me.TabPage_Verify.Controls.Add(Me.Panel85)
        Me.TabPage_Verify.Controls.Add(Me.Panel82)
        Me.TabPage_Verify.Controls.Add(Me.Panel83)
        Me.TabPage_Verify.Controls.Add(Me.Panel84)
        Me.TabPage_Verify.Controls.Add(Me.Panel81)
        Me.TabPage_Verify.Controls.Add(Me.Panel79)
        Me.TabPage_Verify.Controls.Add(Me.Panel80)
        Me.TabPage_Verify.Controls.Add(Me.Panel76)
        Me.TabPage_Verify.Controls.Add(Me.Panel77)
        Me.TabPage_Verify.Controls.Add(Me.Panel74)
        Me.TabPage_Verify.Controls.Add(Me.Panel75)
        Me.TabPage_Verify.Controls.Add(Me.Panel72)
        Me.TabPage_Verify.Controls.Add(Me.Panel73)
        Me.TabPage_Verify.Location = New System.Drawing.Point(4, 22)
        Me.TabPage_Verify.Name = "TabPage_Verify"
        Me.TabPage_Verify.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage_Verify.Size = New System.Drawing.Size(751, 581)
        Me.TabPage_Verify.TabIndex = 2
        Me.TabPage_Verify.Text = "Verify"
        Me.TabPage_Verify.UseVisualStyleBackColor = True
        '
        'Label72
        '
        Me.Label72.AutoSize = True
        Me.Label72.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label72.Location = New System.Drawing.Point(20, 24)
        Me.Label72.Name = "Label72"
        Me.Label72.Size = New System.Drawing.Size(229, 13)
        Me.Label72.TabIndex = 55
        Me.Label72.Text = "Paste values for manual verification and testing"
        '
        'Panel85
        '
        Me.Panel85.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel85.Controls.Add(Me.TextBox_Verify_SaltForSignature)
        Me.Panel85.Controls.Add(Me.Label79)
        Me.Panel85.Location = New System.Drawing.Point(19, 293)
        Me.Panel85.Name = "Panel85"
        Me.Panel85.Size = New System.Drawing.Size(709, 22)
        Me.Panel85.TabIndex = 54
        '
        'TextBox_Verify_SaltForSignature
        '
        Me.TextBox_Verify_SaltForSignature.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_Verify_SaltForSignature.Location = New System.Drawing.Point(117, 1)
        Me.TextBox_Verify_SaltForSignature.Name = "TextBox_Verify_SaltForSignature"
        Me.TextBox_Verify_SaltForSignature.Size = New System.Drawing.Size(474, 20)
        Me.TextBox_Verify_SaltForSignature.TabIndex = 1
        '
        'Label79
        '
        Me.Label79.AutoSize = True
        Me.Label79.Location = New System.Drawing.Point(3, 3)
        Me.Label79.Name = "Label79"
        Me.Label79.Size = New System.Drawing.Size(90, 13)
        Me.Label79.TabIndex = 0
        Me.Label79.Text = "Salt (if applicable)"
        '
        'Panel82
        '
        Me.Panel82.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel82.Controls.Add(Me.TextBox_Verify_DataHashForSignature)
        Me.Panel82.Controls.Add(Me.Label76)
        Me.Panel82.Location = New System.Drawing.Point(19, 241)
        Me.Panel82.Name = "Panel82"
        Me.Panel82.Size = New System.Drawing.Size(709, 24)
        Me.Panel82.TabIndex = 53
        '
        'TextBox_Verify_DataHashForSignature
        '
        Me.TextBox_Verify_DataHashForSignature.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_Verify_DataHashForSignature.Location = New System.Drawing.Point(117, 2)
        Me.TextBox_Verify_DataHashForSignature.Name = "TextBox_Verify_DataHashForSignature"
        Me.TextBox_Verify_DataHashForSignature.Size = New System.Drawing.Size(474, 20)
        Me.TextBox_Verify_DataHashForSignature.TabIndex = 1
        '
        'Label76
        '
        Me.Label76.AutoSize = True
        Me.Label76.Location = New System.Drawing.Point(2, 4)
        Me.Label76.Name = "Label76"
        Me.Label76.Size = New System.Drawing.Size(61, 13)
        Me.Label76.TabIndex = 0
        Me.Label76.Text = "Data Hash:"
        '
        'Panel83
        '
        Me.Panel83.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel83.Controls.Add(Me.TextBox_Verify_PrivateKeyForSignature)
        Me.Panel83.Controls.Add(Me.Label77)
        Me.Panel83.Location = New System.Drawing.Point(19, 267)
        Me.Panel83.Name = "Panel83"
        Me.Panel83.Size = New System.Drawing.Size(709, 24)
        Me.Panel83.TabIndex = 52
        '
        'TextBox_Verify_PrivateKeyForSignature
        '
        Me.TextBox_Verify_PrivateKeyForSignature.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_Verify_PrivateKeyForSignature.Location = New System.Drawing.Point(117, 2)
        Me.TextBox_Verify_PrivateKeyForSignature.Name = "TextBox_Verify_PrivateKeyForSignature"
        Me.TextBox_Verify_PrivateKeyForSignature.Size = New System.Drawing.Size(474, 20)
        Me.TextBox_Verify_PrivateKeyForSignature.TabIndex = 1
        '
        'Label77
        '
        Me.Label77.AutoSize = True
        Me.Label77.Location = New System.Drawing.Point(2, 4)
        Me.Label77.Name = "Label77"
        Me.Label77.Size = New System.Drawing.Size(61, 13)
        Me.Label77.TabIndex = 0
        Me.Label77.Text = "Private Key"
        '
        'Panel84
        '
        Me.Panel84.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel84.Controls.Add(Me.Button_LicenseGen_Verify_GetSignature)
        Me.Panel84.Controls.Add(Me.TextBox_Verify_Signature)
        Me.Panel84.Controls.Add(Me.Label78)
        Me.Panel84.Location = New System.Drawing.Point(19, 317)
        Me.Panel84.Name = "Panel84"
        Me.Panel84.Size = New System.Drawing.Size(709, 22)
        Me.Panel84.TabIndex = 51
        '
        'Button_LicenseGen_Verify_GetSignature
        '
        Me.Button_LicenseGen_Verify_GetSignature.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_LicenseGen_Verify_GetSignature.Location = New System.Drawing.Point(597, -1)
        Me.Button_LicenseGen_Verify_GetSignature.Name = "Button_LicenseGen_Verify_GetSignature"
        Me.Button_LicenseGen_Verify_GetSignature.Size = New System.Drawing.Size(53, 23)
        Me.Button_LicenseGen_Verify_GetSignature.TabIndex = 25
        Me.Button_LicenseGen_Verify_GetSignature.Text = "Get"
        Me.Button_LicenseGen_Verify_GetSignature.UseVisualStyleBackColor = True
        '
        'TextBox_Verify_Signature
        '
        Me.TextBox_Verify_Signature.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_Verify_Signature.Location = New System.Drawing.Point(117, 1)
        Me.TextBox_Verify_Signature.Name = "TextBox_Verify_Signature"
        Me.TextBox_Verify_Signature.Size = New System.Drawing.Size(474, 20)
        Me.TextBox_Verify_Signature.TabIndex = 1
        '
        'Label78
        '
        Me.Label78.AutoSize = True
        Me.Label78.Location = New System.Drawing.Point(3, 3)
        Me.Label78.Name = "Label78"
        Me.Label78.Size = New System.Drawing.Size(52, 13)
        Me.Label78.TabIndex = 0
        Me.Label78.Text = "Signature"
        '
        'Panel81
        '
        Me.Panel81.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel81.Controls.Add(Me.Button_LicenseGen_Verify_Verify)
        Me.Panel81.Controls.Add(Me.TextBox_LicenseGen_Verify_Verified)
        Me.Panel81.Controls.Add(Me.Label75)
        Me.Panel81.Location = New System.Drawing.Point(19, 499)
        Me.Panel81.Name = "Panel81"
        Me.Panel81.Size = New System.Drawing.Size(709, 24)
        Me.Panel81.TabIndex = 50
        '
        'Button_LicenseGen_Verify_Verify
        '
        Me.Button_LicenseGen_Verify_Verify.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_LicenseGen_Verify_Verify.Location = New System.Drawing.Point(597, 1)
        Me.Button_LicenseGen_Verify_Verify.Name = "Button_LicenseGen_Verify_Verify"
        Me.Button_LicenseGen_Verify_Verify.Size = New System.Drawing.Size(62, 23)
        Me.Button_LicenseGen_Verify_Verify.TabIndex = 26
        Me.Button_LicenseGen_Verify_Verify.Text = "Verify"
        Me.Button_LicenseGen_Verify_Verify.UseVisualStyleBackColor = True
        '
        'TextBox_LicenseGen_Verify_Verified
        '
        Me.TextBox_LicenseGen_Verify_Verified.Location = New System.Drawing.Point(117, 2)
        Me.TextBox_LicenseGen_Verify_Verified.Name = "TextBox_LicenseGen_Verify_Verified"
        Me.TextBox_LicenseGen_Verify_Verified.Size = New System.Drawing.Size(77, 20)
        Me.TextBox_LicenseGen_Verify_Verified.TabIndex = 24
        '
        'Label75
        '
        Me.Label75.AutoSize = True
        Me.Label75.Location = New System.Drawing.Point(3, 3)
        Me.Label75.Name = "Label75"
        Me.Label75.Size = New System.Drawing.Size(48, 13)
        Me.Label75.TabIndex = 0
        Me.Label75.Text = "Verified?"
        '
        'Panel79
        '
        Me.Panel79.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel79.Controls.Add(Me.TextBox_LicenseGen_Verify_DataHashForVerification)
        Me.Panel79.Controls.Add(Me.Label73)
        Me.Panel79.Location = New System.Drawing.Point(19, 395)
        Me.Panel79.Name = "Panel79"
        Me.Panel79.Size = New System.Drawing.Size(709, 24)
        Me.Panel79.TabIndex = 49
        '
        'TextBox_LicenseGen_Verify_DataHashForVerification
        '
        Me.TextBox_LicenseGen_Verify_DataHashForVerification.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_LicenseGen_Verify_DataHashForVerification.Location = New System.Drawing.Point(117, 1)
        Me.TextBox_LicenseGen_Verify_DataHashForVerification.Name = "TextBox_LicenseGen_Verify_DataHashForVerification"
        Me.TextBox_LicenseGen_Verify_DataHashForVerification.Size = New System.Drawing.Size(474, 20)
        Me.TextBox_LicenseGen_Verify_DataHashForVerification.TabIndex = 1
        '
        'Label73
        '
        Me.Label73.AutoSize = True
        Me.Label73.Location = New System.Drawing.Point(2, 4)
        Me.Label73.Name = "Label73"
        Me.Label73.Size = New System.Drawing.Size(61, 13)
        Me.Label73.TabIndex = 0
        Me.Label73.Text = "Data Hash:"
        '
        'Panel80
        '
        Me.Panel80.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel80.Controls.Add(Me.TextBox_LicenseGen_Verify_SignatureForVerification)
        Me.Panel80.Controls.Add(Me.Label74)
        Me.Panel80.Location = New System.Drawing.Point(19, 421)
        Me.Panel80.Name = "Panel80"
        Me.Panel80.Size = New System.Drawing.Size(709, 24)
        Me.Panel80.TabIndex = 48
        '
        'TextBox_LicenseGen_Verify_SignatureForVerification
        '
        Me.TextBox_LicenseGen_Verify_SignatureForVerification.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_LicenseGen_Verify_SignatureForVerification.Location = New System.Drawing.Point(117, 1)
        Me.TextBox_LicenseGen_Verify_SignatureForVerification.Name = "TextBox_LicenseGen_Verify_SignatureForVerification"
        Me.TextBox_LicenseGen_Verify_SignatureForVerification.Size = New System.Drawing.Size(474, 20)
        Me.TextBox_LicenseGen_Verify_SignatureForVerification.TabIndex = 1
        '
        'Label74
        '
        Me.Label74.AutoSize = True
        Me.Label74.Location = New System.Drawing.Point(2, 4)
        Me.Label74.Name = "Label74"
        Me.Label74.Size = New System.Drawing.Size(52, 13)
        Me.Label74.TabIndex = 0
        Me.Label74.Text = "Signature"
        '
        'Panel76
        '
        Me.Panel76.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel76.Controls.Add(Me.TextBox_LicenseGen_Verify_SaltForVerification)
        Me.Panel76.Controls.Add(Me.Label70)
        Me.Panel76.Location = New System.Drawing.Point(19, 471)
        Me.Panel76.Name = "Panel76"
        Me.Panel76.Size = New System.Drawing.Size(709, 22)
        Me.Panel76.TabIndex = 12
        '
        'TextBox_LicenseGen_Verify_SaltForVerification
        '
        Me.TextBox_LicenseGen_Verify_SaltForVerification.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_LicenseGen_Verify_SaltForVerification.Location = New System.Drawing.Point(117, 0)
        Me.TextBox_LicenseGen_Verify_SaltForVerification.Name = "TextBox_LicenseGen_Verify_SaltForVerification"
        Me.TextBox_LicenseGen_Verify_SaltForVerification.Size = New System.Drawing.Size(474, 20)
        Me.TextBox_LicenseGen_Verify_SaltForVerification.TabIndex = 1
        '
        'Label70
        '
        Me.Label70.AutoSize = True
        Me.Label70.Location = New System.Drawing.Point(3, 3)
        Me.Label70.Name = "Label70"
        Me.Label70.Size = New System.Drawing.Size(90, 13)
        Me.Label70.TabIndex = 0
        Me.Label70.Text = "Salt (if applicable)"
        '
        'Panel77
        '
        Me.Panel77.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel77.Controls.Add(Me.TextBox_LicenseGen_Verify_PublicKeyForVerification)
        Me.Panel77.Controls.Add(Me.Label71)
        Me.Panel77.Location = New System.Drawing.Point(19, 447)
        Me.Panel77.Name = "Panel77"
        Me.Panel77.Size = New System.Drawing.Size(709, 22)
        Me.Panel77.TabIndex = 11
        '
        'TextBox_LicenseGen_Verify_PublicKeyForVerification
        '
        Me.TextBox_LicenseGen_Verify_PublicKeyForVerification.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_LicenseGen_Verify_PublicKeyForVerification.Location = New System.Drawing.Point(117, 0)
        Me.TextBox_LicenseGen_Verify_PublicKeyForVerification.Name = "TextBox_LicenseGen_Verify_PublicKeyForVerification"
        Me.TextBox_LicenseGen_Verify_PublicKeyForVerification.Size = New System.Drawing.Size(474, 20)
        Me.TextBox_LicenseGen_Verify_PublicKeyForVerification.TabIndex = 1
        '
        'Label71
        '
        Me.Label71.AutoSize = True
        Me.Label71.Location = New System.Drawing.Point(3, 3)
        Me.Label71.Name = "Label71"
        Me.Label71.Size = New System.Drawing.Size(57, 13)
        Me.Label71.TabIndex = 0
        Me.Label71.Text = "Public Key"
        '
        'Panel74
        '
        Me.Panel74.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel74.Controls.Add(Me.Button_LicenseGen_Verify_GetTestDataHash)
        Me.Panel74.Controls.Add(Me.Button_LicenseGen_Verify_CopyTestDataHash)
        Me.Panel74.Controls.Add(Me.TextBox_LicenseGen_Verify_TestDataHashed)
        Me.Panel74.Controls.Add(Me.Label68)
        Me.Panel74.Location = New System.Drawing.Point(19, 160)
        Me.Panel74.Name = "Panel74"
        Me.Panel74.Size = New System.Drawing.Size(709, 22)
        Me.Panel74.TabIndex = 10
        '
        'Button_LicenseGen_Verify_GetTestDataHash
        '
        Me.Button_LicenseGen_Verify_GetTestDataHash.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_LicenseGen_Verify_GetTestDataHash.Location = New System.Drawing.Point(597, -1)
        Me.Button_LicenseGen_Verify_GetTestDataHash.Name = "Button_LicenseGen_Verify_GetTestDataHash"
        Me.Button_LicenseGen_Verify_GetTestDataHash.Size = New System.Drawing.Size(53, 23)
        Me.Button_LicenseGen_Verify_GetTestDataHash.TabIndex = 24
        Me.Button_LicenseGen_Verify_GetTestDataHash.Text = "Get"
        Me.Button_LicenseGen_Verify_GetTestDataHash.UseVisualStyleBackColor = True
        '
        'Button_LicenseGen_Verify_CopyTestDataHash
        '
        Me.Button_LicenseGen_Verify_CopyTestDataHash.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_LicenseGen_Verify_CopyTestDataHash.Location = New System.Drawing.Point(656, -1)
        Me.Button_LicenseGen_Verify_CopyTestDataHash.Name = "Button_LicenseGen_Verify_CopyTestDataHash"
        Me.Button_LicenseGen_Verify_CopyTestDataHash.Size = New System.Drawing.Size(53, 23)
        Me.Button_LicenseGen_Verify_CopyTestDataHash.TabIndex = 22
        Me.Button_LicenseGen_Verify_CopyTestDataHash.Text = "Copy"
        Me.Button_LicenseGen_Verify_CopyTestDataHash.UseVisualStyleBackColor = True
        '
        'TextBox_LicenseGen_Verify_TestDataHashed
        '
        Me.TextBox_LicenseGen_Verify_TestDataHashed.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_LicenseGen_Verify_TestDataHashed.Location = New System.Drawing.Point(117, 0)
        Me.TextBox_LicenseGen_Verify_TestDataHashed.Name = "TextBox_LicenseGen_Verify_TestDataHashed"
        Me.TextBox_LicenseGen_Verify_TestDataHashed.Size = New System.Drawing.Size(474, 20)
        Me.TextBox_LicenseGen_Verify_TestDataHashed.TabIndex = 1
        '
        'Label68
        '
        Me.Label68.AutoSize = True
        Me.Label68.Location = New System.Drawing.Point(3, 3)
        Me.Label68.Name = "Label68"
        Me.Label68.Size = New System.Drawing.Size(94, 13)
        Me.Label68.TabIndex = 0
        Me.Label68.Text = "Test Data Hashed"
        '
        'Panel75
        '
        Me.Panel75.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel75.Controls.Add(Me.TextBox_LicenseGen_Verify_TestData)
        Me.Panel75.Controls.Add(Me.Label69)
        Me.Panel75.Location = New System.Drawing.Point(19, 136)
        Me.Panel75.Name = "Panel75"
        Me.Panel75.Size = New System.Drawing.Size(709, 22)
        Me.Panel75.TabIndex = 9
        '
        'TextBox_LicenseGen_Verify_TestData
        '
        Me.TextBox_LicenseGen_Verify_TestData.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_LicenseGen_Verify_TestData.Location = New System.Drawing.Point(117, 0)
        Me.TextBox_LicenseGen_Verify_TestData.Name = "TextBox_LicenseGen_Verify_TestData"
        Me.TextBox_LicenseGen_Verify_TestData.Size = New System.Drawing.Size(474, 20)
        Me.TextBox_LicenseGen_Verify_TestData.TabIndex = 1
        '
        'Label69
        '
        Me.Label69.AutoSize = True
        Me.Label69.Location = New System.Drawing.Point(3, 3)
        Me.Label69.Name = "Label69"
        Me.Label69.Size = New System.Drawing.Size(54, 13)
        Me.Label69.TabIndex = 0
        Me.Label69.Text = "Test Data"
        '
        'Panel72
        '
        Me.Panel72.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel72.Controls.Add(Me.Button_LicenseGen_Verify_GetMachineHash)
        Me.Panel72.Controls.Add(Me.Button_LicenseGen_Verify_CopyMachineHash)
        Me.Panel72.Controls.Add(Me.TextBox_LicenseGen_Verify_FingerPrintHash)
        Me.Panel72.Controls.Add(Me.Label67)
        Me.Panel72.Location = New System.Drawing.Point(19, 83)
        Me.Panel72.Name = "Panel72"
        Me.Panel72.Size = New System.Drawing.Size(709, 22)
        Me.Panel72.TabIndex = 8
        '
        'Button_LicenseGen_Verify_GetMachineHash
        '
        Me.Button_LicenseGen_Verify_GetMachineHash.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_LicenseGen_Verify_GetMachineHash.Location = New System.Drawing.Point(597, -1)
        Me.Button_LicenseGen_Verify_GetMachineHash.Name = "Button_LicenseGen_Verify_GetMachineHash"
        Me.Button_LicenseGen_Verify_GetMachineHash.Size = New System.Drawing.Size(53, 23)
        Me.Button_LicenseGen_Verify_GetMachineHash.TabIndex = 24
        Me.Button_LicenseGen_Verify_GetMachineHash.Text = "Get"
        Me.Button_LicenseGen_Verify_GetMachineHash.UseVisualStyleBackColor = True
        '
        'Button_LicenseGen_Verify_CopyMachineHash
        '
        Me.Button_LicenseGen_Verify_CopyMachineHash.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_LicenseGen_Verify_CopyMachineHash.Location = New System.Drawing.Point(656, -1)
        Me.Button_LicenseGen_Verify_CopyMachineHash.Name = "Button_LicenseGen_Verify_CopyMachineHash"
        Me.Button_LicenseGen_Verify_CopyMachineHash.Size = New System.Drawing.Size(53, 23)
        Me.Button_LicenseGen_Verify_CopyMachineHash.TabIndex = 22
        Me.Button_LicenseGen_Verify_CopyMachineHash.Text = "Copy"
        Me.Button_LicenseGen_Verify_CopyMachineHash.UseVisualStyleBackColor = True
        '
        'TextBox_LicenseGen_Verify_FingerPrintHash
        '
        Me.TextBox_LicenseGen_Verify_FingerPrintHash.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_LicenseGen_Verify_FingerPrintHash.Location = New System.Drawing.Point(117, 0)
        Me.TextBox_LicenseGen_Verify_FingerPrintHash.Name = "TextBox_LicenseGen_Verify_FingerPrintHash"
        Me.TextBox_LicenseGen_Verify_FingerPrintHash.Size = New System.Drawing.Size(474, 20)
        Me.TextBox_LicenseGen_Verify_FingerPrintHash.TabIndex = 1
        '
        'Label67
        '
        Me.Label67.AutoSize = True
        Me.Label67.Location = New System.Drawing.Point(3, 3)
        Me.Label67.Name = "Label67"
        Me.Label67.Size = New System.Drawing.Size(96, 13)
        Me.Label67.TabIndex = 0
        Me.Label67.Text = "Fingerprint Hashed"
        '
        'Panel73
        '
        Me.Panel73.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel73.Controls.Add(Me.Button_LicenseGen_Verify_GetMachineFingerprint)
        Me.Panel73.Controls.Add(Me.Button_LicenseGen_Verify_CopyMAchineFingerprint)
        Me.Panel73.Controls.Add(Me.TextBox_LicenseGen_Verify_MachineFingerprint)
        Me.Panel73.Controls.Add(Me.Label65)
        Me.Panel73.Location = New System.Drawing.Point(19, 59)
        Me.Panel73.Name = "Panel73"
        Me.Panel73.Size = New System.Drawing.Size(709, 22)
        Me.Panel73.TabIndex = 7
        '
        'Button_LicenseGen_Verify_GetMachineFingerprint
        '
        Me.Button_LicenseGen_Verify_GetMachineFingerprint.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_LicenseGen_Verify_GetMachineFingerprint.Location = New System.Drawing.Point(597, -1)
        Me.Button_LicenseGen_Verify_GetMachineFingerprint.Name = "Button_LicenseGen_Verify_GetMachineFingerprint"
        Me.Button_LicenseGen_Verify_GetMachineFingerprint.Size = New System.Drawing.Size(53, 23)
        Me.Button_LicenseGen_Verify_GetMachineFingerprint.TabIndex = 23
        Me.Button_LicenseGen_Verify_GetMachineFingerprint.Text = "Get"
        Me.Button_LicenseGen_Verify_GetMachineFingerprint.UseVisualStyleBackColor = True
        '
        'Button_LicenseGen_Verify_CopyMAchineFingerprint
        '
        Me.Button_LicenseGen_Verify_CopyMAchineFingerprint.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_LicenseGen_Verify_CopyMAchineFingerprint.Location = New System.Drawing.Point(656, -1)
        Me.Button_LicenseGen_Verify_CopyMAchineFingerprint.Name = "Button_LicenseGen_Verify_CopyMAchineFingerprint"
        Me.Button_LicenseGen_Verify_CopyMAchineFingerprint.Size = New System.Drawing.Size(53, 23)
        Me.Button_LicenseGen_Verify_CopyMAchineFingerprint.TabIndex = 22
        Me.Button_LicenseGen_Verify_CopyMAchineFingerprint.Text = "Copy"
        Me.Button_LicenseGen_Verify_CopyMAchineFingerprint.UseVisualStyleBackColor = True
        '
        'TextBox_LicenseGen_Verify_MachineFingerprint
        '
        Me.TextBox_LicenseGen_Verify_MachineFingerprint.AcceptsReturn = True
        Me.TextBox_LicenseGen_Verify_MachineFingerprint.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_LicenseGen_Verify_MachineFingerprint.Location = New System.Drawing.Point(117, 0)
        Me.TextBox_LicenseGen_Verify_MachineFingerprint.Name = "TextBox_LicenseGen_Verify_MachineFingerprint"
        Me.TextBox_LicenseGen_Verify_MachineFingerprint.Size = New System.Drawing.Size(474, 20)
        Me.TextBox_LicenseGen_Verify_MachineFingerprint.TabIndex = 1
        '
        'Label65
        '
        Me.Label65.AutoSize = True
        Me.Label65.Location = New System.Drawing.Point(3, 3)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(100, 13)
        Me.Label65.TabIndex = 0
        Me.Label65.Text = "Machine Fingerprint"
        '
        'TabPage6
        '
        Me.TabPage6.Controls.Add(Me.TabControl5)
        Me.TabPage6.Location = New System.Drawing.Point(4, 22)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage6.Size = New System.Drawing.Size(751, 581)
        Me.TabPage6.TabIndex = 3
        Me.TabPage6.Text = "Demos"
        Me.TabPage6.UseVisualStyleBackColor = True
        '
        'TabControl5
        '
        Me.TabControl5.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TabControl5.Controls.Add(Me.TabPage7)
        Me.TabControl5.Controls.Add(Me.TabPage8)
        Me.TabControl5.Location = New System.Drawing.Point(6, 18)
        Me.TabControl5.Name = "TabControl5"
        Me.TabControl5.SelectedIndex = 0
        Me.TabControl5.Size = New System.Drawing.Size(739, 557)
        Me.TabControl5.TabIndex = 0
        '
        'TabPage7
        '
        Me.TabPage7.AutoScroll = True
        Me.TabPage7.BackColor = System.Drawing.Color.White
        Me.TabPage7.Controls.Add(Me.GroupBox6)
        Me.TabPage7.Controls.Add(Me.GroupBox5)
        Me.TabPage7.Controls.Add(Me.Label96)
        Me.TabPage7.Controls.Add(Me.Label88)
        Me.TabPage7.Controls.Add(Me.Panel90)
        Me.TabPage7.Controls.Add(Me.GroupBox4)
        Me.TabPage7.Controls.Add(Me.GroupBox3)
        Me.TabPage7.Controls.Add(Me.Label82)
        Me.TabPage7.Controls.Add(Me.Label81)
        Me.TabPage7.Location = New System.Drawing.Point(4, 22)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage7.Size = New System.Drawing.Size(731, 531)
        Me.TabPage7.TabIndex = 0
        Me.TabPage7.Text = "1"
        '
        'GroupBox6
        '
        Me.GroupBox6.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox6.BackColor = System.Drawing.Color.WhiteSmoke
        Me.GroupBox6.Controls.Add(Me.Panel113)
        Me.GroupBox6.Controls.Add(Me.Panel112)
        Me.GroupBox6.Controls.Add(Me.Panel111)
        Me.GroupBox6.Controls.Add(Me.Panel110)
        Me.GroupBox6.Controls.Add(Me.Button68)
        Me.GroupBox6.Controls.Add(Me.Panel109)
        Me.GroupBox6.Controls.Add(Me.Panel107)
        Me.GroupBox6.Controls.Add(Me.Panel108)
        Me.GroupBox6.Controls.Add(Me.Panel106)
        Me.GroupBox6.Controls.Add(Me.Panel105)
        Me.GroupBox6.Controls.Add(Me.Panel104)
        Me.GroupBox6.Controls.Add(Me.Label109)
        Me.GroupBox6.Controls.Add(Me.Label108)
        Me.GroupBox6.Controls.Add(Me.Label107)
        Me.GroupBox6.Controls.Add(Me.Label106)
        Me.GroupBox6.Controls.Add(Me.Panel103)
        Me.GroupBox6.Location = New System.Drawing.Point(12, 1403)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(680, 493)
        Me.GroupBox6.TabIndex = 8
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Step 4 - Verify"
        '
        'Panel113
        '
        Me.Panel113.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel113.Controls.Add(Me.TextBox_Demo1_Verify_CurrentLocalTime)
        Me.Panel113.Controls.Add(Me.Label119)
        Me.Panel113.Location = New System.Drawing.Point(21, 399)
        Me.Panel113.Name = "Panel113"
        Me.Panel113.Size = New System.Drawing.Size(640, 25)
        Me.Panel113.TabIndex = 50
        '
        'TextBox_Demo1_Verify_CurrentLocalTime
        '
        Me.TextBox_Demo1_Verify_CurrentLocalTime.Location = New System.Drawing.Point(136, 3)
        Me.TextBox_Demo1_Verify_CurrentLocalTime.Name = "TextBox_Demo1_Verify_CurrentLocalTime"
        Me.TextBox_Demo1_Verify_CurrentLocalTime.ReadOnly = True
        Me.TextBox_Demo1_Verify_CurrentLocalTime.Size = New System.Drawing.Size(114, 20)
        Me.TextBox_Demo1_Verify_CurrentLocalTime.TabIndex = 2
        '
        'Label119
        '
        Me.Label119.AutoSize = True
        Me.Label119.ForeColor = System.Drawing.Color.Black
        Me.Label119.Location = New System.Drawing.Point(3, 6)
        Me.Label119.Name = "Label119"
        Me.Label119.Size = New System.Drawing.Size(96, 13)
        Me.Label119.TabIndex = 0
        Me.Label119.Text = "Current Local Time"
        '
        'Panel112
        '
        Me.Panel112.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel112.Controls.Add(Me.TextBox_Demo1_Verify_Expired)
        Me.Panel112.Controls.Add(Me.Label117)
        Me.Panel112.Location = New System.Drawing.Point(20, 426)
        Me.Panel112.Name = "Panel112"
        Me.Panel112.Size = New System.Drawing.Size(456, 25)
        Me.Panel112.TabIndex = 49
        '
        'TextBox_Demo1_Verify_Expired
        '
        Me.TextBox_Demo1_Verify_Expired.Location = New System.Drawing.Point(136, 3)
        Me.TextBox_Demo1_Verify_Expired.Name = "TextBox_Demo1_Verify_Expired"
        Me.TextBox_Demo1_Verify_Expired.ReadOnly = True
        Me.TextBox_Demo1_Verify_Expired.Size = New System.Drawing.Size(114, 20)
        Me.TextBox_Demo1_Verify_Expired.TabIndex = 2
        '
        'Label117
        '
        Me.Label117.AutoSize = True
        Me.Label117.ForeColor = System.Drawing.Color.Black
        Me.Label117.Location = New System.Drawing.Point(3, 6)
        Me.Label117.Name = "Label117"
        Me.Label117.Size = New System.Drawing.Size(48, 13)
        Me.Label117.TabIndex = 0
        Me.Label117.Text = "Expired?"
        '
        'Panel111
        '
        Me.Panel111.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel111.Controls.Add(Me.TextBox_Demo1_Verify_CurrentUTCTime)
        Me.Panel111.Controls.Add(Me.Label112)
        Me.Panel111.Location = New System.Drawing.Point(21, 372)
        Me.Panel111.Name = "Panel111"
        Me.Panel111.Size = New System.Drawing.Size(640, 25)
        Me.Panel111.TabIndex = 48
        '
        'TextBox_Demo1_Verify_CurrentUTCTime
        '
        Me.TextBox_Demo1_Verify_CurrentUTCTime.Location = New System.Drawing.Point(136, 3)
        Me.TextBox_Demo1_Verify_CurrentUTCTime.Name = "TextBox_Demo1_Verify_CurrentUTCTime"
        Me.TextBox_Demo1_Verify_CurrentUTCTime.ReadOnly = True
        Me.TextBox_Demo1_Verify_CurrentUTCTime.Size = New System.Drawing.Size(114, 20)
        Me.TextBox_Demo1_Verify_CurrentUTCTime.TabIndex = 2
        '
        'Label112
        '
        Me.Label112.AutoSize = True
        Me.Label112.ForeColor = System.Drawing.Color.Black
        Me.Label112.Location = New System.Drawing.Point(3, 6)
        Me.Label112.Name = "Label112"
        Me.Label112.Size = New System.Drawing.Size(95, 13)
        Me.Label112.TabIndex = 0
        Me.Label112.Text = "Current UTC Time:"
        '
        'Panel110
        '
        Me.Panel110.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel110.Controls.Add(Me.TextBox_Demo1_Verify_IsVerified)
        Me.Panel110.Controls.Add(Me.Label110)
        Me.Panel110.Location = New System.Drawing.Point(20, 345)
        Me.Panel110.Name = "Panel110"
        Me.Panel110.Size = New System.Drawing.Size(640, 25)
        Me.Panel110.TabIndex = 47
        '
        'TextBox_Demo1_Verify_IsVerified
        '
        Me.TextBox_Demo1_Verify_IsVerified.Location = New System.Drawing.Point(136, 3)
        Me.TextBox_Demo1_Verify_IsVerified.Name = "TextBox_Demo1_Verify_IsVerified"
        Me.TextBox_Demo1_Verify_IsVerified.ReadOnly = True
        Me.TextBox_Demo1_Verify_IsVerified.Size = New System.Drawing.Size(114, 20)
        Me.TextBox_Demo1_Verify_IsVerified.TabIndex = 2
        '
        'Label110
        '
        Me.Label110.AutoSize = True
        Me.Label110.ForeColor = System.Drawing.Color.Black
        Me.Label110.Location = New System.Drawing.Point(3, 6)
        Me.Label110.Name = "Label110"
        Me.Label110.Size = New System.Drawing.Size(58, 13)
        Me.Label110.TabIndex = 0
        Me.Label110.Text = "Authentic?"
        '
        'Button68
        '
        Me.Button68.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button68.BackColor = System.Drawing.Color.LightGreen
        Me.Button68.Location = New System.Drawing.Point(483, 430)
        Me.Button68.Name = "Button68"
        Me.Button68.Size = New System.Drawing.Size(103, 44)
        Me.Button68.TabIndex = 46
        Me.Button68.Text = "Verify License File"
        Me.Button68.UseVisualStyleBackColor = False
        '
        'Panel109
        '
        Me.Panel109.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel109.Controls.Add(Me.TextBox_Demo1_Verify_ExtractedFingerprint)
        Me.Panel109.Controls.Add(Me.Label118)
        Me.Panel109.Location = New System.Drawing.Point(20, 220)
        Me.Panel109.Name = "Panel109"
        Me.Panel109.Size = New System.Drawing.Size(640, 25)
        Me.Panel109.TabIndex = 45
        '
        'TextBox_Demo1_Verify_ExtractedFingerprint
        '
        Me.TextBox_Demo1_Verify_ExtractedFingerprint.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_Demo1_Verify_ExtractedFingerprint.Location = New System.Drawing.Point(133, 3)
        Me.TextBox_Demo1_Verify_ExtractedFingerprint.Name = "TextBox_Demo1_Verify_ExtractedFingerprint"
        Me.TextBox_Demo1_Verify_ExtractedFingerprint.ReadOnly = True
        Me.TextBox_Demo1_Verify_ExtractedFingerprint.Size = New System.Drawing.Size(323, 20)
        Me.TextBox_Demo1_Verify_ExtractedFingerprint.TabIndex = 2
        '
        'Label118
        '
        Me.Label118.AutoSize = True
        Me.Label118.ForeColor = System.Drawing.Color.Black
        Me.Label118.Location = New System.Drawing.Point(3, 6)
        Me.Label118.Name = "Label118"
        Me.Label118.Size = New System.Drawing.Size(100, 13)
        Me.Label118.TabIndex = 0
        Me.Label118.Text = "Extracted Signature"
        '
        'Panel107
        '
        Me.Panel107.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel107.Controls.Add(Me.TextBox_Demo1_VerifyFingerprintPlusExpiryHash)
        Me.Panel107.Controls.Add(Me.Label114)
        Me.Panel107.Location = New System.Drawing.Point(20, 318)
        Me.Panel107.Name = "Panel107"
        Me.Panel107.Size = New System.Drawing.Size(640, 25)
        Me.Panel107.TabIndex = 44
        '
        'TextBox_Demo1_VerifyFingerprintPlusExpiryHash
        '
        Me.TextBox_Demo1_VerifyFingerprintPlusExpiryHash.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_Demo1_VerifyFingerprintPlusExpiryHash.Location = New System.Drawing.Point(133, 3)
        Me.TextBox_Demo1_VerifyFingerprintPlusExpiryHash.Name = "TextBox_Demo1_VerifyFingerprintPlusExpiryHash"
        Me.TextBox_Demo1_VerifyFingerprintPlusExpiryHash.ReadOnly = True
        Me.TextBox_Demo1_VerifyFingerprintPlusExpiryHash.Size = New System.Drawing.Size(323, 20)
        Me.TextBox_Demo1_VerifyFingerprintPlusExpiryHash.TabIndex = 1
        '
        'Label114
        '
        Me.Label114.AutoSize = True
        Me.Label114.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label114.Location = New System.Drawing.Point(3, 6)
        Me.Label114.Name = "Label114"
        Me.Label114.Size = New System.Drawing.Size(124, 13)
        Me.Label114.TabIndex = 0
        Me.Label114.Text = "Fingerprint + Expiry Hash"
        '
        'Panel108
        '
        Me.Panel108.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel108.Controls.Add(Me.TextBox_Demo1_VerifyFingerprintPlusExpiry)
        Me.Panel108.Controls.Add(Me.Label116)
        Me.Panel108.Location = New System.Drawing.Point(20, 291)
        Me.Panel108.Name = "Panel108"
        Me.Panel108.Size = New System.Drawing.Size(640, 25)
        Me.Panel108.TabIndex = 43
        '
        'TextBox_Demo1_VerifyFingerprintPlusExpiry
        '
        Me.TextBox_Demo1_VerifyFingerprintPlusExpiry.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_Demo1_VerifyFingerprintPlusExpiry.Location = New System.Drawing.Point(133, 3)
        Me.TextBox_Demo1_VerifyFingerprintPlusExpiry.Name = "TextBox_Demo1_VerifyFingerprintPlusExpiry"
        Me.TextBox_Demo1_VerifyFingerprintPlusExpiry.ReadOnly = True
        Me.TextBox_Demo1_VerifyFingerprintPlusExpiry.Size = New System.Drawing.Size(323, 20)
        Me.TextBox_Demo1_VerifyFingerprintPlusExpiry.TabIndex = 1
        '
        'Label116
        '
        Me.Label116.AutoSize = True
        Me.Label116.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label116.Location = New System.Drawing.Point(3, 6)
        Me.Label116.Name = "Label116"
        Me.Label116.Size = New System.Drawing.Size(99, 13)
        Me.Label116.TabIndex = 0
        Me.Label116.Text = "Fingerprint + Expiry:"
        '
        'Panel106
        '
        Me.Panel106.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel106.Controls.Add(Me.TextBox_Demo1_VerifyFingerprint)
        Me.Panel106.Controls.Add(Me.Label115)
        Me.Panel106.Location = New System.Drawing.Point(20, 264)
        Me.Panel106.Name = "Panel106"
        Me.Panel106.Size = New System.Drawing.Size(640, 25)
        Me.Panel106.TabIndex = 42
        '
        'TextBox_Demo1_VerifyFingerprint
        '
        Me.TextBox_Demo1_VerifyFingerprint.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_Demo1_VerifyFingerprint.Location = New System.Drawing.Point(136, 3)
        Me.TextBox_Demo1_VerifyFingerprint.Name = "TextBox_Demo1_VerifyFingerprint"
        Me.TextBox_Demo1_VerifyFingerprint.ReadOnly = True
        Me.TextBox_Demo1_VerifyFingerprint.Size = New System.Drawing.Size(320, 20)
        Me.TextBox_Demo1_VerifyFingerprint.TabIndex = 2
        '
        'Label115
        '
        Me.Label115.AutoSize = True
        Me.Label115.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label115.Location = New System.Drawing.Point(3, 6)
        Me.Label115.Name = "Label115"
        Me.Label115.Size = New System.Drawing.Size(96, 13)
        Me.Label115.TabIndex = 0
        Me.Label115.Text = "Re-Gen Fingerprint"
        '
        'Panel105
        '
        Me.Panel105.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel105.Controls.Add(Me.Label_Demo1_Verify_ExtractedExpiryInLocalTime)
        Me.Panel105.Controls.Add(Me.Label113)
        Me.Panel105.Location = New System.Drawing.Point(20, 193)
        Me.Panel105.Name = "Panel105"
        Me.Panel105.Size = New System.Drawing.Size(640, 25)
        Me.Panel105.TabIndex = 41
        '
        'Label_Demo1_Verify_ExtractedExpiryInLocalTime
        '
        Me.Label_Demo1_Verify_ExtractedExpiryInLocalTime.AutoSize = True
        Me.Label_Demo1_Verify_ExtractedExpiryInLocalTime.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Label_Demo1_Verify_ExtractedExpiryInLocalTime.Location = New System.Drawing.Point(133, 6)
        Me.Label_Demo1_Verify_ExtractedExpiryInLocalTime.Name = "Label_Demo1_Verify_ExtractedExpiryInLocalTime"
        Me.Label_Demo1_Verify_ExtractedExpiryInLocalTime.Size = New System.Drawing.Size(117, 13)
        Me.Label_Demo1_Verify_ExtractedExpiryInLocalTime.TabIndex = 15
        Me.Label_Demo1_Verify_ExtractedExpiryInLocalTime.Text = "EXTRACTED_EXPIRY"
        '
        'Label113
        '
        Me.Label113.AutoSize = True
        Me.Label113.ForeColor = System.Drawing.Color.Black
        Me.Label113.Location = New System.Drawing.Point(3, 6)
        Me.Label113.Name = "Label113"
        Me.Label113.Size = New System.Drawing.Size(101, 13)
        Me.Label113.TabIndex = 0
        Me.Label113.Text = "Expiry in Local Time"
        '
        'Panel104
        '
        Me.Panel104.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel104.Controls.Add(Me.Label_Demo1_Verify_ExtractedExpiry)
        Me.Panel104.Controls.Add(Me.Label111)
        Me.Panel104.Location = New System.Drawing.Point(20, 166)
        Me.Panel104.Name = "Panel104"
        Me.Panel104.Size = New System.Drawing.Size(640, 25)
        Me.Panel104.TabIndex = 40
        '
        'Label_Demo1_Verify_ExtractedExpiry
        '
        Me.Label_Demo1_Verify_ExtractedExpiry.AutoSize = True
        Me.Label_Demo1_Verify_ExtractedExpiry.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Label_Demo1_Verify_ExtractedExpiry.Location = New System.Drawing.Point(133, 6)
        Me.Label_Demo1_Verify_ExtractedExpiry.Name = "Label_Demo1_Verify_ExtractedExpiry"
        Me.Label_Demo1_Verify_ExtractedExpiry.Size = New System.Drawing.Size(117, 13)
        Me.Label_Demo1_Verify_ExtractedExpiry.TabIndex = 15
        Me.Label_Demo1_Verify_ExtractedExpiry.Text = "EXTRACTED_EXPIRY"
        '
        'Label111
        '
        Me.Label111.AutoSize = True
        Me.Label111.ForeColor = System.Drawing.Color.Black
        Me.Label111.Location = New System.Drawing.Point(3, 6)
        Me.Label111.Name = "Label111"
        Me.Label111.Size = New System.Drawing.Size(108, 13)
        Me.Label111.TabIndex = 0
        Me.Label111.Text = "Extracted Expiry UTC"
        '
        'Label109
        '
        Me.Label109.AutoSize = True
        Me.Label109.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label109.Location = New System.Drawing.Point(18, 83)
        Me.Label109.Name = "Label109"
        Me.Label109.Size = New System.Drawing.Size(551, 13)
        Me.Label109.TabIndex = 39
        Me.Label109.Text = "Expiry gets converted to UTC, combined with the fingerprint, then hashed, so it c" &
    "an be verified agasint the signature"
        '
        'Label108
        '
        Me.Label108.AutoSize = True
        Me.Label108.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label108.Location = New System.Drawing.Point(18, 66)
        Me.Label108.Name = "Label108"
        Me.Label108.Size = New System.Drawing.Size(484, 13)
        Me.Label108.TabIndex = 38
        Me.Label108.Text = "Fingerprint will be gathered automatically based on the same characterisitcs chos" &
    "en during generation"
        '
        'Label107
        '
        Me.Label107.AutoSize = True
        Me.Label107.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label107.Location = New System.Drawing.Point(18, 49)
        Me.Label107.Name = "Label107"
        Me.Label107.Size = New System.Drawing.Size(90, 13)
        Me.Label107.TabIndex = 37
        Me.Label107.Text = "Load the .LIC file."
        '
        'Label106
        '
        Me.Label106.AutoSize = True
        Me.Label106.ForeColor = System.Drawing.Color.Red
        Me.Label106.Location = New System.Drawing.Point(18, 32)
        Me.Label106.Name = "Label106"
        Me.Label106.Size = New System.Drawing.Size(329, 13)
        Me.Label106.TabIndex = 36
        Me.Label106.Text = "ASSUMING YOU DO THIS ON THE MACHINE ITS INTEDED FOR"
        '
        'Panel103
        '
        Me.Panel103.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel103.Controls.Add(Me.Button_Demo1_LoadedLICFileReload)
        Me.Panel103.Controls.Add(Me.Button_Demo1_LoadedLICFileClose)
        Me.Panel103.Controls.Add(Me.Button_Demo1_LoadedLICFileBrowse)
        Me.Panel103.Controls.Add(Me.TextBox_Demo1_LoadedLICFile)
        Me.Panel103.Controls.Add(Me.Label98)
        Me.Panel103.Location = New System.Drawing.Point(20, 121)
        Me.Panel103.Name = "Panel103"
        Me.Panel103.Size = New System.Drawing.Size(640, 25)
        Me.Panel103.TabIndex = 35
        '
        'Button_Demo1_LoadedLICFileReload
        '
        Me.Button_Demo1_LoadedLICFileReload.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_Demo1_LoadedLICFileReload.BackColor = System.Drawing.Color.Transparent
        Me.Button_Demo1_LoadedLICFileReload.Location = New System.Drawing.Point(524, 1)
        Me.Button_Demo1_LoadedLICFileReload.Name = "Button_Demo1_LoadedLICFileReload"
        Me.Button_Demo1_LoadedLICFileReload.Size = New System.Drawing.Size(61, 23)
        Me.Button_Demo1_LoadedLICFileReload.TabIndex = 28
        Me.Button_Demo1_LoadedLICFileReload.Text = "Reload"
        Me.Button_Demo1_LoadedLICFileReload.UseVisualStyleBackColor = False
        '
        'Button_Demo1_LoadedLICFileClose
        '
        Me.Button_Demo1_LoadedLICFileClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_Demo1_LoadedLICFileClose.BackColor = System.Drawing.Color.LightCoral
        Me.Button_Demo1_LoadedLICFileClose.ForeColor = System.Drawing.Color.Black
        Me.Button_Demo1_LoadedLICFileClose.Location = New System.Drawing.Point(586, 1)
        Me.Button_Demo1_LoadedLICFileClose.Name = "Button_Demo1_LoadedLICFileClose"
        Me.Button_Demo1_LoadedLICFileClose.Size = New System.Drawing.Size(54, 23)
        Me.Button_Demo1_LoadedLICFileClose.TabIndex = 27
        Me.Button_Demo1_LoadedLICFileClose.Text = "Close"
        Me.Button_Demo1_LoadedLICFileClose.UseVisualStyleBackColor = False
        '
        'Button_Demo1_LoadedLICFileBrowse
        '
        Me.Button_Demo1_LoadedLICFileBrowse.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_Demo1_LoadedLICFileBrowse.BackColor = System.Drawing.Color.Transparent
        Me.Button_Demo1_LoadedLICFileBrowse.Location = New System.Drawing.Point(462, 1)
        Me.Button_Demo1_LoadedLICFileBrowse.Name = "Button_Demo1_LoadedLICFileBrowse"
        Me.Button_Demo1_LoadedLICFileBrowse.Size = New System.Drawing.Size(61, 23)
        Me.Button_Demo1_LoadedLICFileBrowse.TabIndex = 26
        Me.Button_Demo1_LoadedLICFileBrowse.Text = "Browse"
        Me.Button_Demo1_LoadedLICFileBrowse.UseVisualStyleBackColor = False
        '
        'TextBox_Demo1_LoadedLICFile
        '
        Me.TextBox_Demo1_LoadedLICFile.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_Demo1_LoadedLICFile.Location = New System.Drawing.Point(136, 3)
        Me.TextBox_Demo1_LoadedLICFile.Name = "TextBox_Demo1_LoadedLICFile"
        Me.TextBox_Demo1_LoadedLICFile.ReadOnly = True
        Me.TextBox_Demo1_LoadedLICFile.Size = New System.Drawing.Size(320, 20)
        Me.TextBox_Demo1_LoadedLICFile.TabIndex = 1
        '
        'Label98
        '
        Me.Label98.AutoSize = True
        Me.Label98.ForeColor = System.Drawing.Color.Black
        Me.Label98.Location = New System.Drawing.Point(3, 6)
        Me.Label98.Name = "Label98"
        Me.Label98.Size = New System.Drawing.Size(72, 13)
        Me.Label98.TabIndex = 0
        Me.Label98.Text = "Load .LIC File"
        '
        'GroupBox5
        '
        Me.GroupBox5.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox5.BackColor = System.Drawing.Color.WhiteSmoke
        Me.GroupBox5.Controls.Add(Me.Panel94)
        Me.GroupBox5.Controls.Add(Me.Button59)
        Me.GroupBox5.Controls.Add(Me.Panel102)
        Me.GroupBox5.Controls.Add(Me.Panel101)
        Me.GroupBox5.Controls.Add(Me.Panel100)
        Me.GroupBox5.Controls.Add(Me.Panel99)
        Me.GroupBox5.Controls.Add(Me.Label100)
        Me.GroupBox5.Controls.Add(Me.Label99)
        Me.GroupBox5.Location = New System.Drawing.Point(12, 964)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(681, 350)
        Me.GroupBox5.TabIndex = 7
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Step 3 - Create License File"
        '
        'Panel94
        '
        Me.Panel94.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel94.Controls.Add(Me.Label_Demo1_SetExpiryValueInUTC)
        Me.Panel94.Controls.Add(Me.Label105)
        Me.Panel94.Location = New System.Drawing.Point(23, 172)
        Me.Panel94.Name = "Panel94"
        Me.Panel94.Size = New System.Drawing.Size(641, 25)
        Me.Panel94.TabIndex = 38
        '
        'Label_Demo1_SetExpiryValueInUTC
        '
        Me.Label_Demo1_SetExpiryValueInUTC.AutoSize = True
        Me.Label_Demo1_SetExpiryValueInUTC.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Label_Demo1_SetExpiryValueInUTC.Location = New System.Drawing.Point(130, 6)
        Me.Label_Demo1_SetExpiryValueInUTC.Name = "Label_Demo1_SetExpiryValueInUTC"
        Me.Label_Demo1_SetExpiryValueInUTC.Size = New System.Drawing.Size(73, 13)
        Me.Label_Demo1_SetExpiryValueInUTC.TabIndex = 15
        Me.Label_Demo1_SetExpiryValueInUTC.Text = "SET_EXPIRY"
        '
        'Label105
        '
        Me.Label105.AutoSize = True
        Me.Label105.ForeColor = System.Drawing.Color.Black
        Me.Label105.Location = New System.Drawing.Point(3, 6)
        Me.Label105.Name = "Label105"
        Me.Label105.Size = New System.Drawing.Size(70, 13)
        Me.Label105.TabIndex = 0
        Me.Label105.Text = "Value in UTC"
        '
        'Button59
        '
        Me.Button59.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button59.BackColor = System.Drawing.Color.LightGreen
        Me.Button59.Location = New System.Drawing.Point(484, 289)
        Me.Button59.Name = "Button59"
        Me.Button59.Size = New System.Drawing.Size(103, 44)
        Me.Button59.TabIndex = 37
        Me.Button59.Text = "Build License File"
        Me.Button59.UseVisualStyleBackColor = False
        '
        'Panel102
        '
        Me.Panel102.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel102.Controls.Add(Me.Button58)
        Me.Panel102.Controls.Add(Me.TextBox_Demo1_Signature)
        Me.Panel102.Controls.Add(Me.Label104)
        Me.Panel102.Location = New System.Drawing.Point(23, 256)
        Me.Panel102.Name = "Panel102"
        Me.Panel102.Size = New System.Drawing.Size(641, 25)
        Me.Panel102.TabIndex = 36
        '
        'Button58
        '
        Me.Button58.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button58.BackColor = System.Drawing.Color.LightGreen
        Me.Button58.Location = New System.Drawing.Point(577, 1)
        Me.Button58.Name = "Button58"
        Me.Button58.Size = New System.Drawing.Size(61, 23)
        Me.Button58.TabIndex = 25
        Me.Button58.Text = "Sign"
        Me.Button58.UseVisualStyleBackColor = False
        '
        'TextBox_Demo1_Signature
        '
        Me.TextBox_Demo1_Signature.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_Demo1_Signature.Location = New System.Drawing.Point(133, 3)
        Me.TextBox_Demo1_Signature.Name = "TextBox_Demo1_Signature"
        Me.TextBox_Demo1_Signature.Size = New System.Drawing.Size(431, 20)
        Me.TextBox_Demo1_Signature.TabIndex = 1
        '
        'Label104
        '
        Me.Label104.AutoSize = True
        Me.Label104.Location = New System.Drawing.Point(3, 6)
        Me.Label104.Name = "Label104"
        Me.Label104.Size = New System.Drawing.Size(55, 13)
        Me.Label104.TabIndex = 0
        Me.Label104.Text = "Signature:"
        '
        'Panel101
        '
        Me.Panel101.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel101.Controls.Add(Me.Button61)
        Me.Panel101.Controls.Add(Me.TextBox_Demo1_FingerprintPlusExpiryHash)
        Me.Panel101.Controls.Add(Me.Label103)
        Me.Panel101.Location = New System.Drawing.Point(23, 228)
        Me.Panel101.Name = "Panel101"
        Me.Panel101.Size = New System.Drawing.Size(641, 25)
        Me.Panel101.TabIndex = 35
        '
        'Button61
        '
        Me.Button61.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button61.BackColor = System.Drawing.Color.Transparent
        Me.Button61.Location = New System.Drawing.Point(577, 2)
        Me.Button61.Name = "Button61"
        Me.Button61.Size = New System.Drawing.Size(61, 23)
        Me.Button61.TabIndex = 26
        Me.Button61.Text = "Get Hash"
        Me.Button61.UseVisualStyleBackColor = False
        '
        'TextBox_Demo1_FingerprintPlusExpiryHash
        '
        Me.TextBox_Demo1_FingerprintPlusExpiryHash.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_Demo1_FingerprintPlusExpiryHash.Location = New System.Drawing.Point(133, 3)
        Me.TextBox_Demo1_FingerprintPlusExpiryHash.Name = "TextBox_Demo1_FingerprintPlusExpiryHash"
        Me.TextBox_Demo1_FingerprintPlusExpiryHash.ReadOnly = True
        Me.TextBox_Demo1_FingerprintPlusExpiryHash.Size = New System.Drawing.Size(431, 20)
        Me.TextBox_Demo1_FingerprintPlusExpiryHash.TabIndex = 1
        '
        'Label103
        '
        Me.Label103.AutoSize = True
        Me.Label103.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label103.Location = New System.Drawing.Point(3, 6)
        Me.Label103.Name = "Label103"
        Me.Label103.Size = New System.Drawing.Size(124, 13)
        Me.Label103.TabIndex = 0
        Me.Label103.Text = "Fingerprint + Expiry Hash"
        '
        'Panel100
        '
        Me.Panel100.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel100.Controls.Add(Me.Button60)
        Me.Panel100.Controls.Add(Me.TextBox_Demo1_FingerprintPlusExpiry)
        Me.Panel100.Controls.Add(Me.Label102)
        Me.Panel100.Location = New System.Drawing.Point(23, 200)
        Me.Panel100.Name = "Panel100"
        Me.Panel100.Size = New System.Drawing.Size(641, 25)
        Me.Panel100.TabIndex = 34
        '
        'Button60
        '
        Me.Button60.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button60.BackColor = System.Drawing.Color.Transparent
        Me.Button60.Location = New System.Drawing.Point(577, -1)
        Me.Button60.Name = "Button60"
        Me.Button60.Size = New System.Drawing.Size(61, 23)
        Me.Button60.TabIndex = 26
        Me.Button60.Text = "Get Data"
        Me.Button60.UseVisualStyleBackColor = False
        '
        'TextBox_Demo1_FingerprintPlusExpiry
        '
        Me.TextBox_Demo1_FingerprintPlusExpiry.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_Demo1_FingerprintPlusExpiry.Location = New System.Drawing.Point(133, 3)
        Me.TextBox_Demo1_FingerprintPlusExpiry.Name = "TextBox_Demo1_FingerprintPlusExpiry"
        Me.TextBox_Demo1_FingerprintPlusExpiry.ReadOnly = True
        Me.TextBox_Demo1_FingerprintPlusExpiry.Size = New System.Drawing.Size(431, 20)
        Me.TextBox_Demo1_FingerprintPlusExpiry.TabIndex = 1
        '
        'Label102
        '
        Me.Label102.AutoSize = True
        Me.Label102.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label102.Location = New System.Drawing.Point(3, 6)
        Me.Label102.Name = "Label102"
        Me.Label102.Size = New System.Drawing.Size(99, 13)
        Me.Label102.TabIndex = 0
        Me.Label102.Text = "Fingerprint + Expiry:"
        '
        'Panel99
        '
        Me.Panel99.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel99.Controls.Add(Me.CheckBox12)
        Me.Panel99.Controls.Add(Me.Label97)
        Me.Panel99.Controls.Add(Me.Label_Demo1_SetExpiryValue)
        Me.Panel99.Controls.Add(Me.CheckBox15)
        Me.Panel99.Controls.Add(Me.CheckBox14)
        Me.Panel99.Controls.Add(Me.CheckBox13)
        Me.Panel99.Controls.Add(Me.CheckBox11)
        Me.Panel99.Controls.Add(Me.CheckBox10)
        Me.Panel99.Controls.Add(Me.CheckBox9)
        Me.Panel99.Controls.Add(Me.CheckBox8)
        Me.Panel99.Controls.Add(Me.CheckBox7)
        Me.Panel99.Controls.Add(Me.DateTimePicker1)
        Me.Panel99.Controls.Add(Me.Label101)
        Me.Panel99.Location = New System.Drawing.Point(23, 82)
        Me.Panel99.Name = "Panel99"
        Me.Panel99.Size = New System.Drawing.Size(641, 89)
        Me.Panel99.TabIndex = 33
        '
        'CheckBox12
        '
        Me.CheckBox12.Appearance = System.Windows.Forms.Appearance.Button
        Me.CheckBox12.AutoSize = True
        Me.CheckBox12.Location = New System.Drawing.Point(230, 3)
        Me.CheckBox12.Name = "CheckBox12"
        Me.CheckBox12.Size = New System.Drawing.Size(43, 23)
        Me.CheckBox12.TabIndex = 15
        Me.CheckBox12.Text = "1 Min"
        Me.CheckBox12.UseVisualStyleBackColor = True
        '
        'Label97
        '
        Me.Label97.AutoSize = True
        Me.Label97.Location = New System.Drawing.Point(3, 70)
        Me.Label97.Name = "Label97"
        Me.Label97.Size = New System.Drawing.Size(100, 13)
        Me.Label97.TabIndex = 14
        Me.Label97.Text = "Value in Local Time"
        '
        'Label_Demo1_SetExpiryValue
        '
        Me.Label_Demo1_SetExpiryValue.AutoSize = True
        Me.Label_Demo1_SetExpiryValue.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Label_Demo1_SetExpiryValue.Location = New System.Drawing.Point(130, 70)
        Me.Label_Demo1_SetExpiryValue.Name = "Label_Demo1_SetExpiryValue"
        Me.Label_Demo1_SetExpiryValue.Size = New System.Drawing.Size(73, 13)
        Me.Label_Demo1_SetExpiryValue.TabIndex = 13
        Me.Label_Demo1_SetExpiryValue.Text = "SET_EXPIRY"
        '
        'CheckBox15
        '
        Me.CheckBox15.Appearance = System.Windows.Forms.Appearance.Button
        Me.CheckBox15.AutoSize = True
        Me.CheckBox15.Location = New System.Drawing.Point(332, 3)
        Me.CheckBox15.Name = "CheckBox15"
        Me.CheckBox15.Size = New System.Drawing.Size(49, 23)
        Me.CheckBox15.TabIndex = 12
        Me.CheckBox15.Text = "1 Hour"
        Me.CheckBox15.UseVisualStyleBackColor = True
        '
        'CheckBox14
        '
        Me.CheckBox14.Appearance = System.Windows.Forms.Appearance.Button
        Me.CheckBox14.AutoSize = True
        Me.CheckBox14.Location = New System.Drawing.Point(425, 32)
        Me.CheckBox14.Name = "CheckBox14"
        Me.CheckBox14.Size = New System.Drawing.Size(48, 23)
        Me.CheckBox14.TabIndex = 11
        Me.CheckBox14.Text = "1 Year"
        Me.CheckBox14.UseVisualStyleBackColor = True
        '
        'CheckBox13
        '
        Me.CheckBox13.Appearance = System.Windows.Forms.Appearance.Button
        Me.CheckBox13.AutoSize = True
        Me.CheckBox13.Location = New System.Drawing.Point(359, 32)
        Me.CheckBox13.Name = "CheckBox13"
        Me.CheckBox13.Size = New System.Drawing.Size(61, 23)
        Me.CheckBox13.TabIndex = 10
        Me.CheckBox13.Text = "6 Months"
        Me.CheckBox13.UseVisualStyleBackColor = True
        '
        'CheckBox11
        '
        Me.CheckBox11.Appearance = System.Windows.Forms.Appearance.Button
        Me.CheckBox11.AutoSize = True
        Me.CheckBox11.Location = New System.Drawing.Point(292, 32)
        Me.CheckBox11.Name = "CheckBox11"
        Me.CheckBox11.Size = New System.Drawing.Size(61, 23)
        Me.CheckBox11.TabIndex = 8
        Me.CheckBox11.Text = "3 Months"
        Me.CheckBox11.UseVisualStyleBackColor = True
        '
        'CheckBox10
        '
        Me.CheckBox10.Appearance = System.Windows.Forms.Appearance.Button
        Me.CheckBox10.AutoSize = True
        Me.CheckBox10.Location = New System.Drawing.Point(230, 32)
        Me.CheckBox10.Name = "CheckBox10"
        Me.CheckBox10.Size = New System.Drawing.Size(56, 23)
        Me.CheckBox10.TabIndex = 7
        Me.CheckBox10.Text = "1 Month"
        Me.CheckBox10.UseVisualStyleBackColor = True
        '
        'CheckBox9
        '
        Me.CheckBox9.Appearance = System.Windows.Forms.Appearance.Button
        Me.CheckBox9.AutoSize = True
        Me.CheckBox9.Location = New System.Drawing.Point(438, 3)
        Me.CheckBox9.Name = "CheckBox9"
        Me.CheckBox9.Size = New System.Drawing.Size(55, 23)
        Me.CheckBox9.TabIndex = 6
        Me.CheckBox9.Text = "1 Week"
        Me.CheckBox9.UseVisualStyleBackColor = True
        '
        'CheckBox8
        '
        Me.CheckBox8.Appearance = System.Windows.Forms.Appearance.Button
        Me.CheckBox8.AutoSize = True
        Me.CheckBox8.Location = New System.Drawing.Point(387, 3)
        Me.CheckBox8.Name = "CheckBox8"
        Me.CheckBox8.Size = New System.Drawing.Size(45, 23)
        Me.CheckBox8.TabIndex = 5
        Me.CheckBox8.Text = "1 Day"
        Me.CheckBox8.UseVisualStyleBackColor = True
        '
        'CheckBox7
        '
        Me.CheckBox7.Appearance = System.Windows.Forms.Appearance.Button
        Me.CheckBox7.AutoSize = True
        Me.CheckBox7.Location = New System.Drawing.Point(279, 3)
        Me.CheckBox7.Name = "CheckBox7"
        Me.CheckBox7.Size = New System.Drawing.Size(48, 23)
        Me.CheckBox7.TabIndex = 4
        Me.CheckBox7.Text = "5 Mins"
        Me.CheckBox7.UseVisualStyleBackColor = True
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(92, 3)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(132, 20)
        Me.DateTimePicker1.TabIndex = 1
        '
        'Label101
        '
        Me.Label101.AutoSize = True
        Me.Label101.Location = New System.Drawing.Point(3, 6)
        Me.Label101.Name = "Label101"
        Me.Label101.Size = New System.Drawing.Size(83, 13)
        Me.Label101.TabIndex = 0
        Me.Label101.Text = "Set Expiry Date:"
        '
        'Label100
        '
        Me.Label100.AutoSize = True
        Me.Label100.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label100.Location = New System.Drawing.Point(23, 49)
        Me.Label100.Name = "Label100"
        Me.Label100.Size = New System.Drawing.Size(331, 13)
        Me.Label100.TabIndex = 32
        Me.Label100.Text = "It should contain the Expiry date for example, as well as the signature"
        '
        'Label99
        '
        Me.Label99.AutoSize = True
        Me.Label99.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label99.Location = New System.Drawing.Point(23, 32)
        Me.Label99.Name = "Label99"
        Me.Label99.Size = New System.Drawing.Size(365, 13)
        Me.Label99.TabIndex = 31
        Me.Label99.Text = "Create a license file (.lic) by adding key value pairs to build a JSON structure"
        '
        'Label96
        '
        Me.Label96.AutoSize = True
        Me.Label96.ForeColor = System.Drawing.Color.Red
        Me.Label96.Location = New System.Drawing.Point(104, 68)
        Me.Label96.Name = "Label96"
        Me.Label96.Size = New System.Drawing.Size(337, 13)
        Me.Label96.TabIndex = 6
        Me.Label96.Text = "also doesn't transfer if motherboard or drive are replaced, or upgraded."
        '
        'Label88
        '
        Me.Label88.AutoSize = True
        Me.Label88.ForeColor = System.Drawing.Color.Red
        Me.Label88.Location = New System.Drawing.Point(9, 51)
        Me.Label88.Name = "Label88"
        Me.Label88.Size = New System.Drawing.Size(651, 13)
        Me.Label88.TabIndex = 5
        Me.Label88.Text = "CONSIDERATION: user can rollback system clock, so check NTP, or internet time, or" &
    " windows log file timestamps, think outside the box."
        '
        'Panel90
        '
        Me.Panel90.Location = New System.Drawing.Point(18, 1918)
        Me.Panel90.Name = "Panel90"
        Me.Panel90.Size = New System.Drawing.Size(200, 140)
        Me.Panel90.TabIndex = 4
        '
        'GroupBox4
        '
        Me.GroupBox4.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox4.BackColor = System.Drawing.Color.WhiteSmoke
        Me.GroupBox4.Controls.Add(Me.Label93)
        Me.GroupBox4.Controls.Add(Me.Button_Demo1_GenerateKeys)
        Me.GroupBox4.Controls.Add(Me.Panel91)
        Me.GroupBox4.Location = New System.Drawing.Point(12, 586)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(681, 268)
        Me.GroupBox4.TabIndex = 3
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Step 2 - Generate RSA Public and Private Key Pair"
        '
        'Label93
        '
        Me.Label93.AutoSize = True
        Me.Label93.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label93.Location = New System.Drawing.Point(17, 31)
        Me.Label93.Name = "Label93"
        Me.Label93.Size = New System.Drawing.Size(259, 13)
        Me.Label93.TabIndex = 13
        Me.Label93.Text = "Generate a new pair of keys, or select an existing pair"
        '
        'Button_Demo1_GenerateKeys
        '
        Me.Button_Demo1_GenerateKeys.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_Demo1_GenerateKeys.BackColor = System.Drawing.Color.PaleGreen
        Me.Button_Demo1_GenerateKeys.Location = New System.Drawing.Point(561, 216)
        Me.Button_Demo1_GenerateKeys.Name = "Button_Demo1_GenerateKeys"
        Me.Button_Demo1_GenerateKeys.Size = New System.Drawing.Size(93, 33)
        Me.Button_Demo1_GenerateKeys.TabIndex = 11
        Me.Button_Demo1_GenerateKeys.Text = "Generate Keys"
        Me.Button_Demo1_GenerateKeys.UseVisualStyleBackColor = False
        '
        'Panel91
        '
        Me.Panel91.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel91.Controls.Add(Me.Panel92)
        Me.Panel91.Controls.Add(Me.Panel93)
        Me.Panel91.Controls.Add(Me.Panel95)
        Me.Panel91.Controls.Add(Me.Panel96)
        Me.Panel91.Controls.Add(Me.Panel97)
        Me.Panel91.Controls.Add(Me.Panel98)
        Me.Panel91.Location = New System.Drawing.Point(17, 58)
        Me.Panel91.Name = "Panel91"
        Me.Panel91.Size = New System.Drawing.Size(644, 156)
        Me.Panel91.TabIndex = 12
        '
        'Panel92
        '
        Me.Panel92.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel92.Controls.Add(Me.Label95)
        Me.Panel92.Controls.Add(Me.TextBox_Demo1_Salt)
        Me.Panel92.Location = New System.Drawing.Point(3, 58)
        Me.Panel92.Name = "Panel92"
        Me.Panel92.Size = New System.Drawing.Size(633, 20)
        Me.Panel92.TabIndex = 6
        '
        'Label95
        '
        Me.Label95.AutoSize = True
        Me.Label95.Location = New System.Drawing.Point(3, 3)
        Me.Label95.Name = "Label95"
        Me.Label95.Size = New System.Drawing.Size(90, 13)
        Me.Label95.TabIndex = 2
        Me.Label95.Text = "Salt (if applicable)"
        '
        'TextBox_Demo1_Salt
        '
        Me.TextBox_Demo1_Salt.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_Demo1_Salt.Location = New System.Drawing.Point(117, 0)
        Me.TextBox_Demo1_Salt.Name = "TextBox_Demo1_Salt"
        Me.TextBox_Demo1_Salt.ReadOnly = True
        Me.TextBox_Demo1_Salt.Size = New System.Drawing.Size(430, 20)
        Me.TextBox_Demo1_Salt.TabIndex = 1
        '
        'Panel93
        '
        Me.Panel93.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel93.Controls.Add(Me.Label94)
        Me.Panel93.Controls.Add(Me.TextBox_Demo1_Seed)
        Me.Panel93.Location = New System.Drawing.Point(3, 36)
        Me.Panel93.Name = "Panel93"
        Me.Panel93.Size = New System.Drawing.Size(633, 20)
        Me.Panel93.TabIndex = 5
        '
        'Label94
        '
        Me.Label94.AutoSize = True
        Me.Label94.Location = New System.Drawing.Point(3, 3)
        Me.Label94.Name = "Label94"
        Me.Label94.Size = New System.Drawing.Size(32, 13)
        Me.Label94.TabIndex = 2
        Me.Label94.Text = "Seed"
        '
        'TextBox_Demo1_Seed
        '
        Me.TextBox_Demo1_Seed.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_Demo1_Seed.Location = New System.Drawing.Point(117, 0)
        Me.TextBox_Demo1_Seed.Name = "TextBox_Demo1_Seed"
        Me.TextBox_Demo1_Seed.ReadOnly = True
        Me.TextBox_Demo1_Seed.Size = New System.Drawing.Size(430, 20)
        Me.TextBox_Demo1_Seed.TabIndex = 1
        '
        'Panel95
        '
        Me.Panel95.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel95.Controls.Add(Me.Button_Demo1_DeletePairs)
        Me.Panel95.Controls.Add(Me.ComboBox_Demo1_PreviousPairs)
        Me.Panel95.Controls.Add(Me.Label89)
        Me.Panel95.Location = New System.Drawing.Point(3, 3)
        Me.Panel95.Name = "Panel95"
        Me.Panel95.Size = New System.Drawing.Size(633, 26)
        Me.Panel95.TabIndex = 3
        '
        'Button_Demo1_DeletePairs
        '
        Me.Button_Demo1_DeletePairs.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_Demo1_DeletePairs.Location = New System.Drawing.Point(553, 0)
        Me.Button_Demo1_DeletePairs.Name = "Button_Demo1_DeletePairs"
        Me.Button_Demo1_DeletePairs.Size = New System.Drawing.Size(80, 23)
        Me.Button_Demo1_DeletePairs.TabIndex = 23
        Me.Button_Demo1_DeletePairs.Text = "Delete Pairs"
        Me.Button_Demo1_DeletePairs.UseVisualStyleBackColor = True
        Me.Button_Demo1_DeletePairs.Visible = False
        '
        'ComboBox_Demo1_PreviousPairs
        '
        Me.ComboBox_Demo1_PreviousPairs.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ComboBox_Demo1_PreviousPairs.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_Demo1_PreviousPairs.FormattingEnabled = True
        Me.ComboBox_Demo1_PreviousPairs.Location = New System.Drawing.Point(117, 0)
        Me.ComboBox_Demo1_PreviousPairs.Name = "ComboBox_Demo1_PreviousPairs"
        Me.ComboBox_Demo1_PreviousPairs.Size = New System.Drawing.Size(430, 21)
        Me.ComboBox_Demo1_PreviousPairs.TabIndex = 1
        '
        'Label89
        '
        Me.Label89.AutoSize = True
        Me.Label89.Location = New System.Drawing.Point(3, 3)
        Me.Label89.Name = "Label89"
        Me.Label89.Size = New System.Drawing.Size(74, 13)
        Me.Label89.TabIndex = 0
        Me.Label89.Text = "Previous Pairs"
        '
        'Panel96
        '
        Me.Panel96.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel96.Controls.Add(Me.TextBox_Demo1_KeySize)
        Me.Panel96.Controls.Add(Me.Label90)
        Me.Panel96.Location = New System.Drawing.Point(3, 128)
        Me.Panel96.Name = "Panel96"
        Me.Panel96.Size = New System.Drawing.Size(633, 24)
        Me.Panel96.TabIndex = 2
        '
        'TextBox_Demo1_KeySize
        '
        Me.TextBox_Demo1_KeySize.Location = New System.Drawing.Point(117, 2)
        Me.TextBox_Demo1_KeySize.Name = "TextBox_Demo1_KeySize"
        Me.TextBox_Demo1_KeySize.ReadOnly = True
        Me.TextBox_Demo1_KeySize.Size = New System.Drawing.Size(77, 20)
        Me.TextBox_Demo1_KeySize.TabIndex = 2
        '
        'Label90
        '
        Me.Label90.AutoSize = True
        Me.Label90.Location = New System.Drawing.Point(3, 3)
        Me.Label90.Name = "Label90"
        Me.Label90.Size = New System.Drawing.Size(48, 13)
        Me.Label90.TabIndex = 0
        Me.Label90.Text = "Key Size"
        '
        'Panel97
        '
        Me.Panel97.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel97.Controls.Add(Me.Button_Demo1_PublicKeyCopy)
        Me.Panel97.Controls.Add(Me.TextBox_Demo1_PublicKey)
        Me.Panel97.Controls.Add(Me.Label91)
        Me.Panel97.Location = New System.Drawing.Point(3, 80)
        Me.Panel97.Name = "Panel97"
        Me.Panel97.Size = New System.Drawing.Size(633, 22)
        Me.Panel97.TabIndex = 1
        '
        'Button_Demo1_PublicKeyCopy
        '
        Me.Button_Demo1_PublicKeyCopy.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_Demo1_PublicKeyCopy.Location = New System.Drawing.Point(553, -1)
        Me.Button_Demo1_PublicKeyCopy.Name = "Button_Demo1_PublicKeyCopy"
        Me.Button_Demo1_PublicKeyCopy.Size = New System.Drawing.Size(80, 23)
        Me.Button_Demo1_PublicKeyCopy.TabIndex = 22
        Me.Button_Demo1_PublicKeyCopy.Text = "Copy Key"
        Me.Button_Demo1_PublicKeyCopy.UseVisualStyleBackColor = True
        '
        'TextBox_Demo1_PublicKey
        '
        Me.TextBox_Demo1_PublicKey.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_Demo1_PublicKey.Location = New System.Drawing.Point(117, 0)
        Me.TextBox_Demo1_PublicKey.Name = "TextBox_Demo1_PublicKey"
        Me.TextBox_Demo1_PublicKey.ReadOnly = True
        Me.TextBox_Demo1_PublicKey.Size = New System.Drawing.Size(430, 20)
        Me.TextBox_Demo1_PublicKey.TabIndex = 1
        '
        'Label91
        '
        Me.Label91.AutoSize = True
        Me.Label91.Location = New System.Drawing.Point(3, 3)
        Me.Label91.Name = "Label91"
        Me.Label91.Size = New System.Drawing.Size(57, 13)
        Me.Label91.TabIndex = 0
        Me.Label91.Text = "Public Key"
        '
        'Panel98
        '
        Me.Panel98.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel98.Controls.Add(Me.Button_Demo1_PrivateKeyCopy)
        Me.Panel98.Controls.Add(Me.TextBox_Demo1_PrivateKey)
        Me.Panel98.Controls.Add(Me.Label92)
        Me.Panel98.Location = New System.Drawing.Point(3, 103)
        Me.Panel98.Name = "Panel98"
        Me.Panel98.Size = New System.Drawing.Size(633, 24)
        Me.Panel98.TabIndex = 0
        '
        'Button_Demo1_PrivateKeyCopy
        '
        Me.Button_Demo1_PrivateKeyCopy.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_Demo1_PrivateKeyCopy.Location = New System.Drawing.Point(553, 0)
        Me.Button_Demo1_PrivateKeyCopy.Name = "Button_Demo1_PrivateKeyCopy"
        Me.Button_Demo1_PrivateKeyCopy.Size = New System.Drawing.Size(80, 23)
        Me.Button_Demo1_PrivateKeyCopy.TabIndex = 23
        Me.Button_Demo1_PrivateKeyCopy.Text = "Copy Key"
        Me.Button_Demo1_PrivateKeyCopy.UseVisualStyleBackColor = True
        '
        'TextBox_Demo1_PrivateKey
        '
        Me.TextBox_Demo1_PrivateKey.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_Demo1_PrivateKey.Location = New System.Drawing.Point(117, 1)
        Me.TextBox_Demo1_PrivateKey.Name = "TextBox_Demo1_PrivateKey"
        Me.TextBox_Demo1_PrivateKey.ReadOnly = True
        Me.TextBox_Demo1_PrivateKey.Size = New System.Drawing.Size(430, 20)
        Me.TextBox_Demo1_PrivateKey.TabIndex = 1
        '
        'Label92
        '
        Me.Label92.AutoSize = True
        Me.Label92.Location = New System.Drawing.Point(3, 3)
        Me.Label92.Name = "Label92"
        Me.Label92.Size = New System.Drawing.Size(61, 13)
        Me.Label92.TabIndex = 0
        Me.Label92.Text = "Private Key"
        '
        'GroupBox3
        '
        Me.GroupBox3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox3.BackColor = System.Drawing.Color.WhiteSmoke
        Me.GroupBox3.Controls.Add(Me.CheckBox_Demo1_ShowConcatenatedData)
        Me.GroupBox3.Controls.Add(Me.Label87)
        Me.GroupBox3.Controls.Add(Me.Button_Demo1_GenerateFingerprint)
        Me.GroupBox3.Controls.Add(Me.TextBox_Demo1_Fingerprint)
        Me.GroupBox3.Controls.Add(Me.Label86)
        Me.GroupBox3.Controls.Add(Me.Label85)
        Me.GroupBox3.Controls.Add(Me.ListBox_Demo1_Characteristics)
        Me.GroupBox3.Controls.Add(Me.FlowLayoutPanel11)
        Me.GroupBox3.Controls.Add(Me.Label84)
        Me.GroupBox3.Controls.Add(Me.Label83)
        Me.GroupBox3.Location = New System.Drawing.Point(11, 149)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(687, 359)
        Me.GroupBox3.TabIndex = 2
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Step 1 - Getting Fingerprint"
        '
        'CheckBox_Demo1_ShowConcatenatedData
        '
        Me.CheckBox_Demo1_ShowConcatenatedData.AutoSize = True
        Me.CheckBox_Demo1_ShowConcatenatedData.Location = New System.Drawing.Point(484, 292)
        Me.CheckBox_Demo1_ShowConcatenatedData.Name = "CheckBox_Demo1_ShowConcatenatedData"
        Me.CheckBox_Demo1_ShowConcatenatedData.Size = New System.Drawing.Size(149, 17)
        Me.CheckBox_Demo1_ShowConcatenatedData.TabIndex = 13
        Me.CheckBox_Demo1_ShowConcatenatedData.Text = "Show Concatenated Data"
        Me.CheckBox_Demo1_ShowConcatenatedData.UseVisualStyleBackColor = True
        '
        'Label87
        '
        Me.Label87.AutoSize = True
        Me.Label87.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label87.Location = New System.Drawing.Point(21, 79)
        Me.Label87.Name = "Label87"
        Me.Label87.Size = New System.Drawing.Size(215, 13)
        Me.Label87.TabIndex = 12
        Me.Label87.Text = "Add characteristics to build a fingerprint from"
        '
        'Button_Demo1_GenerateFingerprint
        '
        Me.Button_Demo1_GenerateFingerprint.BackColor = System.Drawing.Color.LightGreen
        Me.Button_Demo1_GenerateFingerprint.Location = New System.Drawing.Point(22, 309)
        Me.Button_Demo1_GenerateFingerprint.Name = "Button_Demo1_GenerateFingerprint"
        Me.Button_Demo1_GenerateFingerprint.Size = New System.Drawing.Size(116, 31)
        Me.Button_Demo1_GenerateFingerprint.TabIndex = 11
        Me.Button_Demo1_GenerateFingerprint.Text = "Generate Fingerprint"
        Me.Button_Demo1_GenerateFingerprint.UseVisualStyleBackColor = False
        '
        'TextBox_Demo1_Fingerprint
        '
        Me.TextBox_Demo1_Fingerprint.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_Demo1_Fingerprint.Location = New System.Drawing.Point(144, 315)
        Me.TextBox_Demo1_Fingerprint.Name = "TextBox_Demo1_Fingerprint"
        Me.TextBox_Demo1_Fingerprint.Size = New System.Drawing.Size(516, 20)
        Me.TextBox_Demo1_Fingerprint.TabIndex = 10
        '
        'Label86
        '
        Me.Label86.AutoSize = True
        Me.Label86.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label86.Location = New System.Drawing.Point(21, 291)
        Me.Label86.Name = "Label86"
        Me.Label86.Size = New System.Drawing.Size(343, 13)
        Me.Label86.TabIndex = 9
        Me.Label86.Text = "Click Generate Fingerprint - to concatenate the list of strings and hash it"
        '
        'Label85
        '
        Me.Label85.AutoSize = True
        Me.Label85.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label85.Location = New System.Drawing.Point(18, 165)
        Me.Label85.Name = "Label85"
        Me.Label85.Size = New System.Drawing.Size(501, 13)
        Me.Label85.TabIndex = 8
        Me.Label85.Text = "The Listbox MUST be Sorted alphabetically, because the ordering matters - it need" &
    "s to remain consistent."
        '
        'ListBox_Demo1_Characteristics
        '
        Me.ListBox_Demo1_Characteristics.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ListBox_Demo1_Characteristics.FormattingEnabled = True
        Me.ListBox_Demo1_Characteristics.Location = New System.Drawing.Point(21, 186)
        Me.ListBox_Demo1_Characteristics.Name = "ListBox_Demo1_Characteristics"
        Me.ListBox_Demo1_Characteristics.ScrollAlwaysVisible = True
        Me.ListBox_Demo1_Characteristics.Size = New System.Drawing.Size(639, 95)
        Me.ListBox_Demo1_Characteristics.Sorted = True
        Me.ListBox_Demo1_Characteristics.TabIndex = 7
        '
        'FlowLayoutPanel11
        '
        Me.FlowLayoutPanel11.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.FlowLayoutPanel11.Controls.Add(Me.CheckBox1)
        Me.FlowLayoutPanel11.Controls.Add(Me.CheckBox2)
        Me.FlowLayoutPanel11.Controls.Add(Me.CheckBox3)
        Me.FlowLayoutPanel11.Controls.Add(Me.CheckBox4)
        Me.FlowLayoutPanel11.Controls.Add(Me.CheckBox5)
        Me.FlowLayoutPanel11.Controls.Add(Me.CheckBox6)
        Me.FlowLayoutPanel11.Location = New System.Drawing.Point(21, 100)
        Me.FlowLayoutPanel11.Name = "FlowLayoutPanel11"
        Me.FlowLayoutPanel11.Size = New System.Drawing.Size(639, 55)
        Me.FlowLayoutPanel11.TabIndex = 6
        '
        'CheckBox1
        '
        Me.CheckBox1.Appearance = System.Windows.Forms.Appearance.Button
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Location = New System.Drawing.Point(3, 3)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(71, 23)
        Me.CheckBox1.TabIndex = 3
        Me.CheckBox1.Text = "BIOS Serial"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'CheckBox2
        '
        Me.CheckBox2.Appearance = System.Windows.Forms.Appearance.Button
        Me.CheckBox2.AutoSize = True
        Me.CheckBox2.Location = New System.Drawing.Point(80, 3)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(106, 23)
        Me.CheckBox2.TabIndex = 4
        Me.CheckBox2.Text = "Motherboard Serial"
        Me.CheckBox2.UseVisualStyleBackColor = True
        '
        'CheckBox3
        '
        Me.CheckBox3.Appearance = System.Windows.Forms.Appearance.Button
        Me.CheckBox3.AutoSize = True
        Me.CheckBox3.Location = New System.Drawing.Point(192, 3)
        Me.CheckBox3.Name = "CheckBox3"
        Me.CheckBox3.Size = New System.Drawing.Size(175, 23)
        Me.CheckBox3.TabIndex = 5
        Me.CheckBox3.Text = "Motherboard Base Board Product"
        Me.CheckBox3.UseVisualStyleBackColor = True
        '
        'CheckBox4
        '
        Me.CheckBox4.Appearance = System.Windows.Forms.Appearance.Button
        Me.CheckBox4.AutoSize = True
        Me.CheckBox4.Location = New System.Drawing.Point(373, 3)
        Me.CheckBox4.Name = "CheckBox4"
        Me.CheckBox4.Size = New System.Drawing.Size(102, 23)
        Me.CheckBox4.TabIndex = 6
        Me.CheckBox4.Text = "System Model Full"
        Me.CheckBox4.UseVisualStyleBackColor = True
        '
        'CheckBox5
        '
        Me.CheckBox5.Appearance = System.Windows.Forms.Appearance.Button
        Me.CheckBox5.AutoSize = True
        Me.CheckBox5.Location = New System.Drawing.Point(481, 3)
        Me.CheckBox5.Name = "CheckBox5"
        Me.CheckBox5.Size = New System.Drawing.Size(44, 23)
        Me.CheckBox5.TabIndex = 7
        Me.CheckBox5.Text = "UUID"
        Me.CheckBox5.UseVisualStyleBackColor = True
        '
        'CheckBox6
        '
        Me.CheckBox6.Appearance = System.Windows.Forms.Appearance.Button
        Me.CheckBox6.AutoSize = True
        Me.CheckBox6.Location = New System.Drawing.Point(3, 32)
        Me.CheckBox6.Name = "CheckBox6"
        Me.CheckBox6.Size = New System.Drawing.Size(111, 23)
        Me.CheckBox6.TabIndex = 8
        Me.CheckBox6.Text = "Drive Serial Number"
        Me.CheckBox6.UseVisualStyleBackColor = True
        '
        'Label84
        '
        Me.Label84.AutoSize = True
        Me.Label84.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label84.Location = New System.Drawing.Point(18, 44)
        Me.Label84.Name = "Label84"
        Me.Label84.Size = New System.Drawing.Size(567, 13)
        Me.Label84.TabIndex = 2
        Me.Label84.Text = "most commonly, the motherboard and/or hard drive details - but it's up to you - c" &
    "ustomize the options however you want"
        '
        'Label83
        '
        Me.Label83.AutoSize = True
        Me.Label83.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label83.Location = New System.Drawing.Point(18, 28)
        Me.Label83.Name = "Label83"
        Me.Label83.Size = New System.Drawing.Size(442, 13)
        Me.Label83.TabIndex = 1
        Me.Label83.Text = "You can fingerprint a machine by several characteristics, either individually or " &
    "in combination."
        '
        'Label82
        '
        Me.Label82.AutoSize = True
        Me.Label82.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label82.Location = New System.Drawing.Point(9, 26)
        Me.Label82.Name = "Label82"
        Me.Label82.Size = New System.Drawing.Size(434, 13)
        Me.Label82.TabIndex = 1
        Me.Label82.Text = "Using RSA for signing and verification, and embedded expiry dates, combined into " &
    "a .lic file"
        '
        'Label81
        '
        Me.Label81.AutoSize = True
        Me.Label81.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label81.Location = New System.Drawing.Point(9, 10)
        Me.Label81.Name = "Label81"
        Me.Label81.Size = New System.Drawing.Size(233, 13)
        Me.Label81.TabIndex = 0
        Me.Label81.Text = "Basic example, tying license to a single machine"
        '
        'TabPage8
        '
        Me.TabPage8.AutoScroll = True
        Me.TabPage8.Controls.Add(Me.Panel126)
        Me.TabPage8.Controls.Add(Me.GroupBox8)
        Me.TabPage8.Controls.Add(Me.GroupBox7)
        Me.TabPage8.Controls.Add(Me.Label121)
        Me.TabPage8.Controls.Add(Me.Label122)
        Me.TabPage8.Controls.Add(Me.Label123)
        Me.TabPage8.Location = New System.Drawing.Point(4, 22)
        Me.TabPage8.Name = "TabPage8"
        Me.TabPage8.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage8.Size = New System.Drawing.Size(731, 531)
        Me.TabPage8.TabIndex = 1
        Me.TabPage8.Text = "2"
        Me.TabPage8.UseVisualStyleBackColor = True
        '
        'Panel126
        '
        Me.Panel126.Location = New System.Drawing.Point(12, 1006)
        Me.Panel126.Name = "Panel126"
        Me.Panel126.Size = New System.Drawing.Size(200, 100)
        Me.Panel126.TabIndex = 13
        '
        'GroupBox8
        '
        Me.GroupBox8.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox8.BackColor = System.Drawing.Color.WhiteSmoke
        Me.GroupBox8.Controls.Add(Me.Button65)
        Me.GroupBox8.Controls.Add(Me.Panel129)
        Me.GroupBox8.Controls.Add(Me.Panel128)
        Me.GroupBox8.Controls.Add(Me.Panel127)
        Me.GroupBox8.Controls.Add(Me.Panel125)
        Me.GroupBox8.Controls.Add(Me.Label144)
        Me.GroupBox8.Controls.Add(Me.Button66)
        Me.GroupBox8.Controls.Add(Me.Label156)
        Me.GroupBox8.Location = New System.Drawing.Point(12, 739)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(675, 228)
        Me.GroupBox8.TabIndex = 12
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "Step 2 - Verify"
        '
        'Button65
        '
        Me.Button65.Location = New System.Drawing.Point(172, 24)
        Me.Button65.Name = "Button65"
        Me.Button65.Size = New System.Drawing.Size(114, 23)
        Me.Button65.TabIndex = 30
        Me.Button65.Text = "Copy From Step 1"
        Me.Button65.UseVisualStyleBackColor = True
        '
        'Panel129
        '
        Me.Panel129.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel129.Controls.Add(Me.TextBox9)
        Me.Panel129.Controls.Add(Me.Label147)
        Me.Panel129.Location = New System.Drawing.Point(21, 172)
        Me.Panel129.Name = "Panel129"
        Me.Panel129.Size = New System.Drawing.Size(637, 25)
        Me.Panel129.TabIndex = 29
        '
        'TextBox9
        '
        Me.TextBox9.Location = New System.Drawing.Point(101, 4)
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.ReadOnly = True
        Me.TextBox9.Size = New System.Drawing.Size(81, 20)
        Me.TextBox9.TabIndex = 1
        '
        'Label147
        '
        Me.Label147.AutoSize = True
        Me.Label147.Location = New System.Drawing.Point(4, 6)
        Me.Label147.Name = "Label147"
        Me.Label147.Size = New System.Drawing.Size(48, 13)
        Me.Label147.TabIndex = 0
        Me.Label147.Text = "Expired?"
        '
        'Panel128
        '
        Me.Panel128.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel128.Controls.Add(Me.TextBox8)
        Me.Panel128.Controls.Add(Me.Label146)
        Me.Panel128.Location = New System.Drawing.Point(21, 145)
        Me.Panel128.Name = "Panel128"
        Me.Panel128.Size = New System.Drawing.Size(637, 25)
        Me.Panel128.TabIndex = 28
        '
        'TextBox8
        '
        Me.TextBox8.Location = New System.Drawing.Point(101, 4)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.ReadOnly = True
        Me.TextBox8.Size = New System.Drawing.Size(81, 20)
        Me.TextBox8.TabIndex = 1
        '
        'Label146
        '
        Me.Label146.AutoSize = True
        Me.Label146.Location = New System.Drawing.Point(4, 6)
        Me.Label146.Name = "Label146"
        Me.Label146.Size = New System.Drawing.Size(54, 13)
        Me.Label146.TabIndex = 0
        Me.Label146.Text = "Valid Until"
        '
        'Panel127
        '
        Me.Panel127.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel127.Controls.Add(Me.TextBox7)
        Me.Panel127.Controls.Add(Me.Label145)
        Me.Panel127.Location = New System.Drawing.Point(21, 118)
        Me.Panel127.Name = "Panel127"
        Me.Panel127.Size = New System.Drawing.Size(637, 25)
        Me.Panel127.TabIndex = 27
        '
        'TextBox7
        '
        Me.TextBox7.Location = New System.Drawing.Point(101, 4)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.ReadOnly = True
        Me.TextBox7.Size = New System.Drawing.Size(81, 20)
        Me.TextBox7.TabIndex = 1
        '
        'Label145
        '
        Me.Label145.AutoSize = True
        Me.Label145.Location = New System.Drawing.Point(4, 6)
        Me.Label145.Name = "Label145"
        Me.Label145.Size = New System.Drawing.Size(36, 13)
        Me.Label145.TabIndex = 0
        Me.Label145.Text = "Valid?"
        '
        'Panel125
        '
        Me.Panel125.Controls.Add(Me.Label133)
        Me.Panel125.Controls.Add(Me.TextBox_Demo2_VerifyKeyPart5)
        Me.Panel125.Controls.Add(Me.Label141)
        Me.Panel125.Controls.Add(Me.TextBox_Demo2_VerifyKeyPart4)
        Me.Panel125.Controls.Add(Me.Label142)
        Me.Panel125.Controls.Add(Me.TextBox_Demo2_VerifyKeyPart3)
        Me.Panel125.Controls.Add(Me.Label143)
        Me.Panel125.Controls.Add(Me.TextBox_Demo2_VerifyKeyPart2)
        Me.Panel125.Controls.Add(Me.TextBox_Demo2_VerifyKeyPart1)
        Me.Panel125.Location = New System.Drawing.Point(20, 71)
        Me.Panel125.Name = "Panel125"
        Me.Panel125.Size = New System.Drawing.Size(490, 25)
        Me.Panel125.TabIndex = 26
        '
        'Label133
        '
        Me.Label133.AutoSize = True
        Me.Label133.Location = New System.Drawing.Point(395, 6)
        Me.Label133.Name = "Label133"
        Me.Label133.Size = New System.Drawing.Size(10, 13)
        Me.Label133.TabIndex = 9
        Me.Label133.Text = "-"
        '
        'TextBox_Demo2_VerifyKeyPart5
        '
        Me.TextBox_Demo2_VerifyKeyPart5.Location = New System.Drawing.Point(411, 3)
        Me.TextBox_Demo2_VerifyKeyPart5.Name = "TextBox_Demo2_VerifyKeyPart5"
        Me.TextBox_Demo2_VerifyKeyPart5.Size = New System.Drawing.Size(81, 20)
        Me.TextBox_Demo2_VerifyKeyPart5.TabIndex = 8
        '
        'Label141
        '
        Me.Label141.AutoSize = True
        Me.Label141.Location = New System.Drawing.Point(292, 6)
        Me.Label141.Name = "Label141"
        Me.Label141.Size = New System.Drawing.Size(10, 13)
        Me.Label141.TabIndex = 7
        Me.Label141.Text = "-"
        '
        'TextBox_Demo2_VerifyKeyPart4
        '
        Me.TextBox_Demo2_VerifyKeyPart4.Location = New System.Drawing.Point(308, 3)
        Me.TextBox_Demo2_VerifyKeyPart4.Name = "TextBox_Demo2_VerifyKeyPart4"
        Me.TextBox_Demo2_VerifyKeyPart4.Size = New System.Drawing.Size(81, 20)
        Me.TextBox_Demo2_VerifyKeyPart4.TabIndex = 6
        '
        'Label142
        '
        Me.Label142.AutoSize = True
        Me.Label142.Location = New System.Drawing.Point(189, 6)
        Me.Label142.Name = "Label142"
        Me.Label142.Size = New System.Drawing.Size(10, 13)
        Me.Label142.TabIndex = 5
        Me.Label142.Text = "-"
        '
        'TextBox_Demo2_VerifyKeyPart3
        '
        Me.TextBox_Demo2_VerifyKeyPart3.Location = New System.Drawing.Point(205, 3)
        Me.TextBox_Demo2_VerifyKeyPart3.Name = "TextBox_Demo2_VerifyKeyPart3"
        Me.TextBox_Demo2_VerifyKeyPart3.Size = New System.Drawing.Size(81, 20)
        Me.TextBox_Demo2_VerifyKeyPart3.TabIndex = 4
        '
        'Label143
        '
        Me.Label143.AutoSize = True
        Me.Label143.Location = New System.Drawing.Point(86, 6)
        Me.Label143.Name = "Label143"
        Me.Label143.Size = New System.Drawing.Size(10, 13)
        Me.Label143.TabIndex = 3
        Me.Label143.Text = "-"
        '
        'TextBox_Demo2_VerifyKeyPart2
        '
        Me.TextBox_Demo2_VerifyKeyPart2.Location = New System.Drawing.Point(102, 3)
        Me.TextBox_Demo2_VerifyKeyPart2.Name = "TextBox_Demo2_VerifyKeyPart2"
        Me.TextBox_Demo2_VerifyKeyPart2.Size = New System.Drawing.Size(81, 20)
        Me.TextBox_Demo2_VerifyKeyPart2.TabIndex = 2
        '
        'TextBox_Demo2_VerifyKeyPart1
        '
        Me.TextBox_Demo2_VerifyKeyPart1.Location = New System.Drawing.Point(-1, 3)
        Me.TextBox_Demo2_VerifyKeyPart1.Name = "TextBox_Demo2_VerifyKeyPart1"
        Me.TextBox_Demo2_VerifyKeyPart1.Size = New System.Drawing.Size(81, 20)
        Me.TextBox_Demo2_VerifyKeyPart1.TabIndex = 1
        '
        'Label144
        '
        Me.Label144.AutoSize = True
        Me.Label144.Location = New System.Drawing.Point(18, 55)
        Me.Label144.Name = "Label144"
        Me.Label144.Size = New System.Drawing.Size(65, 13)
        Me.Label144.TabIndex = 25
        Me.Label144.Text = "License Key"
        '
        'Button66
        '
        Me.Button66.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button66.BackColor = System.Drawing.Color.LightGreen
        Me.Button66.Location = New System.Drawing.Point(575, 64)
        Me.Button66.Name = "Button66"
        Me.Button66.Size = New System.Drawing.Size(83, 38)
        Me.Button66.TabIndex = 12
        Me.Button66.Text = "Verify License Key"
        Me.Button66.UseVisualStyleBackColor = False
        '
        'Label156
        '
        Me.Label156.AutoSize = True
        Me.Label156.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label156.Location = New System.Drawing.Point(18, 28)
        Me.Label156.Name = "Label156"
        Me.Label156.Size = New System.Drawing.Size(146, 13)
        Me.Label156.TabIndex = 1
        Me.Label156.Text = "Input the Serial Key and Veriy"
        '
        'GroupBox7
        '
        Me.GroupBox7.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox7.BackColor = System.Drawing.Color.WhiteSmoke
        Me.GroupBox7.Controls.Add(Me.Panel121)
        Me.GroupBox7.Controls.Add(Me.Panel120)
        Me.GroupBox7.Controls.Add(Me.Panel136)
        Me.GroupBox7.Controls.Add(Me.RadioButton2)
        Me.GroupBox7.Controls.Add(Me.RadioButton1)
        Me.GroupBox7.Controls.Add(Me.Panel119)
        Me.GroupBox7.Controls.Add(Me.Panel124)
        Me.GroupBox7.Controls.Add(Me.Label136)
        Me.GroupBox7.Controls.Add(Me.Button_Demo2_GeneralteLicenseKey)
        Me.GroupBox7.Controls.Add(Me.Label127)
        Me.GroupBox7.Controls.Add(Me.Label128)
        Me.GroupBox7.Location = New System.Drawing.Point(12, 112)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(675, 517)
        Me.GroupBox7.TabIndex = 11
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Step 1 - Set Expiry and Generate Key"
        '
        'Panel121
        '
        Me.Panel121.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel121.Controls.Add(Me.Label132)
        Me.Panel121.Controls.Add(Me.DateTimePicker2)
        Me.Panel121.Controls.Add(Me.Label125)
        Me.Panel121.Location = New System.Drawing.Point(20, 78)
        Me.Panel121.Name = "Panel121"
        Me.Panel121.Size = New System.Drawing.Size(621, 25)
        Me.Panel121.TabIndex = 30
        '
        'Label132
        '
        Me.Label132.AutoSize = True
        Me.Label132.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.Label132.Location = New System.Drawing.Point(295, 6)
        Me.Label132.Name = "Label132"
        Me.Label132.Size = New System.Drawing.Size(73, 13)
        Me.Label132.TabIndex = 6
        Me.Label132.Text = "SET_EXPIRY"
        '
        'DateTimePicker2
        '
        Me.DateTimePicker2.Location = New System.Drawing.Point(122, 2)
        Me.DateTimePicker2.Name = "DateTimePicker2"
        Me.DateTimePicker2.Size = New System.Drawing.Size(144, 20)
        Me.DateTimePicker2.TabIndex = 5
        '
        'Label125
        '
        Me.Label125.AutoSize = True
        Me.Label125.Location = New System.Drawing.Point(4, 6)
        Me.Label125.Name = "Label125"
        Me.Label125.Size = New System.Drawing.Size(111, 13)
        Me.Label125.TabIndex = 0
        Me.Label125.Text = "Set Expiry (DDMMYY)"
        '
        'Panel120
        '
        Me.Panel120.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel120.Controls.Add(Me.Button63)
        Me.Panel120.Controls.Add(Me.TextBox_Demo2_RandomString)
        Me.Panel120.Controls.Add(Me.Label131)
        Me.Panel120.Enabled = False
        Me.Panel120.Location = New System.Drawing.Point(23, 355)
        Me.Panel120.Name = "Panel120"
        Me.Panel120.Size = New System.Drawing.Size(627, 21)
        Me.Panel120.TabIndex = 29
        '
        'Button63
        '
        Me.Button63.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button63.Location = New System.Drawing.Point(538, -1)
        Me.Button63.Name = "Button63"
        Me.Button63.Size = New System.Drawing.Size(83, 23)
        Me.Button63.TabIndex = 5
        Me.Button63.Text = "Generate"
        Me.Button63.UseVisualStyleBackColor = True
        '
        'TextBox_Demo2_RandomString
        '
        Me.TextBox_Demo2_RandomString.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_Demo2_RandomString.Location = New System.Drawing.Point(120, 0)
        Me.TextBox_Demo2_RandomString.Name = "TextBox_Demo2_RandomString"
        Me.TextBox_Demo2_RandomString.Size = New System.Drawing.Size(416, 20)
        Me.TextBox_Demo2_RandomString.TabIndex = 1
        '
        'Label131
        '
        Me.Label131.AutoSize = True
        Me.Label131.Location = New System.Drawing.Point(3, 3)
        Me.Label131.Name = "Label131"
        Me.Label131.Size = New System.Drawing.Size(77, 13)
        Me.Label131.TabIndex = 0
        Me.Label131.Text = "Random String"
        '
        'Panel136
        '
        Me.Panel136.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel136.Controls.Add(Me.Button69)
        Me.Panel136.Controls.Add(Me.TextBox_Demo2_HashCombined)
        Me.Panel136.Controls.Add(Me.Label157)
        Me.Panel136.Location = New System.Drawing.Point(23, 393)
        Me.Panel136.Name = "Panel136"
        Me.Panel136.Size = New System.Drawing.Size(621, 25)
        Me.Panel136.TabIndex = 25
        '
        'Button69
        '
        Me.Button69.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button69.Location = New System.Drawing.Point(538, 1)
        Me.Button69.Name = "Button69"
        Me.Button69.Size = New System.Drawing.Size(80, 23)
        Me.Button69.TabIndex = 4
        Me.Button69.Text = "Clear"
        Me.Button69.UseVisualStyleBackColor = True
        '
        'TextBox_Demo2_HashCombined
        '
        Me.TextBox_Demo2_HashCombined.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_Demo2_HashCombined.Location = New System.Drawing.Point(120, 3)
        Me.TextBox_Demo2_HashCombined.Name = "TextBox_Demo2_HashCombined"
        Me.TextBox_Demo2_HashCombined.ReadOnly = True
        Me.TextBox_Demo2_HashCombined.Size = New System.Drawing.Size(416, 20)
        Me.TextBox_Demo2_HashCombined.TabIndex = 1
        '
        'Label157
        '
        Me.Label157.AutoSize = True
        Me.Label157.Location = New System.Drawing.Point(4, 6)
        Me.Label157.Name = "Label157"
        Me.Label157.Size = New System.Drawing.Size(68, 13)
        Me.Label157.TabIndex = 0
        Me.Label157.Text = "Hash Result:"
        '
        'RadioButton2
        '
        Me.RadioButton2.AutoSize = True
        Me.RadioButton2.Location = New System.Drawing.Point(21, 332)
        Me.RadioButton2.Name = "RadioButton2"
        Me.RadioButton2.Size = New System.Drawing.Size(65, 17)
        Me.RadioButton2.TabIndex = 28
        Me.RadioButton2.Text = "Random"
        Me.RadioButton2.UseVisualStyleBackColor = True
        '
        'RadioButton1
        '
        Me.RadioButton1.AutoSize = True
        Me.RadioButton1.Checked = True
        Me.RadioButton1.Location = New System.Drawing.Point(21, 120)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(60, 17)
        Me.RadioButton1.TabIndex = 27
        Me.RadioButton1.TabStop = True
        Me.RadioButton1.Text = "Custom"
        Me.RadioButton1.UseVisualStyleBackColor = True
        '
        'Panel119
        '
        Me.Panel119.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel119.Controls.Add(Me.Panel114)
        Me.Panel119.Controls.Add(Me.Panel115)
        Me.Panel119.Controls.Add(Me.Panel116)
        Me.Panel119.Controls.Add(Me.Panel122)
        Me.Panel119.Controls.Add(Me.Panel117)
        Me.Panel119.Controls.Add(Me.Panel123)
        Me.Panel119.Controls.Add(Me.Panel118)
        Me.Panel119.Location = New System.Drawing.Point(23, 141)
        Me.Panel119.Name = "Panel119"
        Me.Panel119.Size = New System.Drawing.Size(627, 190)
        Me.Panel119.TabIndex = 26
        '
        'Panel114
        '
        Me.Panel114.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel114.Controls.Add(Me.TextBox_Demo2_LicensedTo)
        Me.Panel114.Controls.Add(Me.Label120)
        Me.Panel114.Location = New System.Drawing.Point(3, 2)
        Me.Panel114.Name = "Panel114"
        Me.Panel114.Size = New System.Drawing.Size(621, 25)
        Me.Panel114.TabIndex = 14
        '
        'TextBox_Demo2_LicensedTo
        '
        Me.TextBox_Demo2_LicensedTo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_Demo2_LicensedTo.Location = New System.Drawing.Point(117, 3)
        Me.TextBox_Demo2_LicensedTo.Name = "TextBox_Demo2_LicensedTo"
        Me.TextBox_Demo2_LicensedTo.Size = New System.Drawing.Size(416, 20)
        Me.TextBox_Demo2_LicensedTo.TabIndex = 1
        '
        'Label120
        '
        Me.Label120.AutoSize = True
        Me.Label120.Location = New System.Drawing.Point(3, 6)
        Me.Label120.Name = "Label120"
        Me.Label120.Size = New System.Drawing.Size(66, 13)
        Me.Label120.TabIndex = 0
        Me.Label120.Text = "Licensed To"
        '
        'Panel115
        '
        Me.Panel115.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel115.Controls.Add(Me.TextBox_Demo2_Email)
        Me.Panel115.Controls.Add(Me.Label124)
        Me.Panel115.Location = New System.Drawing.Point(3, 28)
        Me.Panel115.Name = "Panel115"
        Me.Panel115.Size = New System.Drawing.Size(621, 25)
        Me.Panel115.TabIndex = 15
        '
        'TextBox_Demo2_Email
        '
        Me.TextBox_Demo2_Email.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_Demo2_Email.Location = New System.Drawing.Point(117, 3)
        Me.TextBox_Demo2_Email.Name = "TextBox_Demo2_Email"
        Me.TextBox_Demo2_Email.Size = New System.Drawing.Size(416, 20)
        Me.TextBox_Demo2_Email.TabIndex = 1
        '
        'Label124
        '
        Me.Label124.AutoSize = True
        Me.Label124.Location = New System.Drawing.Point(3, 6)
        Me.Label124.Name = "Label124"
        Me.Label124.Size = New System.Drawing.Size(32, 13)
        Me.Label124.TabIndex = 0
        Me.Label124.Text = "Email"
        '
        'Panel116
        '
        Me.Panel116.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel116.Controls.Add(Me.TextBox_Demo2_Branch)
        Me.Panel116.Controls.Add(Me.Label126)
        Me.Panel116.Location = New System.Drawing.Point(3, 54)
        Me.Panel116.Name = "Panel116"
        Me.Panel116.Size = New System.Drawing.Size(621, 25)
        Me.Panel116.TabIndex = 16
        '
        'TextBox_Demo2_Branch
        '
        Me.TextBox_Demo2_Branch.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_Demo2_Branch.Location = New System.Drawing.Point(117, 3)
        Me.TextBox_Demo2_Branch.Name = "TextBox_Demo2_Branch"
        Me.TextBox_Demo2_Branch.Size = New System.Drawing.Size(416, 20)
        Me.TextBox_Demo2_Branch.TabIndex = 1
        '
        'Label126
        '
        Me.Label126.AutoSize = True
        Me.Label126.Location = New System.Drawing.Point(3, 6)
        Me.Label126.Name = "Label126"
        Me.Label126.Size = New System.Drawing.Size(41, 13)
        Me.Label126.TabIndex = 0
        Me.Label126.Text = "Branch"
        '
        'Panel122
        '
        Me.Panel122.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel122.Controls.Add(Me.Button64)
        Me.Panel122.Controls.Add(Me.TextBox_Demo2_Base64Encoded)
        Me.Panel122.Controls.Add(Me.Label134)
        Me.Panel122.Location = New System.Drawing.Point(3, 158)
        Me.Panel122.Name = "Panel122"
        Me.Panel122.Size = New System.Drawing.Size(621, 25)
        Me.Panel122.TabIndex = 20
        '
        'Button64
        '
        Me.Button64.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button64.Location = New System.Drawing.Point(535, 0)
        Me.Button64.Name = "Button64"
        Me.Button64.Size = New System.Drawing.Size(83, 23)
        Me.Button64.TabIndex = 3
        Me.Button64.Text = "Clear"
        Me.Button64.UseVisualStyleBackColor = True
        '
        'TextBox_Demo2_Base64Encoded
        '
        Me.TextBox_Demo2_Base64Encoded.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_Demo2_Base64Encoded.Location = New System.Drawing.Point(117, 3)
        Me.TextBox_Demo2_Base64Encoded.Name = "TextBox_Demo2_Base64Encoded"
        Me.TextBox_Demo2_Base64Encoded.ReadOnly = True
        Me.TextBox_Demo2_Base64Encoded.Size = New System.Drawing.Size(416, 20)
        Me.TextBox_Demo2_Base64Encoded.TabIndex = 1
        '
        'Label134
        '
        Me.Label134.AutoSize = True
        Me.Label134.Location = New System.Drawing.Point(3, 6)
        Me.Label134.Name = "Label134"
        Me.Label134.Size = New System.Drawing.Size(89, 13)
        Me.Label134.TabIndex = 0
        Me.Label134.Text = "Base64 Encoded"
        '
        'Panel117
        '
        Me.Panel117.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel117.Controls.Add(Me.TextBox_Demo2_Terminal)
        Me.Panel117.Controls.Add(Me.Label129)
        Me.Panel117.Location = New System.Drawing.Point(3, 80)
        Me.Panel117.Name = "Panel117"
        Me.Panel117.Size = New System.Drawing.Size(621, 25)
        Me.Panel117.TabIndex = 17
        '
        'TextBox_Demo2_Terminal
        '
        Me.TextBox_Demo2_Terminal.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_Demo2_Terminal.Location = New System.Drawing.Point(117, 3)
        Me.TextBox_Demo2_Terminal.Name = "TextBox_Demo2_Terminal"
        Me.TextBox_Demo2_Terminal.Size = New System.Drawing.Size(416, 20)
        Me.TextBox_Demo2_Terminal.TabIndex = 1
        '
        'Label129
        '
        Me.Label129.AutoSize = True
        Me.Label129.Location = New System.Drawing.Point(3, 6)
        Me.Label129.Name = "Label129"
        Me.Label129.Size = New System.Drawing.Size(47, 13)
        Me.Label129.TabIndex = 0
        Me.Label129.Text = "Terminal"
        '
        'Panel123
        '
        Me.Panel123.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel123.Controls.Add(Me.Button62)
        Me.Panel123.Controls.Add(Me.TextBox_Demo2_Concatenated)
        Me.Panel123.Controls.Add(Me.Label135)
        Me.Panel123.Location = New System.Drawing.Point(3, 132)
        Me.Panel123.Name = "Panel123"
        Me.Panel123.Size = New System.Drawing.Size(621, 25)
        Me.Panel123.TabIndex = 19
        '
        'Button62
        '
        Me.Button62.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button62.Location = New System.Drawing.Point(535, 1)
        Me.Button62.Name = "Button62"
        Me.Button62.Size = New System.Drawing.Size(83, 23)
        Me.Button62.TabIndex = 2
        Me.Button62.Text = "Clear"
        Me.Button62.UseVisualStyleBackColor = True
        '
        'TextBox_Demo2_Concatenated
        '
        Me.TextBox_Demo2_Concatenated.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_Demo2_Concatenated.Location = New System.Drawing.Point(117, 3)
        Me.TextBox_Demo2_Concatenated.Name = "TextBox_Demo2_Concatenated"
        Me.TextBox_Demo2_Concatenated.ReadOnly = True
        Me.TextBox_Demo2_Concatenated.Size = New System.Drawing.Size(416, 20)
        Me.TextBox_Demo2_Concatenated.TabIndex = 1
        '
        'Label135
        '
        Me.Label135.AutoSize = True
        Me.Label135.Location = New System.Drawing.Point(3, 6)
        Me.Label135.Name = "Label135"
        Me.Label135.Size = New System.Drawing.Size(74, 13)
        Me.Label135.TabIndex = 0
        Me.Label135.Text = "Concatenated"
        '
        'Panel118
        '
        Me.Panel118.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel118.Controls.Add(Me.TextBox_Demo2_Seed)
        Me.Panel118.Controls.Add(Me.Label130)
        Me.Panel118.Location = New System.Drawing.Point(3, 106)
        Me.Panel118.Name = "Panel118"
        Me.Panel118.Size = New System.Drawing.Size(621, 25)
        Me.Panel118.TabIndex = 18
        '
        'TextBox_Demo2_Seed
        '
        Me.TextBox_Demo2_Seed.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_Demo2_Seed.Location = New System.Drawing.Point(117, 3)
        Me.TextBox_Demo2_Seed.Name = "TextBox_Demo2_Seed"
        Me.TextBox_Demo2_Seed.Size = New System.Drawing.Size(416, 20)
        Me.TextBox_Demo2_Seed.TabIndex = 1
        '
        'Label130
        '
        Me.Label130.AutoSize = True
        Me.Label130.Location = New System.Drawing.Point(3, 6)
        Me.Label130.Name = "Label130"
        Me.Label130.Size = New System.Drawing.Size(78, 13)
        Me.Label130.TabIndex = 0
        Me.Label130.Text = "Seed (optional)"
        '
        'Panel124
        '
        Me.Panel124.Controls.Add(Me.Label140)
        Me.Panel124.Controls.Add(Me.TextBox_Demo2_LicenseKeyPart5)
        Me.Panel124.Controls.Add(Me.Label139)
        Me.Panel124.Controls.Add(Me.TextBox_Demo2_LicenseKeyPart4)
        Me.Panel124.Controls.Add(Me.Label138)
        Me.Panel124.Controls.Add(Me.TextBox_Demo2_LicenseKeyPart3)
        Me.Panel124.Controls.Add(Me.Label137)
        Me.Panel124.Controls.Add(Me.TextBox_Demo2_LicenseKeyPart2)
        Me.Panel124.Controls.Add(Me.TextBox_Demo2_LicenseKeyPart1)
        Me.Panel124.Location = New System.Drawing.Point(25, 462)
        Me.Panel124.Name = "Panel124"
        Me.Panel124.Size = New System.Drawing.Size(490, 25)
        Me.Panel124.TabIndex = 24
        '
        'Label140
        '
        Me.Label140.AutoSize = True
        Me.Label140.Location = New System.Drawing.Point(395, 6)
        Me.Label140.Name = "Label140"
        Me.Label140.Size = New System.Drawing.Size(10, 13)
        Me.Label140.TabIndex = 9
        Me.Label140.Text = "-"
        '
        'TextBox_Demo2_LicenseKeyPart5
        '
        Me.TextBox_Demo2_LicenseKeyPart5.Location = New System.Drawing.Point(411, 3)
        Me.TextBox_Demo2_LicenseKeyPart5.Name = "TextBox_Demo2_LicenseKeyPart5"
        Me.TextBox_Demo2_LicenseKeyPart5.ReadOnly = True
        Me.TextBox_Demo2_LicenseKeyPart5.Size = New System.Drawing.Size(81, 20)
        Me.TextBox_Demo2_LicenseKeyPart5.TabIndex = 8
        '
        'Label139
        '
        Me.Label139.AutoSize = True
        Me.Label139.Location = New System.Drawing.Point(292, 6)
        Me.Label139.Name = "Label139"
        Me.Label139.Size = New System.Drawing.Size(10, 13)
        Me.Label139.TabIndex = 7
        Me.Label139.Text = "-"
        '
        'TextBox_Demo2_LicenseKeyPart4
        '
        Me.TextBox_Demo2_LicenseKeyPart4.Location = New System.Drawing.Point(308, 3)
        Me.TextBox_Demo2_LicenseKeyPart4.Name = "TextBox_Demo2_LicenseKeyPart4"
        Me.TextBox_Demo2_LicenseKeyPart4.ReadOnly = True
        Me.TextBox_Demo2_LicenseKeyPart4.Size = New System.Drawing.Size(81, 20)
        Me.TextBox_Demo2_LicenseKeyPart4.TabIndex = 6
        '
        'Label138
        '
        Me.Label138.AutoSize = True
        Me.Label138.Location = New System.Drawing.Point(189, 6)
        Me.Label138.Name = "Label138"
        Me.Label138.Size = New System.Drawing.Size(10, 13)
        Me.Label138.TabIndex = 5
        Me.Label138.Text = "-"
        '
        'TextBox_Demo2_LicenseKeyPart3
        '
        Me.TextBox_Demo2_LicenseKeyPart3.Location = New System.Drawing.Point(205, 3)
        Me.TextBox_Demo2_LicenseKeyPart3.Name = "TextBox_Demo2_LicenseKeyPart3"
        Me.TextBox_Demo2_LicenseKeyPart3.ReadOnly = True
        Me.TextBox_Demo2_LicenseKeyPart3.Size = New System.Drawing.Size(81, 20)
        Me.TextBox_Demo2_LicenseKeyPart3.TabIndex = 4
        '
        'Label137
        '
        Me.Label137.AutoSize = True
        Me.Label137.Location = New System.Drawing.Point(86, 6)
        Me.Label137.Name = "Label137"
        Me.Label137.Size = New System.Drawing.Size(10, 13)
        Me.Label137.TabIndex = 3
        Me.Label137.Text = "-"
        '
        'TextBox_Demo2_LicenseKeyPart2
        '
        Me.TextBox_Demo2_LicenseKeyPart2.Location = New System.Drawing.Point(102, 3)
        Me.TextBox_Demo2_LicenseKeyPart2.Name = "TextBox_Demo2_LicenseKeyPart2"
        Me.TextBox_Demo2_LicenseKeyPart2.ReadOnly = True
        Me.TextBox_Demo2_LicenseKeyPart2.Size = New System.Drawing.Size(81, 20)
        Me.TextBox_Demo2_LicenseKeyPart2.TabIndex = 2
        '
        'TextBox_Demo2_LicenseKeyPart1
        '
        Me.TextBox_Demo2_LicenseKeyPart1.Location = New System.Drawing.Point(-1, 3)
        Me.TextBox_Demo2_LicenseKeyPart1.Name = "TextBox_Demo2_LicenseKeyPart1"
        Me.TextBox_Demo2_LicenseKeyPart1.ReadOnly = True
        Me.TextBox_Demo2_LicenseKeyPart1.Size = New System.Drawing.Size(81, 20)
        Me.TextBox_Demo2_LicenseKeyPart1.TabIndex = 1
        '
        'Label136
        '
        Me.Label136.AutoSize = True
        Me.Label136.Location = New System.Drawing.Point(23, 446)
        Me.Label136.Name = "Label136"
        Me.Label136.Size = New System.Drawing.Size(65, 13)
        Me.Label136.TabIndex = 0
        Me.Label136.Text = "License Key"
        '
        'Button_Demo2_GeneralteLicenseKey
        '
        Me.Button_Demo2_GeneralteLicenseKey.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_Demo2_GeneralteLicenseKey.BackColor = System.Drawing.Color.LightGreen
        Me.Button_Demo2_GeneralteLicenseKey.Location = New System.Drawing.Point(575, 449)
        Me.Button_Demo2_GeneralteLicenseKey.Name = "Button_Demo2_GeneralteLicenseKey"
        Me.Button_Demo2_GeneralteLicenseKey.Size = New System.Drawing.Size(83, 38)
        Me.Button_Demo2_GeneralteLicenseKey.TabIndex = 11
        Me.Button_Demo2_GeneralteLicenseKey.Text = "Generate License Key"
        Me.Button_Demo2_GeneralteLicenseKey.UseVisualStyleBackColor = False
        '
        'Label127
        '
        Me.Label127.AutoSize = True
        Me.Label127.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label127.Location = New System.Drawing.Point(18, 44)
        Me.Label127.Name = "Label127"
        Me.Label127.Size = New System.Drawing.Size(515, 13)
        Me.Label127.TabIndex = 2
        Me.Label127.Text = "Then come up with your own algorithm, like hashing each field and taking the firs" &
    "t 25 characters for example"
        '
        'Label128
        '
        Me.Label128.AutoSize = True
        Me.Label128.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label128.Location = New System.Drawing.Point(18, 28)
        Me.Label128.Name = "Label128"
        Me.Label128.Size = New System.Drawing.Size(471, 13)
        Me.Label128.TabIndex = 1
        Me.Label128.Text = "Input details that uniquely identify a user - it can be fingerprint, the users na" &
    "me, email, a GUID, etc. "
        '
        'Label121
        '
        Me.Label121.AutoSize = True
        Me.Label121.ForeColor = System.Drawing.Color.Red
        Me.Label121.Location = New System.Drawing.Point(9, 51)
        Me.Label121.Name = "Label121"
        Me.Label121.Size = New System.Drawing.Size(574, 13)
        Me.Label121.TabIndex = 9
        Me.Label121.Text = "CONSIDERATION: user can easily copy this multiple times  - because its more an el" &
    "aborate password than a true license"
        '
        'Label122
        '
        Me.Label122.AutoSize = True
        Me.Label122.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label122.Location = New System.Drawing.Point(9, 26)
        Me.Label122.Name = "Label122"
        Me.Label122.Size = New System.Drawing.Size(284, 13)
        Me.Label122.TabIndex = 8
        Me.Label122.Text = "Using a custom algorithm to create a deterministic Key Gen"
        '
        'Label123
        '
        Me.Label123.AutoSize = True
        Me.Label123.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label123.Location = New System.Drawing.Point(9, 10)
        Me.Label123.Name = "Label123"
        Me.Label123.Size = New System.Drawing.Size(233, 13)
        Me.Label123.TabIndex = 7
        Me.Label123.Text = "Basic example, tying license to a single machine"
        '
        'Button_LicenseOTP_TOTP_UserCodeCopyFromUser
        '
        Me.Button_LicenseOTP_TOTP_UserCodeCopyFromUser.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_LicenseOTP_TOTP_UserCodeCopyFromUser.Location = New System.Drawing.Point(558, 0)
        Me.Button_LicenseOTP_TOTP_UserCodeCopyFromUser.Name = "Button_LicenseOTP_TOTP_UserCodeCopyFromUser"
        Me.Button_LicenseOTP_TOTP_UserCodeCopyFromUser.Size = New System.Drawing.Size(75, 23)
        Me.Button_LicenseOTP_TOTP_UserCodeCopyFromUser.TabIndex = 4
        Me.Button_LicenseOTP_TOTP_UserCodeCopyFromUser.Text = "Copy User"
        Me.Button_LicenseOTP_TOTP_UserCodeCopyFromUser.UseVisualStyleBackColor = True
        '
        'Label170
        '
        Me.Label170.AutoSize = True
        Me.Label170.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label170.Location = New System.Drawing.Point(18, 30)
        Me.Label170.Name = "Label170"
        Me.Label170.Size = New System.Drawing.Size(282, 13)
        Me.Label170.TabIndex = 4
        Me.Label170.Text = "Time-Based One-Time Passcodes - change on the interval"
        '
        'Label172
        '
        Me.Label172.AutoSize = True
        Me.Label172.ForeColor = System.Drawing.Color.Red
        Me.Label172.Location = New System.Drawing.Point(18, 46)
        Me.Label172.Name = "Label172"
        Me.Label172.Size = New System.Drawing.Size(527, 13)
        Me.Label172.TabIndex = 5
        Me.Label172.Text = "The code would be embedded in the client, as well running on another machine - wh" &
    "ere neither are connected" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'Label173
        '
        Me.Label173.AutoSize = True
        Me.Label173.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label173.Location = New System.Drawing.Point(9, 23)
        Me.Label173.Name = "Label173"
        Me.Label173.Size = New System.Drawing.Size(323, 13)
        Me.Label173.TabIndex = 10
        Me.Label173.Text = "Then assuming you're running this fomr another machine seperately"
        '
        'GroupBox10
        '
        Me.GroupBox10.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox10.Controls.Add(Me.Label159)
        Me.GroupBox10.Controls.Add(Me.Label160)
        Me.GroupBox10.Controls.Add(Me.Panel140)
        Me.GroupBox10.Controls.Add(Me.Panel146)
        Me.GroupBox10.Location = New System.Drawing.Point(15, 550)
        Me.GroupBox10.Name = "GroupBox10"
        Me.GroupBox10.Size = New System.Drawing.Size(683, 437)
        Me.GroupBox10.TabIndex = 6
        Me.GroupBox10.TabStop = False
        Me.GroupBox10.Text = "HOTP"
        '
        'Label159
        '
        Me.Label159.AutoSize = True
        Me.Label159.ForeColor = System.Drawing.Color.Red
        Me.Label159.Location = New System.Drawing.Point(18, 46)
        Me.Label159.Name = "Label159"
        Me.Label159.Size = New System.Drawing.Size(527, 13)
        Me.Label159.TabIndex = 5
        Me.Label159.Text = "The code would be embedded in the client, as well running on another machine - wh" &
    "ere neither are connected" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'Label160
        '
        Me.Label160.AutoSize = True
        Me.Label160.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label160.Location = New System.Drawing.Point(18, 30)
        Me.Label160.Name = "Label160"
        Me.Label160.Size = New System.Drawing.Size(354, 13)
        Me.Label160.TabIndex = 4
        Me.Label160.Text = "Counter-Based One-Time Passcodes - change on a synchronized counter"
        '
        'Panel140
        '
        Me.Panel140.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel140.Controls.Add(Me.Label161)
        Me.Panel140.Controls.Add(Me.Panel141)
        Me.Panel140.Controls.Add(Me.Panel142)
        Me.Panel140.Controls.Add(Me.Panel143)
        Me.Panel140.Controls.Add(Me.Panel144)
        Me.Panel140.Controls.Add(Me.Panel145)
        Me.Panel140.Controls.Add(Me.Label167)
        Me.Panel140.Location = New System.Drawing.Point(18, 225)
        Me.Panel140.Name = "Panel140"
        Me.Panel140.Size = New System.Drawing.Size(645, 189)
        Me.Panel140.TabIndex = 3
        '
        'Label161
        '
        Me.Label161.AutoSize = True
        Me.Label161.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label161.Location = New System.Drawing.Point(9, 23)
        Me.Label161.Name = "Label161"
        Me.Label161.Size = New System.Drawing.Size(323, 13)
        Me.Label161.TabIndex = 10
        Me.Label161.Text = "Then assuming you're running this fomr another machine seperately"
        '
        'Panel141
        '
        Me.Panel141.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel141.Controls.Add(Me.TextBox2)
        Me.Panel141.Controls.Add(Me.Label162)
        Me.Panel141.Controls.Add(Me.Button67)
        Me.Panel141.Location = New System.Drawing.Point(6, 123)
        Me.Panel141.Name = "Panel141"
        Me.Panel141.Size = New System.Drawing.Size(636, 25)
        Me.Panel141.TabIndex = 9
        '
        'TextBox2
        '
        Me.TextBox2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox2.Location = New System.Drawing.Point(81, 3)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.ReadOnly = True
        Me.TextBox2.Size = New System.Drawing.Size(472, 20)
        Me.TextBox2.TabIndex = 1
        '
        'Label162
        '
        Me.Label162.AutoSize = True
        Me.Label162.Location = New System.Drawing.Point(3, 6)
        Me.Label162.Name = "Label162"
        Me.Label162.Size = New System.Drawing.Size(69, 13)
        Me.Label162.TabIndex = 0
        Me.Label162.Text = "Server Code:"
        '
        'Button67
        '
        Me.Button67.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button67.BackColor = System.Drawing.Color.LightGreen
        Me.Button67.Location = New System.Drawing.Point(558, 0)
        Me.Button67.Name = "Button67"
        Me.Button67.Size = New System.Drawing.Size(75, 23)
        Me.Button67.TabIndex = 0
        Me.Button67.Text = "Verify Code"
        Me.Button67.UseVisualStyleBackColor = False
        '
        'Panel142
        '
        Me.Panel142.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel142.Controls.Add(Me.TextBox3)
        Me.Panel142.Controls.Add(Me.Label163)
        Me.Panel142.Location = New System.Drawing.Point(6, 150)
        Me.Panel142.Name = "Panel142"
        Me.Panel142.Size = New System.Drawing.Size(636, 25)
        Me.Panel142.TabIndex = 8
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(81, 3)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(87, 20)
        Me.TextBox3.TabIndex = 1
        '
        'Label163
        '
        Me.Label163.AutoSize = True
        Me.Label163.Location = New System.Drawing.Point(3, 6)
        Me.Label163.Name = "Label163"
        Me.Label163.Size = New System.Drawing.Size(45, 13)
        Me.Label163.TabIndex = 0
        Me.Label163.Text = "Verified:"
        '
        'Panel143
        '
        Me.Panel143.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel143.Controls.Add(Me.Button70)
        Me.Panel143.Controls.Add(Me.TextBox4)
        Me.Panel143.Controls.Add(Me.Label164)
        Me.Panel143.Location = New System.Drawing.Point(6, 97)
        Me.Panel143.Name = "Panel143"
        Me.Panel143.Size = New System.Drawing.Size(636, 25)
        Me.Panel143.TabIndex = 7
        '
        'Button70
        '
        Me.Button70.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button70.Location = New System.Drawing.Point(558, 0)
        Me.Button70.Name = "Button70"
        Me.Button70.Size = New System.Drawing.Size(75, 23)
        Me.Button70.TabIndex = 4
        Me.Button70.Text = "Copy User"
        Me.Button70.UseVisualStyleBackColor = True
        '
        'TextBox4
        '
        Me.TextBox4.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox4.Location = New System.Drawing.Point(81, 3)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(472, 20)
        Me.TextBox4.TabIndex = 1
        '
        'Label164
        '
        Me.Label164.AutoSize = True
        Me.Label164.Location = New System.Drawing.Point(3, 6)
        Me.Label164.Name = "Label164"
        Me.Label164.Size = New System.Drawing.Size(65, 13)
        Me.Label164.TabIndex = 0
        Me.Label164.Text = "Users Code:"
        '
        'Panel144
        '
        Me.Panel144.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel144.Controls.Add(Me.Button71)
        Me.Panel144.Controls.Add(Me.ComboBox1)
        Me.Panel144.Controls.Add(Me.Label165)
        Me.Panel144.Location = New System.Drawing.Point(6, 70)
        Me.Panel144.Name = "Panel144"
        Me.Panel144.Size = New System.Drawing.Size(636, 25)
        Me.Panel144.TabIndex = 6
        '
        'Button71
        '
        Me.Button71.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button71.Location = New System.Drawing.Point(558, 1)
        Me.Button71.Name = "Button71"
        Me.Button71.Size = New System.Drawing.Size(75, 23)
        Me.Button71.TabIndex = 3
        Me.Button71.Text = "Copy User"
        Me.Button71.UseVisualStyleBackColor = True
        Me.Button71.Visible = False
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "60", "120", "180", "240", "300", "600", "900", "1200", "1800", "3600"})
        Me.ComboBox1.Location = New System.Drawing.Point(81, 3)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(87, 21)
        Me.ComboBox1.TabIndex = 1
        Me.ComboBox1.Text = "30"
        '
        'Label165
        '
        Me.Label165.AutoSize = True
        Me.Label165.Location = New System.Drawing.Point(3, 6)
        Me.Label165.Name = "Label165"
        Me.Label165.Size = New System.Drawing.Size(73, 13)
        Me.Label165.TabIndex = 0
        Me.Label165.Text = "Interval (secs)"
        '
        'Panel145
        '
        Me.Panel145.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel145.Controls.Add(Me.Button72)
        Me.Panel145.Controls.Add(Me.TextBox5)
        Me.Panel145.Controls.Add(Me.Label166)
        Me.Panel145.Location = New System.Drawing.Point(6, 43)
        Me.Panel145.Name = "Panel145"
        Me.Panel145.Size = New System.Drawing.Size(636, 25)
        Me.Panel145.TabIndex = 5
        '
        'Button72
        '
        Me.Button72.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button72.Location = New System.Drawing.Point(558, 1)
        Me.Button72.Name = "Button72"
        Me.Button72.Size = New System.Drawing.Size(75, 23)
        Me.Button72.TabIndex = 2
        Me.Button72.Text = "Copy User"
        Me.Button72.UseVisualStyleBackColor = True
        Me.Button72.Visible = False
        '
        'TextBox5
        '
        Me.TextBox5.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox5.Location = New System.Drawing.Point(81, 3)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(472, 20)
        Me.TextBox5.TabIndex = 1
        '
        'Label166
        '
        Me.Label166.AutoSize = True
        Me.Label166.Location = New System.Drawing.Point(3, 6)
        Me.Label166.Name = "Label166"
        Me.Label166.Size = New System.Drawing.Size(38, 13)
        Me.Label166.TabIndex = 0
        Me.Label166.Text = "Secret"
        '
        'Label167
        '
        Me.Label167.AutoSize = True
        Me.Label167.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label167.Location = New System.Drawing.Point(3, 3)
        Me.Label167.Name = "Label167"
        Me.Label167.Size = New System.Drawing.Size(44, 13)
        Me.Label167.TabIndex = 0
        Me.Label167.Text = "Server"
        '
        'Panel146
        '
        Me.Panel146.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel146.Controls.Add(Me.Panel147)
        Me.Panel146.Controls.Add(Me.Panel148)
        Me.Panel146.Controls.Add(Me.Panel152)
        Me.Panel146.Controls.Add(Me.Panel153)
        Me.Panel146.Controls.Add(Me.Label178)
        Me.Panel146.Location = New System.Drawing.Point(18, 73)
        Me.Panel146.Name = "Panel146"
        Me.Panel146.Size = New System.Drawing.Size(645, 144)
        Me.Panel146.TabIndex = 2
        '
        'Panel147
        '
        Me.Panel147.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel147.Controls.Add(Me.TextBox6)
        Me.Panel147.Controls.Add(Me.Label174)
        Me.Panel147.Location = New System.Drawing.Point(6, 76)
        Me.Panel147.Name = "Panel147"
        Me.Panel147.Size = New System.Drawing.Size(636, 25)
        Me.Panel147.TabIndex = 8
        '
        'TextBox6
        '
        Me.TextBox6.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox6.Location = New System.Drawing.Point(81, 3)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.ReadOnly = True
        Me.TextBox6.Size = New System.Drawing.Size(472, 20)
        Me.TextBox6.TabIndex = 1
        '
        'Label174
        '
        Me.Label174.AutoSize = True
        Me.Label174.Location = New System.Drawing.Point(3, 6)
        Me.Label174.Name = "Label174"
        Me.Label174.Size = New System.Drawing.Size(74, 13)
        Me.Label174.TabIndex = 0
        Me.Label174.Text = "Base32Secret"
        '
        'Panel148
        '
        Me.Panel148.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel148.Controls.Add(Me.TextBox10)
        Me.Panel148.Controls.Add(Me.Label175)
        Me.Panel148.Controls.Add(Me.Button73)
        Me.Panel148.Location = New System.Drawing.Point(6, 102)
        Me.Panel148.Name = "Panel148"
        Me.Panel148.Size = New System.Drawing.Size(636, 25)
        Me.Panel148.TabIndex = 7
        '
        'TextBox10
        '
        Me.TextBox10.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox10.Location = New System.Drawing.Point(81, 3)
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.ReadOnly = True
        Me.TextBox10.Size = New System.Drawing.Size(472, 20)
        Me.TextBox10.TabIndex = 1
        '
        'Label175
        '
        Me.Label175.AutoSize = True
        Me.Label175.Location = New System.Drawing.Point(3, 6)
        Me.Label175.Name = "Label175"
        Me.Label175.Size = New System.Drawing.Size(35, 13)
        Me.Label175.TabIndex = 0
        Me.Label175.Text = "Code:"
        '
        'Button73
        '
        Me.Button73.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button73.BackColor = System.Drawing.Color.LightGreen
        Me.Button73.Location = New System.Drawing.Point(558, 1)
        Me.Button73.Name = "Button73"
        Me.Button73.Size = New System.Drawing.Size(75, 23)
        Me.Button73.TabIndex = 0
        Me.Button73.Text = "Get Code"
        Me.Button73.UseVisualStyleBackColor = False
        '
        'Panel152
        '
        Me.Panel152.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel152.Controls.Add(Me.TextBox12)
        Me.Panel152.Controls.Add(Me.Label176)
        Me.Panel152.Location = New System.Drawing.Point(6, 24)
        Me.Panel152.Name = "Panel152"
        Me.Panel152.Size = New System.Drawing.Size(636, 25)
        Me.Panel152.TabIndex = 6
        '
        'Label176
        '
        Me.Label176.AutoSize = True
        Me.Label176.Location = New System.Drawing.Point(4, 6)
        Me.Label176.Name = "Label176"
        Me.Label176.Size = New System.Drawing.Size(44, 13)
        Me.Label176.TabIndex = 0
        Me.Label176.Text = "Counter"
        '
        'Panel153
        '
        Me.Panel153.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel153.Controls.Add(Me.Button74)
        Me.Panel153.Controls.Add(Me.TextBox11)
        Me.Panel153.Controls.Add(Me.Label177)
        Me.Panel153.Location = New System.Drawing.Point(6, 50)
        Me.Panel153.Name = "Panel153"
        Me.Panel153.Size = New System.Drawing.Size(636, 25)
        Me.Panel153.TabIndex = 5
        '
        'Button74
        '
        Me.Button74.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button74.Location = New System.Drawing.Point(558, 1)
        Me.Button74.Name = "Button74"
        Me.Button74.Size = New System.Drawing.Size(75, 23)
        Me.Button74.TabIndex = 2
        Me.Button74.Text = "Generate"
        Me.Button74.UseVisualStyleBackColor = True
        '
        'TextBox11
        '
        Me.TextBox11.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox11.Location = New System.Drawing.Point(81, 3)
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.Size = New System.Drawing.Size(472, 20)
        Me.TextBox11.TabIndex = 1
        '
        'Label177
        '
        Me.Label177.AutoSize = True
        Me.Label177.Location = New System.Drawing.Point(3, 6)
        Me.Label177.Name = "Label177"
        Me.Label177.Size = New System.Drawing.Size(38, 13)
        Me.Label177.TabIndex = 0
        Me.Label177.Text = "Secret"
        '
        'Label178
        '
        Me.Label178.AutoSize = True
        Me.Label178.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label178.Location = New System.Drawing.Point(3, 3)
        Me.Label178.Name = "Label178"
        Me.Label178.Size = New System.Drawing.Size(39, 13)
        Me.Label178.TabIndex = 0
        Me.Label178.Text = "Client"
        '
        'TextBox12
        '
        Me.TextBox12.Location = New System.Drawing.Point(81, 3)
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.Size = New System.Drawing.Size(87, 20)
        Me.TextBox12.TabIndex = 2
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(803, 711)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.Panel4)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.MinimumSize = New System.Drawing.Size(500, 400)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "SysCrypto"
        Me.Panel1.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout
        Me.FlowLayoutPanel1.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout
        Me.Panel7.ResumeLayout(False)
        Me.Panel36.ResumeLayout(False)
        Me.Panel36.PerformLayout
        Me.Panel33.ResumeLayout(False)
        Me.Panel33.PerformLayout
        Me.Panel9.ResumeLayout(False)
        Me.Panel9.PerformLayout
        Me.Panel8.ResumeLayout(False)
        Me.Panel8.PerformLayout
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage_SysInfo.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout
        Me.TabControl4.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.Panel78.ResumeLayout(False)
        Me.FlowLayoutPanel6.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.Panel86.ResumeLayout(False)
        Me.FlowLayoutPanel7.ResumeLayout(False)
        Me.TabPage3.ResumeLayout(False)
        Me.Panel87.ResumeLayout(False)
        Me.FlowLayoutPanel8.ResumeLayout(False)
        Me.TabPage4.ResumeLayout(False)
        Me.Panel88.ResumeLayout(False)
        Me.FlowLayoutPanel9.ResumeLayout(False)
        Me.TabPage5.ResumeLayout(False)
        Me.Panel89.ResumeLayout(False)
        Me.FlowLayoutPanel10.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout
        Me.TabPage_Encoding.ResumeLayout(False)
        Me.TabPage_Encoding.PerformLayout
        Me.Panel29.ResumeLayout(False)
        Me.Panel29.PerformLayout
        Me.TabControl_Encoding_StringOrFile.ResumeLayout(False)
        Me.TabPage_String.ResumeLayout(False)
        Me.TabPage_String.PerformLayout
        Me.Panel27.ResumeLayout(False)
        Me.Panel27.PerformLayout
        Me.TabPage_File.ResumeLayout(False)
        Me.Panel43.ResumeLayout(False)
        Me.Panel43.PerformLayout
        Me.Panel35.ResumeLayout(False)
        Me.Panel35.PerformLayout
        Me.Panel28.ResumeLayout(False)
        Me.Panel28.PerformLayout
        Me.Panel30.ResumeLayout(False)
        Me.Panel30.PerformLayout
        Me.Panel32.ResumeLayout(False)
        Me.Panel32.PerformLayout
        Me.Panel26.ResumeLayout(False)
        Me.Panel26.PerformLayout
        Me.Panel71.ResumeLayout(False)
        Me.Panel71.PerformLayout
        Me.Panel70.ResumeLayout(False)
        Me.Panel70.PerformLayout
        Me.Panel31.ResumeLayout(False)
        Me.Panel31.PerformLayout
        Me.TabPage_RSA.ResumeLayout(False)
        Me.TabPage_RSA.PerformLayout
        Me.Panel20.ResumeLayout(False)
        Me.FlowLayoutPanel4.ResumeLayout(False)
        Me.Panel21.ResumeLayout(False)
        Me.Panel21.PerformLayout
        Me.Panel24.ResumeLayout(False)
        Me.Panel24.PerformLayout
        Me.Panel18.ResumeLayout(False)
        Me.Panel19.ResumeLayout(False)
        Me.Panel19.PerformLayout
        Me.FlowLayoutPanel3.ResumeLayout(False)
        Me.Panel10.ResumeLayout(False)
        Me.Panel40.ResumeLayout(False)
        Me.Panel40.PerformLayout
        Me.Panel34.ResumeLayout(False)
        Me.Panel34.PerformLayout
        Me.Panel42.ResumeLayout(False)
        Me.Panel42.PerformLayout
        Me.Panel25.ResumeLayout(False)
        Me.Panel25.PerformLayout
        Me.Panel23.ResumeLayout(False)
        Me.Panel23.PerformLayout
        Me.Panel11.ResumeLayout(False)
        Me.Panel11.PerformLayout
        Me.Panel12.ResumeLayout(False)
        Me.Panel12.PerformLayout
        Me.Panel13.ResumeLayout(False)
        Me.Panel13.PerformLayout
        Me.Panel14.ResumeLayout(False)
        Me.Panel14.PerformLayout
        Me.Panel15.ResumeLayout(False)
        Me.FlowLayoutPanel2.ResumeLayout(False)
        Me.Panel16.ResumeLayout(False)
        Me.Panel16.PerformLayout
        Me.Panel17.ResumeLayout(False)
        Me.Panel17.PerformLayout
        Me.TabPage_AES.ResumeLayout(False)
        Me.TabPage_AES.PerformLayout
        Me.TabControl3.ResumeLayout(False)
        Me.TabPage9.ResumeLayout(False)
        Me.TabPage9.PerformLayout
        Me.TabPage10.ResumeLayout(False)
        Me.Panel41.ResumeLayout(False)
        Me.Panel41.PerformLayout
        Me.Panel39.ResumeLayout(False)
        Me.FlowLayoutPanel5.ResumeLayout(False)
        Me.Panel38.ResumeLayout(False)
        Me.Panel38.PerformLayout
        Me.TabPage_LicenseGeneration.ResumeLayout(False)
        Me.TabControl2.ResumeLayout(False)
        Me.TabPage_LICFile.ResumeLayout(False)
        Me.TabPage_LICFile.PerformLayout
        Me.Panel69.ResumeLayout(False)
        Me.Panel69.PerformLayout
        Me.TabControl_License_Lic_ImportedData.ResumeLayout(False)
        Me.TabPage_DataFields.ResumeLayout(False)
        Me.Panel68.ResumeLayout(False)
        Me.Panel68.PerformLayout
        Me.Panel67.ResumeLayout(False)
        Me.Panel67.PerformLayout
        Me.Panel66.ResumeLayout(False)
        Me.Panel66.PerformLayout
        Me.Panel65.ResumeLayout(False)
        Me.Panel65.PerformLayout
        Me.Panel64.ResumeLayout(False)
        Me.Panel64.PerformLayout
        Me.Panel63.ResumeLayout(False)
        Me.Panel63.PerformLayout
        Me.Panel62.ResumeLayout(False)
        Me.Panel62.PerformLayout
        Me.Panel60.ResumeLayout(False)
        Me.Panel60.PerformLayout
        Me.Panel61.ResumeLayout(False)
        Me.Panel61.PerformLayout
        Me.Panel_License_Lic_Verification.ResumeLayout(False)
        Me.Panel_License_Lic_Verification.PerformLayout
        Me.Panel54.ResumeLayout(False)
        Me.Panel54.PerformLayout
        Me.Panel50.ResumeLayout(False)
        Me.Panel50.PerformLayout
        Me.Panel51.ResumeLayout(False)
        Me.Panel51.PerformLayout
        Me.Panel52.ResumeLayout(False)
        Me.Panel52.PerformLayout
        Me.Panel53.ResumeLayout(False)
        Me.Panel53.PerformLayout
        Me.Panel59.ResumeLayout(False)
        Me.Panel59.PerformLayout
        Me.Panel58.ResumeLayout(False)
        Me.Panel58.PerformLayout
        Me.Panel57.ResumeLayout(False)
        Me.Panel57.PerformLayout
        Me.Panel56.ResumeLayout(False)
        Me.Panel56.PerformLayout
        Me.Panel55.ResumeLayout(False)
        Me.Panel55.PerformLayout
        Me.Panel49.ResumeLayout(False)
        Me.Panel49.PerformLayout
        Me.Panel47.ResumeLayout(False)
        Me.Panel47.PerformLayout
        Me.FlowLayoutPanel_License_Lic_Verification.ResumeLayout(False)
        CType(Me.DataGridView_License_Lic_Signature, System.ComponentModel.ISupportInitialize).EndInit
        Me.Panel45.ResumeLayout(False)
        Me.Panel48.ResumeLayout(False)
        Me.Panel48.PerformLayout
        Me.FlowLayoutPanel_License_Lic_AddDataFields.ResumeLayout(False)
        CType(Me.DataGridView_License_Lic_Data, System.ComponentModel.ISupportInitialize).EndInit
        Me.TabPage11.ResumeLayout(False)
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox9.PerformLayout
        Me.Panel134.ResumeLayout(False)
        Me.Panel134.PerformLayout
        Me.Panel151.ResumeLayout(False)
        Me.Panel151.PerformLayout
        Me.Panel139.ResumeLayout(False)
        Me.Panel139.PerformLayout
        Me.Panel135.ResumeLayout(False)
        Me.Panel135.PerformLayout
        Me.Panel137.ResumeLayout(False)
        Me.Panel137.PerformLayout
        Me.Panel138.ResumeLayout(False)
        Me.Panel138.PerformLayout
        Me.Panel130.ResumeLayout(False)
        Me.Panel130.PerformLayout
        Me.Panel150.ResumeLayout(False)
        Me.Panel150.PerformLayout
        Me.Panel133.ResumeLayout(False)
        Me.Panel133.PerformLayout
        Me.Panel132.ResumeLayout(False)
        Me.Panel132.PerformLayout
        Me.Panel131.ResumeLayout(False)
        Me.Panel131.PerformLayout
        Me.TabPage_Verify.ResumeLayout(False)
        Me.TabPage_Verify.PerformLayout
        Me.Panel85.ResumeLayout(False)
        Me.Panel85.PerformLayout
        Me.Panel82.ResumeLayout(False)
        Me.Panel82.PerformLayout
        Me.Panel83.ResumeLayout(False)
        Me.Panel83.PerformLayout
        Me.Panel84.ResumeLayout(False)
        Me.Panel84.PerformLayout
        Me.Panel81.ResumeLayout(False)
        Me.Panel81.PerformLayout
        Me.Panel79.ResumeLayout(False)
        Me.Panel79.PerformLayout
        Me.Panel80.ResumeLayout(False)
        Me.Panel80.PerformLayout
        Me.Panel76.ResumeLayout(False)
        Me.Panel76.PerformLayout
        Me.Panel77.ResumeLayout(False)
        Me.Panel77.PerformLayout
        Me.Panel74.ResumeLayout(False)
        Me.Panel74.PerformLayout
        Me.Panel75.ResumeLayout(False)
        Me.Panel75.PerformLayout
        Me.Panel72.ResumeLayout(False)
        Me.Panel72.PerformLayout
        Me.Panel73.ResumeLayout(False)
        Me.Panel73.PerformLayout
        Me.TabPage6.ResumeLayout(False)
        Me.TabControl5.ResumeLayout(False)
        Me.TabPage7.ResumeLayout(False)
        Me.TabPage7.PerformLayout
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout
        Me.Panel113.ResumeLayout(False)
        Me.Panel113.PerformLayout
        Me.Panel112.ResumeLayout(False)
        Me.Panel112.PerformLayout
        Me.Panel111.ResumeLayout(False)
        Me.Panel111.PerformLayout
        Me.Panel110.ResumeLayout(False)
        Me.Panel110.PerformLayout
        Me.Panel109.ResumeLayout(False)
        Me.Panel109.PerformLayout
        Me.Panel107.ResumeLayout(False)
        Me.Panel107.PerformLayout
        Me.Panel108.ResumeLayout(False)
        Me.Panel108.PerformLayout
        Me.Panel106.ResumeLayout(False)
        Me.Panel106.PerformLayout
        Me.Panel105.ResumeLayout(False)
        Me.Panel105.PerformLayout
        Me.Panel104.ResumeLayout(False)
        Me.Panel104.PerformLayout
        Me.Panel103.ResumeLayout(False)
        Me.Panel103.PerformLayout
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout
        Me.Panel94.ResumeLayout(False)
        Me.Panel94.PerformLayout
        Me.Panel102.ResumeLayout(False)
        Me.Panel102.PerformLayout
        Me.Panel101.ResumeLayout(False)
        Me.Panel101.PerformLayout
        Me.Panel100.ResumeLayout(False)
        Me.Panel100.PerformLayout
        Me.Panel99.ResumeLayout(False)
        Me.Panel99.PerformLayout
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout
        Me.Panel91.ResumeLayout(False)
        Me.Panel92.ResumeLayout(False)
        Me.Panel92.PerformLayout
        Me.Panel93.ResumeLayout(False)
        Me.Panel93.PerformLayout
        Me.Panel95.ResumeLayout(False)
        Me.Panel95.PerformLayout
        Me.Panel96.ResumeLayout(False)
        Me.Panel96.PerformLayout
        Me.Panel97.ResumeLayout(False)
        Me.Panel97.PerformLayout
        Me.Panel98.ResumeLayout(False)
        Me.Panel98.PerformLayout
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout
        Me.FlowLayoutPanel11.ResumeLayout(False)
        Me.FlowLayoutPanel11.PerformLayout
        Me.TabPage8.ResumeLayout(False)
        Me.TabPage8.PerformLayout
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox8.PerformLayout
        Me.Panel129.ResumeLayout(False)
        Me.Panel129.PerformLayout
        Me.Panel128.ResumeLayout(False)
        Me.Panel128.PerformLayout
        Me.Panel127.ResumeLayout(False)
        Me.Panel127.PerformLayout
        Me.Panel125.ResumeLayout(False)
        Me.Panel125.PerformLayout
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout
        Me.Panel121.ResumeLayout(False)
        Me.Panel121.PerformLayout
        Me.Panel120.ResumeLayout(False)
        Me.Panel120.PerformLayout
        Me.Panel136.ResumeLayout(False)
        Me.Panel136.PerformLayout
        Me.Panel119.ResumeLayout(False)
        Me.Panel114.ResumeLayout(False)
        Me.Panel114.PerformLayout
        Me.Panel115.ResumeLayout(False)
        Me.Panel115.PerformLayout
        Me.Panel116.ResumeLayout(False)
        Me.Panel116.PerformLayout
        Me.Panel122.ResumeLayout(False)
        Me.Panel122.PerformLayout
        Me.Panel117.ResumeLayout(False)
        Me.Panel117.PerformLayout
        Me.Panel123.ResumeLayout(False)
        Me.Panel123.PerformLayout
        Me.Panel118.ResumeLayout(False)
        Me.Panel118.PerformLayout
        Me.Panel124.ResumeLayout(False)
        Me.Panel124.PerformLayout
        Me.GroupBox10.ResumeLayout(False)
        Me.GroupBox10.PerformLayout
        Me.Panel140.ResumeLayout(False)
        Me.Panel140.PerformLayout
        Me.Panel141.ResumeLayout(False)
        Me.Panel141.PerformLayout
        Me.Panel142.ResumeLayout(False)
        Me.Panel142.PerformLayout
        Me.Panel143.ResumeLayout(False)
        Me.Panel143.PerformLayout
        Me.Panel144.ResumeLayout(False)
        Me.Panel144.PerformLayout
        Me.Panel145.ResumeLayout(False)
        Me.Panel145.PerformLayout
        Me.Panel146.ResumeLayout(False)
        Me.Panel146.PerformLayout
        Me.Panel147.ResumeLayout(False)
        Me.Panel147.PerformLayout
        Me.Panel148.ResumeLayout(False)
        Me.Panel148.PerformLayout
        Me.Panel152.ResumeLayout(False)
        Me.Panel152.PerformLayout
        Me.Panel153.ResumeLayout(False)
        Me.Panel153.PerformLayout
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Button_Test As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents TextBox_InputData As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents FlowLayoutPanel1 As FlowLayoutPanel
    Friend WithEvents Button_Encrypt As Button
    Friend WithEvents Button_Decrypt As Button
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Panel4 As Panel
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents FileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Panel5 As Panel
    Friend WithEvents Panel6 As Panel
    Friend WithEvents TextBox_OutputData As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Panel7 As Panel
    Friend WithEvents Panel8 As Panel
    Friend WithEvents TextBox_EncryptionKey As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Panel9 As Panel
    Friend WithEvents TextBox_IV As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage_AES As TabPage
    Friend WithEvents TabPage_RSA As TabPage
    Friend WithEvents FlowLayoutPanel3 As FlowLayoutPanel
    Friend WithEvents Button_RSA_GenerateKeys As Button
    Friend WithEvents Panel10 As Panel
    Friend WithEvents Panel11 As Panel
    Friend WithEvents TextBox_RSA_PublicKey As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Panel12 As Panel
    Friend WithEvents TextBox_RSA_PrivateKey As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Panel13 As Panel
    Friend WithEvents Panel14 As Panel
    Friend WithEvents TextBox_RSA_InputData As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Panel15 As Panel
    Friend WithEvents FlowLayoutPanel2 As FlowLayoutPanel
    Friend WithEvents Button_RSA_Encrypt_WithPublic As Button
    Friend WithEvents Panel16 As Panel
    Friend WithEvents Panel17 As Panel
    Friend WithEvents TextBox_RSA_OutputData As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Button_RSA_Decrypt_WithPrivate As Button
    Friend WithEvents Button_RSA_Sign_WithPrivate As Button
    Friend WithEvents Button_RSA_Verify_WithPublic As Button
    Friend WithEvents Panel18 As Panel
    Friend WithEvents Panel19 As Panel
    Friend WithEvents TextBox_RSA_HashInput As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Button_RSA_HashInput As Button
    Friend WithEvents Panel20 As Panel
    Friend WithEvents FlowLayoutPanel4 As FlowLayoutPanel
    Friend WithEvents Panel21 As Panel
    Friend WithEvents TextBox_RSA_Signature As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Panel22 As Panel
    Friend WithEvents Panel24 As Panel
    Friend WithEvents TextBox_RSA_MatchingSignatures As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Button_RSA_VerifyClear As Button
    Friend WithEvents Button_RSA_HashInputClear As Button
    Friend WithEvents Button_RSA_GenerateKeysClear As Button
    Friend WithEvents Button_RSA_SwapInputOutpu As Button
    Friend WithEvents Button_RSA_InputDataClear As Button
    Friend WithEvents Button_RSA_OutputDataClear As Button
    Friend WithEvents Button_RSA_SwapInputOutput As Button
    Friend WithEvents Button_AES_SwapInputOutput As Button
    Friend WithEvents Button_AES_CelarInputOutput As Button
    Friend WithEvents Panel23 As Panel
    Friend WithEvents ComboBox_RSA_KeySize As ComboBox
    Friend WithEvents Label11 As Label
    Friend WithEvents Button_RSA_Encrypt_WithPrivate As Button
    Friend WithEvents Panel25 As Panel
    Friend WithEvents ComboBox_RSA_PreviousPairs As ComboBox
    Friend WithEvents Label18 As Label
    Friend WithEvents TabPage_Encoding As TabPage
    Friend WithEvents Panel42 As Panel
    Friend WithEvents TextBox_RSA_KeyPairDescription As TextBox
    Friend WithEvents Label32 As Label
    Friend WithEvents Button_RSA_ExportGeneratedKeyPairs As Button
    Friend WithEvents Label33 As Label
    Friend WithEvents Button_AES_KeyGenHash As Button
    Friend WithEvents Button_AES_Export As Button
    Friend WithEvents Button_AES_Clear As Button
    Friend WithEvents Button_AES_ConvertIVToHash As Button
    Friend WithEvents Button_AES_ConvertKeyToHash As Button
    Friend WithEvents TabPage_SysInfo As TabPage
    Friend WithEvents TabPage_LicenseGeneration As TabPage
    Friend WithEvents TabControl3 As TabControl
    Friend WithEvents TabPage9 As TabPage
    Friend WithEvents TabPage10 As TabPage
    Friend WithEvents Panel34 As Panel
    Friend WithEvents TextBox_RSA_Seed As TextBox
    Friend WithEvents CheckBox_RSA_EnableSeed As CheckBox
    Friend WithEvents Label19 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Panel26 As Panel
    Friend WithEvents Panel31 As Panel
    Friend WithEvents Button_Encoding_RandomString As Button
    Friend WithEvents TextBox_Encoding_RandomString As TextBox
    Friend WithEvents Label24 As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents TextBox_Encoding_RandomStringLength As TextBox
    Friend WithEvents Panel28 As Panel
    Friend WithEvents Button_Encoding_StringToHash As Button
    Friend WithEvents TextBox_Encoding_HashedString As TextBox
    Friend WithEvents Label25 As Label
    Friend WithEvents Panel27 As Panel
    Friend WithEvents TextBox_Encoding_StringToHash As TextBox
    Friend WithEvents Label22 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Panel29 As Panel
    Friend WithEvents Panel30 As Panel
    Friend WithEvents Button_Encoding_EncodeData As Button
    Friend WithEvents TextBox_Encoding_EncodedData As TextBox
    Friend WithEvents Label27 As Label
    Friend WithEvents Panel32 As Panel
    Friend WithEvents TextBox_Encoding_InputData As TextBox
    Friend WithEvents Label28 As Label
    Friend WithEvents Label31 As Label
    Friend WithEvents Panel35 As Panel
    Friend WithEvents Button_Encoding_DecodeData As Button
    Friend WithEvents TextBox_Encoding_DecodedData As TextBox
    Friend WithEvents Label34 As Label
    Friend WithEvents Panel33 As Panel
    Friend WithEvents CheckBox_AES_Seed As CheckBox
    Friend WithEvents Button_AES_SeedGenerate As Button
    Friend WithEvents TextBox_AES_Seed As TextBox
    Friend WithEvents Panel36 As Panel
    Friend WithEvents CheckBox_AES_Salt As CheckBox
    Friend WithEvents Button_AES_SaltGenerate As Button
    Friend WithEvents TextBox_AES_Salt As TextBox
    Friend WithEvents Button_RSA_PublicKey_Copy As Button
    Friend WithEvents Button_RSA_PrivateKey_Copy As Button
    Friend WithEvents Panel37 As Panel
    Friend WithEvents Button_AES_ClearInput As Button
    Friend WithEvents Button_AES_ClearOutput As Button
    Friend WithEvents Panel38 As Panel
    Friend WithEvents TextBox_AES_BrowsedFilePath As TextBox
    Friend WithEvents Label29 As Label
    Friend WithEvents Button_AES_BrowseForFile As Button
    Friend WithEvents Panel39 As Panel
    Friend WithEvents FlowLayoutPanel5 As FlowLayoutPanel
    Friend WithEvents Button_AES_Files_Encrypt As Button
    Friend WithEvents Button_AES_Files_Decrypt As Button
    Friend WithEvents Button_AES_Files_SwapInputOutput As Button
    Friend WithEvents Button_AES_Files_ClearInputOutput As Button
    Friend WithEvents Panel41 As Panel
    Friend WithEvents TextBox_AES_OutputFile As TextBox
    Friend WithEvents Label35 As Label
    Friend WithEvents Button_AES_FolderToOutput As Button
    Friend WithEvents Panel40 As Panel
    Friend WithEvents CheckBox_RSA_Salt As CheckBox
    Friend WithEvents TextBox_RSA_Salt As TextBox
    Friend WithEvents Button_RSA_PreviousPairsEmpty As Button
    Friend WithEvents Button_RSA_HashInputAndSalt As Button
    Friend WithEvents TabControl_Encoding_StringOrFile As TabControl
    Friend WithEvents TabPage_String As TabPage
    Friend WithEvents TabPage_File As TabPage
    Friend WithEvents Panel43 As Panel
    Friend WithEvents TextBox_Encoding_FilePathToHash As TextBox
    Friend WithEvents Label30 As Label
    Friend WithEvents Button_Encoding_BrowseForFileToHash As Button
    Friend WithEvents Button_Encoding_RandomStringCopy As Button
    Friend WithEvents Button_Encoding_HashedStringCopy As Button
    Friend WithEvents Button_Encoding_Base64StringEncodedCopy As Button
    Friend WithEvents Panel44 As Panel
    Friend WithEvents Button_RSA_SignatureCopy As Button
    Friend WithEvents LinkLabel1 As LinkLabel
    Friend WithEvents Button2 As Button
    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents ListBox2 As ListBox
    Friend WithEvents Button5 As Button
    Friend WithEvents Panel70 As Panel
    Friend WithEvents Button6 As Button
    Friend WithEvents Label63 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Button_Encoding_GenerateGUID As Button
    Friend WithEvents TextBox_Encoding_GenerateGUID As TextBox
    Friend WithEvents Label64 As Label
    Friend WithEvents Panel71 As Panel
    Friend WithEvents ComboBox_Encoding_TimestampGenerate As ComboBox
    Friend WithEvents Button8 As Button
    Friend WithEvents Button_Encoding_TimestampGenerate As Button
    Friend WithEvents TextBox_Encoding_TimestampGenerate As TextBox
    Friend WithEvents Label66 As Label
    Friend WithEvents ComboBox_Encoding_EncodeOrDecodeIn As ComboBox
    Friend WithEvents Button11 As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents Button12 As Button
    Friend WithEvents TabControl2 As TabControl
    Friend WithEvents TabPage_LICFile As TabPage
    Friend WithEvents Panel69 As Panel
    Friend WithEvents TextBox_License_Lic_Imported_DataHashed As TextBox
    Friend WithEvents Label62 As Label
    Friend WithEvents TabControl_License_Lic_ImportedData As TabControl
    Friend WithEvents TabPage_DataFields As TabPage
    Friend WithEvents Panel68 As Panel
    Friend WithEvents TextBox_License_Lic_Imported_DataFields As TextBox
    Friend WithEvents Panel67 As Panel
    Friend WithEvents TextBox_License_Lic_ImportedPublicKeyFingerprint As TextBox
    Friend WithEvents Label61 As Label
    Friend WithEvents Panel66 As Panel
    Friend WithEvents TextBox_License_Lic_ImportedAlgorithm As TextBox
    Friend WithEvents Label60 As Label
    Friend WithEvents Button_License_Lic_CloseJSONLicFile As Button
    Friend WithEvents Panel65 As Panel
    Friend WithEvents TextBox_License_Lic_LICFilePath As TextBox
    Friend WithEvents Label59 As Label
    Friend WithEvents Panel64 As Panel
    Friend WithEvents TextBox_License_Lic_ImportedSignature As TextBox
    Friend WithEvents Label58 As Label
    Friend WithEvents Panel63 As Panel
    Friend WithEvents Button_License_Lic_VerifyImportedLicFile As Button
    Friend WithEvents TextBox_License_Lic_VerifyImportedLICFile As TextBox
    Friend WithEvents Label57 As Label
    Friend WithEvents Panel62 As Panel
    Friend WithEvents TextBox_License_Lic_ImportedSalt As TextBox
    Friend WithEvents Label56 As Label
    Friend WithEvents Panel60 As Panel
    Friend WithEvents TextBox_License_Lic_ImportedKeySize As TextBox
    Friend WithEvents Label54 As Label
    Friend WithEvents Panel61 As Panel
    Friend WithEvents TextBox_License_Lic_PastedPublicKey As TextBox
    Friend WithEvents Label55 As Label
    Friend WithEvents Button_License_Lic_ImportJSONLicFile As Button
    Friend WithEvents Label53 As Label
    Friend WithEvents Button_License_Lic_SaveFile As Button
    Friend WithEvents Label39 As Label
    Friend WithEvents Label38 As Label
    Friend WithEvents Panel46 As Panel
    Friend WithEvents Panel_License_Lic_Verification As Panel
    Friend WithEvents Panel54 As Panel
    Friend WithEvents Button_License_Lic_HashPublicKeyClear As Button
    Friend WithEvents Button_License_Lic_HashPublicKey As Button
    Friend WithEvents TextBox_License_Lic_HashPublicKey As TextBox
    Friend WithEvents Label52 As Label
    Friend WithEvents Label49 As Label
    Friend WithEvents Panel50 As Panel
    Friend WithEvents TextBox_License_Lic_KeySize As TextBox
    Friend WithEvents Label43 As Label
    Friend WithEvents Panel51 As Panel
    Friend WithEvents Button_License_Lic_CopyAllPublicKey As Button
    Friend WithEvents Button_License_Lic_CopyPublicKey As Button
    Friend WithEvents TextBox_License_Lic_PublicKey As TextBox
    Friend WithEvents Label44 As Label
    Friend WithEvents Panel52 As Panel
    Friend WithEvents Button_License_Lic_CopyAllPrivateKey As Button
    Friend WithEvents Button_License_Lic_CopyPrivateKey As Button
    Friend WithEvents TextBox_License_Lic_PrivateKey As TextBox
    Friend WithEvents Label45 As Label
    Friend WithEvents Panel53 As Panel
    Friend WithEvents TextBox_License_Lic_Salt As TextBox
    Friend WithEvents Label51 As Label
    Friend WithEvents Panel59 As Panel
    Friend WithEvents ComboBox_License_Lic_PreviousPairs As ComboBox
    Friend WithEvents Button_License_Lic_GenerateKeys As Button
    Friend WithEvents Label50 As Label
    Friend WithEvents Panel58 As Panel
    Friend WithEvents TextBox_License_Lic_DataOnlyFields As TextBox
    Friend WithEvents Panel57 As Panel
    Friend WithEvents Button_License_Lic_Verify_Clear As Button
    Friend WithEvents Button_License_Lic_Verify As Button
    Friend WithEvents TextBox_License_Lic_Verified As TextBox
    Friend WithEvents Label48 As Label
    Friend WithEvents Panel56 As Panel
    Friend WithEvents Button_License_Lic_SignIt_Clear As Button
    Friend WithEvents Button_License_Lic_SignIt As Button
    Friend WithEvents TextBox_License_Lic_Signature As TextBox
    Friend WithEvents Label47 As Label
    Friend WithEvents Panel55 As Panel
    Friend WithEvents Button_License_Lic_HashDataFields_Clear As Button
    Friend WithEvents Button_License_Lic_HashDataFields As Button
    Friend WithEvents TextBox_License_Lic_HashDataFields As TextBox
    Friend WithEvents Label46 As Label
    Friend WithEvents Panel49 As Panel
    Friend WithEvents Button_License_Lic_Verify_DefaultSignatureNodeName As Button
    Friend WithEvents TextBox_License_Lic_Verify_SignatureNodeName As TextBox
    Friend WithEvents Label42 As Label
    Friend WithEvents Panel47 As Panel
    Friend WithEvents Button_License_Lic_Verify_DefaultJSONNodeName As Button
    Friend WithEvents TextBox_License_Lic_Verify_JSONNodeName As TextBox
    Friend WithEvents Label41 As Label
    Friend WithEvents FlowLayoutPanel_License_Lic_Verification As FlowLayoutPanel
    Friend WithEvents Button_License_Lic_Verify_AddSignatureRow As Button
    Friend WithEvents Button_License_Lic_Verify_AddRow As Button
    Friend WithEvents Button_License_Lic_Verify_AddCommonRows As Button
    Friend WithEvents Button_License_Lic_Verify_DeleteSelected As Button
    Friend WithEvents Button_License_Lic_Verify_Up As Button
    Friend WithEvents Button_License_Lic_Verify_Down As Button
    Friend WithEvents Button_License_Lic_Verify_AutoSort As Button
    Friend WithEvents DataGridView_License_Lic_Signature As DataGridView
    Friend WithEvents Label37 As Label
    Friend WithEvents CheckBox_License_Lic_AddSignature As CheckBox
    Friend WithEvents Button_License_Lic_Preview As Button
    Friend WithEvents Label36 As Label
    Friend WithEvents Panel45 As Panel
    Friend WithEvents Panel48 As Panel
    Friend WithEvents Button_License_Lic_Data_JSONNodeNameDefault As Button
    Friend WithEvents TextBox_License_Lic_Data_JSONNodeName As TextBox
    Friend WithEvents Label40 As Label
    Friend WithEvents FlowLayoutPanel_License_Lic_AddDataFields As FlowLayoutPanel
    Friend WithEvents Button_License_Lic_AddRow As Button
    Friend WithEvents Button_License_Lic_Data_AddCommonRows As Button
    Friend WithEvents Button_License_Lic_DeleteSelected As Button
    Friend WithEvents Button_License_Lic_Data_Up As Button
    Friend WithEvents Button_License_Lic_Data_Down As Button
    Friend WithEvents Button_License_Lic_Data_AutoSort As Button
    Friend WithEvents DataGridView_License_Lic_Data As DataGridView
    Friend WithEvents DataName As DataGridViewTextBoxColumn
    Friend WithEvents DataValue As DataGridViewTextBoxColumn
    Friend WithEvents TabPage_ProductSerial As TabPage
    Friend WithEvents Button7 As Button
    Friend WithEvents ListBox3 As ListBox
    Friend WithEvents Button13 As Button
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents FlowLayoutPanel6 As FlowLayoutPanel
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Button10 As Button
    Friend WithEvents Button14 As Button
    Friend WithEvents Button15 As Button
    Friend WithEvents Button16 As Button
    Friend WithEvents Button17 As Button
    Friend WithEvents Button18 As Button
    Friend WithEvents Button19 As Button
    Friend WithEvents Button20 As Button
    Friend WithEvents Button21 As Button
    Friend WithEvents Button22 As Button
    Friend WithEvents Button23 As Button
    Friend WithEvents Button24 As Button
    Friend WithEvents Button25 As Button
    Friend WithEvents Button26 As Button
    Friend WithEvents Button27 As Button
    Friend WithEvents Button28 As Button
    Friend WithEvents Button29 As Button
    Friend WithEvents Button30 As Button
    Friend WithEvents Button31 As Button
    Friend WithEvents Button32 As Button
    Friend WithEvents Button33 As Button
    Friend WithEvents Button34 As Button
    Friend WithEvents Button35 As Button
    Friend WithEvents Panel78 As Panel
    Friend WithEvents Button36 As Button
    Friend WithEvents TabControl4 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents Panel86 As Panel
    Friend WithEvents FlowLayoutPanel7 As FlowLayoutPanel
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents Panel87 As Panel
    Friend WithEvents FlowLayoutPanel8 As FlowLayoutPanel
    Friend WithEvents TabPage4 As TabPage
    Friend WithEvents TabPage5 As TabPage
    Friend WithEvents Button37 As Button
    Friend WithEvents Button38 As Button
    Friend WithEvents Panel88 As Panel
    Friend WithEvents FlowLayoutPanel9 As FlowLayoutPanel
    Friend WithEvents Panel89 As Panel
    Friend WithEvents FlowLayoutPanel10 As FlowLayoutPanel
    Friend WithEvents Button39 As Button
    Friend WithEvents Button40 As Button
    Friend WithEvents Button41 As Button
    Friend WithEvents Button42 As Button
    Friend WithEvents Button43 As Button
    Friend WithEvents Button44 As Button
    Friend WithEvents Button45 As Button
    Friend WithEvents Button46 As Button
    Friend WithEvents Button47 As Button
    Friend WithEvents Button48 As Button
    Friend WithEvents Button49 As Button
    Friend WithEvents Button50 As Button
    Friend WithEvents Button51 As Button
    Friend WithEvents Button52 As Button
    Friend WithEvents Button53 As Button
    Friend WithEvents Button54 As Button
    Friend WithEvents Button55 As Button
    Friend WithEvents Button56 As Button
    Friend WithEvents Label80 As Label
    Friend WithEvents Button57 As Button
    Friend WithEvents Button_RSA_ImportGeneratedKeyPairs As Button
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents TabPage6 As TabPage
    Friend WithEvents TabControl5 As TabControl
    Friend WithEvents TabPage7 As TabPage
    Friend WithEvents TabPage8 As TabPage
    Friend WithEvents Label81 As Label
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents Label84 As Label
    Friend WithEvents Label83 As Label
    Friend WithEvents Label82 As Label
    Friend WithEvents FlowLayoutPanel11 As FlowLayoutPanel
    Friend WithEvents CheckBox1 As CheckBox
    Friend WithEvents CheckBox2 As CheckBox
    Friend WithEvents CheckBox3 As CheckBox
    Friend WithEvents TabPage_Verify As TabPage
    Friend WithEvents Label72 As Label
    Friend WithEvents Panel85 As Panel
    Friend WithEvents TextBox_Verify_SaltForSignature As TextBox
    Friend WithEvents Label79 As Label
    Friend WithEvents Panel82 As Panel
    Friend WithEvents TextBox_Verify_DataHashForSignature As TextBox
    Friend WithEvents Label76 As Label
    Friend WithEvents Panel83 As Panel
    Friend WithEvents TextBox_Verify_PrivateKeyForSignature As TextBox
    Friend WithEvents Label77 As Label
    Friend WithEvents Panel84 As Panel
    Friend WithEvents Button_LicenseGen_Verify_GetSignature As Button
    Friend WithEvents TextBox_Verify_Signature As TextBox
    Friend WithEvents Label78 As Label
    Friend WithEvents Panel81 As Panel
    Friend WithEvents Button_LicenseGen_Verify_Verify As Button
    Friend WithEvents TextBox_LicenseGen_Verify_Verified As TextBox
    Friend WithEvents Label75 As Label
    Friend WithEvents Panel79 As Panel
    Friend WithEvents TextBox_LicenseGen_Verify_DataHashForVerification As TextBox
    Friend WithEvents Label73 As Label
    Friend WithEvents Panel80 As Panel
    Friend WithEvents TextBox_LicenseGen_Verify_SignatureForVerification As TextBox
    Friend WithEvents Label74 As Label
    Friend WithEvents Panel76 As Panel
    Friend WithEvents TextBox_LicenseGen_Verify_SaltForVerification As TextBox
    Friend WithEvents Label70 As Label
    Friend WithEvents Panel77 As Panel
    Friend WithEvents TextBox_LicenseGen_Verify_PublicKeyForVerification As TextBox
    Friend WithEvents Label71 As Label
    Friend WithEvents Panel74 As Panel
    Friend WithEvents Button_LicenseGen_Verify_GetTestDataHash As Button
    Friend WithEvents Button_LicenseGen_Verify_CopyTestDataHash As Button
    Friend WithEvents TextBox_LicenseGen_Verify_TestDataHashed As TextBox
    Friend WithEvents Label68 As Label
    Friend WithEvents Panel75 As Panel
    Friend WithEvents TextBox_LicenseGen_Verify_TestData As TextBox
    Friend WithEvents Label69 As Label
    Friend WithEvents Panel72 As Panel
    Friend WithEvents Button_LicenseGen_Verify_GetMachineHash As Button
    Friend WithEvents Button_LicenseGen_Verify_CopyMachineHash As Button
    Friend WithEvents TextBox_LicenseGen_Verify_FingerPrintHash As TextBox
    Friend WithEvents Label67 As Label
    Friend WithEvents Panel73 As Panel
    Friend WithEvents Button_LicenseGen_Verify_GetMachineFingerprint As Button
    Friend WithEvents Button_LicenseGen_Verify_CopyMAchineFingerprint As Button
    Friend WithEvents TextBox_LicenseGen_Verify_MachineFingerprint As TextBox
    Friend WithEvents Label65 As Label
    Friend WithEvents CheckBox4 As CheckBox
    Friend WithEvents CheckBox5 As CheckBox
    Friend WithEvents CheckBox6 As CheckBox
    Friend WithEvents Label85 As Label
    Friend WithEvents ListBox_Demo1_Characteristics As ListBox
    Friend WithEvents Label86 As Label
    Friend WithEvents Button_Demo1_GenerateFingerprint As Button
    Friend WithEvents TextBox_Demo1_Fingerprint As TextBox
    Friend WithEvents Label87 As Label
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents Panel90 As Panel
    Friend WithEvents Button_Demo1_GenerateKeys As Button
    Friend WithEvents Panel91 As Panel
    Friend WithEvents Panel92 As Panel
    Friend WithEvents TextBox_Demo1_Salt As TextBox
    Friend WithEvents Panel93 As Panel
    Friend WithEvents TextBox_Demo1_Seed As TextBox
    Friend WithEvents Panel95 As Panel
    Friend WithEvents Button_Demo1_DeletePairs As Button
    Friend WithEvents ComboBox_Demo1_PreviousPairs As ComboBox
    Friend WithEvents Label89 As Label
    Friend WithEvents Panel96 As Panel
    Friend WithEvents Label90 As Label
    Friend WithEvents Panel97 As Panel
    Friend WithEvents Button_Demo1_PublicKeyCopy As Button
    Friend WithEvents TextBox_Demo1_PublicKey As TextBox
    Friend WithEvents Label91 As Label
    Friend WithEvents Panel98 As Panel
    Friend WithEvents Button_Demo1_PrivateKeyCopy As Button
    Friend WithEvents TextBox_Demo1_PrivateKey As TextBox
    Friend WithEvents Label92 As Label
    Friend WithEvents Label93 As Label
    Friend WithEvents Label95 As Label
    Friend WithEvents Label94 As Label
    Friend WithEvents TextBox_Demo1_KeySize As TextBox
    Friend WithEvents Label96 As Label
    Friend WithEvents Label88 As Label
    Friend WithEvents CheckBox_Demo1_ShowConcatenatedData As CheckBox
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents Label100 As Label
    Friend WithEvents Label99 As Label
    Friend WithEvents Panel100 As Panel
    Friend WithEvents TextBox_Demo1_FingerprintPlusExpiry As TextBox
    Friend WithEvents Label102 As Label
    Friend WithEvents Panel99 As Panel
    Friend WithEvents Label101 As Label
    Friend WithEvents Panel101 As Panel
    Friend WithEvents TextBox_Demo1_FingerprintPlusExpiryHash As TextBox
    Friend WithEvents Label103 As Label
    Friend WithEvents Panel102 As Panel
    Friend WithEvents Button58 As Button
    Friend WithEvents TextBox_Demo1_Signature As TextBox
    Friend WithEvents Label104 As Label
    Friend WithEvents Button59 As Button
    Friend WithEvents DateTimePicker1 As DateTimePicker
    Friend WithEvents CheckBox14 As CheckBox
    Friend WithEvents CheckBox13 As CheckBox
    Friend WithEvents CheckBox11 As CheckBox
    Friend WithEvents CheckBox10 As CheckBox
    Friend WithEvents CheckBox9 As CheckBox
    Friend WithEvents CheckBox8 As CheckBox
    Friend WithEvents CheckBox7 As CheckBox
    Friend WithEvents CheckBox15 As CheckBox
    Friend WithEvents Label_Demo1_SetExpiryValue As Label
    Friend WithEvents Label97 As Label
    Friend WithEvents Button61 As Button
    Friend WithEvents Button60 As Button
    Friend WithEvents Panel94 As Panel
    Friend WithEvents Label_Demo1_SetExpiryValueInUTC As Label
    Friend WithEvents Label105 As Label
    Friend WithEvents GroupBox6 As GroupBox
    Friend WithEvents Label109 As Label
    Friend WithEvents Label108 As Label
    Friend WithEvents Label107 As Label
    Friend WithEvents Label106 As Label
    Friend WithEvents Panel103 As Panel
    Friend WithEvents Button_Demo1_LoadedLICFileBrowse As Button
    Friend WithEvents TextBox_Demo1_LoadedLICFile As TextBox
    Friend WithEvents Label98 As Label
    Friend WithEvents Button_Demo1_LoadedLICFileClose As Button
    Friend WithEvents Panel106 As Panel
    Friend WithEvents TextBox_Demo1_VerifyFingerprint As TextBox
    Friend WithEvents Label115 As Label
    Friend WithEvents Panel105 As Panel
    Friend WithEvents Label_Demo1_Verify_ExtractedExpiryInLocalTime As Label
    Friend WithEvents Label113 As Label
    Friend WithEvents Panel104 As Panel
    Friend WithEvents Label_Demo1_Verify_ExtractedExpiry As Label
    Friend WithEvents Label111 As Label
    Friend WithEvents Button_Demo1_LoadedLICFileReload As Button
    Friend WithEvents Panel107 As Panel
    Friend WithEvents TextBox_Demo1_VerifyFingerprintPlusExpiryHash As TextBox
    Friend WithEvents Label114 As Label
    Friend WithEvents Panel108 As Panel
    Friend WithEvents TextBox_Demo1_VerifyFingerprintPlusExpiry As TextBox
    Friend WithEvents Label116 As Label
    Friend WithEvents Panel109 As Panel
    Friend WithEvents TextBox_Demo1_Verify_ExtractedFingerprint As TextBox
    Friend WithEvents Label118 As Label
    Friend WithEvents Button68 As Button
    Friend WithEvents Panel110 As Panel
    Friend WithEvents TextBox_Demo1_Verify_IsVerified As TextBox
    Friend WithEvents Label110 As Label
    Friend WithEvents Panel112 As Panel
    Friend WithEvents TextBox_Demo1_Verify_Expired As TextBox
    Friend WithEvents Label117 As Label
    Friend WithEvents Panel111 As Panel
    Friend WithEvents TextBox_Demo1_Verify_CurrentUTCTime As TextBox
    Friend WithEvents Label112 As Label
    Friend WithEvents Panel113 As Panel
    Friend WithEvents TextBox_Demo1_Verify_CurrentLocalTime As TextBox
    Friend WithEvents Label119 As Label
    Friend WithEvents CheckBox_System_Include_Make As CheckBox
    Friend WithEvents CheckBox_System_Include_Model As CheckBox
    Friend WithEvents CheckBox_System_Include_SystemModel As CheckBox
    Friend WithEvents CheckBox_System_Include_SystemModelFull As CheckBox
    Friend WithEvents CheckBox_System_Include_MotherboardSerial As CheckBox
    Friend WithEvents CheckBox_System_Include_BIOSSerial As CheckBox
    Friend WithEvents CheckBox_System_Include_MotherboardBaseBoardProduct As CheckBox
    Friend WithEvents CheckBox_System_Include_UUID As CheckBox
    Friend WithEvents CheckBox12 As CheckBox
    Friend WithEvents Label121 As Label
    Friend WithEvents Label122 As Label
    Friend WithEvents Label123 As Label
    Friend WithEvents GroupBox7 As GroupBox
    Friend WithEvents Button_Demo2_GeneralteLicenseKey As Button
    Friend WithEvents Label127 As Label
    Friend WithEvents Label128 As Label
    Friend WithEvents Panel114 As Panel
    Friend WithEvents TextBox_Demo2_LicensedTo As TextBox
    Friend WithEvents Label120 As Label
    Friend WithEvents Panel118 As Panel
    Friend WithEvents TextBox_Demo2_Seed As TextBox
    Friend WithEvents Label130 As Label
    Friend WithEvents Panel117 As Panel
    Friend WithEvents TextBox_Demo2_Terminal As TextBox
    Friend WithEvents Label129 As Label
    Friend WithEvents Panel116 As Panel
    Friend WithEvents TextBox_Demo2_Branch As TextBox
    Friend WithEvents Label126 As Label
    Friend WithEvents Panel115 As Panel
    Friend WithEvents TextBox_Demo2_Email As TextBox
    Friend WithEvents Label124 As Label
    Friend WithEvents Panel122 As Panel
    Friend WithEvents TextBox_Demo2_Base64Encoded As TextBox
    Friend WithEvents Label134 As Label
    Friend WithEvents Panel123 As Panel
    Friend WithEvents TextBox_Demo2_Concatenated As TextBox
    Friend WithEvents Label135 As Label
    Friend WithEvents GroupBox8 As GroupBox
    Friend WithEvents Label156 As Label
    Friend WithEvents Panel124 As Panel
    Friend WithEvents Label140 As Label
    Friend WithEvents TextBox_Demo2_LicenseKeyPart5 As TextBox
    Friend WithEvents Label139 As Label
    Friend WithEvents TextBox_Demo2_LicenseKeyPart4 As TextBox
    Friend WithEvents Label138 As Label
    Friend WithEvents TextBox_Demo2_LicenseKeyPart3 As TextBox
    Friend WithEvents Label137 As Label
    Friend WithEvents TextBox_Demo2_LicenseKeyPart2 As TextBox
    Friend WithEvents TextBox_Demo2_LicenseKeyPart1 As TextBox
    Friend WithEvents Label136 As Label
    Friend WithEvents Panel136 As Panel
    Friend WithEvents TextBox_Demo2_HashCombined As TextBox
    Friend WithEvents Label157 As Label
    Friend WithEvents Button64 As Button
    Friend WithEvents Button62 As Button
    Friend WithEvents Button69 As Button
    Friend WithEvents TabPage11 As TabPage
    Friend WithEvents Panel120 As Panel
    Friend WithEvents Button63 As Button
    Friend WithEvents TextBox_Demo2_RandomString As TextBox
    Friend WithEvents Label131 As Label
    Friend WithEvents RadioButton2 As RadioButton
    Friend WithEvents RadioButton1 As RadioButton
    Friend WithEvents Panel119 As Panel
    Friend WithEvents Panel121 As Panel
    Friend WithEvents Label132 As Label
    Friend WithEvents DateTimePicker2 As DateTimePicker
    Friend WithEvents Label125 As Label
    Friend WithEvents Panel125 As Panel
    Friend WithEvents Label133 As Label
    Friend WithEvents TextBox_Demo2_VerifyKeyPart5 As TextBox
    Friend WithEvents Label141 As Label
    Friend WithEvents TextBox_Demo2_VerifyKeyPart4 As TextBox
    Friend WithEvents Label142 As Label
    Friend WithEvents TextBox_Demo2_VerifyKeyPart3 As TextBox
    Friend WithEvents Label143 As Label
    Friend WithEvents TextBox_Demo2_VerifyKeyPart2 As TextBox
    Friend WithEvents TextBox_Demo2_VerifyKeyPart1 As TextBox
    Friend WithEvents Label144 As Label
    Friend WithEvents Button66 As Button
    Friend WithEvents Panel126 As Panel
    Friend WithEvents Panel127 As Panel
    Friend WithEvents TextBox7 As TextBox
    Friend WithEvents Label145 As Label
    Friend WithEvents Panel129 As Panel
    Friend WithEvents TextBox9 As TextBox
    Friend WithEvents Label147 As Label
    Friend WithEvents Panel128 As Panel
    Friend WithEvents TextBox8 As TextBox
    Friend WithEvents Label146 As Label
    Friend WithEvents Button65 As Button
    Friend WithEvents GroupBox9 As GroupBox
    Friend WithEvents Button_LicenseOTP_TOTP_GetCodeUser As Button
    Friend WithEvents Panel130 As Panel
    Friend WithEvents Panel131 As Panel
    Friend WithEvents TextBox_LicenseOTP_TOTP_SecretUser As TextBox
    Friend WithEvents Label149 As Label
    Friend WithEvents Label148 As Label
    Friend WithEvents Panel132 As Panel
    Friend WithEvents ComboBox_LicenseOTP_TOTP_IntervalUser As ComboBox
    Friend WithEvents Label150 As Label
    Friend WithEvents Panel133 As Panel
    Friend WithEvents TextBox_LicenseOTP_TOTP_CodeUser As TextBox
    Friend WithEvents Label151 As Label
    Friend WithEvents Button_LicenseOTP_TOTP_SecretUser As Button
    Friend WithEvents Panel134 As Panel
    Friend WithEvents Panel135 As Panel
    Friend WithEvents TextBox_LicenseOTP_TOTP_UserCodeAdmin As TextBox
    Friend WithEvents Label152 As Label
    Friend WithEvents Button_LicenseOTP_TOTP_VerifyCode As Button
    Friend WithEvents Panel137 As Panel
    Friend WithEvents ComboBox_LicenseOTP_TOTP_IntervalAdmin As ComboBox
    Friend WithEvents Label153 As Label
    Friend WithEvents Panel138 As Panel
    Friend WithEvents Button_LicenseOTP_TOTP_SecretCopyUser As Button
    Friend WithEvents TextBox_LicenseOTP_TOTP_SecretAdmin As TextBox
    Friend WithEvents Label154 As Label
    Friend WithEvents Label155 As Label
    Friend WithEvents Panel139 As Panel
    Friend WithEvents TextBox_LicenseOTP_TOTP_Verified As TextBox
    Friend WithEvents Label158 As Label
    Friend WithEvents Button_LicenseOTP_TOTP_IntervalCopyUser As Button
    Friend WithEvents Panel149 As Panel
    Friend WithEvents Panel150 As Panel
    Friend WithEvents TextBox_LicenseOTP_TOTP_AsBase32User As TextBox
    Friend WithEvents Label168 As Label
    Friend WithEvents Panel151 As Panel
    Friend WithEvents TextBox_LicenseOTP_TOTP_ServerCodeAdmin As TextBox
    Friend WithEvents Label169 As Label
    Friend WithEvents Button_LicenseOTP_TOTP_UserCodeCopyFromUser As Button
    Friend WithEvents Label170 As Label
    Friend WithEvents Label172 As Label
    Friend WithEvents Label173 As Label
    Friend WithEvents GroupBox10 As GroupBox
    Friend WithEvents Label159 As Label
    Friend WithEvents Label160 As Label
    Friend WithEvents Panel140 As Panel
    Friend WithEvents Label161 As Label
    Friend WithEvents Panel141 As Panel
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents Label162 As Label
    Friend WithEvents Button67 As Button
    Friend WithEvents Panel142 As Panel
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents Label163 As Label
    Friend WithEvents Panel143 As Panel
    Friend WithEvents Button70 As Button
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents Label164 As Label
    Friend WithEvents Panel144 As Panel
    Friend WithEvents Button71 As Button
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents Label165 As Label
    Friend WithEvents Panel145 As Panel
    Friend WithEvents Button72 As Button
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents Label166 As Label
    Friend WithEvents Label167 As Label
    Friend WithEvents Panel146 As Panel
    Friend WithEvents Panel147 As Panel
    Friend WithEvents TextBox6 As TextBox
    Friend WithEvents Label174 As Label
    Friend WithEvents Panel148 As Panel
    Friend WithEvents TextBox10 As TextBox
    Friend WithEvents Label175 As Label
    Friend WithEvents Button73 As Button
    Friend WithEvents Panel152 As Panel
    Friend WithEvents Label176 As Label
    Friend WithEvents Panel153 As Panel
    Friend WithEvents Button74 As Button
    Friend WithEvents TextBox11 As TextBox
    Friend WithEvents Label177 As Label
    Friend WithEvents Label178 As Label
    Friend WithEvents TextBox12 As TextBox
End Class
