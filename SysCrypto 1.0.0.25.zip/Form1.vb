﻿




Imports System.Data.SqlTypes
Imports System.IO
Imports System.IO.Ports
Imports System.Management
Imports System.Security.Cryptography.X509Certificates
Imports System.Text
Imports System.Web.Script.Serialization
Imports Newtonsoft.Json
Imports Newtonsoft.Json.Linq
Imports Org.BouncyCastle.Asn1.Sec
Imports Org.BouncyCastle.Crypto
Imports Org.BouncyCastle.Crypto.Parameters
Imports Org.BouncyCastle.Math

Public Class Form1




    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ComboBox_RSA_KeySize.SelectedItem = "1024"
        CheckBox_License_Lic_AddSignature.Checked = True

        ' Migrate the verify tab page to the main tab control, cant be bothered to rewrite it JUST to have it on the main tab control
        ' Move TabPage_Verify from TabControl2 to TabControl1
        If TabControl2.TabPages.Contains(TabPage_Verify) Then
            TabControl2.TabPages.Remove(TabPage_Verify)
            TabControl1.TabPages.Add(TabPage_Verify)
        End If
    End Sub






    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Application.Exit()
    End Sub


    Private Sub AboutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutToolStripMenuItem.Click
        MessageBox.Show(moduleVersion_LicenseGen, "", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub




    Private Async Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        MsgBox("AdminRights in current Context?" & vbCrLf & Await GetThe_User("AdminRights"))
    End Sub







    Private Async Sub Button_Test_Click(sender As Object, e As EventArgs) Handles Button_Test.Click

        ' Computer Details
        Dim answer
        answer = MessageBox.Show("Hostname" & vbCrLf & Await GetThe_Computer("Hostname"), "", MessageBoxButtons.OKCancel)
        If answer = vbCancel Then Exit Sub

        answer = MessageBox.Show("Domain" & vbCrLf & Await GetThe_Computer("Domain"), "", MessageBoxButtons.OKCancel)
        If answer = vbCancel Then Exit Sub

        answer = MessageBox.Show("Make" & vbCrLf & Await GetThe_Computer("Make"), "", MessageBoxButtons.OKCancel)
        If answer = vbCancel Then Exit Sub

        answer = MessageBox.Show("Model" & vbCrLf & Await GetThe_Computer("Model"), "", MessageBoxButtons.OKCancel)
        If answer = vbCancel Then Exit Sub

        answer = MessageBox.Show("SystemModel" & vbCrLf & Await GetThe_Computer("SystemModel"), "", MessageBoxButtons.OKCancel)
        If answer = vbCancel Then Exit Sub

        answer = MessageBox.Show("SystemModelFull" & vbCrLf & Await GetThe_Computer("SystemModelFull"), "", MessageBoxButtons.OKCancel)
        If answer = vbCancel Then Exit Sub

        answer = MessageBox.Show("BIOSSerial" & vbCrLf & Await GetThe_Computer("BIOSSerial"), "", MessageBoxButtons.OKCancel)
        If answer = vbCancel Then Exit Sub

        answer = MessageBox.Show("MotherboardSerial" & vbCrLf & Await GetThe_Computer("MotherboardSerial"), "", MessageBoxButtons.OKCancel)
        If answer = vbCancel Then Exit Sub

        answer = MessageBox.Show("MotherBoardBaseBoardProduct" & vbCrLf & Await GetThe_Computer("MotherBoardBaseBoardProduct"), "", MessageBoxButtons.OKCancel)
        If answer = vbCancel Then Exit Sub

        answer = MessageBox.Show("UUID" & vbCrLf & Await GetThe_Computer("UUID"), "", MessageBoxButtons.OKCancel)
        If answer = vbCancel Then Exit Sub

        answer = MessageBox.Show("CPUName" & vbCrLf & Await GetThe_Computer("CPUName"), "", MessageBoxButtons.OKCancel)
        If answer = vbCancel Then Exit Sub

        answer = MessageBox.Show("CPUCount" & vbCrLf & Await GetThe_Computer("CPUCount"), "", MessageBoxButtons.OKCancel)
        If answer = vbCancel Then Exit Sub

        answer = MessageBox.Show("CPUCores" & vbCrLf & Await GetThe_Computer("CPUCores"), "", MessageBoxButtons.OKCancel)
        If answer = vbCancel Then Exit Sub

        answer = MessageBox.Show("CPUThreads" & vbCrLf & Await GetThe_Computer("CPUThreads"), "", MessageBoxButtons.OKCancel)
        If answer = vbCancel Then Exit Sub

        answer = MessageBox.Show("CPUSpeed" & vbCrLf & Await GetThe_Computer("CPUSpeed"), "", MessageBoxButtons.OKCancel)
        If answer = vbCancel Then Exit Sub

        answer = MessageBox.Show("CPUArchitecture" & vbCrLf & Await GetThe_Computer("CPUArchitecture"), "", MessageBoxButtons.OKCancel)
        If answer = vbCancel Then Exit Sub

        answer = MessageBox.Show("RAMSize" & vbCrLf & Await GetThe_Computer("RAMSize"), "", MessageBoxButtons.OKCancel)
        If answer = vbCancel Then Exit Sub

        answer = MessageBox.Show("RAMSpeed" & vbCrLf & Await GetThe_Computer("RAMSpeed"), "", MessageBoxButtons.OKCancel)
        If answer = vbCancel Then Exit Sub

        answer = MessageBox.Show("OSName" & vbCrLf & Await GetThe_Computer("OSName"), "", MessageBoxButtons.OKCancel)
        If answer = vbCancel Then Exit Sub

        answer = MessageBox.Show("OSBuild" & vbCrLf & Await GetThe_Computer("OSBuild"), "", MessageBoxButtons.OKCancel)
        If answer = vbCancel Then Exit Sub

        answer = MessageBox.Show("OSVersion" & vbCrLf & Await GetThe_Computer("OSVersion"), "", MessageBoxButtons.OKCancel)
        If answer = vbCancel Then Exit Sub

        answer = MessageBox.Show("OSArchitecture" & vbCrLf & Await GetThe_Computer("OSArchitecture"), "", MessageBoxButtons.OKCancel)
        If answer = vbCancel Then Exit Sub

        answer = MessageBox.Show("OSServiceChannel" & vbCrLf & Await GetThe_Computer("OSServiceChannel"), "", MessageBoxButtons.OKCancel)
        If answer = vbCancel Then Exit Sub




        ' Hard Drive Details
        answer = MessageBox.Show("Count" & vbCrLf & Await GetThe_HardDrive("Count"), "", MessageBoxButtons.OKCancel)
        If answer = vbCancel Then Exit Sub

        answer = MessageBox.Show("PNPDeviceID" & vbCrLf & Await GetThe_HardDrive("PNPDeviceID"), "", MessageBoxButtons.OKCancel)
        If answer = vbCancel Then Exit Sub

        answer = MessageBox.Show("DriveSerialNumber" & vbCrLf & Await GetThe_HardDrive("DriveSerialNumber"), "", MessageBoxButtons.OKCancel)
        If answer = vbCancel Then Exit Sub

        answer = MessageBox.Show("VolumeSerialNumber" & vbCrLf & Await GetThe_HardDrive("VolumeSerialNumber"), "", MessageBoxButtons.OKCancel)
        If answer = vbCancel Then Exit Sub

        answer = MessageBox.Show("Model" & vbCrLf & Await GetThe_HardDrive("Model"), "", MessageBoxButtons.OKCancel)
        If answer = vbCancel Then Exit Sub

        answer = MessageBox.Show("DiskDeviceID" & vbCrLf & Await GetThe_HardDrive("DiskDeviceID"), "", MessageBoxButtons.OKCancel)
        If answer = vbCancel Then Exit Sub

        answer = MessageBox.Show("SizeB" & vbCrLf & Await GetThe_HardDrive("SizeB"), "", MessageBoxButtons.OKCancel)
        If answer = vbCancel Then Exit Sub

        answer = MessageBox.Show("SizeGB" & vbCrLf & Await GetThe_HardDrive("SizeGB"), "", MessageBoxButtons.OKCancel)
        If answer = vbCancel Then Exit Sub

        answer = MessageBox.Show("FreeSpaceB" & vbCrLf & Await GetThe_HardDrive("FreeSpaceB"), "", MessageBoxButtons.OKCancel)
        If answer = vbCancel Then Exit Sub

        answer = MessageBox.Show("FreeSpaceGB" & vbCrLf & Await GetThe_HardDrive("FreeSpaceGB"), "", MessageBoxButtons.OKCancel)
        If answer = vbCancel Then Exit Sub

        answer = MessageBox.Show("DriveLetter" & vbCrLf & Await GetThe_HardDrive("DriveLetter"), "", MessageBoxButtons.OKCancel)
        If answer = vbCancel Then Exit Sub

        answer = MessageBox.Show("VolumeName" & vbCrLf & Await GetThe_HardDrive("VolumeName"), "", MessageBoxButtons.OKCancel)
        If answer = vbCancel Then Exit Sub

        answer = MessageBox.Show("FileSystem" & vbCrLf & Await GetThe_HardDrive("FileSystem"), "", MessageBoxButtons.OKCancel)
        If answer = vbCancel Then Exit Sub



        ' Network Details
        answer = MessageBox.Show("NICDescription" & vbCrLf & Await GetThe_Network("NICDescription"), "", MessageBoxButtons.OKCancel)
        If answer = vbCancel Then Exit Sub

        answer = MessageBox.Show("IPv4Address" & vbCrLf & Await GetThe_Network("IPv4Address"), "", MessageBoxButtons.OKCancel)
        If answer = vbCancel Then Exit Sub

        answer = MessageBox.Show("MACAddress" & vbCrLf & Await GetThe_Network("MACAddress"), "", MessageBoxButtons.OKCancel)
        If answer = vbCancel Then Exit Sub

        answer = MessageBox.Show("SubnetMask" & vbCrLf & Await GetThe_Network("SubnetMask"), "", MessageBoxButtons.OKCancel)
        If answer = vbCancel Then Exit Sub

        answer = MessageBox.Show("DefaultGateway" & vbCrLf & Await GetThe_Network("DefaultGateway"), "", MessageBoxButtons.OKCancel)
        If answer = vbCancel Then Exit Sub

        answer = MessageBox.Show("DNSDomainSuffix" & vbCrLf & Await GetThe_Network("DNSDomainSuffix"), "", MessageBoxButtons.OKCancel)
        If answer = vbCancel Then Exit Sub




        ' Current User Details
        answer = MessageBox.Show("Username" & vbCrLf & Await GetThe_User("Username"), "", MessageBoxButtons.OKCancel)
        If answer = vbCancel Then Exit Sub

        answer = MessageBox.Show("DomainAndUsername" & vbCrLf & Await GetThe_User("DomainAndUsername"), "", MessageBoxButtons.OKCancel)
        If answer = vbCancel Then Exit Sub

        answer = MessageBox.Show("AdminRights" & vbCrLf & Await GetThe_User("AdminRights"), "", MessageBoxButtons.OKCancel)
        If answer = vbCancel Then Exit Sub

    End Sub





    Private Async Sub Button_Encrypt_Click(sender As Object, e As EventArgs) Handles Button_Encrypt.Click
        TextBox_OutputData.Text = Await EncryptAsync(TextBox_InputData.Text, TextBox_EncryptionKey.Text, TextBox_IV.Text)
    End Sub

    Private Async Sub Button_Decrypt_Click(sender As Object, e As EventArgs) Handles Button_Decrypt.Click
        TextBox_OutputData.Text = Await DecryptAsync(TextBox_InputData.Text, TextBox_EncryptionKey.Text, TextBox_IV.Text)

    End Sub










    ' RSA TAB 
    ' ===================

    Private Async Sub Button_RSA_GenerateKeys_Click(sender As Object, e As EventArgs) Handles Button_RSA_GenerateKeys.Click


        Dim keySize As Integer = Integer.Parse(ComboBox_RSA_KeySize.SelectedItem.ToString())
        Dim seed As String = TextBox_RSA_Seed.Text.Trim()

        'GenerateRsaKeys(RSAPublicKey, RSAPrivateKey, keySize, seed)
        Await GenerateRsaKeysAsync(keySize, seed)

        ' Get a unique integer key for each key pair (simple counter approach)
        Dim keyIdentifier As Integer = RSAKeyPairs.Count + 1 ' Incremental key identifier

        ' Get the optional description from the new TextBox
        Dim keyPairDescription As String = TextBox_RSA_KeyPairDescription.Text.Trim()

        ' Create the key pair dictionary
        Dim keyPair As New Dictionary(Of String, String) From {
            {"PublicKey", RSAPublicKey},
            {"PrivateKey", RSAPrivateKey},
            {"KeySize", keySize.ToString()},
            {"Seed", seed},
            {"Salt", TextBox_RSA_Salt.Text.Trim()}
        }

        ' Add the description to the dictionary, if it's provided
        If Not String.IsNullOrEmpty(keyPairDescription) Then
            keyPair.Add("Description", keyPairDescription)
        End If


        ' Add the key pair to the dictionary with the unique identifier
        RSAKeyPairs.Add(keyIdentifier, keyPair)

        ' Update the ComboBox with the new key pair entry
        Await UpdateComboBoxWithKeyPairs()

        '' TROUBLESHOOTING
        'For Each outerKvp As KeyValuePair(Of Integer, Dictionary(Of String, String)) In RSAKeyPairs
        '    Debug.WriteLine("Outer Key: " & outerKvp.Key)

        '    For Each innerKvp As KeyValuePair(Of String, String) In outerKvp.Value
        '        Debug.WriteLine("    Inner Key: " & innerKvp.Key & " - Value: " & innerKvp.Value)
        '    Next

        '    ' Check if there's a description and print it out
        '    If outerKvp.Value.ContainsKey("Description") Then
        '        Debug.WriteLine("    Description: " & outerKvp.Value("Description"))
        '    End If
        'Next
        'Debug.WriteLine(vbCrLf & vbCrLf)


        TextBox_RSA_PublicKey.Text = RSAPublicKey
        TextBox_RSA_PrivateKey.Text = RSAPrivateKey

        TextBox_Demo1_PublicKey.Text = RSAPublicKey
        TextBox_Demo1_PrivateKey.Text = RSAPrivateKey

        ComboBox_RSA_PreviousPairs.SelectedIndex = ComboBox_RSA_PreviousPairs.Items.Count - 1

    End Sub






    Private Async Function UpdateComboBoxWithKeyPairs() As Threading.Tasks.Task

        ComboBox_RSA_PreviousPairs.Items.Clear()
        ComboBox_License_Lic_PreviousPairs.Items.Clear()
        ComboBox_Demo1_PreviousPairs.Items.Clear()


        For Each outerKvp As KeyValuePair(Of Integer, Dictionary(Of String, String)) In RSAKeyPairs
            Dim publicKey As String = outerKvp.Value("PublicKey")
            Dim privateKey As String = outerKvp.Value("PrivateKey")
            Dim description As String = If(outerKvp.Value.ContainsKey("Description"), outerKvp.Value("Description"), "")
            Dim seed As String = If(outerKvp.Value.ContainsKey("Seed"), outerKvp.Value("Seed"), "")
            Dim salt As String = If(outerKvp.Value.ContainsKey("Salt"), outerKvp.Value("Salt"), "")
            Dim keySize As String = If(outerKvp.Value.ContainsKey("KeySize"), outerKvp.Value("KeySize"), "")

            Dim last4Pub As String = Await RSA_ExtractLastCharsFromKey(publicKey, 4)
            Dim last4Priv As String = Await RSA_ExtractLastCharsFromKey(privateKey, 4)

            Dim displayText As String = $"{outerKvp.Key} PublicEnding:{last4Pub} PrivateEnding:{last4Priv} Description:{description} Seed:{seed} Salt:{salt} KeySize:{keySize}"
            ComboBox_RSA_PreviousPairs.Items.Add(displayText)
            ComboBox_License_Lic_PreviousPairs.Items.Add(displayText)
            ComboBox_Demo1_PreviousPairs.Items.Add(displayText)
        Next
    End Function







    Private Sub Button_RSA_HashInput_Click(sender As Object, e As EventArgs) Handles Button_RSA_HashInput.Click
        TextBox_RSA_HashInput.Text = GetHash(TextBox_RSA_InputData.Text)
    End Sub
    Private Sub Button_RSA_HashInputAndSalt_Click(sender As Object, e As EventArgs) Handles Button_RSA_HashInputAndSalt.Click
        TextBox_RSA_HashInput.Text = GetHash(TextBox_RSA_InputData.Text & TextBox_RSA_Salt.Text)
    End Sub

    Private Async Sub Button_RSA_Encrypt_WithPrivate_Click(sender As Object, e As EventArgs) Handles Button_RSA_Encrypt_WithPrivate.Click
        TextBox_RSA_OutputData.Text = Await RsaEncrypt(TextBox_RSA_InputData.Text, TextBox_RSA_PublicKey.Text, TextBox_RSA_Salt.Text)
    End Sub

    Private Async Sub Button_RSA_Encrypt_WithPublic_Click(sender As Object, e As EventArgs) Handles Button_RSA_Encrypt_WithPublic.Click
        Dim input As String = TextBox_RSA_InputData.Text
        Dim encrypted As String = Await RsaEncrypt(input, RSAPublicKey, TextBox_RSA_Salt.Text)
        TextBox_RSA_OutputData.Text = encrypted
    End Sub

    Private Async Sub Button_RSA_Decrypt_WithPrivate_Click(sender As Object, e As EventArgs) Handles Button_RSA_Decrypt_WithPrivate.Click
        TextBox_RSA_OutputData.Text = Await RsaDecrypt(TextBox_RSA_InputData.Text, TextBox_RSA_PrivateKey.Text, TextBox_RSA_Salt.Text)
    End Sub

    Private Async Sub Button_RSA_Sign_WithPrivate_Click(sender As Object, e As EventArgs) Handles Button_RSA_Sign_WithPrivate.Click
        TextBox_RSA_Signature.Text = Await RsaSignData(TextBox_RSA_HashInput.Text, TextBox_RSA_PrivateKey.Text, TextBox_RSA_Salt.Text)
    End Sub

    Private Async Sub Button_RSA_Verify_WithPublic_Click(sender As Object, e As EventArgs) Handles Button_RSA_Verify_WithPublic.Click
        Dim isValid As Boolean = Await RsaVerifySignature(TextBox_RSA_HashInput.Text, TextBox_RSA_Signature.Text, TextBox_RSA_PublicKey.Text, TextBox_RSA_Salt.Text)
        TextBox_RSA_MatchingSignatures.Text = isValid.ToString()
    End Sub

    Private Sub Button_RSA_VerifyClear_Click(sender As Object, e As EventArgs) Handles Button_RSA_VerifyClear.Click
        TextBox_RSA_Signature.Text = ""
        TextBox_RSA_MatchingSignatures.Text = ""
    End Sub

    Private Sub Button_RSA_HashInputClear_Click(sender As Object, e As EventArgs) Handles Button_RSA_HashInputClear.Click
        TextBox_RSA_HashInput.Text = ""
    End Sub

    Private Sub Button_RSA_GenerateKeysClear_Click(sender As Object, e As EventArgs) Handles Button_RSA_GenerateKeysClear.Click
        TextBox_RSA_PrivateKey.Text = ""
        TextBox_RSA_PublicKey.Text = ""
        TextBox_RSA_Seed.Text = ""
        TextBox_RSA_Salt.Text = ""
        ComboBox_RSA_KeySize.Text = "1024"
        TextBox_RSA_KeyPairDescription.Text = ""
    End Sub

    Private Sub Button_RSA_ExportGeneratedKeyPairs_Click(sender As Object, e As EventArgs) Handles Button_RSA_ExportGeneratedKeyPairs.Click
        If RSAKeyPairs.Count = 0 Then
            MessageBox.Show("Dictionary Empty" & vbCrLf & vbCrLf & "No Key pairs have been generated yet", "No Keys Generated Yet", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

        Dim answer = MessageBox.Show("Export Generated Key Pairs to JSON File?", "Export to File?", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If answer = vbYes Then
            RSA_ExportGeneratedKeyPairs()
        End If
    End Sub


    Private Sub Button_RSA_SwapInputOutpu_Click(sender As Object, e As EventArgs) Handles Button_RSA_SwapInputOutpu.Click
        Dim input As String = TextBox_RSA_InputData.Text
        Dim output As String = TextBox_RSA_OutputData.Text
        TextBox_RSA_InputData.Text = output
        TextBox_RSA_OutputData.Text = input
    End Sub

    Private Sub Button_RSA_InputDataClear_Click(sender As Object, e As EventArgs) Handles Button_RSA_InputDataClear.Click
        TextBox_RSA_InputData.Text = ""
    End Sub

    Private Sub Button_RSA_OutputDataClear_Click(sender As Object, e As EventArgs) Handles Button_RSA_OutputDataClear.Click
        TextBox_RSA_OutputData.Text = ""
    End Sub

    Private Sub Button_RSA_SwapInputOutput_Click(sender As Object, e As EventArgs) Handles Button_RSA_SwapInputOutput.Click
        TextBox_RSA_InputData.Text = ""
        TextBox_RSA_OutputData.Text = ""
    End Sub

    Private Sub Button_AES_SwapInputOutput_Click(sender As Object, e As EventArgs) Handles Button_AES_SwapInputOutput.Click
        Dim input As String = TextBox_InputData.Text
        Dim output As String = TextBox_OutputData.Text
        TextBox_InputData.Text = output
        TextBox_OutputData.Text = input
    End Sub

    Private Sub Button_AES_CelarInputOutput_Click(sender As Object, e As EventArgs) Handles Button_AES_CelarInputOutput.Click
        TextBox_InputData.Text = ""
        TextBox_OutputData.Text = ""
    End Sub


    Private Sub ComboBox_RSA_PreviousPairs_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox_RSA_PreviousPairs.SelectedIndexChanged

        If ComboBox_RSA_PreviousPairs.SelectedIndex >= 0 Then

            ' Mirror the selection to the license file combobox
            RemoveHandler ComboBox_License_Lic_PreviousPairs.SelectedIndexChanged, AddressOf ComboBox_License_Lic_PreviousPairs_SelectedIndexChanged
            ComboBox_License_Lic_PreviousPairs.SelectedIndex = ComboBox_RSA_PreviousPairs.SelectedIndex
            AddHandler ComboBox_License_Lic_PreviousPairs.SelectedIndexChanged, AddressOf ComboBox_License_Lic_PreviousPairs_SelectedIndexChanged


            Dim selectedText As String = ComboBox_RSA_PreviousPairs.SelectedItem.ToString()
            Dim keyIdentifier As Integer

            ' Parse identifier
            Dim firstSpaceIndex = selectedText.IndexOf(" ")
            If firstSpaceIndex > 0 AndAlso Integer.TryParse(selectedText.Substring(0, firstSpaceIndex), keyIdentifier) Then
                If RSAKeyPairs.ContainsKey(keyIdentifier) Then
                    Dim keyPair = RSAKeyPairs(keyIdentifier)

                    TextBox_RSA_PublicKey.Text = keyPair("PublicKey")
                    TextBox_RSA_PrivateKey.Text = keyPair("PrivateKey")
                    TextBox_RSA_Seed.Text = If(keyPair.ContainsKey("Seed"), keyPair("Seed"), "")
                    TextBox_RSA_Salt.Text = If(keyPair.ContainsKey("Salt"), keyPair("Salt"), "")
                    TextBox_RSA_KeyPairDescription.Text = If(keyPair.ContainsKey("Description"), keyPair("Description"), "")

                    TextBox_Demo1_PublicKey.Text = keyPair("PublicKey")
                    TextBox_Demo1_PrivateKey.Text = keyPair("PrivateKey")
                    TextBox_Demo1_Seed.Text = If(keyPair.ContainsKey("Seed"), keyPair("Seed"), "")
                    TextBox_Demo1_Salt.Text = If(keyPair.ContainsKey("Salt"), keyPair("Salt"), "")

                    TextBox_License_Lic_PublicKey.Text = keyPair("PublicKey")
                    TextBox_License_Lic_PrivateKey.Text = keyPair("PrivateKey")

                    ' Set ComboBox value for key size
                    If keyPair.ContainsKey("KeySize") Then
                        Dim size As String = keyPair("KeySize")
                        If ComboBox_RSA_KeySize.Items.Contains(size) Then
                            ComboBox_RSA_KeySize.SelectedItem = size
                            TextBox_License_Lic_KeySize.Text = size
                            TextBox_Demo1_KeySize.Text = size
                        End If
                    End If
                End If
            End If

        End If

        RemoveHandler ComboBox_Demo1_PreviousPairs.SelectedIndexChanged, AddressOf ComboBox_Demo1_PreviousPairs_SelectedIndexChanged
        ComboBox_Demo1_PreviousPairs.SelectedIndex = ComboBox_RSA_PreviousPairs.SelectedIndex
        AddHandler ComboBox_Demo1_PreviousPairs.SelectedIndexChanged, AddressOf ComboBox_Demo1_PreviousPairs_SelectedIndexChanged
    End Sub




    Private Sub Button_AES_KeyGenHash_Click(sender As Object, e As EventArgs) Handles Button_AES_KeyGenHash.Click

        Dim seedToUse As String
        If CheckBox_AES_Seed.Checked = True Then
            seedToUse = TextBox_AES_Seed.Text
        Else
            TextBox_AES_Seed.Text = GenerateRandomString(32)
            seedToUse = TextBox_AES_Seed.Text
        End If

        Dim saltToUse As String
        If CheckBox_AES_Salt.Checked = True Then
            saltToUse = TextBox_AES_Salt.Text
        Else
            saltToUse = ""
        End If

        TextBox_EncryptionKey.Text = GetHash(seedToUse & seedToUse & seedToUse & saltToUse)
        TextBox_IV.Text = GetHash(seedToUse & seedToUse & saltToUse)
    End Sub




    Private Sub Button_AES_Clear_Click(sender As Object, e As EventArgs) Handles Button_AES_Clear.Click
        Dim answer = MessageBox.Show("Clear all Fields?", "Clear Fields?", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If answer = vbYes Then
            TextBox_EncryptionKey.Text = ""
            TextBox_IV.Text = ""
            TextBox_AES_Seed.Text = ""
            TextBox_AES_Salt.Text = ""
        End If
    End Sub



    Private Sub Button_AES_Export_Click(sender As Object, e As EventArgs) Handles Button_AES_Export.Click

        If String.IsNullOrEmpty(TextBox_EncryptionKey.Text) Or
           String.IsNullOrEmpty(TextBox_IV.Text) Then
            MessageBox.Show("Export Failed" & vbCrLf & "Either the Key or IV is empty", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If

        Dim keyPairsList As New Dictionary(Of String, String)

        keyPairsList.Add("Seed", TextBox_AES_Seed.Text)
        keyPairsList.Add("Salt", TextBox_AES_Salt.Text)
        keyPairsList.Add("Key", TextBox_EncryptionKey.Text)
        keyPairsList.Add("IV", TextBox_IV.Text)

        ' Serialize the list to a JSON string
        Dim json As String = JsonConvert.SerializeObject(keyPairsList, Formatting.Indented)

        ' Prompt the user to select a file to save the JSON
        Using saveFileDialog As New SaveFileDialog()
            saveFileDialog.Filter = "JSON Files|*.json"
            saveFileDialog.Title = "Save RSA Key Pairs"

            If saveFileDialog.ShowDialog() = DialogResult.OK Then
                ' Write the JSON to the selected file
                Try
                    System.IO.File.WriteAllText(saveFileDialog.FileName, json)
                    MessageBox.Show("RSA Key Pairs exported successfully!", "Export Successful", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Catch ex As Exception
                    MessageBox.Show("Error exporting key pairs: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End Try
            End If
        End Using

    End Sub


    Private Sub Button_AES_ConvertKeyToHash_Click(sender As Object, e As EventArgs) Handles Button_AES_ConvertKeyToHash.Click
        Dim answer = MessageBox.Show("Hash the current Seed?", "Hash Seed?", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If answer = vbYes Then
            Dim tempString = TextBox_AES_Seed.Text
            TextBox_AES_Seed.Text = GetHash(tempString)
        End If
    End Sub

    Private Sub Button_AES_ConvertIVToHash_Click(sender As Object, e As EventArgs) Handles Button_AES_ConvertIVToHash.Click
        Dim answer = MessageBox.Show("Hash the current Salt?", "Hash Salt?", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If answer = vbYes Then
            Dim tempString = TextBox_AES_Salt.Text
            TextBox_AES_Salt.Text = GetHash(tempString)
        End If
    End Sub





    Private Sub CheckBox_RSA_EnableSeed_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_RSA_EnableSeed.CheckedChanged
        If CheckBox_RSA_EnableSeed.Checked = True Then
            TextBox_RSA_Seed.Enabled = True
        Else
            TextBox_RSA_Seed.Enabled = False
            TextBox_RSA_Seed.Text = ""

        End If
    End Sub

    Private Sub Label19_Click(sender As Object, e As EventArgs) Handles Label19.Click

    End Sub

    Private Sub Label20_Click(sender As Object, e As EventArgs) Handles Label20.Click

    End Sub

    Private Sub FlowLayoutPanel5_Paint(sender As Object, e As PaintEventArgs)

    End Sub

    Private Sub Panel26_Paint(sender As Object, e As PaintEventArgs) Handles Panel26.Paint

    End Sub

    Private Sub Button_Encoding_RandomString_Click(sender As Object, e As EventArgs) Handles Button_Encoding_RandomString.Click
        Dim length As Integer = CInt(TextBox_Encoding_RandomStringLength.Text)
        TextBox_Encoding_RandomString.Text = GenerateRandomString(length)
    End Sub

    Private Sub TextBox_Encoding_RandomStringLength_TextChanged(sender As Object, e As EventArgs) Handles TextBox_Encoding_RandomStringLength.TextChanged

    End Sub

    Private Sub Button_Encoding_StringToHash_Click(sender As Object, e As EventArgs) Handles Button_Encoding_StringToHash.Click
        Dim stringToUse As String = ""
        If TabControl_Encoding_StringOrFile.SelectedTab Is TabPage_String Then
            stringToUse = TextBox_Encoding_StringToHash.Text
            TextBox_Encoding_HashedString.Text = GetHash(stringToUse)

        ElseIf TabControl_Encoding_StringOrFile.SelectedTab Is TabPage_File Then
            stringToUse = TextBox_Encoding_FilePathToHash.Text
            TextBox_Encoding_HashedString.Text = GetFileHash(stringToUse)
        End If

    End Sub



    Private Sub CheckBox_AES_Seed_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_AES_Seed.CheckedChanged
        If CheckBox_AES_Seed.Checked = True Then
            TextBox_AES_Seed.Enabled = True
            Button_AES_SeedGenerate.Enabled = True
            Button_AES_ConvertKeyToHash.Enabled = True
        Else
            TextBox_AES_Seed.Enabled = False
            TextBox_AES_Seed.Text = ""
            Button_AES_SeedGenerate.Enabled = False
            Button_AES_ConvertKeyToHash.Enabled = False
        End If
    End Sub

    Private Sub Button_AES_SeedGenerate_Click(sender As Object, e As EventArgs) Handles Button_AES_SeedGenerate.Click
        TextBox_AES_Seed.Text = GenerateRandomString(16)
    End Sub

    Private Sub CheckBox_AES_Salt_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_AES_Salt.CheckedChanged
        If CheckBox_AES_Salt.Checked = True Then
            TextBox_AES_Salt.Enabled = True
            Button_AES_SaltGenerate.Enabled = True
            Button_AES_ConvertIVToHash.Enabled = True
        Else
            TextBox_AES_Salt.Enabled = False
            TextBox_AES_Salt.Text = ""
            Button_AES_SaltGenerate.Enabled = False
            Button_AES_ConvertIVToHash.Enabled = False
        End If

    End Sub

    Private Sub Button_AES_SaltGenerate_Click(sender As Object, e As EventArgs) Handles Button_AES_SaltGenerate.Click
        TextBox_AES_Salt.Text = GenerateRandomString(16)
    End Sub

    Private Async Sub Button_RSA_PublicKey_Copy_Click(sender As Object, e As EventArgs) Handles Button_RSA_PublicKey_Copy.Click
        If String.IsNullOrEmpty(TextBox_RSA_PublicKey.Text) = False Then
            Dim tempString As String = Await RSA_ExtractKey_Public(TextBox_RSA_PublicKey.Text)
            CopyStringToClipboard(tempString.Trim())
            MsgBox("copied to clipboard")
        End If
    End Sub

    Private Async Sub Button_RSA_PrivateKey_Copy_Click(sender As Object, e As EventArgs) Handles Button_RSA_PrivateKey_Copy.Click
        If String.IsNullOrEmpty(TextBox_RSA_PrivateKey.Text) = False Then
            Dim tempString As String = Await RSA_ExtractKey_Private(TextBox_RSA_PrivateKey.Text)
            CopyStringToClipboard(tempString.Trim())
            MsgBox("copied to clipboard")
        End If
    End Sub

    Private Sub Button_AES_ClearInput_Click(sender As Object, e As EventArgs) Handles Button_AES_ClearInput.Click
        TextBox_InputData.Text = ""
    End Sub

    Private Sub Button_AES_ClearOutput_Click(sender As Object, e As EventArgs) Handles Button_AES_ClearOutput.Click
        TextBox_OutputData.Text = ""
    End Sub

    Private Sub Button_AES_BrowseForFile_Click(sender As Object, e As EventArgs) Handles Button_AES_BrowseForFile.Click
        ' Create a new instance of OpenFileDialog
        Dim openFileDialog As New OpenFileDialog()

        ' Set the dialog title
        openFileDialog.Title = "Browse for File to Encrypt"

        ' Set the file filter to allow all file types
        openFileDialog.Filter = "All Files (*.*)|*.*"

        ' Show the dialog and check if a file is selected
        If openFileDialog.ShowDialog() = DialogResult.OK Then
            ' Display the selected file path in the TextBox
            TextBox_AES_BrowsedFilePath.Text = openFileDialog.FileName
        End If
    End Sub

    Private Sub Button_AES_FolderToOutput_Click(sender As Object, e As EventArgs) Handles Button_AES_FolderToOutput.Click
        Try
            ' Check if the directory exists
            If Directory.Exists(Path.GetDirectoryName(TextBox_AES_OutputFile.Text)) Then
                ' Open the directory in File Explorer
                Process.Start("explorer.exe", Path.GetDirectoryName(TextBox_AES_OutputFile.Text))
            Else
                MessageBox.Show("The specified directory does not exist.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Async Sub Button_AES_Files_Encrypt_Click(sender As Object, e As EventArgs) Handles Button_AES_Files_Encrypt.Click
        Try
            Dim inputFilePath As String = TextBox_AES_BrowsedFilePath.Text
            Dim outputFileName As String = Path.GetFileNameWithoutExtension(inputFilePath).Replace("_ENCRYPTED", "").Replace("_DECRYPTED", "") & "_ENCRYPTED" & Path.GetExtension(inputFilePath)
            Dim outputFilePath As String = Path.Combine(Path.GetDirectoryName(inputFilePath), outputFileName)

            TextBox_AES_OutputFile.Text = outputFilePath
            Dim result As Boolean = Await EncryptFileAsync(inputFilePath, outputFilePath, TextBox_EncryptionKey.Text, TextBox_IV.Text)
            If result = True Then
                MsgBox("Encrypted")
            Else
                MsgBox("Encrypted Failed - Keys are incorrect")
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Async Sub Button_AES_Files_Decrypt_Click(sender As Object, e As EventArgs) Handles Button_AES_Files_Decrypt.Click
        Try
            Dim inputFilePath As String = TextBox_AES_BrowsedFilePath.Text
            Dim outputFileName As String = Path.GetFileNameWithoutExtension(inputFilePath).Replace("_ENCRYPTED", "").Replace("_DECRYPTED", "") & "_DECRYPTED" & Path.GetExtension(inputFilePath)
            Dim outputFilePath As String = Path.Combine(Path.GetDirectoryName(inputFilePath), outputFileName)

            TextBox_AES_OutputFile.Text = outputFilePath
            Dim result As Boolean = Await DecryptFileAsync(inputFilePath, outputFilePath, TextBox_EncryptionKey.Text, TextBox_IV.Text)
            If result = True Then
                MsgBox("Decrypted")
            Else
                MsgBox("Decryption Failed - either the file wasnt encrypted to begin with, or the Keys are incorrect")
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Button_AES_Files_SwapInputOutput_Click(sender As Object, e As EventArgs) Handles Button_AES_Files_SwapInputOutput.Click
        Dim input As String = TextBox_AES_BrowsedFilePath.Text
        Dim output As String = TextBox_AES_OutputFile.Text
        TextBox_AES_BrowsedFilePath.Text = output
        TextBox_AES_OutputFile.Text = input
    End Sub

    Private Sub Button_AES_Files_ClearInputOutput_Click(sender As Object, e As EventArgs) Handles Button_AES_Files_ClearInputOutput.Click
        TextBox_AES_BrowsedFilePath.Text = ""
        TextBox_AES_OutputFile.Text = ""
    End Sub

    Private Sub CheckBox_RSA_Salt_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_RSA_Salt.CheckedChanged
        If CheckBox_RSA_Salt.Checked = True Then
            TextBox_RSA_Salt.Enabled = True
        Else
            TextBox_RSA_Salt.Enabled = False
            TextBox_RSA_Salt.Text = ""
        End If
    End Sub


    Private Sub Button_RSA_PreviousPairsEmpty_Click(sender As Object, e As EventArgs) Handles Button_RSA_PreviousPairsEmpty.Click
        Dim result As DialogResult = MessageBox.Show(
     "Are you sure you want to clear all previously generated RSA key pairs?",
     "Confirm Clear",
     MessageBoxButtons.YesNo,
     MessageBoxIcon.Warning)

        If result = DialogResult.Yes Then
            ' Clear the dictionary
            RSAKeyPairs.Clear()

            ' Clear the ComboBox
            ComboBox_RSA_PreviousPairs.Items.Clear()
        End If
    End Sub

    Private Sub Button_Encoding_RandomStringCopy_Click(sender As Object, e As EventArgs) Handles Button_Encoding_RandomStringCopy.Click
        CopyStringToClipboard(TextBox_Encoding_RandomString.Text)
        MsgBox("Copied to clipboard")
    End Sub

    Private Sub Button_Encoding_BrowseForFileToHash_Click(sender As Object, e As EventArgs) Handles Button_Encoding_BrowseForFileToHash.Click
        ' Create and configure the OpenFileDialog
        Dim openFileDialog As New OpenFileDialog()
        openFileDialog.Title = "Browse for File to Hash"
        openFileDialog.Filter = "All Files (*.*)|*.*" ' Allow any file type

        ' Show the dialog and check if a file was selected
        If openFileDialog.ShowDialog() = DialogResult.OK Then
            ' Display the selected file path in the TextBox
            TextBox_Encoding_FilePathToHash.Text = openFileDialog.FileName
        End If
    End Sub

    Private Sub Button_Encoding_HashedStringCopy_Click(sender As Object, e As EventArgs) Handles Button_Encoding_HashedStringCopy.Click
        CopyStringToClipboard(TextBox_Encoding_HashedString.Text)
        MsgBox("Copied to clipboard")
    End Sub

    Private Sub Button_Encoding_Base64StringEncodedCopy_Click(sender As Object, e As EventArgs) Handles Button_Encoding_Base64StringEncodedCopy.Click
        CopyStringToClipboard(TextBox_Encoding_EncodedData.Text)
        MsgBox("Copied to clipboard")
    End Sub

    Private Sub Button_Encoding_Base64String_Encode_Click(sender As Object, e As EventArgs) Handles Button_Encoding_EncodeData.Click
        'TextBox_Encoding_EncodedData.Text = Base64String_Encode(TextBox_Encoding_InputData.Text)

        Dim input As String = TextBox_Encoding_InputData.Text
        Dim encodingType As String = ComboBox_Encoding_EncodeOrDecodeIn.SelectedItem.ToString()

        Dim encoded As String = ""

        Select Case encodingType
            Case "Base64"
                Dim bytes As Byte() = Encoding.UTF8.GetBytes(input)
                encoded = Convert.ToBase64String(bytes)

            Case "Base32"
                encoded = Base32String_Encode(Encoding.UTF8.GetBytes(input))

            Case "Hex"
                encoded = BitConverter.ToString(Encoding.UTF8.GetBytes(input)).Replace("-", "")

            Case Else
                MessageBox.Show("Unknown encoding selected.")
                Return
        End Select

        TextBox_Encoding_EncodedData.Text = encoded

    End Sub

    Private Sub Button_Encoding_Base64String_Decode_Click(sender As Object, e As EventArgs) Handles Button_Encoding_DecodeData.Click
        'TextBox_Encoding_DecodedData.Text = Base64String_Decode(TextBox_Encoding_EncodedData.Text)

        Dim encodedInput As String = TextBox_Encoding_InputData.Text
        Dim encodingType As String = ComboBox_Encoding_EncodeOrDecodeIn.SelectedItem.ToString()

        Dim decoded As String = ""

        Try
            Select Case encodingType
                Case "Base64"
                    Dim bytes As Byte() = Convert.FromBase64String(encodedInput)
                    decoded = Encoding.UTF8.GetString(bytes)

                Case "Base32"
                    decoded = Encoding.UTF8.GetString(Base32String_Decode(encodedInput))

                Case "Hex"
                    Dim bytes As New List(Of Byte)
                    For i = 0 To encodedInput.Length - 2 Step 2
                        bytes.Add(Convert.ToByte(encodedInput.Substring(i, 2), 16))
                    Next
                    decoded = Encoding.UTF8.GetString(bytes.ToArray())

                Case Else
                    MessageBox.Show("Unknown encoding selected.")
                    Return
            End Select
        Catch ex As Exception
            MessageBox.Show("Decoding failed: " & ex.Message)
            Return
        End Try

        TextBox_Encoding_EncodedData.Text = decoded
    End Sub





    Private Sub Button_RSA_SignatureCopy_Click(sender As Object, e As EventArgs) Handles Button_RSA_SignatureCopy.Click
        CopyStringToClipboard(TextBox_RSA_Signature.Text)
        MsgBox("Copied to Clipboard")
    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Process.Start("https://emn178.github.io/online-tools/rsa/verify/")
    End Sub

    Private Sub Button_License_Lic_Preview_Click(sender As Object, e As EventArgs) Handles Button_License_Lic_Preview.Click
        CreateJsonFromGridViews()
        FormPreviewLicJSON.ShowDialog()
    End Sub




    '' V2
    Public Function CreateJsonFromGridViews(Optional saveFile As Boolean = False) As String
        ' Create a dictionary to hold the data nodes
        Dim jsonObject As New Dictionary(Of String, Object)

        ' Create a dictionary for the "data" node
        Dim dataNode As New Dictionary(Of String, String)
        For Each row As DataGridViewRow In DataGridView_License_Lic_Data.Rows
            If Not row.IsNewRow Then
                ' Add key-value pairs to the "data" node (DataName and DataValue columns)
                Dim key As String = Convert.ToString(row.Cells(0).Value)
                Dim value As String = Convert.ToString(row.Cells(1).Value)
                If Not String.IsNullOrEmpty(key) AndAlso Not String.IsNullOrEmpty(value) Then
                    dataNode.Add(key, value)
                End If
            End If
        Next

        ' Add the "data" node to the main jsonObject
        Dim dataNodeName As String = "data"
        If String.IsNullOrEmpty(TextBox_License_Lic_Data_JSONNodeName.Text) = False Then
            dataNodeName = TextBox_License_Lic_Data_JSONNodeName.Text
        End If
        jsonObject.Add(dataNodeName, dataNode)

        ' Create a dictionary for the signature values (NO wrapping in "signature" node anymore)
        For Each row As DataGridViewRow In DataGridView_License_Lic_Signature.Rows
            If Not row.IsNewRow Then
                ' Add key-value pairs directly into the main jsonObject
                Dim key As String = Convert.ToString(row.Cells(0).Value)
                Dim value As String = Convert.ToString(row.Cells(1).Value)
                If Not String.IsNullOrEmpty(key) AndAlso Not String.IsNullOrEmpty(value) Then
                    ' Add directly to the root jsonObject
                    jsonObject.Add(key, value)
                End If
            End If
        Next

        ' Convert the dictionary to a JSON string
        Dim jsonString As String = JsonConvert.SerializeObject(jsonObject, Formatting.Indented)

        ' Output the JSON string to the TextBox
        FormPreviewLicJSON.TextBox_Preview_JSON.Text = jsonString

        If saveFile = True Then
            ' Ask the user where to save the file
            Dim saveFileDialog As New SaveFileDialog()
            saveFileDialog.Filter = "License files (*.Lic)|*.lic|All files (*.*)|*.*"
            saveFileDialog.Title = "Save License File"
            saveFileDialog.FileName = "output.lic"

            If saveFileDialog.ShowDialog() = DialogResult.OK Then
                ' Save the JSON string to the selected file
                System.IO.File.WriteAllText(saveFileDialog.FileName, jsonString)

                ' ALSO EXPORT THE RSA KEYS in case you forget to and close the app 
                If RSAKeyPairs.Count > 0 Then
                    Dim answerExportKeys = MessageBox.Show("Export the generated RSA Keys too?", "Export Keys?", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                    If answerExportKeys = vbYes Then
                        RSA_ExportGeneratedKeyPairs()
                    End If
                End If

            End If
        End If

        Return jsonString
    End Function





    Public Function CreateDataOnlyJsonFromGridViews() As String
        ' Create a dictionary for the main JSON object (no wrapping "data" node)
        Dim jsonObject As New Dictionary(Of String, String)

        For Each row As DataGridViewRow In DataGridView_License_Lic_Data.Rows
            If Not row.IsNewRow Then
                ' Add key-value pairs directly to the root dictionary
                Dim key As String = Convert.ToString(row.Cells(0).Value)
                Dim value As String = Convert.ToString(row.Cells(1).Value)
                If Not String.IsNullOrEmpty(key) AndAlso Not String.IsNullOrEmpty(value) Then
                    jsonObject.Add(key, value)
                End If
            End If
        Next

        ' Convert the dictionary to a JSON string
        Dim jsonString As String = JsonConvert.SerializeObject(jsonObject, Formatting.Indented)

        Return jsonString
    End Function




    Public Function ImportJsonLIC(licFilePath As String) As Dictionary(Of String, String)
        Dim result As New Dictionary(Of String, String)(StringComparer.OrdinalIgnoreCase)

        Try
            ' Read the JSON file contents
            Dim jsonContent As String = File.ReadAllText(licFilePath)

            ' Parse the JSON into a dictionary
            Dim serializer As New JavaScriptSerializer()
            Dim data As Dictionary(Of String, Object) = serializer.Deserialize(Of Dictionary(Of String, Object))(jsonContent)

            ' Helper function to find a key based on possible matches
            Dim FindKey As Func(Of IEnumerable(Of String), String) = Function(possibleNames)
                                                                         For Each kvp In data
                                                                             For Each keyName In possibleNames
                                                                                 If kvp.Key.Equals(keyName, StringComparison.OrdinalIgnoreCase) OrElse
                                                                                 kvp.Key.Replace("_", "").Replace("-", "").ToLower().Contains(keyName.Replace("_", "").Replace("-", "").ToLower()) Then
                                                                                     Return kvp.Key
                                                                                 End If
                                                                             Next
                                                                         Next
                                                                         Return Nothing
                                                                     End Function

            '' Find and add the matching keys to the result
            'Dim dataKey = FindKey({"data", "license", "licence"})
            'If dataKey IsNot Nothing Then result("data") = data(dataKey).ToString()

            Dim dataKey = FindKey({"data", "license", "licence"})
            If dataKey IsNot Nothing Then
                Dim dataValue = data(dataKey)
                If TypeOf dataValue Is Dictionary(Of String, Object) Then
                    ' Re-serialize it to JSON string
                    result("data") = serializer.Serialize(CType(dataValue, Dictionary(Of String, Object)))
                Else
                    result("data") = dataValue.ToString()
                End If
            End If
            Dim signatureKey = FindKey({"signature", "digitalsignature", "digital_signature", "digital-signature"})
            If signatureKey IsNot Nothing Then result("signature") = data(signatureKey).ToString()

            Dim algorithmKey = FindKey({"algo", "algorithm"})
            If algorithmKey IsNot Nothing Then result("algorithm") = data(algorithmKey).ToString()

            Dim saltKey = FindKey({"salt"})
            If saltKey IsNot Nothing Then result("salt") = data(saltKey).ToString()

            Dim publicFingerprintKey = FindKey({"publickey_fingerprint", "publicfingerprint", "publicthumbprint"})
            If publicFingerprintKey IsNot Nothing Then result("publickey_fingerprint") = data(publicFingerprintKey).ToString()

            Dim keySizeKey = FindKey({"keysize", "key_size", "key-size", "key size"})
            If keySizeKey IsNot Nothing Then result("keysize") = data(keySizeKey).ToString()

        Catch ex As Exception
            ' Handle any errors, maybe log them if needed
            ' For now, just return an empty dictionary
        End Try

        Return result
    End Function





    Private Sub Button_License_Lic_AddRow_Click(sender As Object, e As EventArgs) Handles Button_License_Lic_AddRow.Click
        ' Create a new row
        Dim newRow As DataGridViewRow = New DataGridViewRow()

        ' Add the cells for DataName and DataValue columns
        newRow.Cells.Add(New DataGridViewTextBoxCell() With {.Value = ""}) ' DataName (TextBox)
        newRow.Cells.Add(New DataGridViewTextBoxCell() With {.Value = ""}) ' DataValue (TextBox)

        ' Add the new row to the DataGridView
        DataGridView_License_Lic_Data.Rows.Add(newRow)
    End Sub


    Private Sub Button_License_Lic_Commit_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub CheckBox_License_Lic_AddSignature_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_License_Lic_AddSignature.CheckedChanged
        If CheckBox_License_Lic_AddSignature.Checked = True Then
            Panel_License_Lic_Verification.Enabled = True
            DataGridView_License_Lic_Signature.Visible = True

        Else
            Panel_License_Lic_Verification.Enabled = False
            DataGridView_License_Lic_Signature.Visible = False
        End If

        'removeRowByKey(TextBox_License_Lic_Verify_SignatureNodeName.Text, DataGridView_License_Lic_Signature)
        'Dim rowsValue As String = ""
        'If String.IsNullOrEmpty(TextBox_License_Lic_Signature.Text) = True Then
        '    rowsValue = "INSERT_HERE"
        'Else
        '    rowsValue = TextBox_License_Lic_Signature.Text
        'End If
        'addDistinctRow(TextBox_License_Lic_Verify_SignatureNodeName.Text, rowsValue, DataGridView_License_Lic_Signature)

        'addDistinctRow(TextBox_License_Lic_Verify_SignatureNodeName.Text, "INSERT_HERE", DataGridView_License_Lic_Signature)
    End Sub


    Private Sub Button_License_Lic_DeleteSelected_Click(sender As Object, e As EventArgs) Handles Button_License_Lic_DeleteSelected.Click
        ' Create a HashSet to store unique row indices (avoids duplicates)
        Dim rowsToDelete As New HashSet(Of Integer)

        ' Check if any rows or cells are selected
        If DataGridView_License_Lic_Data.SelectedCells.Count > 0 Then
            ' Loop through all selected cells
            For Each cell As DataGridViewCell In DataGridView_License_Lic_Data.SelectedCells
                ' Add the row index of each selected cell to the HashSet
                rowsToDelete.Add(cell.RowIndex)
            Next

            ' Now loop through the rowsToDelete set in reverse order to remove rows
            For Each rowIndex As Integer In rowsToDelete.OrderByDescending(Function(r) r)
                ' Make sure we are not trying to delete the new row (empty row)
                If Not DataGridView_License_Lic_Data.Rows(rowIndex).IsNewRow Then
                    ' Remove the row at this index
                    DataGridView_License_Lic_Data.Rows.RemoveAt(rowIndex)
                End If
            Next
        Else
            ' Optionally, show a message if no rows or cells are selected
            MessageBox.Show("Please select one or more cells or rows to delete.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
    End Sub

    Private Sub DataGridView_License_Lic_Data_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView_License_Lic_Data.CellContentClick

    End Sub

    Private Sub DataGridView_License_Lic_Data_CellValidating(sender As Object, e As DataGridViewCellValidatingEventArgs) Handles DataGridView_License_Lic_Data.CellValidating

    End Sub




    Private Sub Button_License_Lic_Verify_AddRow_Click(sender As Object, e As EventArgs) Handles Button_License_Lic_Verify_AddRow.Click
        ' Create a new row
        Dim newRow As DataGridViewRow = New DataGridViewRow()

        ' Add the cells for DataName and DataValue columns
        newRow.Cells.Add(New DataGridViewTextBoxCell() With {.Value = ""}) ' DataName (TextBox)
        newRow.Cells.Add(New DataGridViewTextBoxCell() With {.Value = ""}) ' DataValue (TextBox)

        ' Add the new row to the DataGridView
        DataGridView_License_Lic_Signature.Rows.Add(newRow)
    End Sub



    Private Sub Button_License_Lic_Verify_AddSignatureRow_Click(sender As Object, e As EventArgs) Handles Button_License_Lic_Verify_AddSignatureRow.Click
        removeRowByKey(TextBox_License_Lic_Verify_SignatureNodeName.Text, DataGridView_License_Lic_Signature)
        Dim rowsValue As String = ""
        If String.IsNullOrEmpty(TextBox_License_Lic_Signature.Text) = True Then
            rowsValue = "INSERT_HERE"
        Else
            rowsValue = TextBox_License_Lic_Signature.Text
        End If
        addDistinctRow(TextBox_License_Lic_Verify_SignatureNodeName.Text, rowsValue, DataGridView_License_Lic_Signature)

        ' Clear any previous selections
        DataGridView_License_Lic_Signature.ClearSelection()

        ' Loop through all rows
        For Each row As DataGridViewRow In DataGridView_License_Lic_Signature.Rows
            If Not row.IsNewRow Then
                Dim cellValue As Object = row.Cells(0).Value
                If cellValue IsNot Nothing AndAlso cellValue.ToString().Trim() = TextBox_License_Lic_Verify_SignatureNodeName.Text Then
                    ' Select the cell
                    row.Cells(0).Selected = True
                    ' Optional: also scroll to make sure it’s visible
                    DataGridView_License_Lic_Signature.FirstDisplayedScrollingRowIndex = row.Index
                    Exit Sub ' Stop after first match
                End If
            End If
        Next
    End Sub





    Public Sub addDistinctRow(keyName As String, keyValue As String, ByRef passedDataGridView As DataGridView)
        Dim nodeName As String = TextBox_License_Lic_Verify_SignatureNodeName.Text

        For Each row As DataGridViewRow In passedDataGridView.Rows
            If row.Cells(0).Value IsNot Nothing AndAlso row.Cells(0).Value.ToString() = keyName Then
                'MessageBox.Show("A row with 'DigitalSignature' already exists.", "Duplicate Entry", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Exit Sub
            End If
        Next

        Dim newRow As DataGridViewRow = New DataGridViewRow()

        newRow.Cells.Add(New DataGridViewTextBoxCell() With {.Value = keyName})
        newRow.Cells.Add(New DataGridViewTextBoxCell() With {.Value = keyValue})

        passedDataGridView.Rows.Add(newRow)
    End Sub

    Public Sub removeRowByKey(keyName As String, ByRef passedDataGridView As DataGridView)
        For Each row As DataGridViewRow In passedDataGridView.Rows
            If row.Cells(0).Value IsNot Nothing AndAlso row.Cells(0).Value.ToString() = keyName Then
                passedDataGridView.Rows.Remove(row)
                Exit Sub
            End If
        Next
    End Sub






    Private Sub Button_License_Lic_Verify_DeleteSelected_Click(sender As Object, e As EventArgs) Handles Button_License_Lic_Verify_DeleteSelected.Click
        ' Create a HashSet to store unique row indices (avoids duplicates)
        Dim rowsToDelete As New HashSet(Of Integer)

        ' Check if any rows or cells are selected
        If DataGridView_License_Lic_Signature.SelectedCells.Count > 0 Then
            ' Loop through all selected cells
            For Each cell As DataGridViewCell In DataGridView_License_Lic_Signature.SelectedCells
                ' Add the row index of each selected cell to the HashSet
                rowsToDelete.Add(cell.RowIndex)
            Next

            ' Now loop through the rowsToDelete set in reverse order to remove rows
            For Each rowIndex As Integer In rowsToDelete.OrderByDescending(Function(r) r)
                ' Make sure we are not trying to delete the new row (empty row)
                If Not DataGridView_License_Lic_Signature.Rows(rowIndex).IsNewRow Then
                    ' Remove the row at this index
                    DataGridView_License_Lic_Signature.Rows.RemoveAt(rowIndex)
                End If
            Next
        Else
            ' Optionally, show a message if no rows or cells are selected
            MessageBox.Show("Please select one or more cells or rows to delete.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
    End Sub




    ' Move row up for any DataGridView
    Private Sub MoveRowUp(ByRef passedDatagrid As DataGridView)
        Dim dgv As DataGridView = passedDatagrid
        Dim selectedRowIndex As Integer = dgv.SelectedCells(0).RowIndex ' Get the index of the selected row.

        ' Store the row that was selected
        Dim selectedRow As DataGridViewRow = dgv.Rows(selectedRowIndex)

        ' Make sure the row is not already the first row
        If selectedRowIndex > 0 Then
            ' Remove the row and insert it above the previous row
            dgv.Rows.Remove(selectedRow)
            dgv.Rows.Insert(selectedRowIndex - 1, selectedRow)

            ' Re-select the row that was moved (keeping the original row selected)
            dgv.Rows(selectedRowIndex - 1).Cells(0).Selected = True ' Select the first column of the moved row
        End If
    End Sub


    ' Move row down for any DataGridView
    Private Sub MoveRowDown(ByRef passedDatagrid As DataGridView)
        Dim dgv As DataGridView = passedDatagrid
        Dim selectedRowIndex As Integer = dgv.SelectedCells(0).RowIndex ' Get the index of the selected row.

        ' Store the row that was selected
        Dim selectedRow As DataGridViewRow = dgv.Rows(selectedRowIndex)

        ' Make sure the row is not the last row
        If selectedRowIndex < dgv.Rows.Count - 1 Then
            ' Remove the row and insert it below the next row
            dgv.Rows.Remove(selectedRow)
            dgv.Rows.Insert(selectedRowIndex + 1, selectedRow)

            ' Re-select the row that was moved (keeping the original row selected)
            dgv.Rows(selectedRowIndex + 1).Cells(0).Selected = True ' Select the first column of the moved row
        End If
    End Sub




    Private Sub Button_License_Lic_Verify_DefaultSignatureNodeName_Click(sender As Object, e As EventArgs) Handles Button_License_Lic_Verify_DefaultSignatureNodeName.Click
        TextBox_License_Lic_Verify_SignatureNodeName.Text = "DigitalSignature"
    End Sub

    Private Sub Button_License_Lic_Verify_DefaultJSONNodeName_Click(sender As Object, e As EventArgs) Handles Button_License_Lic_Verify_DefaultJSONNodeName.Click
        TextBox_License_Lic_Verify_JSONNodeName.Text = "signature"
    End Sub

    Private Sub Button_License_Lic_Verify_AddCommonRows_Click(sender As Object, e As EventArgs) Handles Button_License_Lic_Verify_AddCommonRows.Click
        'addDistinctRow("signed_date", DateTime.Now().ToString("yyyy-MM-dd HH:mm:ss"), DataGridView_License_Lic_Signature)
        FormCommonRows.TabControl_CommonRows.SelectedIndex = 1
        FormCommonRows.ShowDialog()
    End Sub


    Private Sub Button_License_Lic_Verify_Up_Click(sender As Object, e As EventArgs) Handles Button_License_Lic_Verify_Up.Click
        MoveRowUp(DataGridView_License_Lic_Signature)
    End Sub

    Private Sub Button_License_Lic_Verify_Down_Click(sender As Object, e As EventArgs) Handles Button_License_Lic_Verify_Down.Click
        MoveRowDown(DataGridView_License_Lic_Signature)
    End Sub



    Private Sub Button_License_Lic_Data_Up_Click(sender As Object, e As EventArgs) Handles Button_License_Lic_Data_Up.Click
        MoveRowUp(DataGridView_License_Lic_Data)
    End Sub

    Private Sub Button_License_Lic_Data_Down_Click(sender As Object, e As EventArgs) Handles Button_License_Lic_Data_Down.Click
        MoveRowDown(DataGridView_License_Lic_Data)
    End Sub

    Private Sub Button_License_Lic_Data_AddCommonRows_Click(sender As Object, e As EventArgs) Handles Button_License_Lic_Data_AddCommonRows.Click
        'addDistinctRow("signed_date", DateTime.Now().ToString("yyyy-MM-dd HH:mm:ss"), DataGridView_License_Lic_Signature)
        FormCommonRows.TabControl_CommonRows.SelectedIndex = 0
        FormCommonRows.ShowDialog()
    End Sub

    Private Sub Button_License_Lic_Verify_AutoSort_Click(sender As Object, e As EventArgs) Handles Button_License_Lic_Verify_AutoSort.Click
        'DataGridView_License_Lic_Signature.Sort()

        SortDataGridView(DataGridView_License_Lic_Signature, 0)

    End Sub


    Public Sub SortDataGridView(ByRef dgv As DataGridView, ByVal columnIndex As Integer)
        ' Check if the column index is valid
        If columnIndex < 0 Or columnIndex >= dgv.Columns.Count Then
            ' If out of range, default to first column (index 0)
            columnIndex = 0
        End If

        ' Sort the DataGridView by the specified column index
        dgv.Sort(dgv.Columns(columnIndex), System.ComponentModel.ListSortDirection.Ascending)
    End Sub

    Private Sub Button_License_Lic_Data_AutoSort_Click(sender As Object, e As EventArgs) Handles Button_License_Lic_Data_AutoSort.Click
        'SortDataGridView(DataGridView_License_Lic_Data, 0)
    End Sub

    Private Sub DataGridView_License_Lic_Data_RowsAdded(sender As Object, e As DataGridViewRowsAddedEventArgs) Handles DataGridView_License_Lic_Data.RowsAdded
        SortDataGridView(DataGridView_License_Lic_Data, 0)
        Dim tempJsonString As String = CreateDataOnlyJsonFromGridViews()
        TextBox_License_Lic_DataOnlyFields.Text = MinifyJson(tempJsonString)
    End Sub

    Private Sub DataGridView_License_Lic_Data_RowsRemoved(sender As Object, e As DataGridViewRowsRemovedEventArgs) Handles DataGridView_License_Lic_Data.RowsRemoved
        SortDataGridView(DataGridView_License_Lic_Data, 0)
        Dim tempJsonString As String = CreateDataOnlyJsonFromGridViews()
        TextBox_License_Lic_DataOnlyFields.Text = MinifyJson(tempJsonString)
    End Sub

    Private Sub DataGridView_License_Lic_Data_CellValueChanged(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView_License_Lic_Data.CellValueChanged
        SortDataGridView(DataGridView_License_Lic_Data, 0)
        Dim tempJsonString As String = CreateDataOnlyJsonFromGridViews()
        TextBox_License_Lic_DataOnlyFields.Text = MinifyJson(tempJsonString)
    End Sub


    Private Sub ComboBox_License_Lic_PreviousPairs_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox_License_Lic_PreviousPairs.SelectedIndexChanged
        ' Mirror the selection
        'RemoveHandler ComboBox_RSA_PreviousPairs.SelectedIndexChanged, AddressOf ComboBox_License_Lic_PreviousPairs_SelectedIndexChanged
        ComboBox_RSA_PreviousPairs.SelectedIndex = ComboBox_License_Lic_PreviousPairs.SelectedIndex
        'AddHandler ComboBox_RSA_PreviousPairs.SelectedIndexChanged, AddressOf ComboBox_License_Lic_PreviousPairs_SelectedIndexChanged

    End Sub


    Private Sub Button_License_Lic_GenerateKeys_Click(sender As Object, e As EventArgs) Handles Button_License_Lic_GenerateKeys.Click
        TabControl1.SelectedTab = TabPage_RSA
    End Sub


    Private Sub Button_License_Lic_HashDataFields_Click(sender As Object, e As EventArgs) Handles Button_License_Lic_HashDataFields.Click
        'TextBox_License_Lic_HashDataFields.Text = GetHash(TextBox_License_Lic_DataOnlyFields.Text)

        Dim normalizedJson As String = MinifyJson(TextBox_License_Lic_DataOnlyFields.Text)
        Dim hashResult As String = GetHash(normalizedJson)
        TextBox_License_Lic_HashDataFields.Text = hashResult

    End Sub

    Private Async Sub Button_License_Lic_SignIt_Click(sender As Object, e As EventArgs) Handles Button_License_Lic_SignIt.Click
        TextBox_License_Lic_Signature.Text = Await RsaSignData(TextBox_License_Lic_HashDataFields.Text, TextBox_RSA_PrivateKey.Text, TextBox_RSA_Salt.Text)
    End Sub

    Private Sub TextBox_RSA_Salt_TextChanged(sender As Object, e As EventArgs) Handles TextBox_RSA_Salt.TextChanged
        TextBox_License_Lic_Salt.Text = TextBox_RSA_Salt.Text
        TextBox_Demo1_Salt.Text = TextBox_RSA_Salt.Text
    End Sub

    Private Async Sub Button_License_Lic_Verify_Click(sender As Object, e As EventArgs) Handles Button_License_Lic_Verify.Click
        Dim isValid As Boolean = Await RsaVerifySignature(TextBox_License_Lic_HashDataFields.Text, TextBox_License_Lic_Signature.Text, TextBox_RSA_PublicKey.Text, TextBox_RSA_Salt.Text)
        TextBox_License_Lic_Verified.Text = isValid.ToString()
    End Sub

    Private Sub Button_License_Lic_HashDataFields_Clear_Click(sender As Object, e As EventArgs) Handles Button_License_Lic_HashDataFields_Clear.Click
        TextBox_License_Lic_HashDataFields.Text = ""
    End Sub

    Private Sub Button_License_Lic_SignIt_Clear_Click(sender As Object, e As EventArgs) Handles Button_License_Lic_SignIt_Clear.Click
        TextBox_License_Lic_Signature.Text = ""
    End Sub

    Private Sub Button_License_Lic_Verify_Clear_Click(sender As Object, e As EventArgs) Handles Button_License_Lic_Verify_Clear.Click
        TextBox_License_Lic_Verified.Text = ""
    End Sub

    Private Sub DataGridView_License_Lic_Signature_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView_License_Lic_Signature.CellContentClick

    End Sub

    Private Sub DataGridView_License_Lic_Signature_RowsAdded(sender As Object, e As DataGridViewRowsAddedEventArgs) Handles DataGridView_License_Lic_Signature.RowsAdded
        SortDataGridView(DataGridView_License_Lic_Signature, 0)
    End Sub

    Private Sub DataGridView_License_Lic_Signature_RowsRemoved(sender As Object, e As DataGridViewRowsRemovedEventArgs) Handles DataGridView_License_Lic_Signature.RowsRemoved
        SortDataGridView(DataGridView_License_Lic_Signature, 0)
    End Sub

    Private Sub DataGridView_License_Lic_Signature_CellValueChanged(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView_License_Lic_Signature.CellValueChanged
        SortDataGridView(DataGridView_License_Lic_Signature, 0)
    End Sub

    Private Sub Button_License_Lic_HashPublicKeyClear_Click(sender As Object, e As EventArgs) Handles Button_License_Lic_HashPublicKeyClear.Click
        TextBox_License_Lic_HashPublicKey.Text = ""
    End Sub

    Private Async Sub Button_License_Lic_HashPublicKey_Click(sender As Object, e As EventArgs) Handles Button_License_Lic_HashPublicKey.Click
        If String.IsNullOrEmpty(TextBox_License_Lic_PublicKey.Text) = False Then
            Dim tempString As String = Await RSA_ExtractKey_Public(TextBox_License_Lic_PublicKey.Text)
            TextBox_License_Lic_HashPublicKey.Text = GetHash(tempString.Trim())
        Else
            MessageBox.Show("Public key field is empty - generate a key pair first, then retry")
        End If
    End Sub

    Private Async Sub Button_License_Lic_CopyPublicKey_Click(sender As Object, e As EventArgs) Handles Button_License_Lic_CopyPublicKey.Click
        If String.IsNullOrEmpty(TextBox_License_Lic_PublicKey.Text) = False Then
            Dim tempString As String = Await RSA_ExtractKey_Public(TextBox_License_Lic_PublicKey.Text)

            Dim answer = MessageBox.Show("Remove all carriage returns and white space?", "Remove White Space?", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If answer = vbYes Then
                CopyStringToClipboard(tempString.Replace(vbCrLf, "").Trim())
            Else
                CopyStringToClipboard(tempString.Trim())
            End If

            MsgBox("copied to clipboard")
        End If
    End Sub

    Private Sub Button_License_Lic_CopyAllPublicKey_Click(sender As Object, e As EventArgs) Handles Button_License_Lic_CopyAllPublicKey.Click
        If String.IsNullOrEmpty(TextBox_License_Lic_PublicKey.Text) = False Then
            Dim answer = MessageBox.Show("Remove all carriage returns and white space?", "Remove White Space?", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If answer = vbYes Then
                CopyStringToClipboard(TextBox_License_Lic_PublicKey.Text.Replace(vbCrLf, "").Trim())
            Else
                CopyStringToClipboard(TextBox_License_Lic_PublicKey.Text.Trim())
            End If
            MsgBox("copied to clipboard")
        End If
    End Sub

    Private Async Sub Button_License_Lic_CopyPrivateKey_Click(sender As Object, e As EventArgs) Handles Button_License_Lic_CopyPrivateKey.Click
        If String.IsNullOrEmpty(TextBox_License_Lic_PrivateKey.Text) = False Then
            Dim tempString As String = Await RSA_ExtractKey_Public(TextBox_License_Lic_PrivateKey.Text)

            Dim answer = MessageBox.Show("Remove all carriage returns and white space?", "Remove White Space?", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If answer = vbYes Then
                CopyStringToClipboard(tempString.Replace(vbCrLf, "").Trim())
            Else
                CopyStringToClipboard(tempString.Trim())
            End If

            MsgBox("copied to clipboard")
        End If
    End Sub

    Private Sub Button_License_Lic_CopyAllPrivateKey_Click(sender As Object, e As EventArgs) Handles Button_License_Lic_CopyAllPrivateKey.Click
        If String.IsNullOrEmpty(TextBox_License_Lic_PrivateKey.Text) = False Then

            Dim answer = MessageBox.Show("Remove all carriage returns and white space?", "Remove White Space?", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If answer = vbYes Then
                CopyStringToClipboard(TextBox_License_Lic_PrivateKey.Text.Replace(vbCrLf, "").Trim())
            Else
                CopyStringToClipboard(TextBox_License_Lic_PrivateKey.Text.Trim())
            End If

            MsgBox("copied to clipboard")
        End If
    End Sub

    Private Sub Button_License_Lic_Data_JSONNodeNameDefault_Click(sender As Object, e As EventArgs) Handles Button_License_Lic_Data_JSONNodeNameDefault.Click
        TextBox_License_Lic_Data_JSONNodeName.Text = "data"
    End Sub

    Private Sub Button_License_Lic_SaveFile_Click(sender As Object, e As EventArgs) Handles Button_License_Lic_SaveFile.Click
        Dim saveFile As Boolean = True
        CreateJsonFromGridViews(saveFile)
    End Sub


    Private Sub Button_License_Lic_ImportJSONLicFile_Click(sender As Object, e As EventArgs) Handles Button_License_Lic_ImportJSONLicFile.Click

        Dim openFileDialog As New OpenFileDialog()

        openFileDialog.Title = "Select License File"
        openFileDialog.Filter = "License Files (*.lic)|*.lic|All Files (*.*)|*.*"
        openFileDialog.RestoreDirectory = True

        If openFileDialog.ShowDialog() = DialogResult.OK Then
            TextBox_License_Lic_LICFilePath.Text = openFileDialog.FileName
            Dim parsedKeyNames As Dictionary(Of String, String) = ImportJsonLIC(openFileDialog.FileName)

            For Each kvp As KeyValuePair(Of String, String) In parsedKeyNames
                'Debug.WriteLine($"Key: {kvp.Key}, Value: {kvp.Value}")

                If kvp.Key = "data" Then
                    TextBox_License_Lic_Imported_DataFields.Text = kvp.Value

                ElseIf kvp.Key = "signature" Then
                    TextBox_License_Lic_ImportedSignature.Text = kvp.Value

                ElseIf kvp.Key = "algorithm" Then
                    TextBox_License_Lic_ImportedAlgorithm.Text = kvp.Value

                ElseIf kvp.Key = "salt" Then
                    TextBox_License_Lic_ImportedSalt.Text = kvp.Value

                ElseIf kvp.Key = "keysize" Then
                    TextBox_License_Lic_ImportedKeySize.Text = kvp.Value

                ElseIf kvp.Key = "publickey_fingerprint" Then
                    TextBox_License_Lic_ImportedPublicKeyFingerprint.Text = kvp.Value

                End If
            Next



        End If

    End Sub


    Private Async Sub Button_License_Lic_VerifyImportedLicFile_Click(sender As Object, e As EventArgs) Handles Button_License_Lic_VerifyImportedLicFile.Click
        Dim isValid As Boolean = Await RsaVerifySignature(TextBox_License_Lic_Imported_DataHashed.Text, TextBox_License_Lic_ImportedSignature.Text, TextBox_License_Lic_PastedPublicKey.Text, TextBox_License_Lic_ImportedSalt.Text)
        TextBox_License_Lic_VerifyImportedLICFile.Text = isValid.ToString()
    End Sub




    Private Sub Button_License_Lic_CloseJSONLicFile_Click(sender As Object, e As EventArgs) Handles Button_License_Lic_CloseJSONLicFile.Click
        TextBox_License_Lic_LICFilePath.Text = ""
        TextBox_License_Lic_ImportedSignature.Text = ""
        TextBox_License_Lic_ImportedSalt.Text = ""
        TextBox_License_Lic_ImportedKeySize.Text = ""
        TextBox_License_Lic_ImportedAlgorithm.Text = ""
        TextBox_License_Lic_ImportedPublicKeyFingerprint.Text = ""

        TextBox_License_Lic_Imported_DataFields.Text = ""
        TextBox_License_Lic_Imported_DataHashed.Text = ""

        TextBox_License_Lic_VerifyImportedLICFile.Text = ""
    End Sub

    Private Sub TextBox_License_Lic_Imported_DataFields_TextChanged(sender As Object, e As EventArgs) Handles TextBox_License_Lic_Imported_DataFields.TextChanged
        TextBox_License_Lic_Imported_DataHashed.Text = GetHash(TextBox_License_Lic_Imported_DataFields.Text)
    End Sub


    Private Async Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        Dim driveHashes As List(Of String) = Await GetFingerprint_HardDrives()
        ListBox1.Items.Clear()
        For Each drivehash In driveHashes
            ListBox1.Items.Add(drivehash)
        Next

    End Sub


    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        ListBox1.Items.Clear()
    End Sub



    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox1.SelectedIndexChanged

    End Sub

    Private Sub ListBox1_KeyDown(sender As Object, e As KeyEventArgs) Handles ListBox1.KeyDown
        If e.Control AndAlso e.KeyCode = Keys.C Then
            If ListBox1.SelectedItems.Count > 0 Then
                Dim selectedItems As String = String.Join(Environment.NewLine, ListBox1.SelectedItems.Cast(Of String)())
                Clipboard.SetText(selectedItems)
                e.Handled = True ' Prevent further processing of this key event
            End If
        End If
    End Sub



    Private Async Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click

        Dim Make As Boolean = CheckBox_System_Include_Make.Checked
        Dim Model As Boolean = CheckBox_System_Include_Model.Checked
        Dim SystemModel As Boolean = CheckBox_System_Include_SystemModel.Checked
        Dim SystemModelFull As Boolean = CheckBox_System_Include_SystemModelFull.Checked
        Dim BIOSSerial As Boolean = CheckBox_System_Include_BIOSSerial.Checked
        Dim MotherboardSerial As Boolean = CheckBox_System_Include_MotherboardSerial.Checked
        Dim MotherboardBaseBoardProduct As Boolean = CheckBox_System_Include_MotherboardBaseBoardProduct.Checked
        Dim MachineUUID As Boolean = CheckBox_System_Include_UUID.Checked


        Dim machineHash As String = Await GetFingerprint_Computer(Make, Model, SystemModel, SystemModelFull, BIOSSerial, MotherboardSerial, MotherboardBaseBoardProduct, MachineUUID)
        ListBox2.Items.Clear()
        ListBox2.Items.Add(machineHash)

    End Sub


    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        ListBox2.Items.Clear()
    End Sub



    Private Sub Button_Encoding_TimestampGenerate_Click(sender As Object, e As EventArgs) Handles Button_Encoding_TimestampGenerate.Click
        Dim selectedFormat As String = ComboBox_Encoding_TimestampGenerate.SelectedItem.ToString()
        Dim currentTime As DateTime = DateTime.Now
        Dim formattedTime As String = ""

        Select Case selectedFormat
            Case "UTC Seconds"
                Dim utcNow As DateTime = DateTime.UtcNow
                Dim unixTime As Long = CLng((utcNow - New DateTime(1970, 1, 1)).TotalSeconds)
                formattedTime = unixTime.ToString()
            Case "YYYY-MM-DD HH:MM:SS"
                formattedTime = currentTime.ToString("yyyy-MM-dd HH:mm:ss")
            Case "DD-MM-YYYY HH:MM:SS"
                formattedTime = currentTime.ToString("dd-MM-yyyy HH:mm:ss")
            Case "HH:MM:SS DD-MM-YYYY"
                formattedTime = currentTime.ToString("HH:mm:ss dd-MM-yyyy")
            Case "HH:MM:SS YYYY-MM-DD"
                formattedTime = currentTime.ToString("HH:mm:ss yyyy-MM-dd")
            Case "YYYY-MM-DD"
                formattedTime = currentTime.ToString("yyyy-MM-dd")
            Case "DD-MM-YYYY"
                formattedTime = currentTime.ToString("dd-MM-yyyy")
            Case "HH:MM:SS"
                formattedTime = currentTime.ToString("HH:mm:ss")
            Case Else
                formattedTime = "Invalid selection"
        End Select

        TextBox_Encoding_TimestampGenerate.Text = formattedTime
    End Sub


    Private Sub Button11_Click(sender As Object, e As EventArgs) Handles Button11.Click
        TextBox_Encoding_DecodedData.Text = ""
    End Sub


    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        TextBox_Encoding_EncodedData.Text = ""
    End Sub


    Private Sub Button12_Click(sender As Object, e As EventArgs) Handles Button12.Click
        Dim string1 As String = TextBox_Encoding_InputData.Text
        Dim string2 As String = TextBox_Encoding_EncodedData.Text

        TextBox_Encoding_InputData.Text = string2
        TextBox_Encoding_EncodedData.Text = string1
    End Sub


    Private Sub Button_Encoding_GenerateGUID_Click(sender As Object, e As EventArgs) Handles Button_Encoding_GenerateGUID.Click
        TextBox_Encoding_GenerateGUID.Text = GenerateUUID_LicGen()
    End Sub

    Private Async Sub Button_LicenseGen_Verify_GetMachineFingerprint_Click(sender As Object, e As EventArgs) Handles Button_LicenseGen_Verify_GetMachineFingerprint.Click
        TextBox_LicenseGen_Verify_MachineFingerprint.Text = Await GetFingerprint_Computer()
    End Sub

    Private Sub Button_LicenseGen_Verify_CopyMAchineFingerprint_Click(sender As Object, e As EventArgs) Handles Button_LicenseGen_Verify_CopyMAchineFingerprint.Click
        CopyStringToClipboard(TextBox_LicenseGen_Verify_MachineFingerprint.Text)
        MsgBox("Copied to clipboard")
    End Sub


    Private Sub Button_LicenseGen_Verify_GetMachineHash_Click(sender As Object, e As EventArgs) Handles Button_LicenseGen_Verify_GetMachineHash.Click
        TextBox_LicenseGen_Verify_FingerPrintHash.Text = GetHash(TextBox_LicenseGen_Verify_MachineFingerprint.Text)
    End Sub


    Private Sub Button_LicenseGen_Verify_CopyMachineHash_Click(sender As Object, e As EventArgs) Handles Button_LicenseGen_Verify_CopyMachineHash.Click
        CopyStringToClipboard(TextBox_LicenseGen_Verify_FingerPrintHash.Text)
        MsgBox("Copied to clipboard")
    End Sub

    Private Sub Button_LicenseGen_Verify_GetTestDataHash_Click(sender As Object, e As EventArgs) Handles Button_LicenseGen_Verify_GetTestDataHash.Click
        TextBox_LicenseGen_Verify_TestDataHashed.Text = GetHash(TextBox_LicenseGen_Verify_TestData.Text)
    End Sub

    Private Async Sub Button_LicenseGen_Verify_GetSignature_Click(sender As Object, e As EventArgs) Handles Button_LicenseGen_Verify_GetSignature.Click
        TextBox_Verify_Signature.Text = Await RsaSignData(TextBox_Verify_DataHashForSignature.Text, TextBox_Verify_PrivateKeyForSignature.Text, TextBox_Verify_SaltForSignature.Text)
    End Sub

    Private Async Sub Button_LicenseGen_Verify_Verify_Click(sender As Object, e As EventArgs) Handles Button_LicenseGen_Verify_Verify.Click
        Dim isValid As Boolean = Await RsaVerifySignature(TextBox_LicenseGen_Verify_DataHashForVerification.Text, TextBox_LicenseGen_Verify_SignatureForVerification.Text, TextBox_LicenseGen_Verify_PublicKeyForVerification.Text, TextBox_LicenseGen_Verify_SaltForVerification.Text)
        TextBox_LicenseGen_Verify_Verified.Text = isValid.ToString()
    End Sub

    Private Async Sub Button13_Click(sender As Object, e As EventArgs) Handles Button13.Click
        Dim fingerprintOfDriveAppRunsFrom As String = Await GetFingerprint_HardDriveAppRunsFrom()
        ListBox3.Items.Clear()
        ListBox3.Items.Add(fingerprintOfDriveAppRunsFrom)
    End Sub



    Private Sub ListBox3_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox3.SelectedIndexChanged

    End Sub
    Private Sub ListBox3_KeyDown(sender As Object, e As KeyEventArgs) Handles ListBox3.KeyDown
        If e.Control AndAlso e.KeyCode = Keys.C Then
            If ListBox3.SelectedItems.Count > 0 Then
                Dim selectedItems As String = String.Join(Environment.NewLine, ListBox3.SelectedItems.Cast(Of String)())
                Clipboard.SetText(selectedItems)
                e.Handled = True ' Prevent further processing of this key event
            End If
        End If
    End Sub




    Private Sub ListBox2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox2.SelectedIndexChanged

    End Sub
    Private Sub ListBox2_KeyDown(sender As Object, e As KeyEventArgs) Handles ListBox2.KeyDown
        If e.Control AndAlso e.KeyCode = Keys.C Then
            If ListBox2.SelectedItems.Count > 0 Then
                Dim selectedItems As String = String.Join(Environment.NewLine, ListBox2.SelectedItems.Cast(Of String)())
                Clipboard.SetText(selectedItems)
                e.Handled = True ' Prevent further processing of this key event
            End If
        End If
    End Sub

    Private Async Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        MsgBox("Hostname" & vbCrLf & Await GetThe_Computer("Hostname"))
    End Sub

    Private Async Sub Button14_Click(sender As Object, e As EventArgs) Handles Button14.Click
        MsgBox("Domain" & vbCrLf & Await GetThe_Computer("Domain"))
    End Sub

    Private Async Sub Button15_Click(sender As Object, e As EventArgs) Handles Button15.Click
        MsgBox("Make" & vbCrLf & Await GetThe_Computer("Make"))
    End Sub

    Private Async Sub Button16_Click(sender As Object, e As EventArgs) Handles Button16.Click
        MsgBox("Model" & vbCrLf & Await GetThe_Computer("Model"))
    End Sub

    Private Async Sub Button17_Click(sender As Object, e As EventArgs) Handles Button17.Click
        MsgBox("SystemModel" & vbCrLf & Await GetThe_Computer("SystemModel"))
    End Sub

    Private Async Sub Button18_Click(sender As Object, e As EventArgs) Handles Button18.Click
        MsgBox("SystemModelFull" & vbCrLf & Await GetThe_Computer("SystemModelFull"))
    End Sub

    Private Async Sub Button19_Click(sender As Object, e As EventArgs) Handles Button19.Click
        MsgBox("BIOSSerial" & vbCrLf & Await GetThe_Computer("BIOSSerial"))
    End Sub

    Private Async Sub Button20_Click(sender As Object, e As EventArgs) Handles Button20.Click
        MsgBox("MotherboardSerial" & vbCrLf & Await GetThe_Computer("MotherboardSerial"))
    End Sub

    Private Async Sub Button21_Click(sender As Object, e As EventArgs) Handles Button21.Click
        MsgBox("MotherBoardBaseBoardProduct" & vbCrLf & Await GetThe_Computer("MotherBoardBaseBoardProduct"))
    End Sub

    Private Async Sub Button22_Click(sender As Object, e As EventArgs) Handles Button22.Click
        MsgBox("UUID" & vbCrLf & Await GetThe_Computer("UUID"))
    End Sub

    Private Async Sub Button23_Click(sender As Object, e As EventArgs) Handles Button23.Click
        MsgBox("CPUName" & vbCrLf & Await GetThe_Computer("CPUName"))
    End Sub

    Private Async Sub Button24_Click(sender As Object, e As EventArgs) Handles Button24.Click
        MsgBox("CPUCount" & vbCrLf & Await GetThe_Computer("CPUCount"))
    End Sub

    Private Async Sub Button25_Click(sender As Object, e As EventArgs) Handles Button25.Click
        MsgBox("CPUCores" & vbCrLf & Await GetThe_Computer("CPUCores"))
    End Sub

    Private Async Sub Button26_Click(sender As Object, e As EventArgs) Handles Button26.Click
        MsgBox("CPUThreads" & vbCrLf & Await GetThe_Computer("CPUThreads"))
    End Sub

    Private Async Sub Button27_Click(sender As Object, e As EventArgs) Handles Button27.Click
        MsgBox("CPUSpeed" & vbCrLf & Await GetThe_Computer("CPUSpeed"))
    End Sub

    Private Async Sub Button28_Click(sender As Object, e As EventArgs) Handles Button28.Click
        MsgBox("CPUArchitecture" & vbCrLf & Await GetThe_Computer("CPUArchitecture"))
    End Sub

    Private Async Sub Button29_Click(sender As Object, e As EventArgs) Handles Button29.Click
        MsgBox("RAMSize" & vbCrLf & Await GetThe_Computer("RAMSize"))
    End Sub

    Private Async Sub Button30_Click(sender As Object, e As EventArgs) Handles Button30.Click
        MsgBox("RAMSpeed" & vbCrLf & Await GetThe_Computer("RAMSpeed"))
    End Sub

    Private Async Sub Button31_Click(sender As Object, e As EventArgs) Handles Button31.Click
        MsgBox("OSName" & vbCrLf & Await GetThe_Computer("OSName"))
    End Sub

    Private Async Sub Button32_Click(sender As Object, e As EventArgs) Handles Button32.Click
        MsgBox("OSBuild" & vbCrLf & Await GetThe_Computer("OSBuild"))
    End Sub

    Private Async Sub Button33_Click(sender As Object, e As EventArgs) Handles Button33.Click
        MsgBox("OSVersion" & vbCrLf & Await GetThe_Computer("OSVersion"))
    End Sub

    Private Async Sub Button34_Click(sender As Object, e As EventArgs) Handles Button34.Click
        MsgBox("OSArchitecture" & vbCrLf & Await GetThe_Computer("OSArchitecture"))
    End Sub

    Private Async Sub Button35_Click(sender As Object, e As EventArgs) Handles Button35.Click
        MsgBox("OSServiceChannel" & vbCrLf & Await GetThe_Computer("OSServiceChannel"))
    End Sub

    Private Async Sub Button36_Click(sender As Object, e As EventArgs) Handles Button36.Click
        MsgBox("Count" & vbCrLf & Await GetThe_HardDrive("Count"))
    End Sub

    Private Async Sub Button37_Click(sender As Object, e As EventArgs) Handles Button37.Click
        Dim allDriveLetters As List(Of String) = Await GetAllDriveLettersAsync()
        For Each driveLetter In allDriveLetters
            MsgBox("PNPDeviceID for Drive: " & driveLetter & ":\" & vbCrLf & vbCrLf & Await GetThe_HardDrive("PNPDeviceID", driveLetter))
        Next
    End Sub

    Private Async Sub Button38_Click(sender As Object, e As EventArgs) Handles Button38.Click
        Dim allDriveLetters As List(Of String) = Await GetAllDriveLettersAsync()
        For Each driveLetter In allDriveLetters
            MsgBox("DriveSerialNumber for Drive: " & driveLetter & ":\" & vbCrLf & vbCrLf & Await GetThe_HardDrive("DriveSerialNumber", driveLetter))
        Next
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        ListBox3.Items.Clear()
    End Sub

    Private Async Sub Button39_Click(sender As Object, e As EventArgs) Handles Button39.Click
        Dim allDriveLetters As List(Of String) = Await GetAllDriveLettersAsync()
        For Each driveLetter In allDriveLetters
            MsgBox("VolumeSerialNumber for Drive: " & driveLetter & ":\" & vbCrLf & vbCrLf & Await GetThe_HardDrive("VolumeSerialNumber", driveLetter))
        Next
    End Sub

    Private Async Sub Button40_Click(sender As Object, e As EventArgs) Handles Button40.Click
        Dim allDriveLetters As List(Of String) = Await GetAllDriveLettersAsync()
        For Each driveLetter In allDriveLetters
            MsgBox("Model for Drive: " & driveLetter & ":\" & vbCrLf & vbCrLf & Await GetThe_HardDrive("Model", driveLetter))
        Next
    End Sub

    Private Async Sub Button41_Click(sender As Object, e As EventArgs) Handles Button41.Click
        Dim allDriveLetters As List(Of String) = Await GetAllDriveLettersAsync()
        For Each driveLetter In allDriveLetters
            MsgBox("DiskDeviceID for Drive: " & driveLetter & ":\" & vbCrLf & vbCrLf & Await GetThe_HardDrive("DiskDeviceID", driveLetter))
        Next
    End Sub

    Private Async Sub Button42_Click(sender As Object, e As EventArgs) Handles Button42.Click
        Dim allDriveLetters As List(Of String) = Await GetAllDriveLettersAsync()
        For Each driveLetter In allDriveLetters
            MsgBox("SizeB for Drive: " & driveLetter & ":\" & vbCrLf & vbCrLf & Await GetThe_HardDrive("SizeB", driveLetter))
        Next
    End Sub

    Private Async Sub Button43_Click(sender As Object, e As EventArgs) Handles Button43.Click
        Dim allDriveLetters As List(Of String) = Await GetAllDriveLettersAsync()
        For Each driveLetter In allDriveLetters
            MsgBox("SizeGB for Drive: " & driveLetter & ":\" & vbCrLf & vbCrLf & Await GetThe_HardDrive("SizeGB", driveLetter))
        Next
    End Sub

    Private Async Sub Button44_Click(sender As Object, e As EventArgs) Handles Button44.Click
        Dim allDriveLetters As List(Of String) = Await GetAllDriveLettersAsync()
        For Each driveLetter In allDriveLetters
            MsgBox("FreeSpaceB for Drive: " & driveLetter & ":\" & vbCrLf & vbCrLf & Await GetThe_HardDrive("FreeSpaceB", driveLetter))
        Next
    End Sub

    Private Async Sub Button45_Click(sender As Object, e As EventArgs) Handles Button45.Click
        Dim allDriveLetters As List(Of String) = Await GetAllDriveLettersAsync()
        For Each driveLetter In allDriveLetters
            MsgBox("FreeSpaceGB for Drive: " & driveLetter & ":\" & vbCrLf & vbCrLf & Await GetThe_HardDrive("FreeSpaceGB", driveLetter))
        Next
    End Sub

    Private Async Sub Button46_Click(sender As Object, e As EventArgs) Handles Button46.Click
        ' 2 METHODS - EITHER:
        Dim allDriveLetters As List(Of String) = Await GetAllDriveLettersAsync()
        For Each driveLetter In allDriveLetters
            MsgBox(driveLetter & ":\")
        Next

        '' OR
        'Dim allDriveLetters As List(Of String) = Await GetAllDriveLettersAsync()
        'For Each driveLetter In allDriveLetters
        '    MsgBox("Drive Letter: " & Await GetThe_HardDrive("DriveLetter", driveLetter))
        'Next
    End Sub

    Private Async Sub Button47_Click(sender As Object, e As EventArgs) Handles Button47.Click
        Dim allDriveLetters As List(Of String) = Await GetAllDriveLettersAsync()
        For Each driveLetter In allDriveLetters
            MsgBox("VolumeName for Drive: " & driveLetter & ":\" & vbCrLf & vbCrLf & Await GetThe_HardDrive("VolumeName", driveLetter))
        Next
    End Sub

    Private Async Sub Button48_Click(sender As Object, e As EventArgs) Handles Button48.Click
        Dim allDriveLetters As List(Of String) = Await GetAllDriveLettersAsync()
        For Each driveLetter In allDriveLetters
            MsgBox("FileSystem for Drive: " & driveLetter & ":\" & vbCrLf & vbCrLf & Await GetThe_HardDrive("FileSystem", driveLetter))
        Next
    End Sub

    Private Async Sub Button49_Click(sender As Object, e As EventArgs) Handles Button49.Click
        MsgBox("NICDescription" & vbCrLf & Await GetThe_Network("NICDescription"))
    End Sub

    Private Async Sub Button50_Click(sender As Object, e As EventArgs) Handles Button50.Click
        MsgBox("IPv4Address" & vbCrLf & Await GetThe_Network("IPv4Address"))
    End Sub

    Private Async Sub Button51_Click(sender As Object, e As EventArgs) Handles Button51.Click
        MsgBox("MACAddress" & vbCrLf & Await GetThe_Network("MACAddress"))
    End Sub

    Private Async Sub Button52_Click(sender As Object, e As EventArgs) Handles Button52.Click
        MsgBox("SubnetMask" & vbCrLf & Await GetThe_Network("SubnetMask"))
    End Sub

    Private Async Sub Button53_Click(sender As Object, e As EventArgs) Handles Button53.Click
        MsgBox("DefaultGateway" & vbCrLf & Await GetThe_Network("DefaultGateway"))
    End Sub

    Private Async Sub Button54_Click(sender As Object, e As EventArgs) Handles Button54.Click
        MsgBox("DNSDomainSuffix" & vbCrLf & Await GetThe_Network("DNSDomainSuffix"))
    End Sub

    Private Async Sub Button55_Click(sender As Object, e As EventArgs) Handles Button55.Click
        MsgBox("Username" & vbCrLf & Await GetThe_User("Username"))
    End Sub

    Private Async Sub Button56_Click(sender As Object, e As EventArgs) Handles Button56.Click
        MsgBox("DomainAndUsername" & vbCrLf & Await GetThe_User("DomainAndUsername"))
    End Sub

    Private Sub Button57_Click(sender As Object, e As EventArgs) Handles Button57.Click
        TextBox_Encoding_EncodedData.Text = SplitAndReverseString(TextBox_Encoding_InputData.Text)
    End Sub

    Private Async Sub Button_RSA_ImportGeneratedKeyPairs_Click(sender As Object, e As EventArgs) Handles Button_RSA_ImportGeneratedKeyPairs.Click
        RSA_ImportGeneratedKeyPairs()

        ' Optionally, update the ComboBox or any other UI element after importing
        Await UpdateComboBoxWithKeyPairs()
    End Sub

    Private Async Sub Button_Demo1_GenerateKeys_Click(sender As Object, e As EventArgs) Handles Button_Demo1_GenerateKeys.Click

        CheckBox_RSA_EnableSeed.Checked = False
        CheckBox_RSA_Salt.Checked = False

        TextBox_Demo1_Seed.Text = ""
        TextBox_Demo1_Salt.Text = ""

        Dim keySize As Integer = Integer.Parse(ComboBox_RSA_KeySize.SelectedItem.ToString())
        Dim seed As String = TextBox_RSA_Seed.Text.Trim()

        'GenerateRsaKeys(RSAPublicKey, RSAPrivateKey, keySize, seed)
        Await GenerateRsaKeysAsync(keySize, seed)

        ' Get a unique integer key for each key pair (simple counter approach)
        Dim keyIdentifier As Integer = RSAKeyPairs.Count + 1 ' Incremental key identifier

        ' Get the optional description from the new TextBox
        Dim keyPairDescription As String = TextBox_RSA_KeyPairDescription.Text.Trim()

        ' Create the key pair dictionary
        Dim keyPair As New Dictionary(Of String, String) From {
            {"PublicKey", RSAPublicKey},
            {"PrivateKey", RSAPrivateKey},
            {"KeySize", keySize.ToString()},
            {"Seed", seed},
            {"Salt", TextBox_RSA_Salt.Text.Trim()}
        }

        ' Add the description to the dictionary, if it's provided
        If Not String.IsNullOrEmpty(keyPairDescription) Then
            keyPair.Add("Description", keyPairDescription)
        End If


        ' Add the key pair to the dictionary with the unique identifier
        RSAKeyPairs.Add(keyIdentifier, keyPair)

        ' Update the ComboBox with the new key pair entry
        Await UpdateComboBoxWithKeyPairs()

        '' TROUBLESHOOTING
        'For Each outerKvp As KeyValuePair(Of Integer, Dictionary(Of String, String)) In RSAKeyPairs
        '    Debug.WriteLine("Outer Key: " & outerKvp.Key)

        '    For Each innerKvp As KeyValuePair(Of String, String) In outerKvp.Value
        '        Debug.WriteLine("    Inner Key: " & innerKvp.Key & " - Value: " & innerKvp.Value)
        '    Next

        '    ' Check if there's a description and print it out
        '    If outerKvp.Value.ContainsKey("Description") Then
        '        Debug.WriteLine("    Description: " & outerKvp.Value("Description"))
        '    End If
        'Next
        'Debug.WriteLine(vbCrLf & vbCrLf)


        TextBox_RSA_PublicKey.Text = RSAPublicKey
        TextBox_RSA_PrivateKey.Text = RSAPrivateKey

        ComboBox_Demo1_PreviousPairs.SelectedIndex = ComboBox_Demo1_PreviousPairs.Items.Count - 1

    End Sub

    Private Sub ComboBox_Demo1_PreviousPairs_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox_Demo1_PreviousPairs.SelectedIndexChanged


        'RemoveHandler ComboBox_RSA_PreviousPairs.SelectedIndexChanged, AddressOf ComboBox_RSA_PreviousPairs_SelectedIndexChanged
        ComboBox_RSA_PreviousPairs.SelectedIndex = ComboBox_Demo1_PreviousPairs.SelectedIndex
        'AddHandler ComboBox_RSA_PreviousPairs.SelectedIndexChanged, AddressOf ComboBox_RSA_PreviousPairs_SelectedIndexChanged


    End Sub

    Private Sub TextBox_RSA_Seed_TextChanged(sender As Object, e As EventArgs) Handles TextBox_RSA_Seed.TextChanged

    End Sub

    Private Sub TextBox_RSA_Seed_KeyUp(sender As Object, e As KeyEventArgs) Handles TextBox_RSA_Seed.KeyUp
        TextBox_Demo1_Seed.Text = TextBox_RSA_Seed.Text
    End Sub




    Private Sub TextBox_RSA_PublicKey_TextChanged(sender As Object, e As EventArgs) Handles TextBox_RSA_PublicKey.TextChanged

    End Sub



    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = True Then
            If ListBox_Demo1_Characteristics.Items.Contains("BIOSSerial") = False Then
                ListBox_Demo1_Characteristics.Items.Add("BIOSSerial")
            End If
        Else
            If ListBox_Demo1_Characteristics.Items.Contains("BIOSSerial") = True Then
                ListBox_Demo1_Characteristics.Items.Remove("BIOSSerial")
            End If
        End If
    End Sub



    Private Sub CheckBox2_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox2.CheckedChanged
        If CheckBox2.Checked = True Then
            If ListBox_Demo1_Characteristics.Items.Contains("MotherboardSerial") = False Then
                ListBox_Demo1_Characteristics.Items.Add("MotherboardSerial")
            End If
        Else
            If ListBox_Demo1_Characteristics.Items.Contains("MotherboardSerial") = True Then
                ListBox_Demo1_Characteristics.Items.Remove("MotherboardSerial")
            End If
        End If
    End Sub



    Private Sub CheckBox3_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox3.CheckedChanged
        If CheckBox3.Checked = True Then
            If ListBox_Demo1_Characteristics.Items.Contains("MotherBoardBaseBoardProduct") = False Then
                ListBox_Demo1_Characteristics.Items.Add("MotherBoardBaseBoardProduct")
            End If
        Else
            If ListBox_Demo1_Characteristics.Items.Contains("MotherBoardBaseBoardProduct") = True Then
                ListBox_Demo1_Characteristics.Items.Remove("MotherBoardBaseBoardProduct")
            End If
        End If
    End Sub



    Private Sub CheckBox4_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox4.CheckedChanged
        If CheckBox4.Checked = True Then
            If ListBox_Demo1_Characteristics.Items.Contains("SystemModelFull") = False Then
                ListBox_Demo1_Characteristics.Items.Add("SystemModelFull")
            End If
        Else
            If ListBox_Demo1_Characteristics.Items.Contains("SystemModelFull") = True Then
                ListBox_Demo1_Characteristics.Items.Remove("SystemModelFull")
            End If
        End If
    End Sub



    Private Sub CheckBox5_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox5.CheckedChanged
        If CheckBox5.Checked = True Then
            If ListBox_Demo1_Characteristics.Items.Contains("UUID") = False Then
                ListBox_Demo1_Characteristics.Items.Add("UUID")
            End If
        Else
            If ListBox_Demo1_Characteristics.Items.Contains("UUID") = True Then
                ListBox_Demo1_Characteristics.Items.Remove("UUID")
            End If
        End If
    End Sub



    Private Sub CheckBox6_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox6.CheckedChanged
        If CheckBox6.Checked = True Then
            If ListBox_Demo1_Characteristics.Items.Contains("DriveSerialNumber") = False Then
                ListBox_Demo1_Characteristics.Items.Add("DriveSerialNumber")
            End If
        Else
            If ListBox_Demo1_Characteristics.Items.Contains("DriveSerialNumber") = True Then
                ListBox_Demo1_Characteristics.Items.Remove("DriveSerialNumber")
            End If
        End If
    End Sub


    Private Async Sub Button_Demo1_GenerateFingerprint_Click(sender As Object, e As EventArgs) Handles Button_Demo1_GenerateFingerprint.Click
        TextBox_Demo1_Fingerprint.Text = ""

        Dim concatenatedString As New StringBuilder
        For Each item In ListBox_Demo1_Characteristics.Items
            Select Case item
                Case "BIOSSerial"
                    concatenatedString.Append(Await GetThe_Computer("BIOSSerial") & ";")

                Case "MotherboardSerial"
                    concatenatedString.Append(Await GetThe_Computer("MotherboardSerial") & ";")

                Case "MotherBoardBaseBoardProduct"
                    concatenatedString.Append(Await GetThe_Computer("MotherBoardBaseBoardProduct") & ";")

                Case "SystemModelFull"
                    concatenatedString.Append(Await GetThe_Computer("SystemModelFull") & ";")

                Case "UUID"
                    concatenatedString.Append(Await GetThe_Computer("UUID") & ";")

                Case "DriveSerialNumber"
                    concatenatedString.Append(Await GetThe_HardDrive("DriveSerialNumber") & ";")
            End Select
        Next

        ' TROUBLESHOOTING
        If CheckBox_Demo1_ShowConcatenatedData.Checked = True Then
            MsgBox("Concatenating:" & vbCrLf & vbCrLf & concatenatedString.ToString & vbCrLf & vbCrLf & vbCrLf & "Then Hash it:" & vbCrLf & vbCrLf & GetHash(concatenatedString.ToString))
        End If

        TextBox_Demo1_Fingerprint.Text = GetHash(concatenatedString.ToString)
    End Sub


    Private Sub CheckBox7_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox7.CheckedChanged
        DateTimePicker1.Value = DateTime.Now.AddMinutes(5).AddSeconds(-DateTime.Now.Second)
        Label_Demo1_SetExpiryValue.Text = DateTimePicker1.Value.ToString("dd/MM/yyyy HH:mm:ss")
    End Sub

    Private Sub CheckBox15_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox15.CheckedChanged
        DateTimePicker1.Value = DateTime.Now.AddHours(1).AddSeconds(-DateTime.Now.Second)
        Label_Demo1_SetExpiryValue.Text = DateTimePicker1.Value.ToString("dd/MM/yyyy HH:mm:ss")
    End Sub

    Private Sub CheckBox8_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox8.CheckedChanged
        DateTimePicker1.Value = DateTime.Now.AddDays(1).Date
        Label_Demo1_SetExpiryValue.Text = DateTimePicker1.Value.ToString("dd/MM/yyyy HH:mm:ss")
    End Sub

    Private Sub CheckBox9_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox9.CheckedChanged
        DateTimePicker1.Value = DateTime.Now.AddDays(7).Date
        Label_Demo1_SetExpiryValue.Text = DateTimePicker1.Value.ToString("dd/MM/yyyy HH:mm:ss")
    End Sub

    Private Sub CheckBox10_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox10.CheckedChanged
        DateTimePicker1.Value = DateTime.Now.AddMonths(1).Date
        Label_Demo1_SetExpiryValue.Text = DateTimePicker1.Value.ToString("dd/MM/yyyy HH:mm:ss")
    End Sub

    Private Sub CheckBox11_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox11.CheckedChanged
        DateTimePicker1.Value = DateTime.Now.AddMonths(3).Date
        Label_Demo1_SetExpiryValue.Text = DateTimePicker1.Value.ToString("dd/MM/yyyy HH:mm:ss")
    End Sub

    Private Sub CheckBox13_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox13.CheckedChanged
        DateTimePicker1.Value = DateTime.Now.AddMonths(6).Date
        Label_Demo1_SetExpiryValue.Text = DateTimePicker1.Value.ToString("dd/MM/yyyy HH:mm:ss")
    End Sub

    Private Sub CheckBox14_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox14.CheckedChanged
        DateTimePicker1.Value = DateTime.Now.AddYears(1).Date
        Label_Demo1_SetExpiryValue.Text = DateTimePicker1.Value.ToString("dd/MM/yyyy HH:mm:ss")
    End Sub

    Private Sub DateTimePicker1_ValueChanged(sender As Object, e As EventArgs) Handles DateTimePicker1.ValueChanged
        Label_Demo1_SetExpiryValue.Text = DateTimePicker1.Value.ToString("dd/MM/yyyy HH:mm:ss")
    End Sub

    Private Sub Label_Demo1_SetExpiryValue_Click(sender As Object, e As EventArgs) Handles Label_Demo1_SetExpiryValue.Click
        ' USE TEXT CHANGED INSTEAD 
    End Sub

    Private Sub Label_Demo1_SetExpiryValue_TextChanged(sender As Object, e As EventArgs) Handles Label_Demo1_SetExpiryValue.TextChanged
        ' Display the UTC seconds
        Label_Demo1_SetExpiryValueInUTC.Text = DateTimePicker1.Value.ToUniversalTime().ToString("dd/MM/yyyy HH:mm:ss")
    End Sub

    Private Sub Button60_Click(sender As Object, e As EventArgs) Handles Button60.Click

        If String.IsNullOrEmpty(TextBox_Demo1_Fingerprint.Text) Then
            MessageBox.Show("No Fingerprint has been generated", "No Fingerprint Generated", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If

        If Label_Demo1_SetExpiryValue.Text = "SET_EXPIRY" Then
            MessageBox.Show("You haven't Set an expiry date - set one first, then retry", "No Expiry Set", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If

        If DateTimePicker1.Value < DateTime.Now() Then
            MessageBox.Show("You've set an expiry in the past - it must be in the future", "Expiry Set to Past Date", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If

        TextBox_Demo1_FingerprintPlusExpiry.Text = TextBox_Demo1_Fingerprint.Text & Label_Demo1_SetExpiryValueInUTC.Text
    End Sub

    Private Sub Button61_Click(sender As Object, e As EventArgs) Handles Button61.Click
        If String.IsNullOrEmpty(TextBox_Demo1_FingerprintPlusExpiry.Text) Then
            MessageBox.Show("No Data has been generated to hash - Create a fingerprint, and set an expiry first, then retry", "No Data Generated", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If

        TextBox_Demo1_FingerprintPlusExpiryHash.Text = GetHash(TextBox_Demo1_FingerprintPlusExpiry.Text)
    End Sub

    Private Async Sub Button58_Click(sender As Object, e As EventArgs) Handles Button58.Click

        If String.IsNullOrEmpty(TextBox_Demo1_PrivateKey.Text) Then
            MessageBox.Show("No Private Key has been specified - Generate, and select one, then retry", "No Private Key Selected", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If

        If String.IsNullOrEmpty(TextBox_Demo1_FingerprintPlusExpiryHash.Text) Then
            MessageBox.Show("No Hash has been generated - ensure you've generated a fingerprint, and specified an expiry date to generate the hash", "No Hash Generated", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If

        TextBox_Demo1_Signature.Text = Await RsaSignData(TextBox_Demo1_FingerprintPlusExpiryHash.Text, TextBox_Demo1_PrivateKey.Text, TextBox_Demo1_Salt.Text)
    End Sub



    Private Sub Button59_Click(sender As Object, e As EventArgs) Handles Button59.Click
        Dim utcDateTime As DateTime = DateTimePicker1.Value.ToUniversalTime
        LICFile_LocalMachine_Export(utcDateTime, TextBox_Demo1_Signature.Text)
    End Sub



    Private Sub Button62_Click(sender As Object, e As EventArgs) Handles Button_Demo1_LoadedLICFileBrowse.Click
        ' Create and configure the OpenFileDialog
        Using openFileDialog As New OpenFileDialog()
            openFileDialog.Filter = "License Files (*.lic)|*.lic|All Files (*.*)|*.*" ' Filter for .lic files, with an option for all files
            openFileDialog.Title = "Select a License File"

            ' Show the dialog and check if the user selected a file
            If openFileDialog.ShowDialog() = DialogResult.OK Then
                ' If a file was selected, populate the TextBox with the file path
                TextBox_Demo1_LoadedLICFile.Text = openFileDialog.FileName
            End If
        End Using

        Demo1_ImportLICFile()

    End Sub



    Private Async Sub Button65_Click(sender As Object, e As EventArgs)

        TextBox_Demo1_VerifyFingerprint.Text = ""

        Dim concatenatedString As New StringBuilder
        For Each item In ListBox_Demo1_Characteristics.Items
            Select Case item
                Case "BIOSSerial"
                    concatenatedString.Append(Await GetThe_Computer("BIOSSerial") & ";")

                Case "MotherboardSerial"
                    concatenatedString.Append(Await GetThe_Computer("MotherboardSerial") & ";")

                Case "MotherBoardBaseBoardProduct"
                    concatenatedString.Append(Await GetThe_Computer("MotherBoardBaseBoardProduct") & ";")

                Case "SystemModelFull"
                    concatenatedString.Append(Await GetThe_Computer("SystemModelFull") & ";")

                Case "UUID"
                    concatenatedString.Append(Await GetThe_Computer("UUID") & ";")

                Case "DriveSerialNumber"
                    concatenatedString.Append(Await GetThe_HardDrive("DriveSerialNumber") & ";")
            End Select
        Next

        ' TROUBLESHOOTING
        If CheckBox_Demo1_ShowConcatenatedData.Checked = True Then
            MsgBox("Concatenating:" & vbCrLf & vbCrLf & concatenatedString.ToString & vbCrLf & vbCrLf & vbCrLf & "Then Hash it:" & vbCrLf & vbCrLf & GetHash(concatenatedString.ToString))
        End If

        TextBox_Demo1_VerifyFingerprint.Text = GetHash(concatenatedString.ToString)

    End Sub





    Private Async Sub Button68_Click(sender As Object, e As EventArgs) Handles Button68.Click

        If String.IsNullOrEmpty(TextBox_Demo1_LoadedLICFile.Text) Then
            MessageBox.Show("Load a .LIC file first", "No LIC File Loaded", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If

        If Label_Demo1_Verify_ExtractedExpiry.Text = "EXTRACTED_EXPIRY" Then
            MessageBox.Show("Load a .LIC file first", "No LIC File Loaded", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If


        ' Re-Generate Fingerprint 
        TextBox_Demo1_VerifyFingerprint.Text = ""

        Dim concatenatedString As New StringBuilder
        For Each item In ListBox_Demo1_Characteristics.Items
            Select Case item
                Case "BIOSSerial"
                    concatenatedString.Append(Await GetThe_Computer("BIOSSerial") & ";")

                Case "MotherboardSerial"
                    concatenatedString.Append(Await GetThe_Computer("MotherboardSerial") & ";")

                Case "MotherBoardBaseBoardProduct"
                    concatenatedString.Append(Await GetThe_Computer("MotherBoardBaseBoardProduct") & ";")

                Case "SystemModelFull"
                    concatenatedString.Append(Await GetThe_Computer("SystemModelFull") & ";")

                Case "UUID"
                    concatenatedString.Append(Await GetThe_Computer("UUID") & ";")

                Case "DriveSerialNumber"
                    concatenatedString.Append(Await GetThe_HardDrive("DriveSerialNumber") & ";")
            End Select
        Next

        ' TROUBLESHOOTING
        If CheckBox_Demo1_ShowConcatenatedData.Checked = True Then
            MsgBox("Concatenating:" & vbCrLf & vbCrLf & concatenatedString.ToString & vbCrLf & vbCrLf & vbCrLf & "Then Hash it:" & vbCrLf & vbCrLf & GetHash(concatenatedString.ToString))
        End If

        TextBox_Demo1_VerifyFingerprint.Text = GetHash(concatenatedString.ToString)






        ' Concatenate fingerprint and Expiry in UTC 
        If String.IsNullOrEmpty(TextBox_Demo1_VerifyFingerprint.Text) Then
            MessageBox.Show("No Fingerprint has been generated", "No Fingerprint Generated", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If

        If Label_Demo1_Verify_ExtractedExpiry.Text = "EXTRACTED_EXPIRY" Then
            MessageBox.Show("Expiry not extracted from license yet", "No Expiry Extracted", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If


        TextBox_Demo1_VerifyFingerprintPlusExpiry.Text = TextBox_Demo1_VerifyFingerprint.Text & Label_Demo1_Verify_ExtractedExpiry.Text



        ' Get Hash
        If String.IsNullOrEmpty(TextBox_Demo1_VerifyFingerprintPlusExpiry.Text) Then
            MessageBox.Show("No Data has been generated to hash - Create a fingerprint, and set an expiry first, then retry", "No Data Generated", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If

        TextBox_Demo1_VerifyFingerprintPlusExpiryHash.Text = GetHash(TextBox_Demo1_VerifyFingerprintPlusExpiry.Text)



        ' Verify Signature 
        Dim isValid As Boolean = Await RsaVerifySignature(TextBox_Demo1_VerifyFingerprintPlusExpiryHash.Text, TextBox_Demo1_Verify_ExtractedFingerprint.Text, TextBox_Demo1_PublicKey.Text, TextBox_Demo1_Salt.Text)
        TextBox_Demo1_Verify_IsVerified.Text = isValid.ToString()
        If isValid = True Then
            TextBox_Demo1_Verify_IsVerified.ForeColor = Color.Green
            TextBox_Demo1_Verify_IsVerified.BackColor = Color.White
        Else
            TextBox_Demo1_Verify_IsVerified.ForeColor = Color.Red
            TextBox_Demo1_Verify_IsVerified.BackColor = Color.White
        End If



        If isValid = True Then
            ' Get Current UTC Time 
            Dim currentUtcTime As DateTime = DateTime.UtcNow
            TextBox_Demo1_Verify_CurrentUTCTime.Text = currentUtcTime.ToString("dd/MM/yyyy HH:mm:ss")

            TextBox_Demo1_Verify_CurrentLocalTime.Text = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss")

            Dim extractedExpiry As DateTime
            Dim isValidDatetime As Boolean = DateTime.TryParseExact(Label_Demo1_Verify_ExtractedExpiry.Text, "dd/MM/yyyy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, extractedExpiry)


            If isValidDatetime Then

                'Debug.WriteLine("currentUtcTime " & currentUtcTime)
                'Debug.WriteLine("extractedExpiry " & extractedExpiry)

                'Debug.WriteLine("currnet local time " & DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"))
                'Debug.WriteLine("extractedExpiry converted to Local Time " & extractedExpiry.ToLocalTime.ToString("dd/MM/yyyy HH:mm:ss"))

                ' If extracted expiry is less than current UTC time, perform actions
                If extractedExpiry.ToLocalTime < DateTime.Now Then
                    TextBox_Demo1_Verify_Expired.Text = "Expired"
                    TextBox_Demo1_Verify_Expired.ForeColor = Color.Red
                    TextBox_Demo1_Verify_Expired.BackColor = Color.White

                Else
                    TextBox_Demo1_Verify_Expired.Text = "Within Date"
                    TextBox_Demo1_Verify_Expired.ForeColor = Color.Green
                    TextBox_Demo1_Verify_Expired.BackColor = Color.White

                End If
            Else
                ' Handle invalid date format
                MessageBox.Show("Invalid expiry date format.")
            End If

        Else
            TextBox_Demo1_Verify_CurrentUTCTime.Text = ""
            TextBox_Demo1_Verify_CurrentLocalTime.Text = ""
            TextBox_Demo1_Verify_Expired.Text = "Invalid"
            TextBox_Demo1_Verify_Expired.ForeColor = Color.Red
            TextBox_Demo1_Verify_Expired.BackColor = Color.White
        End If


    End Sub






    Private Sub Button_Demo1_LoadedLICFileReload_Click(sender As Object, e As EventArgs) Handles Button_Demo1_LoadedLICFileReload.Click

        Demo1_ImportLICFile()

    End Sub







    Private Sub Demo1_ImportLICFile()

        If String.IsNullOrEmpty(TextBox_Demo1_LoadedLICFile.Text) Then
            MessageBox.Show("Load a .LIC file first", "No LIC File Loaded", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If

        If Not File.Exists(TextBox_Demo1_LoadedLICFile.Text) Then
            MessageBox.Show("Specified Path to .LIC file does not exist - check the path and try again", "Path Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If


        Dim importedLICDetails As Dictionary(Of String, String) = LICFile_LocalMachine_Import(TextBox_Demo1_LoadedLICFile.Text)
        Dim extractedExpiry As DateTime
        Dim extractedSignature As String = ""

        For Each kvp In importedLICDetails
            'MsgBox($"{kvp.Key}: {kvp.Value}")

            If kvp.Key.ToLower.Contains("expiry") Then
                extractedExpiry = kvp.Value
            End If

            If kvp.Key.ToLower.Contains("signature") Then
                extractedSignature = kvp.Value
            End If
        Next

        'MsgBox(extractedExpiry.ToString)
        'MsgBox(extractedSignature)

        Label_Demo1_Verify_ExtractedExpiry.Text = extractedExpiry

        Try
            Label_Demo1_Verify_ExtractedExpiryInLocalTime.Text = extractedExpiry.ToLocalTime
        Catch ex As Exception

        End Try


        TextBox_Demo1_Verify_ExtractedFingerprint.Text = extractedSignature


    End Sub




    Private Sub Label_Demo1_Verify_ExtractedExpiry_Click(sender As Object, e As EventArgs) Handles Label_Demo1_Verify_ExtractedExpiry.Click
        ' USE TEXT CHANGED EVENT 
    End Sub

    Private Sub Label_Demo1_Verify_ExtractedExpiry_TextChanged(sender As Object, e As EventArgs) Handles Label_Demo1_Verify_ExtractedExpiry.TextChanged

    End Sub

    Private Sub Button66_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub CheckBox12_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox12.CheckedChanged
        DateTimePicker1.Value = DateTime.Now.AddMinutes(1).AddSeconds(-DateTime.Now.Second)
        Label_Demo1_SetExpiryValue.Text = DateTimePicker1.Value.ToString("dd/MM/yyyy HH:mm:ss")
    End Sub

    Private Async Sub Button_Demo2_GeneralteLicenseKey_Click(sender As Object, e As EventArgs) Handles Button_Demo2_GeneralteLicenseKey.Click

        If RadioButton1.Checked = True Then
            If String.IsNullOrEmpty(TextBox_Demo2_LicensedTo.Text) = True Then
                MessageBox.Show("Licensed To is empty - specify a value", "Empty Value", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

            If String.IsNullOrEmpty(TextBox_Demo2_Email.Text) = True Then
                MessageBox.Show("Email is empty - specify a value", "Empty Value", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

            If String.IsNullOrEmpty(TextBox_Demo2_Branch.Text) = True Then
                MessageBox.Show("Branch empty - specify a value", "Empty Value", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If


            If String.IsNullOrEmpty(TextBox_Demo2_Terminal.Text) = True Then
                MessageBox.Show("Terminal To is empty - specify a value", "Empty Value", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If


            'Dim licensedTo As String = GetHash(TextBox_Demo2_LicensedTo.Text)
            'Dim email As String = GetHash(TextBox_Demo2_Email.Text)
            'Dim branch As String = GetHash(TextBox_Demo2_Branch.Text)
            'Dim terminal As String = GetHash(TextBox_Demo2_Terminal.Text)
            'Dim seed As String = GetHash(TextBox_Demo2_Seed.Text)


            Dim licensedTo As String = TextBox_Demo2_LicensedTo.Text
            Dim email As String = TextBox_Demo2_Email.Text
            Dim branch As String = TextBox_Demo2_Branch.Text
            Dim terminal As String = TextBox_Demo2_Terminal.Text
            Dim seed As String = TextBox_Demo2_Seed.Text
            Dim expiry As String = Label132.Text

            Dim concatenatedStrings As String = licensedTo & email & branch & terminal & seed & expiry
            TextBox_Demo2_Concatenated.Text = concatenatedStrings

            'TextBox_Demo2_Concatenated.Text = licensedTo
            'TextBox_Demo2_Base64Encoded.Text = email
            'TextBox_Demo2_BranchHash.Text = branch
            'TextBox_Demo2_TerminalHash.Text = terminal
            'TextBox_Demo2_SeedHash.Text = seed

            Dim base64EncodedString As String = Base64String_Encode(concatenatedStrings)
            TextBox_Demo2_Base64Encoded.Text = base64EncodedString
            Dim combinedHash As String = GetHash(base64EncodedString)
            TextBox_Demo2_HashCombined.Text = combinedHash

            'Dim concatenatedHashes As String = licensedTo & email & branch & terminal & seed
            'Dim combinedHash As String = GetHash(concatenatedHashes)
            'TextBox_Demo2_HashCombined.Text = combinedHash


            'TextBox_Demo2_LicenseKeyPart1.Text = shiftedHash.Substring(0, 5)
            'TextBox_Demo2_LicenseKeyPart2.Text = shiftedHash.Substring(5, 5)
            'TextBox_Demo2_LicenseKeyPart3.Text = shiftedHash.Substring(10, 5)
            'TextBox_Demo2_LicenseKeyPart4.Text = shiftedHash.Substring(15, 5)
            'TextBox_Demo2_LicenseKeyPart5.Text = shiftedHash.Substring(20, 5)

        Else
            Dim randomString As String = GenerateRandomString(14).ToUpper()
            TextBox_Demo2_RandomString.Text = randomString
            TextBox_Demo2_HashCombined.Text = GetHash(randomString)
        End If

        Dim combinedHashTruncated As String = TextBox_Demo2_HashCombined.Text.Substring(0, 25)
        Dim shiftedHash As String = replaceNumbersWithLetters(combinedHashTruncated)

        ' first 14 Characters
        TextBox_Demo2_LicenseKeyPart1.Text = shiftedHash.Substring(0, 5)
        TextBox_Demo2_LicenseKeyPart2.Text = shiftedHash.Substring(5, 5)
        TextBox_Demo2_LicenseKeyPart3.Text = shiftedHash.Substring(10, 4)

        Dim first14Chars As String = TextBox_Demo2_LicenseKeyPart1.Text & TextBox_Demo2_LicenseKeyPart2.Text & TextBox_Demo2_LicenseKeyPart3.Text
        Debug.WriteLine(first14Chars)


        '' Date
        'TextBox_Demo2_LicenseKeyPart4.Text = shiftedHash.Substring(15, 5)
        'TextBox_Demo2_LicenseKeyPart5.Text = shiftedHash.Substring(20, 5)

        Try

            Dim datePart As String = Label132.Text ' TextBox_Demo2_LicenseKeyPart3.Text.Substring(4, 1) & TextBox_Demo2_LicenseKeyPart4.Text
            Debug.WriteLine("datePart = " & datePart)

            Dim totalSumFirst14 As Integer = GetAlphabetSum(first14Chars)
            Debug.WriteLine("totalSumFirst14 = " & totalSumFirst14)

            Dim scrambledTotal As Integer = ScrambleDigits(datePart, totalSumFirst14)
            Debug.WriteLine("scrambledTotal = " & scrambledTotal)

            Dim unscrambledTotal As Integer = UnscrambleDigits(scrambledTotal, totalSumFirst14)
            Debug.WriteLine("unscrambledTotal = " & unscrambledTotal)



            TextBox_Demo2_LicenseKeyPart3.Text = TextBox_Demo2_LicenseKeyPart3.Text & replaceNumbersWithLetters(scrambledTotal.ToString().Substring(0, 1))
            TextBox_Demo2_LicenseKeyPart4.Text = replaceNumbersWithLetters(scrambledTotal.ToString().Substring(1, 5))




            Dim phase1 As String = TextBox_Demo2_LicenseKeyPart1.Text & TextBox_Demo2_LicenseKeyPart2.Text & TextBox_Demo2_LicenseKeyPart3.Text
            phase1 = GetHash(phase1)

            Dim phase2 As String = phase1 & TextBox_Demo2_LicenseKeyPart4.Text
            phase2 = GetHash(phase2)

            TextBox_Demo2_LicenseKeyPart5.Text = phase2.Substring(0, 5).ToUpper()

        Catch ex As Exception
            'MessageBox.Show(ex.Message)
            Debug.WriteLine("invalid checksum rerunning")
            Button_Demo2_GeneralteLicenseKey.PerformClick()
        End Try

    End Sub





    Function GetAlphabetSum(input As String) As Integer
        Dim total As Integer = 0

        For Each ch As Char In input.ToLower()
            If ch >= "a"c AndAlso ch <= "z"c Then
                total += Asc(ch) - Asc("a"c) + 1
            End If
        Next

        Return total
    End Function



    Function ScrambleDigits(original As String, offset As Integer) As String
        If original.Length <> 6 OrElse Not IsNumeric(original) Then
            Throw New ArgumentException("Input must be a 6-digit numeric string.")
        End If

        Dim resultStr As String = ""

        For Each ch As Char In original
            Dim digit As Integer = CInt(ch.ToString())
            Dim newDigit As Integer = (digit + offset) Mod 10
            resultStr &= newDigit.ToString()
        Next

        Return resultStr
    End Function




    Function UnscrambleDigits(scrambled As String, offset As Integer) As String
        If scrambled.Length <> 6 OrElse Not IsNumeric(scrambled) Then
            Throw New ArgumentException("Input must be a 6-digit numeric string.")
        End If

        Dim resultStr As String = ""

        For Each ch As Char In scrambled
            Dim digit As Integer = CInt(ch.ToString())
            Dim originalDigit As Integer = (digit - offset) Mod 10

            If originalDigit < 0 Then
                originalDigit += 10
            End If

            resultStr &= originalDigit.ToString()
        Next

        Return resultStr
    End Function



    Private Sub Button62_Click_1(sender As Object, e As EventArgs) Handles Button62.Click
        TextBox_Demo2_Concatenated.Text = ""
    End Sub

    Private Sub Button64_Click(sender As Object, e As EventArgs) Handles Button64.Click
        TextBox_Demo2_Base64Encoded.Text = ""
    End Sub

    'Private Sub Button65_Click_1(sender As Object, e As EventArgs)
    '    TextBox_Demo2_BranchHash.Text = ""
    'End Sub

    'Private Sub Button66_Click_1(sender As Object, e As EventArgs)
    '    TextBox_Demo2_TerminalHash.Text = ""
    'End Sub

    'Private Sub Button67_Click(sender As Object, e As EventArgs)
    '    TextBox_Demo2_SeedHash.Text = ""
    'End Sub

    Private Sub Button69_Click(sender As Object, e As EventArgs) Handles Button69.Click
        TextBox_Demo2_HashCombined.Text = ""
    End Sub

    Private Sub Label136_Click(sender As Object, e As EventArgs) Handles Label136.Click

    End Sub

    Private Sub Panel124_Paint(sender As Object, e As PaintEventArgs) Handles Panel124.Paint

    End Sub

    Private Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton1.CheckedChanged
        If RadioButton1.Checked = True Then
            Panel119.Enabled = True
            Panel120.Enabled = False
        Else
            Panel119.Enabled = False
            Panel120.Enabled = True
        End If
    End Sub

    Private Sub RadioButton2_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton2.CheckedChanged
        If RadioButton1.Checked = True Then
            Panel119.Enabled = True
            Panel120.Enabled = False
        Else
            Panel119.Enabled = False
            Panel120.Enabled = True
        End If
    End Sub

    Private Sub Button63_Click(sender As Object, e As EventArgs) Handles Button63.Click
        TextBox_Demo2_RandomString.Text = GenerateRandomString(14).ToUpper()
        TextBox_Demo2_HashCombined.Text = GetHash(TextBox_Demo2_RandomString.Text)
    End Sub

    Private Sub DateTimePicker2_ValueChanged(sender As Object, e As EventArgs) Handles DateTimePicker2.ValueChanged
        'Dim tempDateString As String = DateTimePicker2.Value.ToString("DD/MM/YYYY")
        'Dim first4 As String = tempDateString.Replace("/", "").Substring(0, 4)
        'Dim last2 As String = tempDateString.Substring(tempDateString.Length - 2, 2)
        'Label132.Text = first4 & last2
        Dim tempDateString As String = DateTimePicker2.Value.ToString("ddMMyy")
        Label132.Text = tempDateString

        'TextBox_Demo2_HashAsSaltPlusExpiry.Text = TextBox_Demo2_HashCombined.Text & tempDateString
    End Sub




    Private Sub Button66_Click_1(sender As Object, e As EventArgs) Handles Button66.Click



        Try
            ' Validate

            Dim phase1 As String = TextBox_Demo2_VerifyKeyPart1.Text & TextBox_Demo2_VerifyKeyPart2.Text & TextBox_Demo2_VerifyKeyPart3.Text
            phase1 = GetHash(phase1)

            Dim phase2 As String = phase1 & TextBox_Demo2_VerifyKeyPart4.Text
            phase2 = GetHash(phase2)

            Dim checkSum As String = phase2.Substring(0, 5).ToUpper()

            If checkSum = TextBox_Demo2_VerifyKeyPart5.Text Then
                TextBox7.Text = True
                TextBox7.BackColor = Color.White
                TextBox7.ForeColor = Color.Green

                TextBox8.BackColor = Color.White
                TextBox8.ForeColor = Color.Black
            Else
                TextBox7.Text = False
                TextBox7.BackColor = Color.White
                TextBox7.ForeColor = Color.Red

                TextBox8.Text = "INVALID"
                TextBox8.BackColor = Color.White
                TextBox8.ForeColor = Color.Red

                TextBox9.Text = ""
                Exit Sub
            End If


        Catch ex As Exception
            MsgBox("Unexpected error validating: " & ex.Message)
        End Try




        Try
            ' Exract Date 
            Dim first14Chars As String = TextBox_Demo2_VerifyKeyPart1.Text & TextBox_Demo2_VerifyKeyPart2.Text & TextBox_Demo2_VerifyKeyPart3.Text.Substring(0, 4)
            Debug.WriteLine(vbCrLf & vbCrLf & "Verify first 14: " & first14Chars)

            Dim datePart As String = TextBox_Demo2_VerifyKeyPart3.Text.Substring(4, 1) & TextBox_Demo2_VerifyKeyPart4.Text
            Dim datePartNumbers As String = replaceLettersWithNumbers(datePart)
            Debug.WriteLine("VERIFYING datePart = " & datePart & " -- DatePArtNumbers: " & datePartNumbers)

            Dim totalSumFirst14 As Integer = GetAlphabetSum(first14Chars)
            Debug.WriteLine("totalSumFirst14 = " & totalSumFirst14)

            Dim unscrambledTotal As Integer = UnscrambleDigits(datePartNumbers, totalSumFirst14)
            Debug.WriteLine("unscrambledTotal = " & unscrambledTotal)

            Dim extractedExpiryDate As DateTime

            Try
                If DateTime.TryParseExact(unscrambledTotal, "ddMMyy", Nothing, Globalization.DateTimeStyles.None, extractedExpiryDate) Then
                    ' Success
                    Debug.WriteLine("Parsed Date: " & extractedExpiryDate.ToString("yyyy-MM-dd"))
                    TextBox8.Text = extractedExpiryDate.ToString("yyyy-MM-dd")

                    If DateTime.Now.ToString("yyyy-MM-dd") > extractedExpiryDate.ToString("yyyy-MM-dd") Then
                        TextBox9.Text = "EXPIRED"
                        TextBox9.BackColor = Color.White
                        TextBox9.ForeColor = Color.Red
                    Else
                        TextBox9.Text = "Within Date"
                        TextBox9.BackColor = Color.White
                        TextBox9.ForeColor = Color.Green
                    End If
                Else
                    ' Failed to parse
                    Debug.WriteLine("Invalid date format: " & unscrambledTotal)
                End If
            Catch ex As Exception
                Debug.WriteLine("Unexpected error: " & ex.Message)
                MsgBox("Unexpected error parsing date: " & ex.Message)
            End Try

        Catch ex As Exception
            MsgBox("Unexpected error: " & ex.Message)
        End Try

    End Sub




    Private Sub Button65_Click_1(sender As Object, e As EventArgs) Handles Button65.Click
        TextBox_Demo2_VerifyKeyPart1.Text = TextBox_Demo2_LicenseKeyPart1.Text
        TextBox_Demo2_VerifyKeyPart2.Text = TextBox_Demo2_LicenseKeyPart2.Text
        TextBox_Demo2_VerifyKeyPart3.Text = TextBox_Demo2_LicenseKeyPart3.Text
        TextBox_Demo2_VerifyKeyPart4.Text = TextBox_Demo2_LicenseKeyPart4.Text
        TextBox_Demo2_VerifyKeyPart5.Text = TextBox_Demo2_LicenseKeyPart5.Text
    End Sub



    Private Function replaceNumbersWithLetters(passedString As String) As String
        Dim tempStrimg = passedString.Replace(0, "j").Replace(1, "k").Replace(2, "q").Replace(3, "r").Replace(4, "t").Replace(5, "u").Replace(6, "w").Replace(7, "x").Replace(8, "y").Replace(9, "z").ToUpper()
        Return tempStrimg
    End Function


    Private Function replaceLettersWithNumbers(passedString As String) As String
        Dim tempStrimg = passedString.Replace("J", 0).Replace("K", 1).Replace("Q", 2).Replace("R", 3).Replace("T", 4).Replace("U", 5).Replace("W", 6).Replace("X", 7).Replace("Y", 8).Replace("Z", 9).ToUpper()
        Return tempStrimg
    End Function



    Private Sub Button67_Click(sender As Object, e As EventArgs) Handles Button_LicenseOTP_TOTP_GetCodeUser.Click
        'Dim base32Secret As String = "JBSWY3DPEHPK3PXP" ' Example Base32 secret, same as server
        'Dim code As String = GenerateTOTP(base32Secret)

        Dim bytes As Byte() = Encoding.UTF8.GetBytes(TextBox_LicenseOTP_TOTP_SecretUser.Text)
        Dim base32Secret As String = Base32String_Encode(bytes)

        TextBox_LicenseOTP_TOTP_AsBase32User.Text = base32Secret

        If String.IsNullOrEmpty(base32Secret) = True Then
            MessageBox.Show("User Secret Empty" & vbCrLf & "Input, or Generate a Secret first, then retry")
            Exit Sub
        End If

        Dim interval As Integer = 30
        Try
            interval = CInt(ComboBox_LicenseOTP_TOTP_IntervalUser.Text)
        Catch ex As Exception

        End Try

        Dim code As String = GenerateTOTP(base32Secret, interval)
        TextBox_LicenseOTP_TOTP_CodeUser.Text = code

        ' Show code to user for authentication
        Debug.WriteLine("Your current TOTP is: " & code)
    End Sub



    Private Sub Button72_Click(sender As Object, e As EventArgs) Handles Button_LicenseOTP_TOTP_VerifyCode.Click

        'Dim base32Secret As String = "JBSWY3DPEHPK3PXP" ' Example Base32 secret, same as server
        'Dim serverCode As String = GenerateTOTP(base32Secret)

        'Dim answer = MessageBox.Show("copy from user fields?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        'If answer = vbYes Then
        '    TextBox_LicenseOTP_TOTP_SecretAdmin.Text = TextBox_LicenseOTP_TOTP_AsBase32User.Text
        '    ComboBox_LicenseOTP_TOTP_IntervalAdmin.Text = ComboBox_LicenseOTP_TOTP_IntervalUser.Text
        '    TextBox_LicenseOTP_TOTP_UserCodeAdmin.Text = TextBox_LicenseOTP_TOTP_CodeUser.Text
        'End If

        Dim usersCode As String = TextBox_LicenseOTP_TOTP_UserCodeAdmin.Text

        Dim interval As Integer = 30
        Try
            interval = CInt(ComboBox_LicenseOTP_TOTP_IntervalAdmin.Text)
        Catch ex As Exception

        End Try

        Dim base32Secret As String = TextBox_LicenseOTP_TOTP_SecretAdmin.Text ' Example Base32 secret, same as server
        Dim serverCode As String = GenerateTOTP(base32Secret, interval)
        TextBox_LicenseOTP_TOTP_ServerCodeAdmin.Text = serverCode

        If usersCode = serverCode Then
            Console.WriteLine("TOTP Verified successfully.")
            TextBox_LicenseOTP_TOTP_Verified.Text = True
            TextBox_LicenseOTP_TOTP_Verified.BackColor = Color.White
            TextBox_LicenseOTP_TOTP_Verified.ForeColor = Color.Green
        Else
            Console.WriteLine("Invalid TOTP code.")
            TextBox_LicenseOTP_TOTP_Verified.Text = False
            TextBox_LicenseOTP_TOTP_Verified.BackColor = Color.White
            TextBox_LicenseOTP_TOTP_Verified.ForeColor = Color.Red
        End If
    End Sub

    Private Sub Button_LicenseOTP_TOTP_SecretUser_Click(sender As Object, e As EventArgs) Handles Button_LicenseOTP_TOTP_SecretUser.Click
        TextBox_LicenseOTP_TOTP_SecretUser.Text = GenerateUUID_LicGen()
    End Sub

    Private Sub Button_LicenseOTP_TOTP_SecretCopyUser_Click(sender As Object, e As EventArgs) Handles Button_LicenseOTP_TOTP_SecretCopyUser.Click
        TextBox_LicenseOTP_TOTP_SecretAdmin.Text = TextBox_LicenseOTP_TOTP_AsBase32User.Text
    End Sub

    Private Sub Button_LicenseOTP_TOTP_IntervalCopyUser_Click(sender As Object, e As EventArgs) Handles Button_LicenseOTP_TOTP_IntervalCopyUser.Click
        ComboBox_LicenseOTP_TOTP_IntervalAdmin.Text = ComboBox_LicenseOTP_TOTP_IntervalUser.Text
    End Sub

    Private Sub Button_LicenseOTP_TOTP_UserCodeCopyFromUser_Click(sender As Object, e As EventArgs) Handles Button_LicenseOTP_TOTP_UserCodeCopyFromUser.Click
        'TextBox_LicenseOTP_TOTP_UserCodeAdmin.Text = TextBox_LicenseOTP_TOTP_CodeUser.Text

        TextBox_LicenseOTP_TOTP_SecretAdmin.Text = TextBox_LicenseOTP_TOTP_AsBase32User.Text
        ComboBox_LicenseOTP_TOTP_IntervalAdmin.Text = ComboBox_LicenseOTP_TOTP_IntervalUser.Text
        TextBox_LicenseOTP_TOTP_UserCodeAdmin.Text = TextBox_LicenseOTP_TOTP_CodeUser.Text
    End Sub



    Private Sub Button73_Click(sender As Object, e As EventArgs) Handles Button73.Click

        'Dim base32Secret As String = "JBSWY3DPEHPK3PXP" ' Shared secret
        ''Dim counter As Long = GetCounterFromStorage() ' Store counter persistently (e.g., local file, DB)
        'Dim code As String = GenerateHOTP(base32Secret, counter)

        'Console.WriteLine("Your HOTP code is: " & code)
    End Sub




    ' Creates a LIC file with expiry date and signature, binded to a unique machine fingerprint
    Public Sub LICFile_LocalMachine_Export(expiry_date As DateTime, signature As String)
        ' Create a structure to hold the license data
        Dim licenseData As New Dictionary(Of String, Object)

        ' Create the data node with the expiry_date
        Dim data As New Dictionary(Of String, Object)
        data("expiry_date") = expiry_date.ToString("dd/MM/yyyy HH:mm:ss") ' ISO 8601 format
        licenseData("data") = data

        ' Add the signature
        licenseData("signature") = signature

        ' Convert the data to a JSON string using Newtonsoft.Json
        Dim json As String = JsonConvert.SerializeObject(licenseData, Formatting.Indented)

        ' Show a SaveFileDialog to prompt the user to save the file
        Using saveDialog As New SaveFileDialog()
            saveDialog.Filter = "License Files (*.lic)|*.lic|All Files (*.*)|*.*"
            saveDialog.DefaultExt = "lic"

            ' If the user selects a file and clicks Save
            If saveDialog.ShowDialog() = DialogResult.OK Then
                ' Save the JSON string to the selected file
                Try
                    File.WriteAllText(saveDialog.FileName, json)
                    MessageBox.Show("License file saved successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Catch ex As Exception
                    MessageBox.Show("Error saving the file: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End Try
            End If
        End Using
    End Sub



    Public Function LICFile_LocalMachine_Import(filepath As String) As Dictionary(Of String, String)
        Dim result As New Dictionary(Of String, String)

        Try
            ' Read the content of the .lic file
            Dim fileContent As String = File.ReadAllText(filepath)

            ' Deserialize the JSON content into a JObject (root is an object, not a dictionary)
            Dim licenseData As JObject = JObject.Parse(fileContent)

            ' Loop through all the top-level properties in the JSON object
            For Each prop As KeyValuePair(Of String, JToken) In licenseData
                ' Check if the value is a JObject (this handles nested objects)
                If TypeOf prop.Value Is JObject Then
                    ' If the value is a JObject, loop through its properties
                    For Each innerProp As KeyValuePair(Of String, JToken) In CType(prop.Value, JObject)
                        ' Add the inner properties to the result dictionary
                        result.Add(innerProp.Key, innerProp.Value.ToString())
                    Next
                Else
                    ' If it's a simple property, add it directly to the dictionary
                    result.Add(prop.Key, prop.Value.ToString())
                End If
            Next
        Catch ex As Exception
            ' Handle errors, e.g., file not found, invalid JSON format, etc.
            MessageBox.Show("Error importing the license file: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        Return result
    End Function



End Class

