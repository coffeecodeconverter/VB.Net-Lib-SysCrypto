﻿Public Class FormPreviewLicJSON
    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub Button_Preview_SaveFile_Click(sender As Object, e As EventArgs) Handles Button_Preview_SaveFile.Click
        Dim saveFile As Boolean = True
        Form1.CreateJsonFromGridViews(saveFile)
    End Sub

End Class