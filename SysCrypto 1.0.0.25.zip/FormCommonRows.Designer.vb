﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormCommonRows
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TabControl_CommonRows = New System.Windows.Forms.TabControl()
        Me.TabPage_Data = New System.Windows.Forms.TabPage()
        Me.FlowLayoutPanel3 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Button_CommonRows_Data_All = New System.Windows.Forms.Button()
        Me.Button_CommonRows_Data_Noner = New System.Windows.Forms.Button()
        Me.FlowLayoutPanel_Data_CommonRows = New System.Windows.Forms.FlowLayoutPanel()
        Me.CheckBox_CommonRows_Data_LicenseKey = New System.Windows.Forms.CheckBox()
        Me.CheckBox_CommonRows_Data_Product = New System.Windows.Forms.CheckBox()
        Me.CheckBox_CommonRows_Data_LicenseCount = New System.Windows.Forms.CheckBox()
        Me.CheckBox_CommonRows_Data_LicensesUsed = New System.Windows.Forms.CheckBox()
        Me.CheckBox_CommonRows_Data_LicensesRemaining = New System.Windows.Forms.CheckBox()
        Me.CheckBox_CommonRows_Data_Licensee = New System.Windows.Forms.CheckBox()
        Me.CheckBox_CommonRows_Data_Email = New System.Windows.Forms.CheckBox()
        Me.CheckBox_CommonRows_Data_Address = New System.Windows.Forms.CheckBox()
        Me.CheckBox_CommonRows_Data_Branch = New System.Windows.Forms.CheckBox()
        Me.CheckBox_CommonRows_Data_Terminal = New System.Windows.Forms.CheckBox()
        Me.CheckBox_CommonRows_Data_Type = New System.Windows.Forms.CheckBox()
        Me.CheckBox_CommonRows_Data_Features = New System.Windows.Forms.CheckBox()
        Me.CheckBox_CommonRows_Data_Modules = New System.Windows.Forms.CheckBox()
        Me.CheckBox_CommonRows_Data_IssuedDate = New System.Windows.Forms.CheckBox()
        Me.CheckBox_CommonRows_Data_ExpiryDate = New System.Windows.Forms.CheckBox()
        Me.CheckBox_CommonRows_Data_Serial = New System.Windows.Forms.CheckBox()
        Me.CheckBox_CommonRows_Data_UUID = New System.Windows.Forms.CheckBox()
        Me.CheckBox_CommonRows_Data_ContractNumber = New System.Windows.Forms.CheckBox()
        Me.CheckBox_CommonRows_Data_HardDriveFingerprints = New System.Windows.Forms.CheckBox()
        Me.CheckBox_CommonRows_Data_ComputerFingerprints = New System.Windows.Forms.CheckBox()
        Me.TabPage_Signature = New System.Windows.Forms.TabPage()
        Me.FlowLayoutPanel4 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Button_CommonRows_Signature_All = New System.Windows.Forms.Button()
        Me.Button_CommonRows_Signature_None = New System.Windows.Forms.Button()
        Me.FlowLayoutPanel_Signature_CommonRows = New System.Windows.Forms.FlowLayoutPanel()
        Me.CheckBox_CommonRows_Signature_KeySize = New System.Windows.Forms.CheckBox()
        Me.CheckBox_CommonRows_Signature_Algorithm = New System.Windows.Forms.CheckBox()
        Me.CheckBox_CommonRows_Signature_PublicKeyFingerprint = New System.Windows.Forms.CheckBox()
        Me.CheckBox_CommonRows_Signature_AddSignatureRow = New System.Windows.Forms.CheckBox()
        Me.CheckBox_CommonRows_Signature_Salt = New System.Windows.Forms.CheckBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.TabControl_CommonRows.SuspendLayout()
        Me.TabPage_Data.SuspendLayout()
        Me.FlowLayoutPanel3.SuspendLayout()
        Me.FlowLayoutPanel_Data_CommonRows.SuspendLayout()
        Me.TabPage_Signature.SuspendLayout()
        Me.FlowLayoutPanel4.SuspendLayout()
        Me.FlowLayoutPanel_Signature_CommonRows.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl_CommonRows
        '
        Me.TabControl_CommonRows.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TabControl_CommonRows.Controls.Add(Me.TabPage_Data)
        Me.TabControl_CommonRows.Controls.Add(Me.TabPage_Signature)
        Me.TabControl_CommonRows.Location = New System.Drawing.Point(3, -10)
        Me.TabControl_CommonRows.Name = "TabControl_CommonRows"
        Me.TabControl_CommonRows.SelectedIndex = 0
        Me.TabControl_CommonRows.Size = New System.Drawing.Size(359, 267)
        Me.TabControl_CommonRows.TabIndex = 0
        '
        'TabPage_Data
        '
        Me.TabPage_Data.Controls.Add(Me.FlowLayoutPanel3)
        Me.TabPage_Data.Controls.Add(Me.FlowLayoutPanel_Data_CommonRows)
        Me.TabPage_Data.Location = New System.Drawing.Point(4, 22)
        Me.TabPage_Data.Name = "TabPage_Data"
        Me.TabPage_Data.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage_Data.Size = New System.Drawing.Size(351, 241)
        Me.TabPage_Data.TabIndex = 0
        Me.TabPage_Data.Text = "Data"
        Me.TabPage_Data.UseVisualStyleBackColor = True
        '
        'FlowLayoutPanel3
        '
        Me.FlowLayoutPanel3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.FlowLayoutPanel3.BackColor = System.Drawing.Color.Silver
        Me.FlowLayoutPanel3.Controls.Add(Me.Button_CommonRows_Data_All)
        Me.FlowLayoutPanel3.Controls.Add(Me.Button_CommonRows_Data_Noner)
        Me.FlowLayoutPanel3.Location = New System.Drawing.Point(6, 6)
        Me.FlowLayoutPanel3.Name = "FlowLayoutPanel3"
        Me.FlowLayoutPanel3.Size = New System.Drawing.Size(339, 30)
        Me.FlowLayoutPanel3.TabIndex = 2
        '
        'Button_CommonRows_Data_All
        '
        Me.Button_CommonRows_Data_All.Location = New System.Drawing.Point(3, 3)
        Me.Button_CommonRows_Data_All.Name = "Button_CommonRows_Data_All"
        Me.Button_CommonRows_Data_All.Size = New System.Drawing.Size(75, 23)
        Me.Button_CommonRows_Data_All.TabIndex = 12
        Me.Button_CommonRows_Data_All.Text = "All"
        Me.Button_CommonRows_Data_All.UseVisualStyleBackColor = True
        '
        'Button_CommonRows_Data_Noner
        '
        Me.Button_CommonRows_Data_Noner.Location = New System.Drawing.Point(84, 3)
        Me.Button_CommonRows_Data_Noner.Name = "Button_CommonRows_Data_Noner"
        Me.Button_CommonRows_Data_Noner.Size = New System.Drawing.Size(75, 23)
        Me.Button_CommonRows_Data_Noner.TabIndex = 13
        Me.Button_CommonRows_Data_Noner.Text = "None"
        Me.Button_CommonRows_Data_Noner.UseVisualStyleBackColor = True
        '
        'FlowLayoutPanel_Data_CommonRows
        '
        Me.FlowLayoutPanel_Data_CommonRows.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.FlowLayoutPanel_Data_CommonRows.Controls.Add(Me.CheckBox_CommonRows_Data_LicenseKey)
        Me.FlowLayoutPanel_Data_CommonRows.Controls.Add(Me.CheckBox_CommonRows_Data_Product)
        Me.FlowLayoutPanel_Data_CommonRows.Controls.Add(Me.CheckBox_CommonRows_Data_LicenseCount)
        Me.FlowLayoutPanel_Data_CommonRows.Controls.Add(Me.CheckBox_CommonRows_Data_LicensesUsed)
        Me.FlowLayoutPanel_Data_CommonRows.Controls.Add(Me.CheckBox_CommonRows_Data_LicensesRemaining)
        Me.FlowLayoutPanel_Data_CommonRows.Controls.Add(Me.CheckBox_CommonRows_Data_Licensee)
        Me.FlowLayoutPanel_Data_CommonRows.Controls.Add(Me.CheckBox_CommonRows_Data_Email)
        Me.FlowLayoutPanel_Data_CommonRows.Controls.Add(Me.CheckBox_CommonRows_Data_Address)
        Me.FlowLayoutPanel_Data_CommonRows.Controls.Add(Me.CheckBox_CommonRows_Data_Branch)
        Me.FlowLayoutPanel_Data_CommonRows.Controls.Add(Me.CheckBox_CommonRows_Data_Terminal)
        Me.FlowLayoutPanel_Data_CommonRows.Controls.Add(Me.CheckBox_CommonRows_Data_Type)
        Me.FlowLayoutPanel_Data_CommonRows.Controls.Add(Me.CheckBox_CommonRows_Data_Features)
        Me.FlowLayoutPanel_Data_CommonRows.Controls.Add(Me.CheckBox_CommonRows_Data_Modules)
        Me.FlowLayoutPanel_Data_CommonRows.Controls.Add(Me.CheckBox_CommonRows_Data_IssuedDate)
        Me.FlowLayoutPanel_Data_CommonRows.Controls.Add(Me.CheckBox_CommonRows_Data_ExpiryDate)
        Me.FlowLayoutPanel_Data_CommonRows.Controls.Add(Me.CheckBox_CommonRows_Data_Serial)
        Me.FlowLayoutPanel_Data_CommonRows.Controls.Add(Me.CheckBox_CommonRows_Data_UUID)
        Me.FlowLayoutPanel_Data_CommonRows.Controls.Add(Me.CheckBox_CommonRows_Data_ContractNumber)
        Me.FlowLayoutPanel_Data_CommonRows.Controls.Add(Me.CheckBox_CommonRows_Data_HardDriveFingerprints)
        Me.FlowLayoutPanel_Data_CommonRows.Controls.Add(Me.CheckBox_CommonRows_Data_ComputerFingerprints)
        Me.FlowLayoutPanel_Data_CommonRows.Location = New System.Drawing.Point(6, 54)
        Me.FlowLayoutPanel_Data_CommonRows.Name = "FlowLayoutPanel_Data_CommonRows"
        Me.FlowLayoutPanel_Data_CommonRows.Size = New System.Drawing.Size(339, 181)
        Me.FlowLayoutPanel_Data_CommonRows.TabIndex = 1
        '
        'CheckBox_CommonRows_Data_LicenseKey
        '
        Me.CheckBox_CommonRows_Data_LicenseKey.Appearance = System.Windows.Forms.Appearance.Button
        Me.CheckBox_CommonRows_Data_LicenseKey.AutoSize = True
        Me.CheckBox_CommonRows_Data_LicenseKey.Location = New System.Drawing.Point(3, 3)
        Me.CheckBox_CommonRows_Data_LicenseKey.Name = "CheckBox_CommonRows_Data_LicenseKey"
        Me.CheckBox_CommonRows_Data_LicenseKey.Size = New System.Drawing.Size(75, 23)
        Me.CheckBox_CommonRows_Data_LicenseKey.TabIndex = 3
        Me.CheckBox_CommonRows_Data_LicenseKey.Text = "License Key"
        Me.CheckBox_CommonRows_Data_LicenseKey.UseVisualStyleBackColor = True
        '
        'CheckBox_CommonRows_Data_Product
        '
        Me.CheckBox_CommonRows_Data_Product.Appearance = System.Windows.Forms.Appearance.Button
        Me.CheckBox_CommonRows_Data_Product.AutoSize = True
        Me.CheckBox_CommonRows_Data_Product.Location = New System.Drawing.Point(84, 3)
        Me.CheckBox_CommonRows_Data_Product.Name = "CheckBox_CommonRows_Data_Product"
        Me.CheckBox_CommonRows_Data_Product.Size = New System.Drawing.Size(54, 23)
        Me.CheckBox_CommonRows_Data_Product.TabIndex = 14
        Me.CheckBox_CommonRows_Data_Product.Text = "Product"
        Me.CheckBox_CommonRows_Data_Product.UseVisualStyleBackColor = True
        '
        'CheckBox_CommonRows_Data_LicenseCount
        '
        Me.CheckBox_CommonRows_Data_LicenseCount.Appearance = System.Windows.Forms.Appearance.Button
        Me.CheckBox_CommonRows_Data_LicenseCount.AutoSize = True
        Me.CheckBox_CommonRows_Data_LicenseCount.Location = New System.Drawing.Point(144, 3)
        Me.CheckBox_CommonRows_Data_LicenseCount.Name = "CheckBox_CommonRows_Data_LicenseCount"
        Me.CheckBox_CommonRows_Data_LicenseCount.Size = New System.Drawing.Size(85, 23)
        Me.CheckBox_CommonRows_Data_LicenseCount.TabIndex = 15
        Me.CheckBox_CommonRows_Data_LicenseCount.Text = "License Count"
        Me.CheckBox_CommonRows_Data_LicenseCount.UseVisualStyleBackColor = True
        '
        'CheckBox_CommonRows_Data_LicensesUsed
        '
        Me.CheckBox_CommonRows_Data_LicensesUsed.Appearance = System.Windows.Forms.Appearance.Button
        Me.CheckBox_CommonRows_Data_LicensesUsed.AutoSize = True
        Me.CheckBox_CommonRows_Data_LicensesUsed.Location = New System.Drawing.Point(235, 3)
        Me.CheckBox_CommonRows_Data_LicensesUsed.Name = "CheckBox_CommonRows_Data_LicensesUsed"
        Me.CheckBox_CommonRows_Data_LicensesUsed.Size = New System.Drawing.Size(87, 23)
        Me.CheckBox_CommonRows_Data_LicensesUsed.TabIndex = 16
        Me.CheckBox_CommonRows_Data_LicensesUsed.Text = "Licenses Used"
        Me.CheckBox_CommonRows_Data_LicensesUsed.UseVisualStyleBackColor = True
        '
        'CheckBox_CommonRows_Data_LicensesRemaining
        '
        Me.CheckBox_CommonRows_Data_LicensesRemaining.Appearance = System.Windows.Forms.Appearance.Button
        Me.CheckBox_CommonRows_Data_LicensesRemaining.AutoSize = True
        Me.CheckBox_CommonRows_Data_LicensesRemaining.Location = New System.Drawing.Point(3, 32)
        Me.CheckBox_CommonRows_Data_LicensesRemaining.Name = "CheckBox_CommonRows_Data_LicensesRemaining"
        Me.CheckBox_CommonRows_Data_LicensesRemaining.Size = New System.Drawing.Size(112, 23)
        Me.CheckBox_CommonRows_Data_LicensesRemaining.TabIndex = 17
        Me.CheckBox_CommonRows_Data_LicensesRemaining.Text = "Licenses Remaining"
        Me.CheckBox_CommonRows_Data_LicensesRemaining.UseVisualStyleBackColor = True
        '
        'CheckBox_CommonRows_Data_Licensee
        '
        Me.CheckBox_CommonRows_Data_Licensee.Appearance = System.Windows.Forms.Appearance.Button
        Me.CheckBox_CommonRows_Data_Licensee.AutoSize = True
        Me.CheckBox_CommonRows_Data_Licensee.Location = New System.Drawing.Point(121, 32)
        Me.CheckBox_CommonRows_Data_Licensee.Name = "CheckBox_CommonRows_Data_Licensee"
        Me.CheckBox_CommonRows_Data_Licensee.Size = New System.Drawing.Size(76, 23)
        Me.CheckBox_CommonRows_Data_Licensee.TabIndex = 4
        Me.CheckBox_CommonRows_Data_Licensee.Text = "Licensed To"
        Me.CheckBox_CommonRows_Data_Licensee.UseVisualStyleBackColor = True
        '
        'CheckBox_CommonRows_Data_Email
        '
        Me.CheckBox_CommonRows_Data_Email.Appearance = System.Windows.Forms.Appearance.Button
        Me.CheckBox_CommonRows_Data_Email.AutoSize = True
        Me.CheckBox_CommonRows_Data_Email.Location = New System.Drawing.Point(203, 32)
        Me.CheckBox_CommonRows_Data_Email.Name = "CheckBox_CommonRows_Data_Email"
        Me.CheckBox_CommonRows_Data_Email.Size = New System.Drawing.Size(42, 23)
        Me.CheckBox_CommonRows_Data_Email.TabIndex = 7
        Me.CheckBox_CommonRows_Data_Email.Text = "Email"
        Me.CheckBox_CommonRows_Data_Email.UseVisualStyleBackColor = True
        '
        'CheckBox_CommonRows_Data_Address
        '
        Me.CheckBox_CommonRows_Data_Address.Appearance = System.Windows.Forms.Appearance.Button
        Me.CheckBox_CommonRows_Data_Address.AutoSize = True
        Me.CheckBox_CommonRows_Data_Address.Location = New System.Drawing.Point(251, 32)
        Me.CheckBox_CommonRows_Data_Address.Name = "CheckBox_CommonRows_Data_Address"
        Me.CheckBox_CommonRows_Data_Address.Size = New System.Drawing.Size(55, 23)
        Me.CheckBox_CommonRows_Data_Address.TabIndex = 8
        Me.CheckBox_CommonRows_Data_Address.Text = "Address"
        Me.CheckBox_CommonRows_Data_Address.UseVisualStyleBackColor = True
        '
        'CheckBox_CommonRows_Data_Branch
        '
        Me.CheckBox_CommonRows_Data_Branch.Appearance = System.Windows.Forms.Appearance.Button
        Me.CheckBox_CommonRows_Data_Branch.AutoSize = True
        Me.CheckBox_CommonRows_Data_Branch.Location = New System.Drawing.Point(3, 61)
        Me.CheckBox_CommonRows_Data_Branch.Name = "CheckBox_CommonRows_Data_Branch"
        Me.CheckBox_CommonRows_Data_Branch.Size = New System.Drawing.Size(51, 23)
        Me.CheckBox_CommonRows_Data_Branch.TabIndex = 9
        Me.CheckBox_CommonRows_Data_Branch.Text = "Branch"
        Me.CheckBox_CommonRows_Data_Branch.UseVisualStyleBackColor = True
        '
        'CheckBox_CommonRows_Data_Terminal
        '
        Me.CheckBox_CommonRows_Data_Terminal.Appearance = System.Windows.Forms.Appearance.Button
        Me.CheckBox_CommonRows_Data_Terminal.AutoSize = True
        Me.CheckBox_CommonRows_Data_Terminal.Location = New System.Drawing.Point(60, 61)
        Me.CheckBox_CommonRows_Data_Terminal.Name = "CheckBox_CommonRows_Data_Terminal"
        Me.CheckBox_CommonRows_Data_Terminal.Size = New System.Drawing.Size(57, 23)
        Me.CheckBox_CommonRows_Data_Terminal.TabIndex = 10
        Me.CheckBox_CommonRows_Data_Terminal.Text = "Terminal"
        Me.CheckBox_CommonRows_Data_Terminal.UseVisualStyleBackColor = True
        '
        'CheckBox_CommonRows_Data_Type
        '
        Me.CheckBox_CommonRows_Data_Type.Appearance = System.Windows.Forms.Appearance.Button
        Me.CheckBox_CommonRows_Data_Type.AutoSize = True
        Me.CheckBox_CommonRows_Data_Type.Location = New System.Drawing.Point(123, 61)
        Me.CheckBox_CommonRows_Data_Type.Name = "CheckBox_CommonRows_Data_Type"
        Me.CheckBox_CommonRows_Data_Type.Size = New System.Drawing.Size(81, 23)
        Me.CheckBox_CommonRows_Data_Type.TabIndex = 11
        Me.CheckBox_CommonRows_Data_Type.Text = "License Type"
        Me.CheckBox_CommonRows_Data_Type.UseVisualStyleBackColor = True
        '
        'CheckBox_CommonRows_Data_Features
        '
        Me.CheckBox_CommonRows_Data_Features.Appearance = System.Windows.Forms.Appearance.Button
        Me.CheckBox_CommonRows_Data_Features.AutoSize = True
        Me.CheckBox_CommonRows_Data_Features.Location = New System.Drawing.Point(210, 61)
        Me.CheckBox_CommonRows_Data_Features.Name = "CheckBox_CommonRows_Data_Features"
        Me.CheckBox_CommonRows_Data_Features.Size = New System.Drawing.Size(58, 23)
        Me.CheckBox_CommonRows_Data_Features.TabIndex = 12
        Me.CheckBox_CommonRows_Data_Features.Text = "Features"
        Me.CheckBox_CommonRows_Data_Features.UseVisualStyleBackColor = True
        '
        'CheckBox_CommonRows_Data_Modules
        '
        Me.CheckBox_CommonRows_Data_Modules.Appearance = System.Windows.Forms.Appearance.Button
        Me.CheckBox_CommonRows_Data_Modules.AutoSize = True
        Me.CheckBox_CommonRows_Data_Modules.Location = New System.Drawing.Point(274, 61)
        Me.CheckBox_CommonRows_Data_Modules.Name = "CheckBox_CommonRows_Data_Modules"
        Me.CheckBox_CommonRows_Data_Modules.Size = New System.Drawing.Size(57, 23)
        Me.CheckBox_CommonRows_Data_Modules.TabIndex = 13
        Me.CheckBox_CommonRows_Data_Modules.Text = "Modules"
        Me.CheckBox_CommonRows_Data_Modules.UseVisualStyleBackColor = True
        '
        'CheckBox_CommonRows_Data_IssuedDate
        '
        Me.CheckBox_CommonRows_Data_IssuedDate.Appearance = System.Windows.Forms.Appearance.Button
        Me.CheckBox_CommonRows_Data_IssuedDate.AutoSize = True
        Me.CheckBox_CommonRows_Data_IssuedDate.Location = New System.Drawing.Point(3, 90)
        Me.CheckBox_CommonRows_Data_IssuedDate.Name = "CheckBox_CommonRows_Data_IssuedDate"
        Me.CheckBox_CommonRows_Data_IssuedDate.Size = New System.Drawing.Size(74, 23)
        Me.CheckBox_CommonRows_Data_IssuedDate.TabIndex = 5
        Me.CheckBox_CommonRows_Data_IssuedDate.Text = "Issued Date"
        Me.CheckBox_CommonRows_Data_IssuedDate.UseVisualStyleBackColor = True
        '
        'CheckBox_CommonRows_Data_ExpiryDate
        '
        Me.CheckBox_CommonRows_Data_ExpiryDate.Appearance = System.Windows.Forms.Appearance.Button
        Me.CheckBox_CommonRows_Data_ExpiryDate.AutoSize = True
        Me.CheckBox_CommonRows_Data_ExpiryDate.Location = New System.Drawing.Point(83, 90)
        Me.CheckBox_CommonRows_Data_ExpiryDate.Name = "CheckBox_CommonRows_Data_ExpiryDate"
        Me.CheckBox_CommonRows_Data_ExpiryDate.Size = New System.Drawing.Size(71, 23)
        Me.CheckBox_CommonRows_Data_ExpiryDate.TabIndex = 6
        Me.CheckBox_CommonRows_Data_ExpiryDate.Text = "Expiry Date"
        Me.CheckBox_CommonRows_Data_ExpiryDate.UseVisualStyleBackColor = True
        '
        'CheckBox_CommonRows_Data_Serial
        '
        Me.CheckBox_CommonRows_Data_Serial.Appearance = System.Windows.Forms.Appearance.Button
        Me.CheckBox_CommonRows_Data_Serial.AutoSize = True
        Me.CheckBox_CommonRows_Data_Serial.Location = New System.Drawing.Point(160, 90)
        Me.CheckBox_CommonRows_Data_Serial.Name = "CheckBox_CommonRows_Data_Serial"
        Me.CheckBox_CommonRows_Data_Serial.Size = New System.Drawing.Size(43, 23)
        Me.CheckBox_CommonRows_Data_Serial.TabIndex = 18
        Me.CheckBox_CommonRows_Data_Serial.Text = "Serial"
        Me.CheckBox_CommonRows_Data_Serial.UseVisualStyleBackColor = True
        '
        'CheckBox_CommonRows_Data_UUID
        '
        Me.CheckBox_CommonRows_Data_UUID.Appearance = System.Windows.Forms.Appearance.Button
        Me.CheckBox_CommonRows_Data_UUID.AutoSize = True
        Me.CheckBox_CommonRows_Data_UUID.Location = New System.Drawing.Point(209, 90)
        Me.CheckBox_CommonRows_Data_UUID.Name = "CheckBox_CommonRows_Data_UUID"
        Me.CheckBox_CommonRows_Data_UUID.Size = New System.Drawing.Size(44, 23)
        Me.CheckBox_CommonRows_Data_UUID.TabIndex = 19
        Me.CheckBox_CommonRows_Data_UUID.Text = "UUID"
        Me.CheckBox_CommonRows_Data_UUID.UseVisualStyleBackColor = True
        '
        'CheckBox_CommonRows_Data_ContractNumber
        '
        Me.CheckBox_CommonRows_Data_ContractNumber.Appearance = System.Windows.Forms.Appearance.Button
        Me.CheckBox_CommonRows_Data_ContractNumber.AutoSize = True
        Me.CheckBox_CommonRows_Data_ContractNumber.Location = New System.Drawing.Point(3, 119)
        Me.CheckBox_CommonRows_Data_ContractNumber.Name = "CheckBox_CommonRows_Data_ContractNumber"
        Me.CheckBox_CommonRows_Data_ContractNumber.Size = New System.Drawing.Size(97, 23)
        Me.CheckBox_CommonRows_Data_ContractNumber.TabIndex = 20
        Me.CheckBox_CommonRows_Data_ContractNumber.Text = "Contract Number"
        Me.CheckBox_CommonRows_Data_ContractNumber.UseVisualStyleBackColor = True
        '
        'CheckBox_CommonRows_Data_HardDriveFingerprints
        '
        Me.CheckBox_CommonRows_Data_HardDriveFingerprints.Appearance = System.Windows.Forms.Appearance.Button
        Me.CheckBox_CommonRows_Data_HardDriveFingerprints.AutoSize = True
        Me.CheckBox_CommonRows_Data_HardDriveFingerprints.Location = New System.Drawing.Point(106, 119)
        Me.CheckBox_CommonRows_Data_HardDriveFingerprints.Name = "CheckBox_CommonRows_Data_HardDriveFingerprints"
        Me.CheckBox_CommonRows_Data_HardDriveFingerprints.Size = New System.Drawing.Size(125, 23)
        Me.CheckBox_CommonRows_Data_HardDriveFingerprints.TabIndex = 21
        Me.CheckBox_CommonRows_Data_HardDriveFingerprints.Text = "Hard Drive Fingerprints"
        Me.CheckBox_CommonRows_Data_HardDriveFingerprints.UseVisualStyleBackColor = True
        '
        'CheckBox_CommonRows_Data_ComputerFingerprints
        '
        Me.CheckBox_CommonRows_Data_ComputerFingerprints.Appearance = System.Windows.Forms.Appearance.Button
        Me.CheckBox_CommonRows_Data_ComputerFingerprints.AutoSize = True
        Me.CheckBox_CommonRows_Data_ComputerFingerprints.Location = New System.Drawing.Point(3, 148)
        Me.CheckBox_CommonRows_Data_ComputerFingerprints.Name = "CheckBox_CommonRows_Data_ComputerFingerprints"
        Me.CheckBox_CommonRows_Data_ComputerFingerprints.Size = New System.Drawing.Size(114, 23)
        Me.CheckBox_CommonRows_Data_ComputerFingerprints.TabIndex = 22
        Me.CheckBox_CommonRows_Data_ComputerFingerprints.Text = "Computer Fingerprint"
        Me.CheckBox_CommonRows_Data_ComputerFingerprints.UseVisualStyleBackColor = True
        '
        'TabPage_Signature
        '
        Me.TabPage_Signature.Controls.Add(Me.FlowLayoutPanel4)
        Me.TabPage_Signature.Controls.Add(Me.FlowLayoutPanel_Signature_CommonRows)
        Me.TabPage_Signature.Location = New System.Drawing.Point(4, 22)
        Me.TabPage_Signature.Name = "TabPage_Signature"
        Me.TabPage_Signature.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage_Signature.Size = New System.Drawing.Size(351, 241)
        Me.TabPage_Signature.TabIndex = 1
        Me.TabPage_Signature.Text = "Signature"
        Me.TabPage_Signature.UseVisualStyleBackColor = True
        '
        'FlowLayoutPanel4
        '
        Me.FlowLayoutPanel4.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.FlowLayoutPanel4.BackColor = System.Drawing.Color.Silver
        Me.FlowLayoutPanel4.Controls.Add(Me.Button_CommonRows_Signature_All)
        Me.FlowLayoutPanel4.Controls.Add(Me.Button_CommonRows_Signature_None)
        Me.FlowLayoutPanel4.Location = New System.Drawing.Point(6, 6)
        Me.FlowLayoutPanel4.Name = "FlowLayoutPanel4"
        Me.FlowLayoutPanel4.Size = New System.Drawing.Size(339, 30)
        Me.FlowLayoutPanel4.TabIndex = 3
        '
        'Button_CommonRows_Signature_All
        '
        Me.Button_CommonRows_Signature_All.Location = New System.Drawing.Point(3, 3)
        Me.Button_CommonRows_Signature_All.Name = "Button_CommonRows_Signature_All"
        Me.Button_CommonRows_Signature_All.Size = New System.Drawing.Size(75, 23)
        Me.Button_CommonRows_Signature_All.TabIndex = 10
        Me.Button_CommonRows_Signature_All.Text = "All"
        Me.Button_CommonRows_Signature_All.UseVisualStyleBackColor = True
        '
        'Button_CommonRows_Signature_None
        '
        Me.Button_CommonRows_Signature_None.Location = New System.Drawing.Point(84, 3)
        Me.Button_CommonRows_Signature_None.Name = "Button_CommonRows_Signature_None"
        Me.Button_CommonRows_Signature_None.Size = New System.Drawing.Size(75, 23)
        Me.Button_CommonRows_Signature_None.TabIndex = 11
        Me.Button_CommonRows_Signature_None.Text = "None"
        Me.Button_CommonRows_Signature_None.UseVisualStyleBackColor = True
        '
        'FlowLayoutPanel_Signature_CommonRows
        '
        Me.FlowLayoutPanel_Signature_CommonRows.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.FlowLayoutPanel_Signature_CommonRows.Controls.Add(Me.CheckBox_CommonRows_Signature_KeySize)
        Me.FlowLayoutPanel_Signature_CommonRows.Controls.Add(Me.CheckBox_CommonRows_Signature_Algorithm)
        Me.FlowLayoutPanel_Signature_CommonRows.Controls.Add(Me.CheckBox_CommonRows_Signature_PublicKeyFingerprint)
        Me.FlowLayoutPanel_Signature_CommonRows.Controls.Add(Me.CheckBox_CommonRows_Signature_AddSignatureRow)
        Me.FlowLayoutPanel_Signature_CommonRows.Controls.Add(Me.CheckBox_CommonRows_Signature_Salt)
        Me.FlowLayoutPanel_Signature_CommonRows.Location = New System.Drawing.Point(6, 51)
        Me.FlowLayoutPanel_Signature_CommonRows.Name = "FlowLayoutPanel_Signature_CommonRows"
        Me.FlowLayoutPanel_Signature_CommonRows.Size = New System.Drawing.Size(339, 184)
        Me.FlowLayoutPanel_Signature_CommonRows.TabIndex = 0
        '
        'CheckBox_CommonRows_Signature_KeySize
        '
        Me.CheckBox_CommonRows_Signature_KeySize.Appearance = System.Windows.Forms.Appearance.Button
        Me.CheckBox_CommonRows_Signature_KeySize.AutoSize = True
        Me.CheckBox_CommonRows_Signature_KeySize.Location = New System.Drawing.Point(3, 3)
        Me.CheckBox_CommonRows_Signature_KeySize.Name = "CheckBox_CommonRows_Signature_KeySize"
        Me.CheckBox_CommonRows_Signature_KeySize.Size = New System.Drawing.Size(58, 23)
        Me.CheckBox_CommonRows_Signature_KeySize.TabIndex = 3
        Me.CheckBox_CommonRows_Signature_KeySize.Text = "Key Size"
        Me.CheckBox_CommonRows_Signature_KeySize.UseVisualStyleBackColor = True
        '
        'CheckBox_CommonRows_Signature_Algorithm
        '
        Me.CheckBox_CommonRows_Signature_Algorithm.Appearance = System.Windows.Forms.Appearance.Button
        Me.CheckBox_CommonRows_Signature_Algorithm.AutoSize = True
        Me.CheckBox_CommonRows_Signature_Algorithm.Location = New System.Drawing.Point(67, 3)
        Me.CheckBox_CommonRows_Signature_Algorithm.Name = "CheckBox_CommonRows_Signature_Algorithm"
        Me.CheckBox_CommonRows_Signature_Algorithm.Size = New System.Drawing.Size(60, 23)
        Me.CheckBox_CommonRows_Signature_Algorithm.TabIndex = 4
        Me.CheckBox_CommonRows_Signature_Algorithm.Text = "Algorithm"
        Me.CheckBox_CommonRows_Signature_Algorithm.UseVisualStyleBackColor = True
        '
        'CheckBox_CommonRows_Signature_PublicKeyFingerprint
        '
        Me.CheckBox_CommonRows_Signature_PublicKeyFingerprint.Appearance = System.Windows.Forms.Appearance.Button
        Me.CheckBox_CommonRows_Signature_PublicKeyFingerprint.AutoSize = True
        Me.CheckBox_CommonRows_Signature_PublicKeyFingerprint.Location = New System.Drawing.Point(133, 3)
        Me.CheckBox_CommonRows_Signature_PublicKeyFingerprint.Name = "CheckBox_CommonRows_Signature_PublicKeyFingerprint"
        Me.CheckBox_CommonRows_Signature_PublicKeyFingerprint.Size = New System.Drawing.Size(119, 23)
        Me.CheckBox_CommonRows_Signature_PublicKeyFingerprint.TabIndex = 5
        Me.CheckBox_CommonRows_Signature_PublicKeyFingerprint.Text = "Public Key Fingerprint"
        Me.CheckBox_CommonRows_Signature_PublicKeyFingerprint.UseVisualStyleBackColor = True
        '
        'CheckBox_CommonRows_Signature_AddSignatureRow
        '
        Me.CheckBox_CommonRows_Signature_AddSignatureRow.Appearance = System.Windows.Forms.Appearance.Button
        Me.CheckBox_CommonRows_Signature_AddSignatureRow.AutoSize = True
        Me.CheckBox_CommonRows_Signature_AddSignatureRow.Location = New System.Drawing.Point(3, 32)
        Me.CheckBox_CommonRows_Signature_AddSignatureRow.Name = "CheckBox_CommonRows_Signature_AddSignatureRow"
        Me.CheckBox_CommonRows_Signature_AddSignatureRow.Size = New System.Drawing.Size(109, 23)
        Me.CheckBox_CommonRows_Signature_AddSignatureRow.TabIndex = 28
        Me.CheckBox_CommonRows_Signature_AddSignatureRow.Text = "Add Signature Row"
        Me.CheckBox_CommonRows_Signature_AddSignatureRow.UseVisualStyleBackColor = True
        '
        'CheckBox_CommonRows_Signature_Salt
        '
        Me.CheckBox_CommonRows_Signature_Salt.Appearance = System.Windows.Forms.Appearance.Button
        Me.CheckBox_CommonRows_Signature_Salt.AutoSize = True
        Me.CheckBox_CommonRows_Signature_Salt.Location = New System.Drawing.Point(118, 32)
        Me.CheckBox_CommonRows_Signature_Salt.Name = "CheckBox_CommonRows_Signature_Salt"
        Me.CheckBox_CommonRows_Signature_Salt.Size = New System.Drawing.Size(35, 23)
        Me.CheckBox_CommonRows_Signature_Salt.TabIndex = 29
        Me.CheckBox_CommonRows_Signature_Salt.Text = "Salt"
        Me.CheckBox_CommonRows_Signature_Salt.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.Controls.Add(Me.TabControl_CommonRows)
        Me.Panel1.Location = New System.Drawing.Point(-1, 2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(365, 257)
        Me.Panel1.TabIndex = 1
        '
        'FormCommonRows
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(364, 259)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FormCommonRows"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Add Rows"
        Me.TabControl_CommonRows.ResumeLayout(False)
        Me.TabPage_Data.ResumeLayout(False)
        Me.FlowLayoutPanel3.ResumeLayout(False)
        Me.FlowLayoutPanel_Data_CommonRows.ResumeLayout(False)
        Me.FlowLayoutPanel_Data_CommonRows.PerformLayout()
        Me.TabPage_Signature.ResumeLayout(False)
        Me.FlowLayoutPanel4.ResumeLayout(False)
        Me.FlowLayoutPanel_Signature_CommonRows.ResumeLayout(False)
        Me.FlowLayoutPanel_Signature_CommonRows.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents TabControl_CommonRows As TabControl
    Friend WithEvents TabPage_Data As TabPage
    Friend WithEvents TabPage_Signature As TabPage
    Friend WithEvents Panel1 As Panel
    Friend WithEvents FlowLayoutPanel_Signature_CommonRows As FlowLayoutPanel
    Friend WithEvents CheckBox_CommonRows_Signature_KeySize As CheckBox
    Friend WithEvents CheckBox_CommonRows_Signature_Algorithm As CheckBox
    Friend WithEvents CheckBox_CommonRows_Signature_PublicKeyFingerprint As CheckBox
    Friend WithEvents FlowLayoutPanel_Data_CommonRows As FlowLayoutPanel
    Friend WithEvents CheckBox_CommonRows_Data_LicenseKey As CheckBox
    Friend WithEvents CheckBox_CommonRows_Data_Licensee As CheckBox
    Friend WithEvents CheckBox_CommonRows_Data_IssuedDate As CheckBox
    Friend WithEvents CheckBox_CommonRows_Data_ExpiryDate As CheckBox
    Friend WithEvents CheckBox_CommonRows_Data_Email As CheckBox
    Friend WithEvents CheckBox_CommonRows_Data_Address As CheckBox
    Friend WithEvents CheckBox_CommonRows_Data_Branch As CheckBox
    Friend WithEvents CheckBox_CommonRows_Data_Terminal As CheckBox
    Friend WithEvents CheckBox_CommonRows_Data_Type As CheckBox
    Friend WithEvents CheckBox_CommonRows_Data_Features As CheckBox
    Friend WithEvents CheckBox_CommonRows_Data_Modules As CheckBox
    Friend WithEvents CheckBox_CommonRows_Data_Product As CheckBox
    Friend WithEvents CheckBox_CommonRows_Data_LicenseCount As CheckBox
    Friend WithEvents CheckBox_CommonRows_Data_LicensesUsed As CheckBox
    Friend WithEvents CheckBox_CommonRows_Data_LicensesRemaining As CheckBox
    Friend WithEvents FlowLayoutPanel3 As FlowLayoutPanel
    Friend WithEvents FlowLayoutPanel4 As FlowLayoutPanel
    Friend WithEvents Button_CommonRows_Signature_All As Button
    Friend WithEvents Button_CommonRows_Signature_None As Button
    Friend WithEvents Button_CommonRows_Data_All As Button
    Friend WithEvents Button_CommonRows_Data_Noner As Button
    Friend WithEvents CheckBox_CommonRows_Data_Serial As CheckBox
    Friend WithEvents CheckBox_CommonRows_Data_UUID As CheckBox
    Friend WithEvents CheckBox_CommonRows_Data_ContractNumber As CheckBox
    Friend WithEvents CheckBox_CommonRows_Signature_AddSignatureRow As CheckBox
    Friend WithEvents CheckBox_CommonRows_Signature_Salt As CheckBox
    Friend WithEvents CheckBox_CommonRows_Data_HardDriveFingerprints As CheckBox
    Friend WithEvents CheckBox_CommonRows_Data_ComputerFingerprints As CheckBox
End Class
